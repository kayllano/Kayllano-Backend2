/*  

  Made By kayzu
  Base : Kayzu
  WhatsApp : wa.me/6289673462138
  Telegram : t.me/kayzu—MD
  Youtube : @Kayzu Hosting
  Buy no enc sung ketik sc di gb

  Channel : https://whatsapp.com/channel/0029VatjTeULo4hk0RJlly0V

  Copy Code?, Recode?, Rename?, Reupload?, Reseller? Taruh Credit Ya :D

*/

require('./len')
require('./lib/LenwyMenu')
const { WA_DEFAULT_EPHEMERAL, getAggregateVotesInPollMessage, generateWAMessageFromContent, proto, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, interactiveMessage, downloadContentFromMessage, areJidsSameUser, getContentType } = require("@whiskeysockets/baileys")
const fs = require('fs')
const util = require('util')
const chalk = require('chalk')
const os = require('os')
const axios = require('axios')
const fsx = require('fs-extra')
const crypto = require('crypto')
const ffmpeg = require('fluent-ffmpeg')
const moment = require('moment-timezone')
const { JSDOM } = require('jsdom')
const { color, bgcolor } = require('./lib/color')
const { ssweb } = require('./lib/ssweb')
const { quote } = require('./lib/quote')
const { uptotelegra } = require('./lib/upload')
const { Primbon } = require('scrape-primbon')
const { remini } = require('./lib/remini')
const { TelegraPh } = require('./lib/uploader')
const uploadImage = require('./lib/uploadImage')
const primbon = new Primbon()
const hxz = require('hxz-api')
const jsobfus = require('javascript-obfuscator')
const cheerio = require('cheerio')
const ytdl = require("ytdl-core")
const speed = require('performance-now')
const types = [ 'photo', 'video' ];
const { performance } = require('perf_hooks')
const { exec, spawn, execSync } = require("child_process")
const { mediafireDl } = require('./database/mediafire.js')
const { smsg, tanggal, getTime, formatp, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, parseMention, getRandom, getGroupAdmins } = require('./lib/myfunc')
const { FajarNews, BBCNews, metroNews, CNNNews, iNews, KumparanNews, TribunNews, DailyNews, DetikNews, OkezoneNews, CNBCNews, KompasNews, SindoNews, TempoNews, IndozoneNews, AntaraNews, RepublikaNews, VivaNews, KontanNews, MerdekaNews, KomikuSearch, AniPlanetSearch, KomikFoxSearch, KomikStationSearch, MangakuSearch, KiryuuSearch, KissMangaSearch, KlikMangaSearch, PalingMurah, LayarKaca21, AminoApps, Mangatoon, WAModsSearch, Emojis, CoronaInfo, JalanTikusMeme,Cerpen, Quotes, Couples, Darkjokes } = require("dhn-api");
const { addResponList, delResponList, isAlreadyResponList, isAlreadyResponListGroup, sendResponList, updateResponList, getDataResponList } = require('./lib/respon-list');
const { addRespons, checkRespons, deleteRespons } = require('./lib/respon')

const Ai4Chat = require('./scrape/lenwy/Ai4Chat.js')
const iLenwy = require('./scrape/lenwy/iLenwy.js')
const alosehat = require('./scrape/lenwy/alosehat.js') 
const LenwyLiga = require('./scrape/lenwy/LenLiga.js')
const LenSurah = require('./scrape/lenwy/LenSurah.js')
const LenwyJadwalSholat = require('./scrape/lenwy/LenJadwal.js')
const LenwyMp3 = require('./scrape/lenwy/Mp3.js')
const LenwyMp4 = require('./scrape/lenwy/SLMP4.js')
const GSM = require('./scrape/lenwy/Gsmarena.js')
const Zerochan = require('./scrape/lenwy/Zerochan.js')
const Morse = require('./scrape/lenwy/Morse.js')
const LenIp = require('./scrape/lenwy/Ip.js')
const CatboxMoe = require('./scrape/lenwy/CatboxMoe.js')
const Obat = require('./scrape/lenwy/Obat.js')
const FFW = require('./scrape/lenwy/FFW.js')
const An1 = require('./scrape/lenwy/An1.js')
const Lenread = require('./scrape/lenwy/caribuku.js')
const RuangMovie = require('./scrape/lenwy/film.js')
const PlayStore = require('./scrape/lenwy/playstore.js')
const Webtoons = require('./scrape/lenwy/webtoons.js')
const Steam = require('./scrape/lenwy/steam.js')
const Guardian = require('./scrape/lenwy/GuardianTales.js')
const WikiMedia = require('./scrape/lenwy/wikimedia.js')
const LirikLagu = require('./scrape/lenwy/lirik.js')
const IMDB = require('./scrape/lenwy/imdb.js')
const LenwyCH = require('./scrape/lenwy/LenCH.js')
const Yimg = require('./scrape/lenwy/yahooimg.js')
const samehadaku = require('./scrape/lenwy/samehada.js')
const cinema = require('./scrape/lenwy/cineplex.js')
const moewalls = require('./scrape/lenwy/moewall.js')
const wManga = require('./scrape/lenwy/westmanga.js')
// Membaca Seluruh Database
global.db.data = JSON.parse(fs.readFileSync('./src/database.json'))
if (global.db.data) global.db.data = {
users: {},
chats: {},
game: {},
database: {},
settings: {},
setting: {},
others: {},
sticker: {},
...(global.db.data || {})
}

let kuismath = db.data.game.math = []
let tebakgambar = db.data.game.tebakgambar = []
let tebakkata = db.data.game.tebakkata = []
let caklontong = db.data.game.lontong = []
let caklontong_desk = db.data.game.lontong_desk = []
let tebakkalimat = db.data.game.kalimat = []
let tebaklirik = db.data.game.lirik = []
let tebaktebakan = db.data.game.tebakan = []
let db_respon_list = JSON.parse(fs.readFileSync('./database/list-message.json'));
let reminders = {};

const authorr = "6289673462138"
const yts = require('./scrape/yt-search')
const { ytSearch } = require('./scrape/yt')
const thumbnail = fs.readFileSync ('./data/image/Kay.jpeg')
const thumb = fs.readFileSync ('./data/image/Kay.jpeg')
const kalimage = fs.readFileSync ('./data/image/Kay.jpeg')
const { antispam } = require('./lib/antispam')
const pengguna = JSON.parse(fs.readFileSync('./database/user.json'))
const owner = JSON.parse(fs.readFileSync('./premium.json'))
const author = JSON.parse(fs.readFileSync('./author.json'))
const ntilink = JSON.parse(fs.readFileSync("./lib/antilink.json"))
const chatbot = JSON.parse(fs.readFileSync("./lib/chatbot.json"))
const antidel = JSON.parse(fs.readFileSync("./lib/antidel.json"))
const banned = JSON.parse(fs.readFileSync('./data/ban/banned.json'))
const imagenya = JSON.parse(fs.readFileSync('./database/Lenwytesti.json'))
const contacts = JSON.parse(fs.readFileSync("./database/contacts.json"))

// Get Database
const isContacts = contacts.includes(m.sender)

module.exports = lenwy = async (lenwy, m, chatUpdate, store) => {
 try {
var body = ( m.mtype === 'conversation' ? m.message.conversation : m.mtype === 'imageMessage' ? m.message.imageMessage.caption : m.mtype === 'videoMessage' ? m.message.videoMessage.caption : m.mtype === 'extendedTextMessage' ? m.message.extendedTextMessage.text : m.mtype === 'buttonsResponseMessage' ? m.message.buttonsResponseMessage.selectedButtonId : m.mtype === 'listResponseMessage' ? m.message.listResponseMessage.singleSelectReply.selectedRowId : m.mtype === 'InteractiveResponseMessage' ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson)?.id : m.mtype === 'templateButtonReplyMessage' ? m.message.templateButtonReplyMessage.selectedId : m.mtype === 'messageContextInfo' ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.message.InteractiveResponseMessage.NativeFlowResponseMessage || m.text : '');
var budy = (typeof m.text == 'string' ? m.text : '')
var prefix = prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "" : prefa ?? global.prefix


const isCmd = body.startsWith(prefix)
const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
//Kalau Mau Single Prefix Kamu Ganti Command Diatas Pakai Ini : const command = body.slice(1).trim().split(/ +/).shift().toLowerCase()


const args = body.trim().split(/ +/).slice(1)
const full_args = body.replace(command, '').slice(1).trim()
const spychat = body.replace().slice().trim()
const pushname = m.pushName || "No Name"
const text = q = args.join(" ")
const { type, quotedMsg, mentioned, now, fromMe } = m
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const isMedia = /image|video|sticker|audio/.test(mime)
const from = mek.key.remoteJid
const botNumber = await lenwy.decodeJid(lenwy.user.id)
const isCreator = [botNumber, ...author].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const isPrem = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
const groupMetadata = m.isGroup ? await lenwy.groupMetadata(from).catch(e => {}) : ''
const groupName = m.isGroup ? groupMetadata.subject : ''
const participants = m.isGroup ? await groupMetadata.participants : ''
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : ''
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
const AntiLink = m.isGroup ? ntilink.includes(from) : false 
const ChatBot = m.isGroup ? chatbot.includes(from) : false 
const autodelete = from && isCmd ? antidel.includes(from) : false 
const isBan = banned.includes(m.sender)
const isUser = pengguna.includes(m.sender)
const content = JSON.stringify(m.message)
const numberQuery = text.replace(new RegExp("[()+-/ +/]", "gi"), "") + "@s.whatsapp.net"
const mentionByTag = m.mtype == "extendedTextMessage" && m.message.extendedTextMessage.contextInfo != null ? m.message.extendedTextMessage.contextInfo.mentionedJid : []
const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')
const salam = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('a')
const qtod = m.quoted? "true":"false"
const more = String.fromCharCode(0)
const readmore = more.repeat(4281)

const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
        const wib = moment.tz('Asia/Jakarta').format('HH : mm : ss')
        const wit = moment.tz('Asia/Jayapura').format('HH : mm : ss')
        const wita = moment.tz('Asia/Makassar').format('HH : mm : ss')

        const time2 = moment().tz('Asia/Jakarta').format('HH:mm:ss')
        if(time2 < "23:59:00"){
        var ucapanWaktu = 'Selamat Malam'
        }
        if(time2 < "15:00:00"){
        var ucapanWaktu = 'Selamat Petang'
        }
        if(time2 < "18:00:00"){
        var ucapanWaktu = 'Selamat Sore'
        }
        if(time2 < "13:00:00"){
        var ucapanWaktu = 'Selamat Siang'
        }
        if(time2 < "10:00:00"){
        var ucapanWaktu = 'Selamat Pagi'
        }
        if(time2 < "05:00:00"){
        var ucapanWaktu = 'Selamat Subuh'
        }
        if(time2 < "03:00:00"){
        var ucapanWaktu = 'Selamat Tengah Malam'
        }
        
        if (!lenwy.public) {
if (!m.key.fromMe && !isPrem) return
}

const cap = 'LEN'
try {
pplu = await lenwy.profilePictureUrl(anu.id, 'image')
} catch {
pplu = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}
const len = {
            key: {
                participant: `0@s.whatsapp.net`,
                ...(m.chat ? {
                    remoteJid: `status@broadcast`
                } : {})
            },
            message: {
                "contactMessage": {
                    'displayName': `${pushname}`,
                    'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;KayOffc,;;;\nFN: KayOffc V2.2\nitem1.TEL;waid=${m.sender.split("@")[0]}:+${m.sender.split("@")[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
                    'jpegThumbnail': pplu,
                    thumbnail: pplu,
                    sendEphemeral: true
                }   
            }
        }

const len2 = {
    key: {
        fromMe: false,
        participant: `0@s.whatsapp.net`,
        ...(m.chat ? {
            remoteJid: "status@broadcast"
        } : {})
    },
    message: {
        "extendedTextMessage": {
            "text": ucapanWaktu,
            "title": `KayzuMD`,
            "thumbnailUrl": pplu
        }
    }
}

const lenwyreply = (teks) => {
lenwy.sendMessage(from, { text: teks, contextInfo:{"externalAdReply": {"title": `This Bot KayzuMD`,"body": `Hai ${pushname} Jangan Spam Ya`, "previewType": "PHOTO","thumbnail": thumb,"sourceUrl": `https://whatsapp.com/channel/0029VatjTeULo4hk0RJlly0V`}}}, { quoted: len })}
// Tanpa ContextInfo : lenwy.sendMessage(from, { text: teks, }, { quoted: len })}

const onlygc = () => {} 

// Tanpa Auto Chat : const onlygc = () => {} 

try {
            let isNumber = x => typeof x === 'number' && !isNaN(x)
            let limitUser = global.LenwySet.free
            let coinUser = global.LenwySet.coin
            let staminaUser = global.LenwySet.stamina
            let kekuatanUser = global.LenwySet.kekuatan
            let tahanUser = global.LenwySet.tahan
            let user = global.db.data.users[m.sender]
            if (typeof user !== 'object') global.db.data.users[m.sender] = {}
            if (user) {
                if (!isNumber(user.afkTime)) user.afkTime = -1
                if (!('afkReason' in user)) user.afkReason = ''
                if (!isNumber(user.limit)) user.limit = limitUser
                if (!isNumber(user.coin)) user.coin = coinUser
                if (!isNumber(user.stamina)) user.stamina = staminaUser  
                if (!isNumber(user.kekuatan)) user.kekuatan = kekuatanUser 
                if (!isNumber(user.tahan)) user.tahan = tahanUser 
                if (!isNumber(user.level)) user.level = 0
                if (!('autolevelup' in user)) user.autolevelup = true
            } else global.db.data.users[m.sender] = {
                afkTime: -1,
                afkReason: '',
                limit: limitUser,
                coin: coinUser,
                stamina: staminaUser,
                kekuatan: kekuatanUser,
                tahan: tahanUser,
                level: 0,
                autolevelup: true
            }
            let chats = global.db.data.chats[m.chat]
            if (typeof chats !== 'object') global.db.data.chats[m.chat] = {}
            if (chats) {
                if (!('mute' in chats)) chats.mute = false
                if (!('wlcm' in chats)) chats.wlcm = true
                if (!('antitoxic' in chats)) chats.antitoxic = false
                if (!('antilink' in chats)) chats.antilink = false
                if (!('antilinkyt' in chats)) chats.antilinkyt = false
                if (!('antilinktt' in chats)) chats.antilinktt = false
                if (!('antivirtex' in chats)) chats.antivirtex = true
                if (!('antipanel' in chats)) chats.antipanel = false
                if (!('antilinkv2' in chats)) chats.antilinkv2 = false
                if (!('antiwame' in chats)) chats.antiwame = false
                if (!('notification' in chats)) chats.notification = {}
            } else global.db.data.chats[m.chat] = {
                mute: false,
                wlcm: true,
                antitoxic: false,
                antilink: false,
                antilinkyt: false,
                antilinktt: false,
                antivirtex: true,
                antipanel: false,
                antiwame: false,
                antilinkv2: false,
                notification: {
                     status: false,
                     text_left: '',
                     text_welcome:''
                  }
            }
            let setting = global.db.data.settings[botNumber]
            if (typeof setting !== 'object') global.db.data.settings[botNumber] = {}
            if (setting) {
                if (!isNumber(setting.status)) setting.status = 0
                if (!('autobio' in setting)) setting.autobio = false
                if (!('autoread' in setting)) setting.autoread = false
            } else global.db.data.settings[botNumber] = {
                status: 0,
                autobio: false,
                autoread: false
            }

        } catch (err) {
            console.error(err)
        }

let cron = require('node-cron')
        cron.schedule('02 12 * * *', () => {
            let user = Object.keys(global.db.data.users)
            let limitUser = global.LenwySet.free
            for (let jid of user) global.db.data.users[jid].limit = limitUser
            console.log('Reseted Limit')
        }, {
            scheduled: true,
            timezone: "Asia/Jakarta"
        })

const totalfitur = () =>{
            var mytext = fs.readFileSync("./lenwy.js").toString()
            var numUpper = (mytext.match(/case '/g) || []).length
            return numUpper
        }

if(m.mtype === "interactiveResponseMessage"){  
            let msg = m.message[m.mtype]  || m.msg
            if(msg.nativeFlowResponseMessage  && !m.isBot  ){ 
                let { id } = JSON.parse(msg.nativeFlowResponseMessage.paramsJson) || {}  
                if(id){
                    let emit_msg = { 
                        key : { ...m.key } , // SET RANDOME MESSAGE ID  
                        message:{ extendedTextMessage : { text : id } } ,
                        pushName : m.pushName,
                        messageTimestamp  : m.messageTimestamp || 754785898978
                    }
                    return lenwy.ev.emit("messages.upsert" , { messages : [ emit_msg ] ,  type : "notify"})
                }
            }
        }        

function cwr(tMatch, tWr, wrReq) {
    let tLose = tMatch * (100 - tWr) / 100;
    let seratusPersen = tLose * (100 / (100 - wrReq));
    let final = seratusPersen - tMatch;
    return Math.round(final);
  } 

function LenTime(duration) {
var milliseconds = parseInt((duration % 1000) / 100),
seconds = Math.floor((duration / 1000) % 60),
minutes = Math.floor((duration / (1000 * 60)) % 60),
hours = Math.floor((duration / (1000 * 60 * 60)) % 24)
hours = (hours < 10) ? "0" + hours : hours
minutes = (minutes < 10) ? "0" + minutes : minutes
seconds = (seconds < 10) ? "0" + seconds : seconds

return hours + " Jam " + minutes + " Menit " + seconds + " Detik"
}                 
        
function generateRandomPassword() {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
  const length = 10;
  let password = '';
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    password += characters[randomIndex];
  }
  return password;
}

async function jarak(dari, ke) {
    let html = (await axios(`https://www.google.com/search?q=${encodeURIComponent('jarak ' + dari + ' ke ' + ke)}&hl=id`)).data
    let $ = cheerio.load(html), obj = {}
    let img = html.split("var s=\'")?.[1]?.split("\'")?.[0]
    obj.img = /^data:.*?\/.*?;base64,/i.test(img) ? Buffer.from(img.split`,` [1], 'base64') : ''
    obj.desc = $('div.BNeawe.deIvCb.AP7Wnd').text()?.trim()
    return obj
}

async function createImage(url) {
  const { imageMessage } = await generateWAMessageContent({
    image: {url}}, {upload: lenwy.waUploadToServer});
  return imageMessage;
}

function pinterest(querry){
    return new Promise(async(resolve,reject) => {
         axios.get('https://id.pinterest.com/search/pins/?autologin=true&q=' + querry, {
            headers: {
            "cookie" : "_auth=1; _b=\"AVna7S1p7l1C5I9u0+nR3YzijpvXOPc6d09SyCzO+DcwpersQH36SmGiYfymBKhZcGg=\"; _pinterest_sess=TWc9PSZHamJOZ0JobUFiSEpSN3Z4a2NsMk9wZ3gxL1NSc2k2NkFLaUw5bVY5cXR5alZHR0gxY2h2MVZDZlNQalNpUUJFRVR5L3NlYy9JZkthekp3bHo5bXFuaFZzVHJFMnkrR3lTbm56U3YvQXBBTW96VUgzVUhuK1Z4VURGKzczUi9hNHdDeTJ5Y2pBTmxhc2owZ2hkSGlDemtUSnYvVXh5dDNkaDN3TjZCTk8ycTdHRHVsOFg2b2NQWCtpOWxqeDNjNkk3cS85MkhhSklSb0hwTnZvZVFyZmJEUllwbG9UVnpCYVNTRzZxOXNJcmduOVc4aURtM3NtRFo3STlmWjJvSjlWTU5ITzg0VUg1NGhOTEZzME9SNFNhVWJRWjRJK3pGMFA4Q3UvcHBnWHdaYXZpa2FUNkx6Z3RNQjEzTFJEOHZoaHRvazc1c1UrYlRuUmdKcDg3ZEY4cjNtZlBLRTRBZjNYK0lPTXZJTzQ5dU8ybDdVS015bWJKT0tjTWYyRlBzclpiamdsNmtpeUZnRjlwVGJXUmdOMXdTUkFHRWloVjBMR0JlTE5YcmhxVHdoNzFHbDZ0YmFHZ1VLQXU1QnpkM1FqUTNMTnhYb3VKeDVGbnhNSkdkNXFSMXQybjRGL3pyZXRLR0ZTc0xHZ0JvbTJCNnAzQzE0cW1WTndIK0trY05HV1gxS09NRktadnFCSDR2YzBoWmRiUGZiWXFQNjcwWmZhaDZQRm1UbzNxc21pV1p5WDlabm1UWGQzanc1SGlrZXB1bDVDWXQvUis3elN2SVFDbm1DSVE5Z0d4YW1sa2hsSkZJb1h0MTFpck5BdDR0d0lZOW1Pa2RDVzNySWpXWmUwOUFhQmFSVUpaOFQ3WlhOQldNMkExeDIvMjZHeXdnNjdMYWdiQUhUSEFBUlhUVTdBMThRRmh1ekJMYWZ2YTJkNlg0cmFCdnU2WEpwcXlPOVZYcGNhNkZDd051S3lGZmo0eHV0ZE42NW8xRm5aRWpoQnNKNnNlSGFad1MzOHNkdWtER0xQTFN5Z3lmRERsZnZWWE5CZEJneVRlMDd2VmNPMjloK0g5eCswZUVJTS9CRkFweHc5RUh6K1JocGN6clc1JmZtL3JhRE1sc0NMTFlpMVErRGtPcllvTGdldz0=; _ir=0"
        }
            }).then(({ data }) => {
        const $ = cheerio.load(data)
        const result = [];
        const hasil = [];
         $('div > a').get().map(b => {
        const link = $(b).find('img').attr('src')
            result.push(link)
        });
        result.forEach(v => {
         if(v == undefined) return
         hasil.push(v.replace(/230/g,'730'))
            })
            hasil.shift();
        resolve(hasil)
        })
    })
}

function sort(property, ascending = true) {
  if (property) return (...args) => args[ascending & 1][property] - args[!ascending & 1][property]
  else return (...args) => args[ascending & 1] - args[!ascending & 1]
}

function toNumber(property, _default = 0) {
  if (property) return (a, i, b) => {
    return {...b[i], [property]: a[property] === undefined ? _default : a[property]}
  }
  else return a => a === undefined ? _default : a
}

function enumGetKey(a) {
  return a.jid
}

function pickRandom(list) {
return list[Math.floor(Math.random() * list.length)]
}

if (m.sender.startsWith('212')) return lenwy.updateBlockStatus(m.sender, 'block')

if (m.message) {
if (global.db.data.settings[botNumber].autoread) {
lenwy.readMessages([m.key])
}
}

if (command) {
if (!isCreator && !m.isGroup) return onlygc()
}

if (spychat) {
if (!isCreator && !m.isGroup) return
const { color } = require('./lib/color')
const moment = require("moment-timezone")
let levelling = require('./lib/levelling')
        let user = global.db.data.users[m.sender]
        if (!user.autolevelup) return !0
        let before = user.level * 1
        while (levelling.canLevelUp(user.level, user.exp, global.multiplier)) user.level++
        if (before !== user.level) {
            let chating = `🥳 Congratulations ${pushname}, you have leveled up!
*${before}* -> *${user.level}*
Use *Profile* To Check`
            lenwyreply(chating)
            console.log(color(chating, 'pink'))
        }
    }

const downloadMp3 = async (Link) => {
try {
await ytdl.getInfo(Link)
let mp3File = getRandom('.mp3')
console.log(color('Download Audio With ytdl-core'))
ytdl(Link, { filter: 'audioonly' })
.pipe(fs.createWriteStream(mp3File))
.on('finish', async () => {
await lenwy.sendMessage(from, { audio: fs.readFileSync(mp3File), mimetype: 'audio/mpeg' }, { quoted: m })
fs.unlinkSync(mp3File)
})
} catch (err) {
lenwyreply(`${err}`)
}
}

function parseMention(text = '') {
return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net')
}

const downloadMp4 = async (Link) => {
try {
await ytdl.getInfo(Link)
let mp4File = getRandom('.mp4')
console.log(color('Download Video With ytdl-core'))
let nana = ytdl(Link)
.pipe(fs.createWriteStream(mp4File))
.on('finish', async () => {
await lenwy.sendMessage(from, { video: fs.readFileSync(mp4File), gifPlayback: false }, { quoted: m })
fs.unlinkSync(`./${mp4File}`)
})
} catch (err) {
lenwyreply(`${err}`)
}
}

async function LenwyLD () {
var leni = [
"*𖣘 Hello Im kayzu*",
"*メ Author : kayzu*",
"*ム Waiting results...*",
]
let { key } = await lenwy.sendMessage(from, {text: '*𖣘 Loading*'},  { quoted: len })

for (let i = 0; i < leni.length; i++) {
await sleep(200)
await lenwy.sendMessage(from, {text: leni[i], edit: key }, { quoted: len });
}
}

if (autodelete) {
lenwy.sendMessage(m.chat, { delete: m.key })
}

if (m.isBaileys && m.fromMe) {
          lenwyreply(`*Bot Lain Terdeteksi*\n\n*Bot Akan Di Keluarkan, Karena Admin Mengaktifkan Anti Bot*`)
    await lenwy.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
}

const listcolor = ['red','green','yellow','blue','magenta','cyan','white']
const randomcolor = listcolor[Math.floor(Math.random() * listcolor.length)]
if (m.message) {
lenwy.sendPresenceUpdate(from)
console.log(chalk.yellow.bgCyan.bold(botname), color(`⨠ Pesan`, `${randomcolor}`), color(`Dari`, `${randomcolor}`), color(`${pushname}`, `${randomcolor}`), color(` :`, `${randomcolor}`), color(`${body}`, `white`))
}

if (isCmd && !isUser) {
pengguna.push(sender)
fs.writeFileSync('./database/user.json', JSON.stringify(pengguna, null, 2))
}

if (m.isGroup && isAlreadyResponList(m.chat, body.toLowerCase(), db_respon_list)) {
var get_data_respon = getDataResponList(m.chat, body.toLowerCase(), db_respon_list)
if (get_data_respon.isImage === false) {
lenwy.sendMessage(m.chat, { text: sendResponList(m.chat, body.toLowerCase(), db_respon_list) }, {
quoted: m
})
} else {
lenwy.sendMessage(m.chat, { image: await getBuffer(get_data_respon.image_url), caption: get_data_respon.response }, {
quoted: m
})
}
}

if (db.data.chats[m.chat].lenwy_antitoxic) {
const isToxic = /(ewe|bangsad|mmk|koncol|puki|kojtol|kintil|momok|nigga|ajg|ewean|yatim|anjing|kontol|memek|bangsat|babi|goblok|goblog|kntl|pepek|ppk|ngentod|ngentd|ngntd|kentod|gblk|asu|jembut|memek|yapit|entot|puqi|kntd|bgst|anjg|anj|fuck|hitam|ireng|jawir|gay|asw|ktl|ngentot|ngewe|bokep|bkp)/i;
    if (!m.isGroup) return
    const isAntiToxic = isToxic.exec(m.text)
    if (isAntiToxic && !isCreator) {
    lenwy.sendMessage(m.chat, { delete: m.key })
    await lenwy.sendMessage(m.chat, { audio: fs.readFileSync('./mp3/toxic.mp3'), mimetype: 'audio/mpeg', ptt: true, fileLength: 88738}, { quoted: len })
    }}

 if (db.data.chats[m.chat].antispam) {
if (m.isGroup && m.message && antispam.isFiltered(from)) {
console.log(`[SPAM]`, color(moment(m.messageTimestamp * 100).format('DD/MM/YYYY HH:mm:ss'), 'yellow'), color(`${command} [${args.length}]`), 'from', color(m.pushName))
return await lenwy.sendMessage(m.chat, { delete: m.key })
}}   

// Anti Link
if (db.data.chats[m.chat].lenwy_antigc) {
            if (budy.match(`chat.whatsapp.com`)) {
                let gclink = (`https://chat.whatsapp.com/` + await lenwy.groupInviteCode(m.chat))
                let isLinkThisGc = new RegExp(gclink, 'i')
                let isgclink = isLinkThisGc.test(m.text)
                if (isgclink) return lenwyreply(`*Eh Ternyata Link Group Ini*`)
                if (isAdmins) return lenwyreply(`*Ehh Halo Admin*`)
                if (isCreator) return lenwyreply(`*Ehh Halo Owner*`)
                lenwy.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
            }
        }
        if (db.data.chats[m.chat].lenwy_antigc2) {
            if (budy.match(`chat.whatsapp.com`)) {
                lenwyreply(`Anti Link Gc Whatsapp*\n*Kamu Terdeteksi Mengirim Link Group*`)
                if (!isBotAdmins) return lenwyreply(mess.botAdmin)
                let gclink = (`https://chat.whatsapp.com/` + await lenwy.groupInviteCode(m.chat))
                let isLinkThisGc = new RegExp(gclink, 'i')
                let isgclink = isLinkThisGc.test(m.text)
                if (isgclink) return lenwyreply(`*Eh Ternyata Link Group Ini*`)
                if (isAdmins) return lenwyreply(`*Ehh Halo Admin*`)
                if (isCreator) return lenwyreply(`*Ehh Halo Owner*`)
                lenwy.sendMessage(m.chat, { delete: m.key })
            }
        }

        if (db.data.chats[m.chat].lenwy_antiwame) {
            if (budy.includes('https://wa.me') || budy.includes('wa.me') || budy.includes('Https://wa.me') || budy.includes('Wa.me') ) {
                lenwyreply(`Anti Wame Whatsapp*\n*Kamu Terdeteksi Mengirim Chat Wame*`)
                if (!isBotAdmins) return lenwyreply(mess.botAdmin)
                let gclink = (`https://chat.whatsapp.com/` + await lenwy.groupInviteCode(m.chat))
                let isLinkThisGc = new RegExp(gclink, 'i')
                let isgclink = isLinkThisGc.test(m.text)
                if (isgclink) return lenwyreply(`*Eh Ternyata Link Group Ini*`)
                if (isAdmins) return lenwyreply(`*Ehh Halo Admin*`)
                if (isCreator) return lenwyreply(`*Ehh Halo Owner*`)
                lenwy.sendMessage(m.chat, { delete: m.key })
            }
        }

        if (db.data.chats[m.chat].lenwy_antilink) {
            if (budy.includes('https:') || budy.includes('http') || budy.includes('Https:') || budy.includes('Http') ) {
                lenwyreply(`Anti Link Whatsapp*\n*Kamu Terdeteksi Mengirim Link*`)
                if (!isBotAdmins) return lenwyreply(mess.botAdmin)
                let gclink = (`https://chat.whatsapp.com/` + await lenwy.groupInviteCode(m.chat))
                let isLinkThisGc = new RegExp(gclink, 'i')
                let isgclink = isLinkThisGc.test(m.text)
                if (isgclink) return lenwyreply(`*Eh Ternyata Link Group Ini*`)
                if (isAdmins) return lenwyreply(`*Ehh Halo Admin*`)
                if (isCreator) return lenwyreply(`*Ehh Halo Owner*`)
                lenwy.sendMessage(m.chat, { delete: m.key })
            }
        }

        if (db.data.chats[m.chat].lenwy_antipanel) {
            if (budy.includes('PANEL') || budy.includes('Panel') || budy.includes('panel') || budy.includes('pnel') ) {
                lenwyreply(`*Anti Promosi Panel*\n*Kamu Terdeteksi Mengirim Promosi Panel*`)
                if (!isBotAdmins) return lenwyreply(mess.botAdmin)
                let gclink = (`https://chat.whatsapp.com/` + await lenwy.groupInviteCode(m.chat))
                let isLinkThisGc = new RegExp(gclink, 'i')
                let isgclink = isLinkThisGc.test(m.text)
                if (isgclink) return lenwyreply(`*Eh Ternyata Link Group Ini*`)
                if (isAdmins) return lenwyreply(`*Ehh Halo Admin*`)
                if (isCreator) return lenwyreply(`*Ehh Halo Owner*`)
                lenwy.sendMessage(m.chat, { delete: m.key })
            }
        }

        if (db.data.chats[m.chat].lenwy_antitiktok) {
            if (budy.match(`https://vt.tiktok.com`)) {
                lenwyreply(`*Anti Link Tiktok*\n*Kamu Terdeteksi Mengirim Link Tiktok*`)
                if (!isBotAdmins) return lenwyreply(mess.botAdmin)
                let gclink = (`https://chat.whatsapp.com/` + await lenwy.groupInviteCode(m.chat))
                let isLinkThisGc = new RegExp(gclink, 'i')
                let isgclink = isLinkThisGc.test(m.text)
                if (isgclink) return lenwyreply(`*Eh Ternyata Link Group Ini*`)
                if (isAdmins) return lenwyreply(`*Ehh Halo Admin*`)
                if (isCreator) return lenwyreply(`*Ehh Halo Owner*`)
                lenwy.sendMessage(m.chat, { delete: m.key })
            }
        }

        if (db.data.chats[m.chat].lenwy_antiyoutube) {
            if (budy.match(`https://youtu.be`)) {
                lenwyreply(`*Anti Link Youtube*\n*Kamu Terdeteksi Mengirim Link Youtube*`)
                if (!isBotAdmins) return lenwyreply(mess.botAdmin)
                let gclink = (`https://chat.whatsapp.com/` + await lenwy.groupInviteCode(m.chat))
                let isLinkThisGc = new RegExp(gclink, 'i')
                let isgclink = isLinkThisGc.test(m.text)
                if (isgclink) return lenwyreply(`*Eh Ternyata Link Group Ini*`)
                if (isAdmins) return lenwyreply(`*Ehh Halo Admin*`)
                if (isCreator) return lenwyreply(`*Ehh Halo Owner*`)
                lenwy.sendMessage(m.chat, { delete: m.key })
            }
        }

                if (db.data.chats[m.chat].lenwy_antich) {
            if (budy.includes('https://whatsapp.com/channel/') || budy.includes('https://whatsapp.com/channel/') || budy.includes('https://whatsapp.com/channel/') || budy.includes('https://whatsapp.com/channel/') ) {
                lenwyreply(`*Anti Channel Whatsapp*\n*Kamu Terdeteksi Mengirim Link Channel Wa*`)
                if (!isBotAdmins) return lenwyreply(mess.botAdmin)
                let gclink = (`https://chat.whatsapp.com/` + await lenwy.groupInviteCode(m.chat))
                let isLinkThisGc = new RegExp(gclink, 'i')
                let isgclink = isLinkThisGc.test(m.text)
                if (isAdmins) return lenwyreply(`*Follow Saluran KayzuMD Yaa*`)
                if (isCreator) return lenwyreply(`*Follow Saluran KayzuMD Yaa*`)
                lenwy.sendMessage(m.chat, { delete: m.key })
            }
        }

let list = []
for (let i of owner) {
list.push({
displayName: await lenwy.getName(i + '@s.whatsapp.net'),
vcard: `BEGIN:VCARD\n
VERSION:3.0\n
N:${await lenwy.getName(i + '@s.whatsapp.net')}\n
FN:${await lenwy.getName(i + '@s.whatsapp.net')}\n
item1.TEL;waid=${i}:${i}\n
item1.X-ABLabel:Ponsel\n
item2.EMAIL;type=INTERNET:Fakekayzu@gmail.com\n
item2.X-ABLabel:Email\n
item3.URL:Youtube : kayzuMD\n
item3.X-ABLabel:Grup WangSaff\n
item4.ADR:;;Mars Area 51;;;;\n
item4.X-ABLabel:Region\n
END:VCARD`
})
}

// Respon Cmd with media
if (isMedia && m.msg.fileSha256 && (m.msg.fileSha256.toString('base64') in global.db.data.sticker)) {
let hash = global.db.data.sticker[m.msg.fileSha256.toString('base64')]
let { text, mentionedJid } = hash
let messages = await generateWAMessage(from, { text: text, mentions: mentionedJid }, {
userJid: lenwy.user.id,
quoted : m.quoted && m.quoted.fakeObj
})
messages.key.fromMe = areJidsSameUser(m.sender, lenwy.user.id)
messages.key.id = m.key.id
messages.pushName = m.pushName
if (m.isGroup) messages.participant = m.sender
let msg = {
...chatUpdate,
messages: [proto.WebMessageInfo.fromObject(messages)],
type: 'append'
}
lenwy.ev.emit('messages.upsert', msg)
}

if (budy.startsWith('©️')) {
try {
return lenwyreply(JSON.stringify(eval(`${args.join(' ')}`),null,'\t'))
} catch (e) {
lenwyreply(e)
}
}

async function sendGeekzMessage(chatId, message, options = {}){
    let generate = await generateWAMessage(chatId, message, options)
    let type2 = getContentType(generate.message)
    if ('contextInfo' in options) generate.message[type2].contextInfo = options?.contextInfo
    if ('contextInfo' in message) generate.message[type2].contextInfo = message?.contextInfo
    return await lenwy.relayMessage(chatId, generate.message, { messageId: generate.key.id })
}

async function obfus(query) {
return new Promise((resolve, reject) => {
try {
const obfuscationResult = jsobfus.obfuscate(query,
{
compact: false,
controlFlowFlattening: true,
controlFlowFlatteningThreshold: 1,
numbersToExpressions: true,
simplify: true, 
stringArrayShuffle: true,
splitStrings: true,
stringArrayThreshold: 1
}
);
const result = {
status: 200,
author: `Lenwy`,
result: obfuscationResult.getObfuscatedCode()
}
resolve(result)
} catch (e) {
reject(e)
}
})
}

async function aigpt(prompt) {
  try {
   const response = await axios.get("https://tools.revesery.com/ai/ai.php?query=" + prompt, {
     headers: {
      'Accept': '*/*',
      'Content-Type': 'application/json',
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.9999.999 Safari/537.36'
      }
    });
    const res = response.data
    const evaled = res.result
    /*
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
lenwyreply(evaled)
*/
  } catch (error) {
  console.error(error)
  }
}

async function ttslide(text) {
    let response = await axios.get(`https://dlpanda.com/id?url=${text}&token=G7eRpMaa`)
    const html = response.data
    const $ = cheerio.load(html)
    let asd = []
    let imgSrc = []
    let creator = 'Jikarinka'
    $('div.col-md-12 > img').each((index,
        element) => {
        imgSrc.push($(element).attr('src'))
    })
    asd.push({
        creator,
        imgSrc
    })
    let fix = imgSrc.map((e,
        i) => {
        return {
            img: e,
            creator: creator[i]
        }
    })
    for (let i of asd) {
        return i
    }
}

async function cai(query) {
        let token = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkVqYmxXUlVCWERJX0dDOTJCa2N1YyJ9.eyJnaXZlbl9uYW1lIjoiUkNTIiwiZmFtaWx5X25hbWUiOiJYWiIsIm5pY2tuYW1lIjoicmNzeHo2NDkiLCJuYW1lIjoiUkNTIFhaIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FDZzhvY0lYbGpRdW11SWlQTjdwLUoxUk1HNjZ0ODZzTzJhMG9DcW93RTlZVDFzaj1zOTYtYyIsImxvY2FsZSI6ImlkIiwidXBkYXRlZF9hdCI6IjIwMjMtMTEtMDVUMTQ6NTM6NDkuNjM0WiIsImVtYWlsIjoicmNzeHo2NDlAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImlzcyI6Imh0dHBzOi8vY2hhcmFjdGVyLWFpLnVzLmF1dGgwLmNvbS8iLCJhdWQiOiJkeUQzZ0UyODFNcWdJU0c3RnVJWFloTDJXRWtucVp6diIsImlhdCI6MTY5OTE5NjAzNCwiZXhwIjoxNzAyNzk2MDM0LCJzdWIiOiJnb29nbGUtb2F1dGgyfDExMDY5MjA2MTkzMTI0MTU4NTgwNSIsInNpZCI6IjVhaklfSlRJeFBZWGpzU0piWmdzRnQ4MXhaTHRhRERyIiwibm9uY2UiOiJUQzE0V2xvMVNGSmlkVU5FWVVSbFJXb3dTV3RJU25acVRtVTRVR3hoUldReU0xQm5Rbk0yYjAwNWJ3PT0ifQ.jduu283Aycw7GwUL270EkwoF71bINRrLnFzVJGpoG9uOO4A-jxtZ07XRZIr_t4lT_gt2N19BWXg7SGxRR_coFbCJLfyUHLzxx6ZaDGMqUnCPhJ6WXBHABsTsqnlQIJs1sQPJyLKw01-FU5FoB8atW3OIyjt0nJayJtMSm4NzKkGR2gBWZSNR3FIqX7r4NY_wUSc-1Za50FaMiLg3XdGkfE59wxs_NdlxxdPVVG4G4uKBWQCIy6ofRDnnb22Wfw1knt8yXMjGfq8RtSsAkGMmjp_KVICSRDCqy0cCOtUdmih5LCRyEQagIRBl90SP753C7ehiue_ucidCYh9XrxP7HQ";
    return new Promise(async (resolve, reject) => {
    try {
        const request = await axios({
            method: "POST",
            url: "https://beta.character.ai/chat/streaming/",
            body: JSON.stringify(query),
            headers: {
            "authorization": "Token " + token,
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
            client: "Token " + token
            }
            })

        if (request.status() === 200) {
            const response = await JSON.parse(request);
            const replies = response.replies;

            const messages = []

            for (let i = 0; i < replies.length; i++) {
                lenwy.sendMessage(i, {text: `${text}`}, {quoted:m})
            }
            resolve(i);
            }
        } catch (error) {
      reject(error);
    }
})
}

function setReminder(time, reminder, sender) {
    let reminderTime = time * 60000;

    let reminderDate = new Date(Date.now() + reminderTime);

    reminders[sender] = {
        time: reminderTime,
        message: reminder,
        reminderDate: reminderDate
    };

    setTimeout(() => {
        delete reminders[sender];
    }, reminderTime);
}

async function tiktoks(query) {
  return new Promise(async (resolve, reject) => {
    try {
      const response = await axios({
        method: 'POST',
        url: 'https://tikwm.com/api/feed/search',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'Cookie': 'current_language=en',
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
        },
        data: {
          keywords: query,
          count: 50,
          cursor: 0,
          HD: 1
        }
      });
      const videos = response.data.data.videos;
      if (videos.length === 0) {
        reject("*Tidak Ada Video Yang Ditemukan*");
      } else {
        const gywee = Math.floor(Math.random() * videos.length);
        const videorndm = videos[gywee]; 

        const result = {
          title: videorndm.title,
          cover: videorndm.cover,
          origin_cover: videorndm.origin_cover,
          no_watermark: videorndm.play,
          watermark: videorndm.wmplay,
          music: videorndm.music
        };
        resolve(result);
      }
    } catch (error) {
      reject(error);
    }
  });
}

async function tiktok2(query) {
  return new Promise(async (resolve, reject) => {
    try {
    const encodedParams = new URLSearchParams();
encodedParams.set('url', query);
encodedParams.set('hd', '1');

      const response = await axios({
        method: 'POST',
        url: 'https://tikwm.com/api/',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'Cookie': 'current_language=en',
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
        },
        data: encodedParams
      });
      const videos = response.data.data;
        const result = {
          title: videos.title,
          cover: videos.cover,
          origin_cover: videos.origin_cover,
          no_watermark: videos.play,
          watermark: videos.wmplay,
          music: videos.music
        };
        resolve(result);
    } catch (error) {
      reject(error);
    }
  });
}

const clean = (data) => {
  let regex = /(<([^>]+)>)/gi;
  data = data.replace(/(<br?\s?\/>)/gi, " \n");
  return data.replace(regex, "");
};

async function shortener(url) {
  return url;
}

async function tiktok11(query) {
  let response = await axios("https://lovetik.com/api/ajax/search", {
    method: "POST",
    data: new URLSearchParams(Object.entries({ query })),
  });

  result = {};

  result.creator = "YNTKTS";
  result.title = clean(response.data.desc);
  result.author = clean(response.data.author);
  result.nowm = await shortener(
    (response.data.links[0].a || "").replace("https", "http")
  );
  result.watermark = await shortener(
    (response.data.links[1].a || "").replace("https", "http")
  );
  result.audio = await shortener(
    (response.data.links[2].a || "").replace("https", "http")
  );
  result.thumbnail = await shortener(response.data.cover);
  return result;
}

async function filterValidImages(images, limit) {
  const validImages = [];
  for (const image of images) {
    if (await isImageURL(image)) {
      validImages.push(image);
      if (validImages.length >= limit) {
        break // Hentikan jika sudah mencapai jumlah gambar yang diminta
      }
    }
  }
  return validImages;
}

async function isImageURL(url) {
  try {
    const res = await fetch(url, { method: 'HEAD' });
    const contentType = res.headers.get('content-type');
    return contentType && contentType.startsWith('image'); // Memeriksa apakah tipe file adalah gambar
  } catch (error) {
    return false; // Jika terjadi kesalahan dalam memeriksa URL, mengembalikan false
  }
}

var createSerial = (size) => {
return crypto.randomBytes(size).toString('hex').slice(0, size)
}
try {
ppuser = await lenwy.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}
ppnyauser = await getBuffer(ppuser)

if (kuismath.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = kuismath[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 await lenwyreply(`*𖣐 Kuis Matematika*\n*𖣐 Jawaban Benar*\n*Ingin Bermain Lagi? Silakan Ketik Math Mode*`)
 delete kuismath[m.sender.split('@')[0]]
} else lenwyreply('*𖣐 Jawaban Salah!*')
}

if (tebakgambar.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebakgambar[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 lenwy.sendMessage(m.chat, { image: ppnyauser, caption: `*𖣐 Tebak Gambar*\n*𖣐 Jawaban Benar*\n*𖣐 Ingin Bermain Lagi? Silahkan Ketik Tebak Gambar*`}, {quoted:m})
 delete tebakgambar[m.sender.split('@')[0]]
} else lenwyreply('*𖣐 Jawaban Salah!*')
}

if (tebakkata.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebakkata[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 lenwy.sendMessage(m.chat, { image: ppnyauser, caption: `*𖣐 Tebak Kata*\n*𖣐 Jawaban Benar*\n*𖣐 Ingin Bermain Lagi? Silahkan Ketik Tebak Kata*`}, {quoted:m})  
 delete tebakkata[m.sender.split('@')[0]]
} else lenwyreply('*𖣐 Jawaban Salah!*')
}

if (caklontong.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = caklontong[m.sender.split('@')[0]]
deskripsi = caklontong_desk[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 lenwy.sendMessage(m.chat, { image: ppnyauser, caption: `*𖣐 Tebak Lontong*\n*𖣐 Jawaban Benar*\n*𖣐 Ingin Bermain Lagi? Silahkan Ketik Tebak Lontong*`}, {quoted:m}) 
 delete caklontong[m.sender.split('@')[0]]
delete caklontong_desk[m.sender.split('@')[0]]
} else lenwyreply('*𖣐 Jawaban Salah!*')
}

if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebakkalimat[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 lenwy.sendMessage(m.chat, { image: ppnyauser, caption: `*𖣐 Tebak Kalimat*\n*𖣐 Jawaban Benar*\n*𖣐 Ingin Bermain Lagi? Silahkan Ketik Tebak Kalimat*`}, {quoted:m}) 
 delete tebakkalimat[m.sender.split('@')[0]]
} else lenwyreply('*𖣐 Jawaban Salah!*')
}

if (tebaklirik.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebaklirik[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 lenwy.sendMessage(m.chat, { image: ppnyauser, caption: `*𖣐 Tebak Lirik*\n*𖣐 Jawaban Benar*\n*𖣐 Ingin Bermain Lagi? Silahkan Ketik Tebak Lirik*`}, {quoted:m}) 
 delete tebaklirik[m.sender.split('@')[0]]
} else lenwyreply('*𖣐 Jawaban Salah!*')
}

if (tebaktebakan.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
kuis = true
jawaban = tebaktebakan[m.sender.split('@')[0]]
if (budy.toLowerCase() == jawaban) {
 lenwy.sendMessage(m.chat, { image: ppnyauser, caption: `*𖣐 Tebak Tebakan*\n*𖣐 Jawaban Benar*\n*𖣐 Ingin Bermain Lagi? Silahkan Ketik Tebak Tebakan*`}, {quoted:m}) 
 delete tebaktebakan[m.sender.split('@')[0]]
} else lenwyreply('*𖣐 Jawaban Salah!*')
}

//TicTacToe
this.game = this.game ? this.game : {}
let room = Object.values(this.game).find(room => room.id && room.game && room.state && room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender) && room.state == 'PLAYING')
if (room) {
let ok
let isWin = !1
let isTie = !1
let isSurrender = !1
// lenwyreply(`[DEBUG]\n${parseInt(m.text)}`)
if (!/^([1-9]|(me)?nyerah|surr?ender|off|skip)$/i.test(m.text)) return
isSurrender = !/^[1-9]$/.test(m.text)
if (m.sender !== room.game.currentTurn) { // nek wayahku
if (!isSurrender) return !0
}
if (!isSurrender && 1 > (ok = room.game.turn(m.sender === room.game.playerO, parseInt(m.text) - 1))) {
lenwyreply({
'-3': 'Game telah berakhir',
'-2': 'Invalid',
'-1': 'Posisi Invalid',
0: 'Posisi Invalid',
}[ok])
return !0
}
if (m.sender === room.game.winner) isWin = true
else if (room.game.board === 511) isTie = true
let arr = room.game.render().map(v => {
return {
X: '❌',
O: '⭕',
1: '1️⃣',
2: '2️⃣',
3: '3️⃣',
4: '4️⃣',
5: '5️⃣',
6: '6️⃣',
7: '7️⃣',
8: '8️⃣',
9: '9️⃣',
}[v]
})
if (isSurrender) {
room.game._currentTurn = m.sender === room.game.playerX
isWin = true
}
let winner = isSurrender ? room.game.currentTurn : room.game.winner
let str = `Room ID: ${room.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

${isWin ? `@${winner.split('@')[0]} Menang!` : isTie ? `Game berakhir` : `Giliran ${['❌', '⭕'][1 * room.game._currentTurn]} (@${room.game.currentTurn.split('@')[0]})`}
❌: @${room.game.playerX.split('@')[0]}
⭕: @${room.game.playerO.split('@')[0]}

Ketik *nyerah* untuk menyerah dan mengakui kekalahan`
if ((room.game._currentTurn ^ isSurrender ? room.x : room.o) !== from)
room[room.game._currentTurn ^ isSurrender ? 'x' : 'o'] = from
if (room.x !== room.o) await lenwy.sendText(room.x, str, m, { mentions: parseMention(str) } )
await lenwy.sendText(room.o, str, m, { mentions: parseMention(str) } )
if (isTie || isWin) {
delete this.game[room.id]
}
}

//Suit PvP
this.suit = this.suit ? this.suit : {}
let roof = Object.values(this.suit).find(roof => roof.id && roof.status && [roof.p, roof.p2].includes(m.sender))
if (roof) {
let win = ''
let tie = false
if (m.sender == roof.p2 && /^(acc(ept)?|terima|gas|oke?|tolak|gamau|nanti|ga(k.)?bisa|y)/i.test(m.text) && m.isGroup && roof.status == 'wait') {
if (/^(tolak|gamau|nanti|n|ga(k.)?bisa)/i.test(m.text)) {
lenwy.sendTextWithMentions(from, `@${roof.p2.split`@`[0]} menolak suit, suit dibatalkan`, m)
delete this.suit[roof.id]
return !0
}
roof.status = 'play'
roof.asal = from
clearTimeout(roof.waktu)
//delete roof[roof.id].waktu
lenwy.sendText(from, `Suit telah dikirimkan ke chat

@${roof.p.split`@`[0]} dan 
@${roof.p2.split`@`[0]}

Silahkan pilih suit di chat masing"
klik https://wa.me/${botNumber.split`@`[0]}`, m, { mentions: [roof.p, roof.p2] })
if (!roof.pilih) lenwy.sendText(roof.p, `Silahkan pilih \n\nBatu🗿\nKertas📄\nGunting✂️`, m)
if (!roof.pilih2) lenwy.sendText(roof.p2, `Silahkan pilih \n\nBatu🗿\nKertas📄\nGunting✂️`, m)
roof.waktu_milih = setTimeout(() => {
if (!roof.pilih && !roof.pilih2) lenwy.sendText(from, `Kedua pemain tidak niat main,\nSuit dibatalkan`)
else if (!roof.pilih || !roof.pilih2) {
win = !roof.pilih ? roof.p2 : roof.p
lenwy.sendTextWithMentions(from, `@${(roof.pilih ? roof.p2 : roof.p).split`@`[0]} tidak memilih suit, game berakhir`, m)
}
delete this.suit[roof.id]
return !0
}, roof.timeout)
}
let jwb = m.sender == roof.p
let jwb2 = m.sender == roof.p2
let g = /gunting/i
let b = /batu/i
let k = /kertas/i
let reg = /^(gunting|batu|kertas)/i
if (jwb && reg.test(m.text) && !roof.pilih && !m.isGroup) {
roof.pilih = reg.exec(m.text.toLowerCase())[0]
roof.text = m.text
lenwyreply(`Kamu telah memilih ${m.text} ${!roof.pilih2 ? `\n\nMenunggu lawan memilih` : ''}`)
if (!roof.pilih2) lenwy.sendText(roof.p2, '_Lawan sudah memilih_\nSekarang giliran kamu', 0)
}
if (jwb2 && reg.test(m.text) && !roof.pilih2 && !m.isGroup) {
roof.pilih2 = reg.exec(m.text.toLowerCase())[0]
roof.text2 = m.text
lenwyreply(`Kamu telah memilih ${m.text} ${!roof.pilih ? `\n\nMenunggu lawan memilih` : ''}`)
if (!roof.pilih) lenwy.sendText(roof.p, '_Lawan sudah memilih_\nSekarang giliran kamu', 0)
}
let stage = roof.pilih
let stage2 = roof.pilih2
if (roof.pilih && roof.pilih2) {
clearTimeout(roof.waktu_milih)
if (b.test(stage) && g.test(stage2)) win = roof.p
else if (b.test(stage) && k.test(stage2)) win = roof.p2
else if (g.test(stage) && k.test(stage2)) win = roof.p
else if (g.test(stage) && b.test(stage2)) win = roof.p2
else if (k.test(stage) && b.test(stage2)) win = roof.p
else if (k.test(stage) && g.test(stage2)) win = roof.p2
else if (stage == stage2) tie = true
lenwy.sendText(roof.asal, `_*Hasil Suit*_${tie ? '\nSERI' : ''}

@${roof.p.split`@`[0]} (${roof.text}) ${tie ? '' : roof.p == win ? ` Menang \n` : ` Kalah \n`}
@${roof.p2.split`@`[0]} (${roof.text2}) ${tie ? '' : roof.p2 == win ? ` Menang \n` : ` Kalah \n`}
`.trim(), m, { mentions: [roof.p, roof.p2] })
delete this.suit[roof.id]
}
}
let mentionUser = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])]
for (let jid of mentionUser) {
let user = global.db.data.users[jid]
if (!user) continue
let afkTime = user.afkTime
if (!afkTime || afkTime < 0) continue
let reason = user.afkReason || ''
lenwyreply(`*Jangan Tag Dia!*
*Dia Sedang AFK* ${reason ? '𝗗𝗲𝗻𝗴𝗮𝗻 𝗔𝗹𝗮𝘀𝗮𝗻 : ' + reason : 'tanpa alasan*'}
🕒 *Selama : ${clockString(new Date - afkTime)}*
`.trim())
}
if (global.db.data.users[m.sender].afkTime > -1) {
let user = global.db.data.users[m.sender]
lenwyreply(`
*${pushname} Kembali Dari Afk*\n${user.afkReason ? '*Dengan Alasan :  ' + user.afkReason : ''}*\n🕒 *Selama : ${clockString(new Date - user.afkTime)}*
`.trim())
user.afkTime = -1
user.afkReason = ''
}

switch(command) { 
/*case 'menu': 
case 'mainmenu': {
if (isBan) return lenwyreply('*Kamu Di Ban Owner*')
LenwyLD()
await sleep(1000)
let anu = `*Hello Im Kayzu*
*WhatsApp Bot To Solve Your Problems*
*Please Dont Call Bots Or Your May Get Blocked*

*Info Bot*  
 *⨠ Creator : ${authorr}*
 *⨠ Runtime : ${runtime(process.uptime())}*
 *⨠ Mode Bot : ${lenwy.public ? `Public Mode` : `Self Mode`}*

📃 *Info User*
 *⨠ Name : ${pushname}*
 *⨠ Number : ${m.sender.split('@')[0]}*
 *⨠ Status : ${isCreator ? '女 Creator' : isPrem ? '*Premium' : "🏷️ User"}*

*メ Keterangan*
 *⨠ Help : Menunjukkan Panduan*
 *⨠ Menu : Menunjukkan Simple Menu*
 *⨠ Allmenu : Menunjukkan Semua Menu*

*Menu Bot*
 *⨠* 𝗦𝘁𝗼𝗿𝗲
 *⨠* 𝗔𝗶𝗠𝗲𝗻𝘂
 *⨠* 𝗙𝘂𝗻𝗺𝗲𝗻𝘂
 *⨠* 𝗚𝗮𝗺𝗲𝗺𝗲𝗻𝘂
 *⨠* 𝗚𝗿𝗼𝘂𝗽𝗺𝗲𝗻𝘂
 *⨠* 𝗕𝗲𝗿𝗶𝘁𝗮𝗺𝗲𝗻𝘂
 *⨠* 𝗥𝗮𝗻𝗱𝗼𝗺𝗺𝗲𝗻𝘂
 *⨠* 𝗗𝗼𝘄𝗻𝗺𝗲𝗻𝘂
 *⨠* 𝗪𝗲𝗲𝗯𝘀𝗺𝗲𝗻𝘂
 *⨠* 𝗜𝘀𝗹𝗮𝗺𝗶𝗺𝗲𝗻𝘂
 *⨠* 𝗤𝘂𝗼𝘁𝗲𝘀𝗺𝗲𝗻𝘂
 *⨠* 𝗦𝗲𝗮𝗿𝗰𝗵𝗺𝗲𝗻𝘂
 *⨠* 𝗖𝗼𝗻𝘃𝗲𝗿𝘁𝗺𝗲𝗻𝘂
 *⨠* 𝗙𝗮𝘃𝗺𝗲𝗻𝘂
 *⨠* 𝗣𝘂𝘀𝗵𝗺𝗲𝗻𝘂
 *⨠* 𝗔𝗻𝘁𝗶𝗺𝗲𝗻𝘂
 *⨠* 𝗣𝗮𝗻𝗲𝗹𝗺𝗲𝗻𝘂

𝗞𝗮𝗹𝗼 𝗔𝗱𝗮 𝗬𝗮𝗻𝗴 𝗘𝗿𝗼𝗿 𝗖𝗵𝗮𝘁 𝗢𝘄𝗻𝗲𝗿 𝗬𝗮
`
lenwy.sendMessage(m.chat, {
    video: fs.readFileSync('./data/video/menu.mp4'),
    caption: anu,
    gifPlayback: true,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true, 
        title: `${ucapanWaktu} ${pushname}`,
        body: "Lenwy",
        thumbnailUrl: "https://files.catbox.moe/cnsw60.jpg",
        sourceUrl: "https://whatsapp.com/channel/0029VatjTeULo4hk0RJlly0V",
        mediaType: 1,
        renderLargerThumbnail: false
      }
    }
   })
}
break*/ 

case 'allmenu': {
  if (isBan) return lenwyreply('*Kamu Di Ban Owner*');
  LenwyLD();
  await sleep(1000);
  
  // Ambil waktu saat ini
  let date = new Date().toLocaleDateString('id-ID', { 
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });

  // Menyesuaikan waktu dengan zona waktu Indonesia
  let time = new Date().toLocaleTimeString('id-ID', { 
    hour: '2-digit', 
    minute: '2-digit', 
    second: '2-digit', 
    timeZone: 'Asia/Jakarta' 
  });

let soundPath = './mp3/menu.mp3'; // Path file suara
lenwy.sendMessage(m.chat, { audio: { url: soundPath }, mimetype: 'audio/mpeg', ptt: true }, { quoted: m });
  
  let anu = `
┈──────────────────────⏣
           ⏤͟͟͞͞ᵡ    *I N F O   B O T*   ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⛩️• Bot Name : KiromiMD
   ⛩️• Creator : ${authorr}
   ⛩️• Mode Bot : ${lenwy.public ? `Public Mode` : `Self Mode`}
   ⛩️• Runtime : ${runtime(process.uptime())}
   ⛩️• Date : ${date}
   ⛩️• Time : ${time}
┈──────────────────────⏣
           ⏤͟͟͞͞ᵡ    *R U L E S*   ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⛩️• *ᴅɪʟᴀʀᴀɴɢ ᴍᴇɴᴇʟᴘᴏɴ ɴᴏ ʙᴏᴛ*
   ⛩️• *ᴅɪʟᴀʀᴀɴɢ ᴊᴏᴍᴏᴋ*
   ⛩️• *ᴅɪʟᴀʀᴀɴɢ sᴘᴀᴍ, ᴡᴀᴊɪʙ ᴊᴇᴅᴀ*
   ⛩️• *ᴅɪʟᴀʀᴀɴɢ 𝟷𝟾+*
   ⛩️• *ᴅɪʟᴀʀᴀɴɢ ʙᴜʟʟʏɪɴɢ*
┈──────────────────────⏣
           ⏤͟͟͞͞ᵡ    M E N U   B O T   ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Aimenu  
   ⏣  •Animemenu
   ⏣ • Antimenu  
   ⏣ • Asupan  
   ⏣ • Beritamenu  
   ⏣ • Credit
   ⏣ • Convertmenu  
   ⏣ • Dowloadmenu  
   ⏣ • Ephoto
   ⏣ • Favmenu  
   ⏣ • Funmenu  
   ⏣ • Gamemenu  
   ⏣ • Generateimageai  
   ⏣ • Groupmenu    
   ⏣ • Nonton
   ⏣ • Ownermenu    
   ⏣ • Premiummenu  
   ⏣ • Pushmenu  
   ⏣ • Quotesmenu  
   ⏣ • Randomimage  
   ⏣ • Randomanime
   ⏣ • Randommenu  
   ⏣ • Rules  
   ⏣ • Rpg
   ⏣ • Store  
   ⏣ • Sertifikat
   ⏣ • Searchmenu  
   ⏣ • Weebsmenu  
   ⏣ • Islamimenu
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ    S T O R E   ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Addlist  
   ⏣ • Addtesti  
   ⏣ • Bagi
   ⏣ • Deltesti  
   ⏣ • Dellist  
   ⏣ • Done  
   ⏣ • Formatjp  
   ⏣ • Formatneed  
   ⏣ • Freerekber  
   ⏣ • Kali
   ⏣ • Kurang
   ⏣ • List  
   ⏣ • Listtesti  
   ⏣ • Rules  
   ⏣ • Tambah
   ⏣ • Testimoni  
   ⏣ • Updatelist
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ    A I   ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • AI  
   ⏣ • Ask  
   ⏣ • Bing  
   ⏣ • ChatGPT  
   ⏣ • ChatGPTGo  
   ⏣ • Gemini  
   ⏣ • GPT-4  
   ⏣ • MetaAI  
   ⏣ • MuslimAI  
   ⏣ • OpenAI  
   ⏣ • Translate  
   ⏣ • YouSearch
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ    F U N   ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Apakah  
   ⏣ • Bagaimanakah  
   ⏣ • Bisakah  
   ⏣ • CekCantik  
   ⏣ • CekGantengCewek  
   ⏣ • CantikCewek  
   ⏣ • Dare  
   ⏣ • GantengCewek  
   ⏣ • Kapankah  
   ⏣ • Stalkyoutube
   ⏣ • Stalkff
   ⏣ • Stalktele
   ⏣ • Stalkmc
   ⏣ • Stalktiktok
   ⏣ • stalktiktok2
   ⏣ • Stalkig
   ⏣ • Rate  
   ⏣ • Truth
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ    ＮＯＮＴＯＮＴＶ   ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Globaltv
   ⏣ • Gtv
   ⏣ • Rcti
   ⏣ • Mnctv
   ⏣ • Trans7
   ⏣ • Transtv
   ⏣ • Antv
   ⏣ • Sctv
   ⏣ • Nettv
   ⏣ • Net
   ⏣ • Indosiar
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ    G A M E   ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Asah Otak  
   ⏣ • Family 100  
   ⏣ • Kuismath Easy  
   ⏣ • Kuismath Extreme  
   ⏣ • Kuismath Hard  
   ⏣ • Kuismath Impossible  
   ⏣ • Kuismath Impossible 2  
   ⏣ • Kuismath Medium  
   ⏣ • Kuismath Noob  
   ⏣ • Siapakah Aku  
   ⏣ • Susun Kata  
   ⏣ • Tebak Bendera  
   ⏣ • Tebak Kalimat  
   ⏣ • Tebak Karakter FF  
   ⏣ • Tebak Kimia  
   ⏣ • Tebak Kata  
   ⏣ • Tebak Lirik  
   ⏣ • Tebak Lontong  
   ⏣ • Tebak Logo  
   ⏣ • Tebak Warna  
   ⏣ • Tebaktebakan  
   ⏣ • Tekateki  
   ⏣ • TTC
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ    ＧＥＮＥＲＡＴＥ ＩＭＡＧＥ   ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • BingIMG  
   ⏣ • Dalle  
   ⏣ • FluXImage  
   ⏣ • Stably
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ    ＳＥＲＴＩＦＩＫＡＴ   ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Stkbaik
   ⏣ • Stkcantik
   ⏣ • Stkganteng
   ⏣ • Stkhitam
   ⏣ • Stkmiskin
   ⏣ • Stkkaya
   ⏣ • Stkmarah
   ⏣ • Stksabar
   ⏣ • Stksakiti
   ⏣ • Stkkeren
   ⏣ • Stkmisterius
   ⏣ • Stksombong
   ⏣ • Stksantai
   ⏣ • Stkgila
   ⏣ • Stklucu
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ    ＧＲＯＵＰ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Add (62xxx)  
   ⏣ • Antilinkgc On/Off  
   ⏣ • Antitoxic On/Off  
   ⏣ • Bcgc (Teksnya)  
   ⏣ • Brat (Buat Sticker Chat)  
   ⏣ • Editdesk (Teksnya)  
   ⏣ • Editgroup Close/Open  
   ⏣ • Editinfo On/Off  
   ⏣ • Editsubjek (Teksnya)  
   ⏣ • Group Close/Open  
   ⏣ • Hidetag (Teksnya)  
   ⏣ • Inspect (Linknya)  
   ⏣ • Join (Linknya)  
   ⏣ • duar (62xxx)  
   ⏣ • Linkgroup  
   ⏣ • Promote (62xxx)  
   ⏣ • Reportbug  
   ⏣ • Resetlinkgc  
   ⏣ • Saran  
   ⏣ • Sendlinkgc (62xxx)  
   ⏣ • Share (Teksnya)  
   ⏣ • Tagall (Teks)  
   ⏣ • Timeclose  
   ⏣ • Timeopen  
   ⏣ • Totag
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ  ＢＥＲＩＴＡ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Dailynews  
   ⏣ • Detiknews  
   ⏣ • Inews  
   ⏣ • Kompasnews  
   ⏣ • Kontan
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ  ＲＡＮＤＯＭ ＩＭＡＧＥ   ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Bluearchive  
   ⏣ • hijab  
   ⏣ • indo  
   ⏣ • japanese  
   ⏣ • korean  
   ⏣ • malay  
   ⏣ • randomgirl  
   ⏣ • randomboy  
   ⏣ • thai  
   ⏣ • vietnamese  
   ⏣ • aesthetic  
   ⏣ • chinese  
   ⏣ • pubg  
   ⏣ • antiwork  
   ⏣ • blackpink2  
   ⏣ • cosplay  
   ⏣ • cat  
   ⏣ • doggo  
   ⏣ • justina  
   ⏣ • kayes  
   ⏣ • bike  
   ⏣ • boneka  
   ⏣ • kpop  
   ⏣ • notnot  
   ⏣ • car  
   ⏣ • rose  
   ⏣ • ryujin  
   ⏣ • ulzangboy  
   ⏣ • ulzanggirl  
   ⏣ • mobilelegend
   ⏣ • Neko
   ⏣ • Waifu
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ  ＲＡＮＤＯＭ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ •  About  
   ⏣ •  Aboutkay  
   ⏣ •  Acak  
   ⏣ •  Admin  
   ⏣ •  Afk  
   ⏣ •  Calendar  
   ⏣ •  Calender  
   ⏣ •  Confess  
   ⏣ •  Couple  
   ⏣ •  Cwr  
   ⏣ •  Faktaunik  
   ⏣ •  Friend  
   ⏣ •  Getname  
   ⏣ •  Getpic  
   ⏣ •  Ip  
   ⏣ •  Kata Ucapan  
   ⏣ •  Kalender  
   ⏣ •  Menfess  
   ⏣ •  Meme  
   ⏣ •  Morse  
   ⏣ •  Nickff  
   ⏣ •  Owner  
   ⏣ •  Pantun  
   ⏣ •  Prayer  
   ⏣ •  Prank  
   ⏣ •  Puisi  
   ⏣ •  Qc  
   ⏣ •  Qckode  
   ⏣ •  Readmore  
   ⏣ •  Reminder  
   ⏣ •  Kuliner
   ⏣ •  Resep  
   ⏣ •  Services  
   ⏣ •  Sholatsubuh  
   ⏣ •  Sholawaktu  
   ⏣ •  Sticker  
   ⏣ •  Time  
   ⏣ •  Tagsw  
   ⏣ •  Toqr    
   ⏣ •  Weather  
   ⏣ •  Wangy  
   ⏣ •  Emojimix  
   ⏣ •  Cekasalmember  
   ⏣ •  Cekkontol  
   ⏣ •  Cekmemek  
   ⏣ •  Cekkhodam  
   ⏣ •  Assalamualaikum
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ  ＤＯＷＮＬＯＡＤ   ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ •  Capcut  
   ⏣ • Fbdl  
   ⏣ • Fb2  
   ⏣ • Gdrive  
   ⏣ • Igdl  
   ⏣ • Igslide  
   ⏣ • Likee  
   ⏣ • Mediafire  
   ⏣ • Pinvt  
   ⏣ • Pinslide  
   ⏣ • Searchyt  
   ⏣ • Snackvideo  
   ⏣ • Snackvid  
   ⏣ • Spotify   
   ⏣ • Spotifytrack  
   ⏣ • Tiktok  
   ⏣ • Tiktok2  
   ⏣ • Tiktok3  
   ⏣ • Tiktok4  
   ⏣ • Tiktok5  
   ⏣ • Tiktokv2  
   ⏣ • Tiktoksearch  
   ⏣ • Tiktokslide  
   ⏣ • Tiktokslide2  
   ⏣ • Twitter  
   ⏣ • Videy  
   ⏣ • Youtube  
   ⏣ • Ytplay  
   ⏣ • Ytmp3  
   ⏣ • Ytmp-3  
   ⏣ • Ytmp4  
   ⏣ • Ytmpv4  
   ⏣ • Ytvid  
   ⏣ • Ytvideo  
   ⏣ • Ytshorts  
   ⏣ • X
   ⏣ • Xnxxs
   ⏣ • Xnxxdl
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ  ＷＥＥＢＳ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Awoo  
   ⏣ • Bite  
   ⏣ • Blush  
   ⏣ • Bonk  
   ⏣ • Bully  
   ⏣ • Cuddle  
   ⏣ • Cringe  
   ⏣ • Cry  
   ⏣ • Dance  
   ⏣ • Glomp  
   ⏣ • Happy  
   ⏣ • Handhold  
   ⏣ • Highfive  
   ⏣ • Hug  
   ⏣ • Kill  
   ⏣ • Kiss  
   ⏣ • Lick  
   ⏣ • Nom  
   ⏣ • Poke  
   ⏣ • Pat  
   ⏣ • Slap  
   ⏣ • Smile  
   ⏣ • Smugh  
   ⏣ • Wave  
   ⏣ • Wink  
   ⏣ • Yeet
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ  ＩＳＬＡＭＩ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Asmaulhusna  
   ⏣ • Ayatkursi  
   ⏣ • Audiosurah
   ⏣ • Doa  
   ⏣ • History
   ⏣ • Jadwalsholat  
   ⏣ • Surah
   ⏣ • Wirid
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ  ＱＵＯＴＥＳ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Bucin  
   ⏣ • Fml  
   ⏣ • Katabijak  
   ⏣ • Katacinta  
   ⏣ • Katagalau  
   ⏣ • Kata Senja  
   ⏣ • Kata Sindiran  
   ⏣ • Katahacker  
   ⏣ • Katailham  
   ⏣ • Motivasi  
   ⏣ • Quotessanime  
   ⏣ • Quotes  
   ⏣ • Quotespubg  
   ⏣ • Quotessislamic
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ  ＲＡＮＤＯＭ ＡＮＩＭＥ   ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Akira
   ⏣ • Akiyama
   ⏣ • Ana
   ⏣ • Art
   ⏣ • Asuna
   ⏣ • Ayuzawa
   ⏣ • Boruto
   ⏣ • Bts
   ⏣ • Chiho
   ⏣ • Chitoge
   ⏣ • Cosplay
   ⏣ • Cosplayloli
   ⏣ • Cosplaysagiri
   ⏣ • Cyber
   ⏣ • Deidara
   ⏣ • Doraemon
   ⏣ • Elena
   ⏣ • Emilia
   ⏣ • Erza
   ⏣ • Exo
   ⏣ • Gamewallpaper
   ⏣ • Gremory
   ⏣ • Hacker
   ⏣ • Hestia
   ⏣ • Hinata
   ⏣ • Husbu
   ⏣ • Inori
   ⏣ • Islamic
   ⏣ • Isuzu
   ⏣ • Itachi
   ⏣ • Itori
   ⏣ • Jennie
   ⏣ • Jiso
   ⏣ • Justina
   ⏣ • Kaga
   ⏣ • Kagura
   ⏣ • Kakasih
   ⏣ • Kaori
   ⏣ • Cartoon
   ⏣ • Shortquote
   ⏣ • Keneki
   ⏣ • Kotori
   ⏣ • Kurumi
   ⏣ • Lisa
   ⏣ • Loli2
   ⏣ • Madara
   ⏣ • Megumin
   ⏣ • Mikasa
   ⏣ • Mikey
   ⏣ • Minato
   ⏣ • Mountain
   ⏣ • Naruto
   ⏣ • Neko
   ⏣ • Neko2
   ⏣ • Nekonime
   ⏣ • Nezuko
   ⏣ • Onepiece
   ⏣ • Pentol
   ⏣ • Pokemon
   ⏣ • Programming
   ⏣ • Randomnime
   ⏣ • Randomnime2
   ⏣ • Rize
   ⏣ • Rose
   ⏣ • Sagiri
   ⏣ • Sakura
   ⏣ • Sasuke
   ⏣ • Satanic
   ⏣ • Shina
   ⏣ • Shinka
   ⏣ • Shinomiya
   ⏣ • Shizuka
   ⏣ • Shota
   ⏣ • Space
   ⏣ • Technology
   ⏣ • Tejina
   ⏣ • Toukachan
   ⏣ • Tsunade
   ⏣ • Waifu
   ⏣ • Yotsuba
   ⏣ • Yuki
   ⏣ • Yulibocil
   ⏣ • Yumeko
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ    ＭＯＶＩＥ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Ceritahoror
   ⏣ • Ceritacerpen
   ⏣ • Cerpen
   ⏣ • Cerpen2
   ⏣ • Cerpenremaja
   ⏣ • Cerpenanak
   ⏣ • Cerpenmisteri
   ⏣ • Cerpencinta
   ⏣ • Cerpenbudaya
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ    ＡＮＩＭＥ   ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Animeinfo  
   ⏣ • Animeinfo2
   ⏣ • Anime  
   ⏣ • Wattpad  
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ    ＥＰＨＯＴＯ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Glitchtext
   ⏣ • Writetext
   ⏣ • Advancedglow
   ⏣ • Typographytext
   ⏣ • Pixelglitch
   ⏣ • Neonglitch
   ⏣ • Flagtext
   ⏣ • Flag3dtext
   ⏣ • Deletingtext
   ⏣ • Blackpinkstyle
   ⏣ • Glowingtext
   ⏣ • Underwatertext
   ⏣ • Logomaker
   ⏣ • Cartoonstyle
   ⏣ • Papercutstyle
   ⏣ • Watercolortext
   ⏣ • Effectclouds
   ⏣ • Blackpinklogo
   ⏣ • Gradienttext
   ⏣ • Summerbeach
   ⏣ • Luxurygold
   ⏣ • Multicoloredneon
   ⏣ • Sandsummer
   ⏣ • Galaxywallpaper
   ⏣ • 1917style
   ⏣ • Makingneon
   ⏣ • Royaltext
   ⏣ • Freecreate
   ⏣ • Galaxystyle
   ⏣ • Lighteffects
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ    ＰＲＩＭＢＯＮ  ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Artimimpi  
   ⏣ • Artinama  
   ⏣ • Dilanquote  
   ⏣ • Jodoh  
   ⏣ • Kecocokannama  
   ⏣ • Nomerhoki  
   ⏣ • Ramalancinta  
   ⏣ • Ramalanjodoh  
   ⏣ • Ramalansuamiistri  
   ⏣ • Randomnama  
   ⏣ • Randompeople  
   ⏣ • Randompuisi  
   ⏣ • Tebakgender  
   ⏣ • Tebakumur
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ    ＲＰＧ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Cek
   ⏣ • Beli
   ⏣ • Toko
   ⏣ • Koin
   ⏣ • Bonus
   ⏣ • Claim
   ⏣ • Minum
   ⏣ • Makan
   ⏣ • Tidur
   ⏣ • Status
   ⏣ • Stamina
   ⏣ • Bertani
   ⏣ • Berburu
   ⏣ • Berlatih
   ⏣ • Dungeon
   ⏣ • Pengawal
   ⏣ • Menebang
   ⏣ • Berdagang
   ⏣ • Memancing
   ⏣ • Menambang
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ    ＳＥＡＲＣＨ   ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Alosehat  
   ⏣ • Apksearch  
   ⏣ • An1  
   ⏣ • Bukalapaksearch  
   ⏣ • Carikodepos  
   ⏣ • Calendar  
   ⏣ • Checkapikey  
   ⏣ • Checkresi  
   ⏣ • Cinema  
   ⏣ • Cuaca  
   ⏣ • Drakorsearch  
   ⏣ • Film  
   ⏣ • Ffw  
   ⏣ • Ff
   ⏣ • Gt  
   ⏣ • Google  
   ⏣ • Gempa  
   ⏣ • Gsmarena  
   ⏣ • Harilibur  
   ⏣ • Infoch  
   ⏣ • Jarak  
   ⏣ • Jadwaltv
   ⏣ • Kodebahasa  
   ⏣ • Liga  
   ⏣ • Lmdb  
   ⏣ • Lyric  
   ⏣ • Mcserver  
   ⏣ • Moewall  
   ⏣ • Mlbb
   ⏣ • Npms  
   ⏣ • Otakudesu  
   ⏣ • Profil
   ⏣ • Play  
   ⏣ • Playstore  
   ⏣ • Pixiv  
   ⏣ • Samehadaku  
   ⏣ • Samehadapage  
   ⏣ • Searchbijak  
   ⏣ • Searchmusic
   ⏣ • Searchplace  
   ⏣ • Song  
   ⏣ • Spotify  
   ⏣ • Stickerwa  
   ⏣ • Steam  
   ⏣ • Wallpaper  
   ⏣ • Westmanga  
   ⏣ • Wiki  
   ⏣ • Wikipedia 
   ⏣ • Wikimedia  
   ⏣ • YahooImg  
   ⏣ • Zerochan
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ  ＣＯＮＶＥＲＴ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Hd  
   ⏣ • Hdr  
   ⏣ • Img2promt  
   ⏣ • Img2txt  
   ⏣ • Remimi  
   ⏣ • Removebg  
   ⏣ • Toaudio
   ⏣ • Tovn
   ⏣ • Toptv
   ⏣ • Wm
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ  ＰＲＥＭＩＵＭ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Bingimg  
   ⏣ • Capcut  
   ⏣ • Chatgpt  
   ⏣ • Chatgptgo  
   ⏣ • Fluximage  
   ⏣ • Igslide  
   ⏣ • Igstalk  
   ⏣ • Lirik  
   ⏣ • Luminai  
   ⏣ • Muslimai  
   ⏣ • Openai  
   ⏣ • Pinslide  
   ⏣ • Snackvideo  
   ⏣ • Soundcloud  
   ⏣ • Spotifytrack  
   ⏣ • Tiktokslide  
   ⏣ • Tiktokstalk  
   ⏣ • Terabox  
   ⏣ • Tourl  
   ⏣ • Translate  
   ⏣ • Twitter  
   ⏣ • Yousearch  
   ⏣ • Simsimi  
   ⏣ • Metaai
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ  ＯＷＮＥＲ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Addcoin  
   ⏣ • Addlimit  
   ⏣ • Addprem  
   ⏣ • Addstamina  
   ⏣ • Addcase
   ⏣ • Delcase
   ⏣ • Getcase
   ⏣ • Backup
   ⏣ • Afk  
   ⏣ • Autoread On/Off  
   ⏣ • Ban  
   ⏣ • Cekidgc  
   ⏣ • Crateqr  
   ⏣ • Dellimit  
   ⏣ • Delcoin  
   ⏣ • Delstamina  
   ⏣ • Detectqr  
   ⏣ • Enc  
   ⏣ • Getdb  
   ⏣ • Getuser  
   ⏣ • Kayzuoffc  
   ⏣ • Listscfree  
   ⏣ • Panel  
   ⏣ • Payment/Pay  
   ⏣ • Pesanan/Order  
   ⏣ • Public  
   ⏣ • Resetcoin  
   ⏣ • Resetlimit  
   ⏣ • Scrape  
   ⏣ • Self  
   ⏣ • Setmenu  
   ⏣ • Shop  
   ⏣ • Sewa  
   ⏣ • Upswaudio  
   ⏣ • Upswimg  
   ⏣ • Upswteks  
   ⏣ • Upswvideo
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ  ＦＡＶＯＲＩＴＥ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Ai  
   ⏣ • Brat
   ⏣ • Bratvid
   ⏣ • Emoji
   ⏣ • Hd  
   ⏣ • Ig  
   ⏣ • Play  
   ⏣ • play2  
   ⏣ • Remini  
   ⏣ • S  
   ⏣ • Tiktok  
   ⏣ • Wm  
   ⏣ • Ytmp3  
   ⏣ • Ytmp4
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ    ＡＳＵＰＡＮ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • bokep
   ⏣ • cucimata
   ⏣ • Paptt
   ⏣ • Paptt2 
   ⏣ • Tobrut
   ⏣ • Bocil
   ⏣ • Tiktokgirl  
   ⏣ • Tiktoknukthy  
   ⏣ • Tiktokkayes  
   ⏣ • Tiktokpanrika  
   ⏣ • Tiktoknotnot  
   ⏣ • Tiktokghea  
   ⏣ • Tiktoksantuy  
   ⏣ • Tiktokbocil
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ  ＰＵＳＨ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Cek Id Gc  
   ⏣ • Save Kontak  
   ⏣ • Push Kontak  
   ⏣ • Push Kontak 2
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ  ＡＮＴＩ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Antich  
   ⏣ • Antiwame  
   ⏣ • Antilink  
   ⏣ • Antipanel  
   ⏣ • Antitoxic  
   ⏣ • Antilinkyt  
   ⏣ • Antilinktt  
   ⏣ • Antilinkgc  
   ⏣ • Antilinkgcv1
┈──────────────────────⏣
`
lenwy.sendMessage(m.chat, {
    image : fs.readFileSync('./data/image/Kay.jpeg'),
    caption: anu,
    gifPlayback: true,
   })
}
break

case 'menu': 
case 'mainmenu': {
    if (isBan) return lenwyreply('Kamu Di Ban Owner');
    LenwyLD();
    await sleep(1000);

    // Ambil waktu saat ini
    let date = new Date().toLocaleDateString('id-ID', { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    });
    let time = new Date().toLocaleTimeString('id-ID', { 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit', 
        timeZone: 'Asia/Jakarta' 
    });

    // Limit harian user
    let userLimit = isCreator ? "Unlimited" : (db.data.users[m.sender] && db.data.users[m.sender].limit) || 0;

// Memutar suara sebagai voice note
let soundPath = './mp3/menu.mp3'; // Path file suara
lenwy.sendMessage(m.chat, { 
    audio: { url: soundPath }, 
    mimetype: 'audio/mp4',
    ptt: true // Mengubah audio menjadi voice note
}, { quoted: m });

    // Teks menu dengan coin otomatis
    let LenwyBTm = `
┈──────────────────────⏣
           ⏤͟͟͞͞ᵡ    *I N F O   B O T*   ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⛩️• Bot Name : KiromiMD
   ⛩️• Creator : ${authorr}
   ⛩️• Mode Bot : ${lenwy.public ? `Public Mode` : `Self Mode`}
   ⛩️• Runtime : ${runtime(process.uptime())}
   ⛩️• Date : ${date}
   ⛩️• Time : ${time}`

let LenwyORIm = `
┈──────────────────────⏣
           ⏤͟͟͞͞ᵡ    *I N F O   B O T*   ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⛩️• Bot Name : KiromiMD
   ⛩️• Creator : ${authorr}
   ⛩️• Mode Bot : ${lenwy.public ? `Public Mode` : `Self Mode`}
   ⛩️• Runtime : ${runtime(process.uptime())}
   ⛩️• Date : ${date}
   ⛩️• Time : ${time}
┈──────────────────────⏣
           ⏤͟͟͞͞ᵡ    *R U L E S*   ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⛩️• *ᴅɪʟᴀʀᴀɴɢ ᴍᴇɴᴇʟᴘᴏɴ ɴᴏ ʙᴏᴛ*
   ⛩️• *ᴅɪʟᴀʀᴀɴɢ ᴊᴏᴍᴏᴋ*
   ⛩️• *ᴅɪʟᴀʀᴀɴɢ sᴘᴀᴍ, ᴡᴀᴊɪʙ ᴊᴇᴅᴀ*
   ⛩️• *ᴅɪʟᴀʀᴀɴɢ 𝟷𝟾+*
   ⛩️• *ᴅɪʟᴀʀᴀɴɢ ʙᴜʟʟʏɪɴɢ*${LenwyORI(prefix)}`
if (lenwymenu === 'LenwyORI') {
lenwy.sendMessage(m.chat, {
/*video: fs.readFileSync('./data/video/menu.mp4')*/
image : fs.readFileSync('./data/image/Kay.jpeg'),
caption: LenwyORIm,
gifPlayback: true,
contextInfo: {
externalAdReply: {
showAdAttribution: true, 
title: `${ucapanWaktu} ${pushname}`,
body: "KiromiMD",
thumbnailUrl: "https://files.catbox.moe/cnsw60.jpg",
sourceUrl: "https://whatsapp.com/channel/0029VatjTeULo4hk0RJlly0V",
mediaType: 1,
renderLargerThumbnail: false
                            }
                        }
                    }, {
                        quoted: m
                    })
                        } else if (lenwymenu === 'Button') {
let sections = [{
        title: 'List Produk',
        highlight_label: 'Favorit',
        rows: [{
        header: '🛍️ Beli Script',
        title: 'Script kayzuMD',
        description: `Beli Script kayzuMD`,
        id: `script`
        },
        {
        header: '🛍️ Beli Panel',
        title: 'Panel Pterodactyl',
        description: "Beli Panel Pterodactyl",
        id: `panel`
        },
        {    
        header: '🛍️ Sewa Bot',
        title: 'Sewa Bot',
        description: "Sewa Bot kayzuMD",
        id: `sewa`
        }]
        },
        {
        title: 'List Menu', 
        rows: [{
        header: 'Allmenu',
        title: 'Allmenu Bot',
        description: "Menampilkan Seluruh Menu", 
        id: `allmenu`
        },
        {
        header: 'Storemenu',
        title: 'Menu Store', 
        description: "Menampilkan Menu Store", 
        id: `store`
        },
        {
        header: 'Aimenu',
        title: 'Menu AI', 
        description: "Menampilkan Menu AI", 
        id: `aimenu`
        },
        {
        header: 'Funmenu',
        title: 'Menu Fun', 
        description: "Menampilkan Menu Fun", 
        id: `funmenu`
        },
        {
        header: 'Rpgmenu',
        title: 'Menu Rpg', 
        description: "Menampilkan Menu Rpg", 
        id: `rpgmenu`
        },
        {
        header: 'Gamemenu',
        title: 'Menu Game', 
        description: "Menampilkan Menu Game", 
        id: `gamemenu`
        },
        {
        header: 'Groupmenu',
        title: 'Menu Group', 
        description: "Menampilkan Menu Group", 
        id: `groupmenu`
        },
        {
        header: 'Beritamenu',
        title: 'Menu Berita', 
        description: "Menampilkan Menu Berita", 
        id: `beritamenu`
        },
        {
        header: 'Randommenu',
        title: 'Menu Random', 
        description: "Menampilkan Menu Random", 
        id: `randommenu`
        },
        {
        header: 'Downmenu',
        title: 'Menu Download', 
        description: "Menampilkan Menu Download", 
        id: `${prefix}groupmenu`
        },
        {
        header: 'Weebsmenu',
        title: 'Menu Weebs',
        description: "Menampilkan Menu Weebs", 
        id: `weebsmenu`
        },
        {
        header: 'Islamimenu',
        title: 'Menu Islami', 
        description: "Menampilkan Menu Islami", 
        id: `islamimenu`
        },
        {
        header: 'Quotesmenu',
        title: 'Menu Quotes',
        description: 'Menampilkan Menu Quotes',
        id: `quotesmenu`
        },
        {
        header: 'Searchmenu',
        title: 'Menu Search', 
        description: "Menampilkan Menu Search", 
        id: `searchmenu`
        },
        {
        header: 'Convertmenu',
        title: 'Menu Convert',
        description: "Menampilkan Menu Convert", 
        id: 'convertmenu'
        },
        {
        header: '👑 Ownermenu',
        title: 'Menu Owner',
        description: "Menampilkan Menu Owner", 
        id: 'ownermenu'
        },
        {    
        header: 'Favmenu',
        title: 'Menu Favorit', 
        description: "Menampilkan Menu Favorit", 
        id: `favmenu`
        },
        {
        header: 'Pushmenu',
        title: 'Menu Push Kontak', 
        description: "Menampilkan Menu Push Kontak", 
        id: `pushmenu`
        },
        {
        header: 'Antimenu',
        title: 'Menu Anti', 
        description: "Menampilkan Menu Anti", 
        id: `antimenu`
        },
        {
        header: 'Panelmenu',
        title: 'Menu Panel',
        description: "Menampilkan Menu Panel", 
        id: `panelmenu`
        }]
        },
        {   
        title: '*メ*Saluran WhatsApp',
        highlight_label: 'Informasi',
        rows: [{
        header: 'Saluran',
        title: 'Saluran kayzuMD',
        description: `Link Download Sc kayzuMD`,
        id: `kayzu`
        }]
     }]
let listMessage = {
title: 'Menu', 
sections
};
let msg = generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
         contextInfo: { 
            isForwarded: true, 
        },
          body: proto.Message.InteractiveMessage.Body.create({
            text: LenwyBTm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            hasMediaAttachment: false,...(await prepareWAMessageMedia({ image : fs.readFileSync('./data/image/thumb2.png')}, { upload: lenwy.waUploadToServer})), 
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [              
              {
                "name": "single_select",
                "buttonParamsJson": JSON.stringify(listMessage)
              },
              {
              "name": "quick_reply",
              "buttonParamsJson": "{\"display_text\":\"Owner\",\"id\":\".owner\"}"
              }
           ],
          })
        })
    }
  }
}, { quoted: m })

lenwy.relayMessage(msg.key.remoteJid, msg.message, {
  messageId: m.key.id
})
}
}
break

case 'setmenu':
if (!isPrem) return lenwyreply(mess.prem)
if ((args[0]) === 'Kayzu'|| (args[0]) === 'kayzu' ){
lenwymenu = "LenwyORI"
lenwyreply(`*Berhasil Beralih Kedalam Menu kayzuMD*`)
} else if ((args[0]) === 'Button'|| (args[0]) === 'button' ){
lenwymenu = "Button"
lenwyreply(`*Berhasil Beralih Kedalam Menu Button*`)
}  else if (!q) {
lenwyreply(`*Menu Yang Tersedia*
 *⨠ kayzuMD*
 *⨠ Button*

*Contoh : Setmenu kayzuMD* `)

} else {
lenwyreply("*Menu Tidak Ditemukan*")
}
break 

case 'setproduk':
if (!isPrem) return lenwyreply(mess.prem)
if ((args[0]) === 'Normal'|| (args[0]) === 'normal' ){
lenwypro = "LenwyP"
lenwyreply(`*Berhasil Beralih Kedalam Menu Produk Normal*`)
} else if ((args[0]) === 'Button'|| (args[0]) === 'button' ){
lenwypro = "Button"
lenwyreply(`*Berhasil Beralih Kedalam Menu Produk Button*`)
}  else if (!q) {
lenwyreply(`*Menu Produk Yang Tersedia*
 *⨠ Normal*
 *⨠ Button*

*Contoh : Setproduk Normal* `)

} else {
lenwyreply("*Menu Produk Tidak Ditemukan*")
}
break 

case 'antimenu': {
    if (isBan) return lenwyreply('Kamu Di Ban Owner')
    LenwyLD()
    await sleep(1000)
    
// Memutar suara sebagai voice note
let soundPath = './mp3/menu.mp3'; // Path file suara
lenwy.sendMessage(m.chat, { 
    audio: { url: soundPath }, 
    mimetype: 'audio/mp4',
    ptt: true // Mengubah audio menjadi voice note
}, { quoted: m });
    
    // Kirim teks antimenu
    lenwyreply(`
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ  ＡＮＴＩ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
  ⏣ • Antich  
  ⏣ • Antiwame  
  ⏣ • Antilink  
  ⏣ • Antipanel  
  ⏣ • Antitoxic  
  ⏣ • Antilinkyt  
  ⏣ • Antilinktt  
  ⏣ • Antilinkgc  
  ⏣ • Antilinkgcv1
    `)
}
break

case 'ownmenu': {
    if (isBan) return lenwyreply('Kamu Di Ban Owner')
    LenwyLD()
    await sleep(1000)
    
// Memutar suara sebagai voice note
let soundPath = './mp3/menu.mp3'; // Path file suara
lenwy.sendMessage(m.chat, { 
    audio: { url: soundPath }, 
    mimetype: 'audio/mp4',
    ptt: true // Mengubah audio menjadi voice note
}, { quoted: m });
    
    // Kirim teks antimenu
    lenwyreply(`
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ  ＯＷＮＥＲ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Addcoin  
   ⏣ • Addlimit  
   ⏣ • Addprem  
   ⏣ • Addstamina  
   ⏣ • Addcase
   ⏣ • Delcase
   ⏣ • Getcase
   ⏣ • Backup
   ⏣ • Afk  
   ⏣ • Autoread On/Off  
   ⏣ • Ban  
   ⏣ • Cekidgc  
   ⏣ • Crateqr  
   ⏣ • Dellimit  
   ⏣ • Delcoin  
   ⏣ • Delstamina  
   ⏣ • Detectqr  
   ⏣ • Enc  
   ⏣ • Getdb  
   ⏣ • Getuser  
   ⏣ • Kayzuoffc  
   ⏣ • Listscfree  
   ⏣ • Panel  
   ⏣ • Payment/Pay  
   ⏣ • Pesanan/Order  
   ⏣ • Public  
   ⏣ • Resetcoin  
   ⏣ • Resetlimit  
   ⏣ • Scrape  
   ⏣ • Self  
   ⏣ • Setmenu  
   ⏣ • Shop  
   ⏣ • Sewa  
   ⏣ • Upswaudio  
   ⏣ • Upswimg  
   ⏣ • Upswteks  
   ⏣ • Upswvideo
    `)
}
break

case 'groupmenu': {
    if (isBan) return lenwyreply('Kamu Di Ban Owner')
    LenwyLD()
    await sleep(1000)

// Memutar suara sebagai voice note
let soundPath = './mp3/menu.mp3'; // Path file suara
lenwy.sendMessage(m.chat, { 
    audio: { url: soundPath }, 
    mimetype: 'audio/mp4',
    ptt: true // Mengubah audio menjadi voice note
}, { quoted: m });
    
    // Kirim teks groupmenu
    lenwyreply(`
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ    ＧＲＯＵＰ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Add (62xxx)  
   ⏣ • Antilinkgc On/Off  
   ⏣ • Antitoxic On/Off  
   ⏣ • Bcgc (Teksnya)  
   ⏣ • Brat (Buat Sticker Chat)  
   ⏣ • Demote (62xxx)  
   ⏣ • Done
   ⏣ • Editdesk (Teksnya)  
   ⏣ • Editgroup Close/Open  
   ⏣ • Editinfo On/Off  
   ⏣ • Editsubjek (Teksnya)  
   ⏣ • Group Close/Open  
   ⏣ • Hidetag (Teksnya)  
   ⏣ • Inspect (Linknya)  
   ⏣ • Join (Linknya)  
   ⏣ • Duar (62xxx)  
   ⏣ • Linkgroup  
   ⏣ • Promote (62xxx)  
   ⏣ • Proses
   ⏣ • Reportbug  
   ⏣ • Resetlinkgc  
   ⏣ • Saran  
   ⏣ • Sendlinkgc (62xxx)  
   ⏣ • Share (Teksnya)  
   ⏣ • Tagall (Teks)  
   ⏣ • Timeclose  
   ⏣ • Timeopen  
   ⏣ • Totag
    `)
}
break

case 'downmenu': case 'downloadmenu': {
    if (isBan) return lenwyreply('Kamu Di Ban Owner')
    LenwyLD()
    await sleep(1000)

// Memutar suara sebagai voice note
let soundPath = './mp3/menu.mp3'; // Path file suara
lenwy.sendMessage(m.chat, { 
    audio: { url: soundPath }, 
    mimetype: 'audio/mp4',
    ptt: true // Mengubah audio menjadi voice note
}, { quoted: m });
    
    // Kirim teks downloadmenu
    lenwyreply(`
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ  ＤＯＷＮＬＯＡＤ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ •  Capcut  
   ⏣ • Fbdl  
   ⏣ • Fb2  
   ⏣ • Gdrive  
   ⏣ • Igdl  
   ⏣ • Igslide  
   ⏣ • Likee  
   ⏣ • Mediafire  
   ⏣ • Pinvt  
   ⏣ • Pinslide  
   ⏣ • Searchyt  
   ⏣ • Snackvideo  
   ⏣ • Snackvid  
   ⏣ • Spotify   
   ⏣ • Spotifytrack  
   ⏣ • Tiktok  
   ⏣ • Tiktok2  
   ⏣ • Tiktok3  
   ⏣ • Tiktok4  
   ⏣ • Tiktok5  
   ⏣ • Tiktokv2  
   ⏣ • Tiktoksearch  
   ⏣ • Tiktokslide  
   ⏣ • Tiktokslide2  
   ⏣ • Twitter  
   ⏣ • Videy  
   ⏣ • Youtube  
   ⏣ • Ytplay  
   ⏣ • Ytmp3  
   ⏣ • Ytmp-3  
   ⏣ • Ytmp4  
   ⏣ • Ytmpv4  
   ⏣ • Ytvid  
   ⏣ • Ytvideo  
   ⏣ • Ytshorts  
   ⏣ • X
   ⏣ • Xnxxs
   ⏣ • Xnxxdl
    `)
}
break

case 'menumovie': case 'moviemenu': {
    if (isBan) return lenwyreply('Kamu Di Ban Owner')
    LenwyLD()
    await sleep(1000)

// Memutar suara sebagai voice note
let soundPath = './mp3/menu.mp3'; // Path file suara
lenwy.sendMessage(m.chat, { 
    audio: { url: soundPath }, 
    mimetype: 'audio/mp4',
    ptt: true // Mengubah audio menjadi voice note
}, { quoted: m });
    
    // Kirim teks downloadmenu
    lenwyreply(`
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ    ＭＯＶＩＥ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
⏣ • Ceritahoror
⏣ • Ceritacerpen
⏣ • Cerpen
⏣ • Cerpen2
⏣ • Cerpenremaja
⏣ • Cerpenanak
⏣ • Cerpenmisteri
⏣ • Cerpencinta
⏣ • Cerpenbudaya
    `)
}
break

case 'rpg': case 'menurpg': {
    if (isBan) return lenwyreply('Kamu Di Ban Owner')
    LenwyLD()
    await sleep(1000)

// Memutar suara sebagai voice note
let soundPath = './mp3/menu.mp3'; // Path file suara
lenwy.sendMessage(m.chat, { 
    audio: { url: soundPath }, 
    mimetype: 'audio/mp4',
    ptt: true // Mengubah audio menjadi voice note
}, { quoted: m });
    
    // Kirim teks downloadmenu
    lenwyreply(`
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ    ＲＰＧ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Cek
   ⏣ • Beli
   ⏣ • Toko
   ⏣ • Koin
   ⏣ • Bonus
   ⏣ • Claim
   ⏣ • Minum
   ⏣ • Makan
   ⏣ • Tidur
   ⏣ • Status
   ⏣ • Stamina
   ⏣ • Bertani
   ⏣ • Berburu
   ⏣ • Berlatih
   ⏣ • Dungeon
   ⏣ • Pengawal
   ⏣ • Menebang
   ⏣ • Berdagang
   ⏣ • Memancing
   ⏣ • Menambang
    `)
}
break
case 'menufav': case 'favmenu': {
    if (isBan) return lenwyreply('Kamu Di Ban Owner')
    LenwyLD()
    await sleep(1000)

// Memutar suara sebagai voice note
let soundPath = './mp3/menu.mp3'; // Path file suara
lenwy.sendMessage(m.chat, { 
    audio: { url: soundPath }, 
    mimetype: 'audio/mp4',
    ptt: true // Mengubah audio menjadi voice note
}, { quoted: m });
    
    // Kirim teks downloadmenu
    lenwyreply(`
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ  ＦＡＶＯＲＩＴＥ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Ai  
   ⏣ • Brat
   ⏣ • Bratvid
   ⏣ • Hd  
   ⏣ • Ig  
   ⏣ • Play  
   ⏣ • play2  
   ⏣ • Remini  
   ⏣ • S  
   ⏣ • Tiktok  
   ⏣ • Wm  
   ⏣ • Ytmp3  
   ⏣ • Ytmp4
    `)
}
break

case 'asupanmenu': case 'menuasupan': {
    if (isBan) return lenwyreply('Kamu Di Ban Owner')
    LenwyLD()
    await sleep(1000)

// Memutar suara sebagai voice note
let soundPath = './mp3/menu.mp3'; // Path file suara
lenwy.sendMessage(m.chat, { 
    audio: { url: soundPath }, 
    mimetype: 'audio/mp4',
    ptt: true // Mengubah audio menjadi voice note
}, { quoted: m });
    
    // Kirim teks downloadmenu
    lenwyreply(`
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ    ＡＳＵＰＡＮ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • bokep
   ⏣ • cucimata
   ⏣ • Paptt
   ⏣ • Paptt2 
   ⏣ • Tobrut
   ⏣ • Bocil
   ⏣ • Tiktokgirl  
   ⏣ • Tiktoknukthy  
   ⏣ • Tiktokkayes  
   ⏣ • Tiktokpanrika  
   ⏣ • Tiktoknotnot  
   ⏣ • Tiktokghea  
   ⏣ • Tiktoksantuy  
   ⏣ • Tiktokbocil
    `)
}
break

case 'primbon': case 'primbonmenu': {
    if (isBan) return lenwyreply('Kamu Di Ban Owner')
    LenwyLD()
    await sleep(1000)

// Memutar suara sebagai voice note
let soundPath = './mp3/menu.mp3'; // Path file suara
lenwy.sendMessage(m.chat, { 
    audio: { url: soundPath }, 
    mimetype: 'audio/mp4',
    ptt: true // Mengubah audio menjadi voice note
}, { quoted: m });
    
    // Kirim teks downloadmenu
    lenwyreply(`
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ    ＰＲＩＭＢＯＮ  ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Artimimpi  
   ⏣ • Artinama  
   ⏣ • Dilanquote  
   ⏣ • Jodoh  
   ⏣ • Kecocokannama  
   ⏣ • Nomerhoki  
   ⏣ • Ramalancinta  
   ⏣ • Ramalanjodoh  
   ⏣ • Ramalansuamiistri  
   ⏣ • Randomnama  
   ⏣ • Randompeople  
   ⏣ • Randompuisi  
   ⏣ • Tebakgender  
   ⏣ • Tebakumur

    `)
}
break

case 'generateimageai': case 'aiimage': {
    if (isBan) return lenwyreply('Kamu Di Ban Owner')
    LenwyLD()
    await sleep(1000)

// Memutar suara sebagai voice note
let soundPath = './mp3/menu.mp3'; // Path file suara
lenwy.sendMessage(m.chat, { 
    audio: { url: soundPath }, 
    mimetype: 'audio/mp4',
    ptt: true // Mengubah audio menjadi voice note
}, { quoted: m });
    
    // Kirim teks downloadmenu
    lenwyreply(`
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ    ＧＥＮＥＲＡＴＥ ＩＭＡＧＥ ＡＩ   ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Dalle
   ⏣ • FluXImage
   ⏣ • BingIMG
   ⏣ • Stably
    `)
}
break

case 'islammenu': case 'islamimenu': {
    if (isBan) return lenwyreply('Kamu Di Ban Owner')
    LenwyLD()
    await sleep(1000)

// Memutar suara sebagai voice note
let soundPath = './mp3/menu.mp3'; // Path file suara
lenwy.sendMessage(m.chat, { 
    audio: { url: soundPath }, 
    mimetype: 'audio/mp4',
    ptt: true // Mengubah audio menjadi voice note
}, { quoted: m });
    
    // Kirim teks islammenu
    lenwyreply(`
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ  ＩＳＬＡＭＩ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Asmaulhusna  
   ⏣ • Ayatkursi  
   ⏣ • Audiosurah
   ⏣ • Doa  
   ⏣ • History
   ⏣ • Jadwalsholat  
   ⏣ • Surah
   ⏣ • Wirid
    `)
}
break

case 'ephoto': {
    if (isBan) return lenwyreply('Kamu Di Ban Owner')
    LenwyLD()
    await sleep(1000)

// Memutar suara sebagai voice note
let soundPath = './mp3/menu.mp3'; // Path file suara
lenwy.sendMessage(m.chat, { 
    audio: { url: soundPath }, 
    mimetype: 'audio/mp4',
    ptt: true // Mengubah audio menjadi voice note
}, { quoted: m });
    
    // Kirim teks ownermenu
    lenwyreply(`
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ  ＥＰＨＯＴＯ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Glitchtext
   ⏣ • Writetext
   ⏣ • Advancedglow
   ⏣ • Typographytext
   ⏣ • Pixelglitch
   ⏣ • Neonglitch
   ⏣ • Flagtext
   ⏣ • Flag3dtext
   ⏣ • Deletingtext
   ⏣ • Blackpinkstyle
   ⏣ • Glowingtext
   ⏣ • Underwatertext
   ⏣ • Logomaker
   ⏣ • Cartoonstyle
   ⏣ • Papercutstyle
   ⏣ • Watercolortext
   ⏣ • Effectclouds
   ⏣ • Blackpinklogo
   ⏣ • Gradienttext
   ⏣ • Summerbeach
   ⏣ • Luxurygold
   ⏣ • Multicoloredneon
   ⏣ • Sandsummer
   ⏣ • Galaxywallpaper
   ⏣ • 1917style
   ⏣ • Makingneon
   ⏣ • Royaltext
   ⏣ • Freecreate
   ⏣ • Galaxystyle
   ⏣ • Lighteffects
    `)
}
break

case 'animemenu': {
    if (isBan) return lenwyreply('Kamu Di Ban Owner')
    LenwyLD()
    await sleep(1000)

// Memutar suara sebagai voice note
let soundPath = './mp3/menu.mp3'; // Path file suara
lenwy.sendMessage(m.chat, { 
    audio: { url: soundPath }, 
    mimetype: 'audio/mp4',
    ptt: true // Mengubah audio menjadi voice note
}, { quoted: m });
    
    // Kirim teks favmenu
    lenwyreply(`
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ    ＡＮＩＭＥ   ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Animeinfo  
   ⏣ • Anime  
   ⏣ • Wattpad  
    `)
}
break

case 'randomimage': {

    if (isBan) return lenwyreply('Kamu Di Ban Owner')
    LenwyLD()
    await sleep(1000)

// Memutar suara sebagai voice note
let soundPath = './mp3/menu.mp3'; // Path file suara
lenwy.sendMessage(m.chat, { 
    audio: { url: soundPath }, 
    mimetype: 'audio/mp4',
    ptt: true // Mengubah audio menjadi voice note
}, { quoted: m });
    
    // Kirim teks favmenu
    lenwyreply(`
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ  ＲＡＮＤＯＭ ＩＭＡＧＥ   ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Bluearchive  
   ⏣ • hijab  
   ⏣ • indo  
   ⏣ • japanese  
   ⏣ • korean  
   ⏣ • malay  
   ⏣ • randomgirl  
   ⏣ • randomboy  
   ⏣ • thai  
   ⏣ • vietnamese  
   ⏣ • aesthetic  
   ⏣ • chinese  
   ⏣ • pubg  
   ⏣ • antiwork  
   ⏣ • blackpink2  
   ⏣ • cosplay  
   ⏣ • cat  
   ⏣ • doggo  
   ⏣ • justina  
   ⏣ • kayes  
   ⏣ • bike  
   ⏣ • boneka  
   ⏣ • kpop  
   ⏣ • notnot  
   ⏣ • car  
   ⏣ • rose  
   ⏣ • ryujin  
   ⏣ • ulzangboy  
   ⏣ • ulzanggirl  
   ⏣ • mobilelegend
   ⏣ • Neko
   ⏣ • Waifu
    `)
}
break

case 'randomanime': {

    if (isBan) return lenwyreply('Kamu Di Ban Owner')
    LenwyLD()
    await sleep(1000)

// Memutar suara sebagai voice note
let soundPath = './mp3/menu.mp3'; // Path file suara
lenwy.sendMessage(m.chat, { 
    audio: { url: soundPath }, 
    mimetype: 'audio/mp4',
    ptt: true // Mengubah audio menjadi voice note
}, { quoted: m });
    
    // Kirim teks favmenu
    lenwyreply(`
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ  ＲＡＮＤＯＭ ＡＮＩＭＥ   ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Akira
   ⏣ • Akiyama
   ⏣ • Ana
   ⏣ • Art
   ⏣ • Asuna
   ⏣ • Ayuzawa
   ⏣ • Boruto
   ⏣ • Bts
   ⏣ • Chiho
   ⏣ • Chitoge
   ⏣ • Cosplay
   ⏣ • Cosplayloli
   ⏣ • Cosplaysagiri
   ⏣ • Cyber
   ⏣ • Deidara
   ⏣ • Doraemon
   ⏣ • Elena
   ⏣ • Emilia
   ⏣ • Erza
   ⏣ • Exo
   ⏣ • Gamewallpaper
   ⏣ • Gremory
   ⏣ • Hacker
   ⏣ • Hestia
   ⏣ • Hinata
   ⏣ • Husbu
   ⏣ • Inori
   ⏣ • Islamic
   ⏣ • Isuzu
   ⏣ • Itachi
   ⏣ • Itori
   ⏣ • Jennie
   ⏣ • Jiso
   ⏣ • Justina
   ⏣ • Kaga
   ⏣ • Kagura
   ⏣ • Kakasih
   ⏣ • Kaori
   ⏣ • Cartoon
   ⏣ • Shortquote
   ⏣ • Keneki
   ⏣ • Kotori
   ⏣ • Kurumi
   ⏣ • Lisa
   ⏣ • Loli2
   ⏣ • Madara
   ⏣ • Megumin
   ⏣ • Mikasa
   ⏣ • Mikey
   ⏣ • Minato
   ⏣ • Mountain
   ⏣ • Naruto
   ⏣ • Neko
   ⏣ • Neko2
   ⏣ • Nekonime
   ⏣ • Nezuko
   ⏣ • Onepiece
   ⏣ • Pentol
   ⏣ • Pokemon
   ⏣ • Programming
   ⏣ • Randomnime
   ⏣ • Randomnime2
   ⏣ • Rize
   ⏣ • Rose
   ⏣ • Sagiri
   ⏣ • Sakura
   ⏣ • Sasuke
   ⏣ • Satanic
   ⏣ • Shina
   ⏣ • Shinka
   ⏣ • Shinomiya
   ⏣ • Shizuka
   ⏣ • Shota
   ⏣ • Space
   ⏣ • Technology
   ⏣ • Tejina
   ⏣ • Toukachan
   ⏣ • Tsunade
   ⏣ • Waifu
   ⏣ • Yotsuba
   ⏣ • Yuki
   ⏣ • Yulibocil
   ⏣ • Yumeko
    `)
}
break

case 'convertmenu': {
    if (isBan) return lenwyreply('Kamu Di Ban Owner')
    LenwyLD()
    await sleep(1000)

// Memutar suara sebagai voice note
let soundPath = './mp3/menu.mp3'; // Path file suara
lenwy.sendMessage(m.chat, { 
    audio: { url: soundPath }, 
    mimetype: 'audio/mp4',
    ptt: true // Mengubah audio menjadi voice note
}, { quoted: m });

    // Kirim teks convertmenu
    lenwyreply(`
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ  ＣＯＮＶＥＲＴ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Hd  
   ⏣ • Hdr  
   ⏣ • Img2promt  
   ⏣ • Img2txt  
   ⏣ • Remimi  
   ⏣ • Removebg  
   ⏣ • Toaudio
   ⏣ • Tovn
   ⏣ • Toptv
   ⏣ • Wm
    `)
}
break

case 'pushmenu': {
if (isBan) return lenwyreply('Kamu Di Ban Owner')
const y11 = `
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ  ＰＵＳＨ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Cek Id Gc  
   ⏣ • Save Kontak  
   ⏣ • Push Kontak  
   ⏣ • Push Kontak 2
`
lenwyreply(y11)
}
break

case 'randommenu': {
    if (isBan) return lenwyreply('Kamu Di Ban Owner')
    LenwyLD()
    await sleep(1000)

// Memutar suara sebagai voice note
let soundPath = './mp3/menu.mp3'; // Path file suara
lenwy.sendMessage(m.chat, { 
    audio: { url: soundPath }, 
    mimetype: 'audio/mp4',
    ptt: true // Mengubah audio menjadi voice note
}, { quoted: m });

    // Kirim teks randommenu
    lenwyreply(`
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ  ＲＡＮＤＯＭ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ •  About  
   ⏣ •  Aboutkay  
   ⏣ •  Acak  
   ⏣ •  Admin  
   ⏣ •  Afk  
   ⏣ •  Calendar  
   ⏣ •  Calender  
   ⏣ •  Confess  
   ⏣ •  Couple  
   ⏣ •  Cwr  
   ⏣ •  Faktaunik  
   ⏣ •  Friend  
   ⏣ •  Getname  
   ⏣ •  Getpic  
   ⏣ •  Ip  
   ⏣ •  Kata Ucapan  
   ⏣ •  Kalender  
   ⏣ •  Menfess  
   ⏣ •  Meme  
   ⏣ •  Morse  
   ⏣ •  Nickff  
   ⏣ •  Owner  
   ⏣ •  Pantun  
   ⏣ •  Prayer  
   ⏣ •  Prank  
   ⏣ •  Puisi  
   ⏣ •  Qc  
   ⏣ •  Qckode  
   ⏣ •  Readmore  
   ⏣ •  Reminder  
   ⏣ •  Resep  
   ⏣ •  Services  
   ⏣ •  Sholatsubuh  
   ⏣ •  Sholawaktu  
   ⏣ •  Sticker  
   ⏣ •  Time  
   ⏣ •  Tagsw  
   ⏣ •  Toqr    
   ⏣ •  Weather  
   ⏣ •  Wangy  
   ⏣ •  Emojimix  
   ⏣ •  Cekasalmember  
   ⏣ •  Cekkontol  
   ⏣ •  Cekmemek  
   ⏣ •  Cekkhodam  
   ⏣ •  Assalamualaikum
    `)
}
break

case 'aimenu': {
    if (isBan) return lenwyreply('Kamu Di Ban Owner')
    LenwyLD()
    await sleep(1000)

// Memutar suara sebagai voice note
let soundPath = './mp3/menu.mp3'; // Path file suara
lenwy.sendMessage(m.chat, { 
    audio: { url: soundPath }, 
    mimetype: 'audio/mp4',
    ptt: true // Mengubah audio menjadi voice note
}, { quoted: m });

    // Kirim teks AI menu
    lenwyreply(`
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ    A I   ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • AI  
   ⏣ • Ask  
   ⏣ • Bing  
   ⏣ • ChatGPT  
   ⏣ • ChatGPTGo  
   ⏣ • Gemini  
   ⏣ • GPT-4  
   ⏣ • MetaAI  
   ⏣ • MuslimAI  
   ⏣ • OpenAI  
   ⏣ • Translate  
   ⏣ • YouSearch
    `)
}
break

case 'searchmenu': {
    if (isBan) return lenwyreply('Kamu Di Ban Owner')
    LenwyLD()
    await sleep(1000)

// Memutar suara sebagai voice note
let soundPath = './mp3/menu.mp3'; // Path file suara
lenwy.sendMessage(m.chat, { 
    audio: { url: soundPath }, 
    mimetype: 'audio/mp4',
    ptt: true // Mengubah audio menjadi voice note
}, { quoted: m });

    // Kirim teks Search menu
    lenwyreply(`
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ    SEARCH   ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Alosehat  
   ⏣ • Apksearch  
   ⏣ • An1  
   ⏣ • Bukalapaksearch  
   ⏣ • Carikodepos  
   ⏣ • Calendar  
   ⏣ • Checkapikey  
   ⏣ • Checkresi  
   ⏣ • Cinema  
   ⏣ • Cuaca  
   ⏣ • Drakorsearch  
   ⏣ • Film  
   ⏣ • Ffw  
   ⏣ • Ff
   ⏣ • Gt  
   ⏣ • Google  
   ⏣ • Gempa  
   ⏣ • Gsmarena  
   ⏣ • Harilibur  
   ⏣ • Infoch  
   ⏣ • Jarak  
   ⏣ • Jadwaltv
   ⏣ • Kodebahasa  
   ⏣ • Liga  
   ⏣ • Lmdb  
   ⏣ • Lyric  
   ⏣ • Mcserver  
   ⏣ • Moewall  
   ⏣ • Mlbb
   ⏣ • Npms  
   ⏣ • Otakudesu  
   ⏣ • Profil
   ⏣ • Play  
   ⏣ • Playstore  
   ⏣ • Pixiv  
   ⏣ • Samehadaku  
   ⏣ • Samehadapage  
   ⏣ • Searchbijak  
   ⏣ • Searchmusic
   ⏣ • Searchplace  
   ⏣ • Song  
   ⏣ • Spotify  
   ⏣ • Stickerwa  
   ⏣ • Steam  
   ⏣ • Wallpaper  
   ⏣ • Westmanga  
   ⏣ • Wiki  
   ⏣ • Wikipedia 
   ⏣ • Wikimedia  
   ⏣ • YahooImg  
   ⏣ • Zerochan
    `)
}
break

case 'weebsmenu': {
    if (isBan) return lenwyreply('Kamu Di Ban Owner')
    LenwyLD()
    await sleep(1000)
    
// Memutar suara sebagai voice note
let soundPath = './mp3/menu.mp3'; // Path file suara
lenwy.sendMessage(m.chat, { 
    audio: { url: soundPath }, 
    mimetype: 'audio/mp4',
    ptt: true // Mengubah audio menjadi voice note
}, { quoted: m });
    
    // Kirim teks weebs menu
    lenwyreply(`
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ  ＷＥＥＢＳ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Awoo  
   ⏣ • Bite  
   ⏣ • Blush  
   ⏣ • Bonk  
   ⏣ • Bully  
   ⏣ • Cry  
   ⏣ • Cringe  
   ⏣ • Cuddle  
   ⏣ • Dance  
   ⏣ • Glomp  
   ⏣ • Happy  
   ⏣ • Handhold  
   ⏣ • Highfive  
   ⏣ • Hug  
   ⏣ • Kill  
   ⏣ • Kiss  
   ⏣ • Lick  
   ⏣ • Nom  
   ⏣ • Pat  
   ⏣ • Poke  
   ⏣ • Slap  
   ⏣ • Smile  
   ⏣ • Smugh  
   ⏣ • Wave  
   ⏣ • Wink  
   ⏣ • Yeet
    `)
}
break

case 'beritamenu': {
    if (isBan) return lenwyreply('Kamu Di Ban Owner')
    LenwyLD()
    await sleep(1000)
    
// Memutar suara sebagai voice note
let soundPath = './mp3/menu.mp3'; // Path file suara
lenwy.sendMessage(m.chat, { 
    audio: { url: soundPath }, 
    mimetype: 'audio/mp4',
    ptt: true // Mengubah audio menjadi voice note
}, { quoted: m });
    
    // Kirim teks berita menu
    lenwyreply(`
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ  ＢＥＲＩＴＡ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Dailynews  
   ⏣ • Detiknews  
   ⏣ • Inews  
   ⏣ • Kompasnews  
   ⏣ • Kontan
    `)
}
break

case 'quotesmenu': {
    if (isBan) return lenwyreply('Kamu Di Ban Owner')
    LenwyLD()
    await sleep(1000)

// Memutar suara sebagai voice note
let soundPath = './mp3/menu.mp3'; // Path file suara
lenwy.sendMessage(m.chat, { 
    audio: { url: soundPath }, 
    mimetype: 'audio/mp4',
    ptt: true // Mengubah audio menjadi voice note
}, { quoted: m });

    // Kirim teks Quotes menu
    lenwyreply(`
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ  ＱＵＯＴＥＳ    ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Bucin  
   ⏣ • Fml  
   ⏣ • Katabijak  
   ⏣ • Katacinta  
   ⏣ • Katagalau  
   ⏣ • Kata Senja  
   ⏣ • Katahacker  
   ⏣ • Katailham  
   ⏣ • Kata Sindiran  
   ⏣ • Motivasi  
   ⏣ • Quotessanime  
   ⏣ • Quotes  
   ⏣ • Quotespubg  
   ⏣ • Quotessislamic
    `)
}
break

case 'kayzumd':
case 'kayzumenu': {
    if (isBan) return lenwyreply('Kamu Di Ban Owner')
    LenwyLD()
    await sleep(1000)

// Memutar suara sebagai voice note
let soundPath = './mp3/menu.mp3'; // Path file suara
lenwy.sendMessage(m.chat, { 
    audio: { url: soundPath }, 
    mimetype: 'audio/mp4',
    ptt: true // Mengubah audio menjadi voice note
}, { quoted: m });

    // Kirim teks KayzuMD menu
    lenwyreply(`
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ    K A Y Z U   ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Addlimit  
   ⏣ • Dellimit  
   ⏣ • Kayzuoffc  
   ⏣ • Listscfree  
   ⏣ • Panel  
   ⏣ • Pesanan/Order  
   ⏣ • Payment/Pay  
   ⏣ • Scrape  
   ⏣ • Setmenu  
   ⏣ • Shop  
   ⏣ • Sewa
    `)
}
break

case 'gamemenu': {
    if (isBan) return lenwyreply('Kamu Di Ban Owner')
    LenwyLD()
    await sleep(1000)

// Memutar suara sebagai voice note
let soundPath = './mp3/menu.mp3'; // Path file suara
lenwy.sendMessage(m.chat, { 
    audio: { url: soundPath }, 
    mimetype: 'audio/mp4',
    ptt: true // Mengubah audio menjadi voice note
}, { quoted: m });

    // Kirim teks Game menu
    lenwyreply(`
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ    G A M E     ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Asah Otak  
   ⏣ • Family 100  
   ⏣ • Kuismath Easy  
   ⏣ • Kuismath Extreme  
   ⏣ • Kuismath Hard  
   ⏣ • Kuismath Impossible  
   ⏣ • Kuismath Impossible 2  
   ⏣ • Kuismath Noob  
   ⏣ • Susun Kata  
   ⏣ • Siapakah Aku  
   ⏣ • Tebak Bendera  
   ⏣ • Tebak Kalimat  
   ⏣ • Tebak Karakter FF  
   ⏣ • Tebak Kata  
   ⏣ • Tebak Kimia  
   ⏣ • Tebak Lirik  
   ⏣ • Tebak Logo  
   ⏣ • Tebak Warna  
   ⏣ • Tebak Lontong  
   ⏣ • Tebaktebakan  
   ⏣ • Tekateki  
   ⏣ • Tebak Hero ML  
   ⏣ • TTC
    `)
}
break

case 'nonton':
case 'nontontv': {
    if (isBan) return lenwyreply('Kamu Di Ban Owner')
    LenwyLD()
    await sleep(1000)

// Memutar suara sebagai voice note
let soundPath = './mp3/menu.mp3'; // Path file suara
lenwy.sendMessage(m.chat, { 
    audio: { url: soundPath }, 
    mimetype: 'audio/mp4',
    ptt: true // Mengubah audio menjadi voice note
}, { quoted: m });

    // Kirim teks Game menu
    lenwyreply(`
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ    ＮＯＮＴＯＮＴＶ   ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Globaltv
   ⏣ • Gtv
   ⏣ • Rcti
   ⏣ • Mnctv
   ⏣ • Trans7
   ⏣ • Transtv
   ⏣ • Antv
   ⏣ • Sctv
   ⏣ • Nettv
   ⏣ • Net
   ⏣ • Indosiar
    `)
}
break

case 'funmenu': {
if (isBan) return lenwyreply('Kamu Di Ban Owner')
LenwyLD()
await sleep(1000)
lenwyreply(`
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ    F U N   ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Apakah  
   ⏣ • Bagaimanakah  
   ⏣ • Bisakah  
   ⏣ • CekCantik  
   ⏣ • CekGantengCewek  
   ⏣ • CantikCewek  
   ⏣ • Dare  
   ⏣ • GantengCewek  
   ⏣ • Kapankah  
   ⏣ • Stalkyoutube
   ⏣ • Stalkff
   ⏣ • Stalktele
   ⏣ • Stalkmc
   ⏣ • Stalktiktok
   ⏣ • stalktiktok2
   ⏣ • Stalkig
   ⏣ • Rate  
   ⏣ • Truth
`)
}
break

case 'store':
case 'storemenu': {
    if (isBan) return lenwyreply('Kamu Di Ban Owner')
    LenwyLD()
    await sleep(1000)

// Memutar suara sebagai voice note
let soundPath = './mp3/menu.mp3'; // Path file suara
lenwy.sendMessage(m.chat, { 
    audio: { url: soundPath }, 
    mimetype: 'audio/mp4',
    ptt: true // Mengubah audio menjadi voice note
}, { quoted: m });

    // Kirim teks Store menu
    lenwyreply(`
┈──────────────────────⏣
      ⏤͟͟͞͞ᵡ    S T O R E     ᵡ͟͟͞͞⏤
┈──────────────────────⏣
   ⏣ • Addlist  
   ⏣ • Addtesti  
   ⏣ • Dellist  
   ⏣ • Deltesti  
   ⏣ • Done  
   ⏣ • Formatjp  
   ⏣ • Formatneed  
   ⏣ • Freerekber  
   ⏣ • List  
   ⏣ • Listtesti  
   ⏣ • Rules  
   ⏣ • Testimoni  
   ⏣ • Updatelist
    `)
}
break

case 'seftifikat':
case 'menuseftifikat': {
    if (isBan) return lenwyreply('Kamu Di Ban Owner')
    LenwyLD()
    await sleep(1000)

// Memutar suara sebagai voice note
let soundPath = './mp3/menu.mp3'; // Path file suara
lenwy.sendMessage(m.chat, { 
    audio: { url: soundPath }, 
    mimetype: 'audio/mp4',
    ptt: true // Mengubah audio menjadi voice note
}, { quoted: m });

    // Kirim teks Store menu
    lenwyreply(`
   ⏣ • Stkbaik
   ⏣ • Stkcantik
   ⏣ • Stkganteng
   ⏣ • Stkhitam
   ⏣ • Stkmiskin
   ⏣ • Stkkaya
   ⏣ • Stkmarah
   ⏣ • Stksabar
   ⏣ • Stksakiti
   ⏣ • Stkkeren
   ⏣ • Stkmisterius
   ⏣ • Stksombong
   ⏣ • Stksantai
   ⏣ • Stkgila
   ⏣ • Stklucu
    `)
}
break

case 'produk': {
let LenwyBP = `Daftar Produk

Mau Beli? Bisa Chat :
Chat : wa.me/6289673462138
Langsung Ke Tele : t.me/kayzuMD
  
*Tombol Dibawah Akan Menunjukkan Daftar Produk Yang Kami Jual*`
  
let LenwyP = `*Daftar Produk*
  
*Mau Beli? Bisa Chat :*
*Chat : wa.me/6289673462138*
*Langsung Ke Tele : t.me/kayzuMD*
  
*List Produk*
*Sc*
*Src*
*Shop*
*Sewa*
*Panel*
  
*Ketik Daftar Diatas Untuk Melihat Detail Produk*`
  if (lenwypro === 'LenwyP') {
  lenwy.sendMessage(m.chat, {
  /*video: fs.readFileSync('./data/video/menu.mp4')*/
  image : fs.readFileSync('./data/image/Kay.jpeg'),
  caption: LenwyP,
  gifPlayback: true,
  contextInfo: {
  externalAdReply: {
  showAdAttribution: true, 
  title: `${ucapanWaktu} ${pushname}`,
  body: "Lenwy",
  thumbnailUrl: "https://files.catbox.moe/cnsw60.jpg",
  sourceUrl: "https://whatsapp.com/channel/0029VatjTeULo4hk0RJlly0V",
  mediaType: 1,
  renderLargerThumbnail: false
                              }
                          }
                      }, {
                          quoted: m
                      })
                          } else if (lenwypro === 'Button') {
  let sections = [{
          title: 'List Produk',
          highlight_label: 'Favorit',
          rows: [{
          header: '🛍️ Beli Script',
          title: 'Script kayzuMD',
          description: `Beli Script kayzuMD`,
          id: `script`
          },
          {
          header: '🛍️ Beli Scrape',
          title: 'Scrape REST API',
          description: "Beli Scraper",
          id: `src`
          },
          {
          header: '🛍️ Beli Panel',
          title: 'Panel Pterodactyl',
          description: "Beli Panel Pterodactyl",
          id: `panel`
          },
          {        
          header: '🛍️ Sewa Bot',
          title: 'Sewa Bot',
          description: "Sewa Bot kayzuMD",
          id: `sewa`
          }]
          },
          { 
          title: '*メ*Saluran WhatsApp',
          highlight_label: 'Informasi',
          rows: [{
          header: 'Saluran',
          title: 'Saluran kayzuMD',
          description: `Link Download Sc kayzuMD`,
          id: `kayzu`
          }]
       }]
  let listMessage = {
  title: 'Menu', 
  sections
  };
  let msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
          "messageContextInfo": {
            "deviceListMetadata": {},
            "deviceListMetadataVersion": 2
          },
          interactiveMessage: proto.Message.InteractiveMessage.create({
           contextInfo: { 
              isForwarded: true, 
          },
            body: proto.Message.InteractiveMessage.Body.create({
              text: LenwyBP
            }),
            header: proto.Message.InteractiveMessage.Header.create({
              hasMediaAttachment: false,...(await prepareWAMessageMedia({ image : fs.readFileSync('./data/image/thumb2.png')}, { upload: lenwy.waUploadToServer})), 
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: [              
                {
                  "name": "single_select",
                  "buttonParamsJson": JSON.stringify(listMessage)
                },
                {
                "name": "quick_reply",
                "buttonParamsJson": "{\"display_text\":\"Owner\",\"id\":\".owner\"}"
                }
             ],
            })
          })
      }
    }
  }, { quoted: m })
  
  lenwy.relayMessage(msg.key.remoteJid, msg.message, {
    messageId: m.key.id
  })
  }
  }
  break

case 'help': {
lenwyreply(`
╔┈┈┈┈┈「 *HELP* 」┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈✧
╎╭─────────────────────────✧
╎│ 𝗣𝗮𝗻𝗱𝘂𝗮𝗻 𝗨𝗻𝘁𝘂𝗸 𝗠𝗲𝗻𝗴𝘂𝗻𝗮𝗸𝗮𝗻 𝗕𝗼𝘁
╎│•#𝟭 𝗠𝗲𝗺𝗯𝘂𝗮𝘁 𝗦𝘁𝗶𝗰𝗸𝗲𝗿 𝗙𝗼𝘁𝗼/𝗩𝗶𝗱𝗲𝗼
╎│•#𝟮 𝗡𝘆𝗮𝗿𝗶 𝗔𝗽𝗸 𝗠𝗼𝗱,𝗣𝗹𝗮𝘆𝘀𝘁𝗼𝗿𝗲,𝗙𝗶𝗹𝗺,𝗖𝗶𝗻𝗲𝗺𝗮 𝗗𝗹𝗹
╎│•#𝟯 𝗠𝗲𝗻𝗴𝘂𝗯𝗮𝗵 𝗪𝗮𝘁𝗲𝗿𝗺𝗮𝗿𝗸 𝗦𝘁𝗶𝗰𝗸𝗲𝗿
╎│•#𝟰 𝗠𝗲𝗻𝗶𝗻𝗴𝗸𝗮𝘁𝗸𝗮𝗻 𝗞𝘂𝗮𝗹𝗶𝘁𝗮𝘀 𝗙𝗼𝘁𝗼
╎│•#𝟱 𝗠𝗲𝗻𝗴𝘂𝗻𝗱𝘂𝗵 𝗩𝗶𝗱𝗲𝗼 𝗗𝗮𝗿𝗶 𝗟𝗶𝗻𝗸(𝗧𝗶𝗸𝘁𝗼𝗸,𝗜𝗴/𝗬𝘁)
╎│•#𝟲 𝗖𝗮𝗿𝗶 𝗠𝘂𝘀𝗶𝗸
╎│•#𝟳 𝗕𝗲𝗿𝘁𝗮𝗻𝘆𝗮 𝗣𝗮𝗱𝗮 𝗕𝗼𝘁
╎│•#𝟴 𝗙𝗶𝘁𝘂𝗿 𝗔𝗶
╎│•#𝟵 𝗠𝗲𝗻𝗰𝗮𝗿𝗶 𝗯𝗲𝗿𝗶𝘁𝗮
╎│•#𝟭𝟬 𝗜𝗻𝗳𝗼𝗺𝗮𝘀𝗶 𝗕𝗼𝘁
╎│•#𝟭𝟭 𝗠𝗲𝗻𝗴𝗲𝘁𝗮𝗵𝘂𝗶 𝗝𝗮𝗿𝗮𝗸 𝗞𝗼𝘁𝗮
╎│•#𝟭𝟮 𝗠𝗲𝗻𝗴𝗵𝗮𝗽𝘂𝘀 𝗣𝗲𝘀𝗮𝗻 𝗕𝗼𝘁
╎│
╎│𝗖𝗮𝗿𝗮 𝗠𝗲𝗻𝗴𝘂𝗻𝗮𝗸𝗮𝗻 𝗣𝗮𝗻𝗱𝘂𝗮𝗻 
╎│𝗞𝗲𝘁𝗶𝗸 𝗦𝗲𝘀𝘂𝗮𝗶 𝗡𝗼𝗺𝗼𝗿, 𝗖𝗼𝗻𝘁𝗼𝗵 : 𝗡𝗢𝟭
╎╰─────────────────────────✧
╚┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈✧
`)
}
break

case '#1': case 'no1': {
lenwyreply(`*Membuat Sticker Whatsapp*

Untuk Membuat Sticker Whatsapp Kirim Foto/Video Dengan Caption S, Stiker, Sticker*
Untuk Membuat Sticker Video Kirim Video Minimal 9 Detik Dengan CAption S*`)
}
break

case 'no2': {
lenwyreply(`*Nyari Apk Mod,Playstote,Film,Cinema Dll*

*Untuk Mencari Apk Mod Gunakan Command An1*
*Untuk Mencari Apk Playstore,Gunakan Command Playstore*
*Untuk Mencari Film,Gunakaan Command Film (judul film)*
*Untuk Mencari Cinema,Gunakan Command Cinema (judul Cinema)*
*Untuk Mengetahui Lebih Lanjut Gunakan Command (searchmenu)*
`)
}
break

case 'no3': {
lenwyreply(`*Mengubah Watermark Sticker*

Untuk Mengubah Watermark Sticker Reply Sticker Dengan Mengetik : Wm (Teks)*
Contoh : Wm kayzuMD*`)
}
break

case 'no4': {
lenwyreply(`*Meningkatkan Kualitas Gambar*

Untuk Meningkatkan Kualitas Gambar Kirim Gambar/Foto Dengan Caption Hd, Remini,hdr*`)
}
break

case 'no5': {
lenwyreply(`*Mengunduh Foto/Video Dari Link*

*Untuk Mengunduh Video Dari Link Ketik : Tiktok (Link Tiktok)*
*Untuk Mengunduh Video Dari Link Ketik : Ig (Link Ig)*
*Untuk Mengunduh Video Dari Link Ketik : Ytmp4 (Link Yt) Untuk Mp4*
Lebih Lengkapnya Ketik Downmenu*

*Pastikan Link Sesuai Dengan Perintah*`)
}
break

case 'no6': {
lenwyreply(`*Mengambil Audio/Video Dari Youtube*

*Untuk mengambil Audio/Video Dari Youtube Ketik : Ytmp4 (Link)*
*Ytmp3 Untuk Audio | Ytmp4 Untuk Video*
*Play (judul Lagu)*
*Song (judul Lagu)*
*Audio/Video Lebih Dari 8 Menit Kemungkinan Gagal Dikirim*`)
}
break

case 'no7': {
lenwyreply(`*Bertanya Kepada Bot*

*"Bertanya Kepada Bot" adalah suatu proses di mana pengguna dapat mengajukan pertanyaan atau permintaan informasi kepada program atau sistem otomatis, yang biasanya berbasis kecerdasan buatan (AI). Bot ini dirancang untuk memahami dan merespons pertanyaan dengan cara yang informatif dan relevan. Proses ini sering digunakan dalam berbagai aplikasi, seperti layanan pelanggan, pembelajaran daring, atau sebagai asisten pribadi.*`)
}
break

case 'no8': {
lenwyreply(`*Fitur Ai*

*Fitur AI (Kecerdasan Buatan) merupakan teknologi yang dirancang untuk meniru dan meningkatkan kemampuan manusia dalam berbagai aspek*
*Untuk Mengunakan Fitur Ai Gunakan Command (Aimenu)*`)
}
break

case 'no9': {
lenwyreply(`*Mencari Berita*

Untuk Mencari Berita Ketik : Inews*
Lebih Lengkapnya Ketik Beritamenu*`)
}
break

case 'no10': {
lenwyreply(`*𝗜𝗻𝗳𝗼𝗺𝗮𝘀𝗶 𝗕𝗼𝘁*

𝗕𝗼𝘁 𝗞𝗮𝘆𝘇𝘂 𝗠𝗗 𝗮𝗱𝗮𝗹𝗮𝗵 𝗯𝗼𝘁 𝗺𝘂𝗹𝘁𝗶𝗳𝘂𝗻𝗴𝘀𝗶 𝘆𝗮𝗻𝗴 𝗱𝗶𝗿𝗮𝗻𝗰𝗮𝗻𝗴 𝘂𝗻𝘁𝘂𝗸 𝗺𝗲𝗹𝗮𝘆𝗮𝗻𝗶 𝗯𝗲𝗿𝗯𝗮𝗴𝗮𝗶 𝗸𝗲𝗯𝘂𝘁𝘂𝗵𝗮𝗻 𝗽𝗲𝗻𝗴𝗴𝘂𝗻𝗮, 𝗯𝗮𝗶𝗸 𝗱𝗮𝗹𝗮𝗺 𝗴𝗿𝘂𝗽 𝗺𝗮𝘂𝗽𝘂𝗻 𝗽𝗲𝗿𝘀𝗼𝗻𝗮𝗹. 𝗕𝗲𝗿𝗶𝗸𝘂𝘁 𝗽𝗲𝗻𝗷𝗲𝗹𝗮𝘀𝗮𝗻 𝗺𝗲𝗻𝗴𝗲𝗻𝗮𝗶 𝗳𝗶𝘁𝘂𝗿 𝗱𝗮𝗻 𝗳𝘂𝗻𝗴𝘀𝗶 𝘂𝘁𝗮𝗺𝗮𝗻𝘆𝗮:


𝗙𝗶𝘁𝘂𝗿 𝗨𝘁𝗮𝗺𝗮

𝟭. 𝗜𝗻𝗳𝗼𝗿𝗺𝗮𝘀𝗶 𝗣𝗲𝗻𝗴𝗴𝘂𝗻𝗮: 𝗠𝗲𝗻𝗮𝗺𝗽𝗶𝗹𝗸𝗮𝗻 𝗱𝗮𝘁𝗮 𝘂𝘀𝗲𝗿 𝘀𝗲𝗽𝗲𝗿𝘁𝗶 𝗻𝗮𝗺𝗮, 𝘀𝘁𝗮𝘁𝘂𝘀, 𝗱𝗮𝗻 𝗷𝘂𝗺𝗹𝗮𝗵 𝗸𝗼𝗶𝗻.

𝟮. 𝗠𝗼𝗱𝗲 𝗕𝗼𝘁: 𝗗𝗮𝗽𝗮𝘁 𝗱𝗶𝗴𝘂𝗻𝗮𝗸𝗮𝗻 𝗱𝗮𝗹𝗮𝗺 𝗺𝗼𝗱𝗲 𝗽𝘂𝗯𝗹𝗶𝗸 𝗱𝗮𝗻 𝗣𝗿𝗶𝗯𝗮𝗱𝗶 𝗱𝗲𝗻𝗴𝗮𝗻 𝘄𝗮𝗸𝘁𝘂 𝗿𝘂𝗻𝘁𝗶𝗺𝗲 𝘆𝗮𝗻𝗴 𝘀𝘁𝗮𝗯𝗶𝗹.

𝗔𝘁𝘂𝗿𝗮𝗻 𝗕𝗼𝘁

𝟭. 𝗗𝗶𝗹𝗮𝗿𝗮𝗻𝗴 𝘀𝗽𝗮𝗺, 𝗺𝗲𝗻𝗲𝗹𝗽𝗼𝗻 𝗯𝗼𝘁, 𝗮𝘁𝗮𝘂 𝗺𝗲𝗻𝘆𝗮𝗹𝗮𝗵𝗴𝘂𝗻𝗮𝗸𝗮𝗻 𝗳𝗶𝘁𝘂𝗿.
𝟮. 𝗠𝗲𝗺𝗮𝘁𝘂𝗵𝗶 𝗯𝗮𝘁𝗮𝘀 𝗹𝗶𝗺𝗶𝘁 𝗵𝗮𝗿𝗶𝗮𝗻 𝘂𝗻𝘁𝘂𝗸 𝗽𝗲𝗻𝗴𝗴𝘂𝗻𝗮𝗮𝗻 𝗳𝗶𝘁𝘂𝗿 𝘁𝗲𝗿𝘁𝗲𝗻𝘁𝘂.
𝟯. 𝗛𝘂𝗯𝘂𝗻𝗴𝗶 𝗼𝘄𝗻𝗲𝗿 𝗷𝗶𝗸𝗮 𝘁𝗲𝗿𝗷𝗮𝗱𝗶 𝗸𝗲𝗻𝗱𝗮𝗹𝗮 𝘁𝗲𝗸𝗻𝗶𝘀.


𝗞𝘂𝘀𝘁𝗼𝗺𝗶𝘀𝗮𝘀𝗶 & 𝗣𝗲𝗺𝗯𝗮𝘆𝗮𝗿𝗮𝗻

𝗣𝗲𝗻𝗴𝗴𝘂𝗻𝗮 𝗱𝗮𝗽𝗮𝘁 𝗺𝗲𝗻𝗮𝗺𝗯𝗮𝗵𝗸𝗮𝗻 𝗳𝗶𝘁𝘂𝗿, 𝗺𝗲𝗺𝗲𝘀𝗮𝗻 𝗹𝗮𝘆𝗮𝗻𝗮𝗻 𝗽𝗿𝗲𝗺𝗶𝘂𝗺, 𝗮𝘁𝗮𝘂 𝗺𝗲𝗺𝗯𝗲𝗹𝗶 𝘀𝗰𝗿𝗶𝗽𝘁 𝗱𝗮𝗻 𝗽𝗮𝗻𝗲𝗹 𝗺𝗲𝗹𝗮𝗹𝘂𝗶 𝗺𝗲𝗻𝘂 𝗸𝗵𝘂𝘀𝘂𝘀.


𝗕𝗲𝗿𝗺𝗶𝗻𝗮𝘁 𝗺𝗲𝗻𝗴𝗴𝘂𝗻𝗮𝗸𝗮𝗻/𝗺𝗲𝗺𝗯𝗲𝗹𝗶 𝗯𝗼𝘁? 𝗛𝘂𝗯𝘂𝗻𝗴𝗶 𝗼𝘄𝗻𝗲𝗿 𝘂𝗻𝘁𝘂𝗸 𝗶𝗻𝗳𝗼𝗿𝗺𝗮𝘀𝗶 𝗹𝗲𝗯𝗶𝗵 𝗹𝗮𝗻𝗷𝘂𝘁!

𝗕𝗼𝘁 𝗶𝗻𝗶 𝘀𝗮𝗻𝗴𝗮𝘁 𝗳𝗹𝗲𝗸𝘀𝗶𝗯𝗲𝗹 𝗱𝗮𝗻 𝗰𝗼𝗰𝗼𝗸 𝗱𝗶𝗴𝘂𝗻𝗮𝗸𝗮𝗻 𝘂𝗻𝘁𝘂𝗸 𝗺𝗲𝗻𝗴𝗲𝗹𝗼𝗹𝗮 𝗴𝗿𝘂𝗽, 𝗺𝗲𝗻𝗰𝗮𝗿𝗶 𝗶𝗻𝗳𝗼𝗿𝗺𝗮𝘀𝗶, 𝗯𝗲𝗿𝗺𝗮𝗶𝗻 𝗴𝗮𝗺𝗲, 𝗮𝘁𝗮𝘂 𝘀𝗲𝗸𝗮𝗱𝗮𝗿 𝗵𝗶𝗯𝘂𝗿𝗮𝗻.`)
}
break

case 'no11': {
lenwyreply(`*Mengetahui Jarak Kota*

Untuk Mengetahui Jarak Kota ketik : Jarak (Nama Kota)|(Nama Kota)*
Contoh : Jarak Bandung|Jakarta*`)
}
break

case 'no12': {
lenwyreply(`*Menghapus Pesan Bot*

Untuk Menghapus Pesan Bot Balas Pesan Bot Dengan Mengetik : Del*`)
}
break

case 'liga': {
  if (isBan) return lenwyreply('*Kamu Di Ban Owner*');
  if (!q) return lenwyreply('*Masukkan Nama Liga*');
  const liga = q.toLowerCase();
  try {
    const result = await LenwyLiga(liga);
    if (Array.isArray(result) && result.length > 0) {
      let Lenwyy = '';
      result.forEach((team) => {
        Lenwyy += `🏆 *Peringkat ${team.rank} : ${team.name}*\n`;
        Lenwyy += `\n*Statistik :*\n*Pertandingan : ${team.match}*\n*Point : ${team.point}*\n*Menang : ${team.win}*\n*Seri : ${team.draw}*\n*Kalah : ${team.lose}*\n*Jumlah Goal : ${team.goals}*\n*GD : ${team.gd}*\n\n==============================\n\n`;
      });
      lenwyreply(Lenwyy);
    } else {
      lenwyreply('*Data Tidak Ditemukan!*');
    }
  } catch (err) {
    console.error(err);
    lenwyreply('*Terjadi Kesalahan, Coba Lagi Nanti!*');
  }
}
break

case 'kodebahasa': {
lenwyreply(`*Kode Bahasa*

 *⨠ Af: Afrikaans* 
 *⨠ Sq: Albanian*
 *⨠ Ar: Arabic*
 *⨠ Hy: Armenian*
 *⨠ Ca: Catalan* 
 *⨠ Zh: Chinese*
 *⨠ Zh-Cn: Chinese (Mandarin/China)*
 *⨠ Zh-Tw: Chinese (Mandarin/Taiwan)*
 *⨠ Zh-Yue: Chinese (Cantonese)*
 *⨠ Hr: Croatian*
 *⨠ Cs: Czech*
 *⨠ Da: Danish*
 *⨠ Nl: Dutch*
 *⨠ En: English*    
 *⨠ En-Au: English (Australia)*
 *⨠ En-Uk: English (United Kingdom)*
 *⨠ en-Us: English (United States)* 
 *⨠ Eo: Esperanto* 
 *⨠ Fi: Finnish* 
 *⨠ Fr: French*
 *⨠ De: German*
 *⨠ El: Greek* 
 *⨠ Ht: Haitian Creole* 
 *⨠ Hi: Hindi* 
 *⨠ Hu: Hungarian* 
 *⨠ Ss: Icelandic* 
 *⨠ Id: Indonesian* 
 *⨠ It: Italian*
 *⨠ Ja: Japanese*
 *⨠ Ko: Korean*
 *⨠ La: Latin*
 *⨠ Lv: Latvian*
 *⨠ Mk: Macedonian*
 *⨠ No: Norwegian*
 *⨠ Pl: Polish*
 *⨠ Pt: Portuguese*
 *⨠ Pt-Br: Portuguese (Brazil)*
 *⨠ Ro: Romanian*
 *⨠ Ru: Russian*
 *⨠ Sr: Serbian*
 *⨠ Sk: Slovak*
 *⨠ Es: Spanish* 
 *⨠ Es-Es: Spanish (Spain)*
 *⨠ Es-Us: Spanish (United States)*
 *⨠ Sw: Swahili*
 *⨠ Sv: Swedish*
 *⨠ Ta: Tamil*
 *⨠ Th: Thai*
 *⨠ Tr: Turkish*
 *⨠ Vi: Vietnamese* 
 *⨠ Cy: Welsh*

*Kalo Ada Error Bisa Chat Owner Ya*
`)
}
break

case 'sc': case 'buysc': case 'sellsc': case 'sellscript': {
    let imageUrl = 'https://files.catbox.moe/s7hwem.jpg'; // Gambar promosi SC KiromiMD

    let caption = `*ＳＥＬＬ ＳＣ ＫＩＲＯＭＩ ＭＤ* 🔥\n
🚀 _Script KiromiMD adalah script bot WhatsApp dengan 1000+ fitur yang siap pakai dan mudah dikonfigurasi. Cocok untuk bot pribadi, bot jualan, hingga bot komunitas!_\n\n
✨ *FITUR UNGGULAN:*\n
➵ 2 Mode Bot
➵ Runtime Stabil
➵ Anti Spam & Anti Call
➵ Fitur Anime & Weeb
➵ Download Menu
➵ Game & Rpg
➵ Asupan & Nonton
➵ Convert & Ephoto
➵ Premium Menu
➵ Store & Sertifikat
➵ Islamic Menu
➵ Fitur Update Berkala
➵ Optimasi Bot untuk Kecepatan Tinggi
➵ Support Multi-Device
➵ Fitur Keamanan Anti-Banned
➵ Support Semua Jenis File & Media
➵ Customizable Commands
➵ Easy to Configure
➵ Error-Free Performance
➵ Dan masih banyak lagi!\n
💰 *Harga?*
➤ *40.000 No update*
➤ *70.000 Free Update (Masuk gb khusus)*
📈 𝗙𝗶𝘁𝘂𝗿 𝟴𝟱𝟬++ 𝗱𝗮𝗻 𝗮𝗸𝗮𝗻 𝘁𝗲𝗿𝘂𝘀 𝗱𝗶𝘂𝗽𝗱𝗮𝘁𝗲 𝗱𝗲𝗻𝗴𝗮𝗻 𝗳𝗶𝘁𝘂𝗿 𝗯𝗮𝗿𝘂!`;

    let message = {
        image: { url: imageUrl },
        caption: caption
    };

    lenwy.sendMessage(m.chat, message, { quoted: m });
}
break

case 'list': case 'listmenu':{ 
if (db_respon_list.length === 0) return lenwyreply(`*Belum Ada List Yang Ditambahkan*`)
if (!isAlreadyResponListGroup(m.chat, db_respon_list)) return lenwyreply(`*Belum Ada List Yang Terdaftar Di Grup Ini*`)
let teks = `*Halo @${m.sender.split("@")[0]}*\n*Berikut Adalah List Item Yang Terdaftar Dalam Group :*\n`
for (let i of db_respon_list) {
if (i.id === m.chat) {
teks += `*⨠ ${i.key.toUpperCase()}*\n`
}
}
teks += `\n*Silahkan Ketik Nama Item Diatas Untuk Melihatnya Secara Detail*`
lenwy.sendMessage(m.chat, {text: teks, mentions: [m.sender]}, {quoted:m}) 
}
break

case'addlist': 
if (!m.isGroup) return lenwyreply(mess.group)
if (!isAdmins) return lenwyreply(mess.admin)
var args1 = q.split("|")[0].toLowerCase()
var args2 = q.split("|")[1]
if (!q.includes("|")) return lenwyreply(`*Cara Pengunaan : Addlist Item|Respon*\n*Contoh : Addlist Panel|list Panel lu *`)
if (isAlreadyResponList(m.chat, args1, db_respon_list)) return lenwyreply(`*Nama Item ${args1} Sudah Terdaftar Dalam Group Ini*`)
addResponList(m.chat, args1, args2, false, '-', db_respon_list)
lenwyreply(`*Sukses Menambahkan Item Dengan Kode : ${args1}*`)
break

case 'dellist': 
if (!m.isGroup) return lenwyreply(mess.group)
if (!isAdmins) return lenwyreply(mess.admin)
if (db_respon_list.length === 0) return lenwyreply(`*Belum Ada List Yang Ditambahkan*`)
if (!text) return lenwyreply(`*Ketik Nama Item Yang Ingin Dihapus*`)
if (!isAlreadyResponList(m.chat, q.toLowerCase(), db_respon_list)) return lenwyreply(`*Nama Item ${q} Tidak Terdaftar*`)
delResponList(m.chat, q.toLowerCase(), db_respon_list)
lenwyreply(`*Sukses Menghapus Item Dengan kode : ${q}*`)
break

case 'updatelist':
if (!m.isGroup) return lenwyreply(mess.group)
if (!isAdmins) return lenwyreply(mess.admin)
var args1 = q.split("|")[0].toLowerCase()
var args2 = q.split("|")[1]
if (!q.includes("|")) return lenwyreply(`*Cara Pengunaan : Updatelist Item|Respon*\n*Contoh : Updatelist kayzuMDy|Subscribe kayzu*`)
if (!isAlreadyResponListGroup(m.chat, db_respon_list)) return lenwyreply(`*Nama Item ${args1} Sudah Terdaftar Dalam Group Ini*`)
updateResponList(m.chat, args1, args2, false, '-', db_respon_list)
lenwyreply(`*Sukses Memperbarui Item Dengan Kode : ${args1}*`)
break

case 'addtesti':{
if (!isCreator) return lenwyreply(mess.owner)
if (!/image/.test(mime)) return lenwyreply(`*Mana Fotonya?*`)    
if (args.length < 1) return lenwyreply('*Berikan Nama Pada Image*')
if (imagenya.includes(q)) return lenwyreply("*Nama Tersebut Sudah Tersedia*")
let TestiLenwy = await lenwy.downloadAndSaveMediaMessage(quoted)
imagenya.push(q)
await fsx.copy(TestiLenwy, `./database/Testilenwy/${q}.jpg`)
fs.writeFileSync('./database/Lenwytesti.json', JSON.stringify(imagenya))
fs.unlinkSync(TestiLenwy)
lenwyreply(`*Sukses Menambahkan ${q} Kedalam Database*`)
}
break

case 'testi':
case 'testimoni':
if (!q) return lenwyreply(`*Masukkan Nama Testimoni Yang Tersedia*`)
let LenwyTesti = `*Testimoni Dalam Database Berhasil Dikirimkan*`     
lenwy.sendMessage(m.chat, {
image: fs.readFileSync(`./database/Testilenwy/${q}.jpg`), caption: LenwyTesti }, { quoted: m
})
break

case 'listtesti':
case 'listtestimoni':{
let teks = '*List Testimoni*\n'
for (let LenTesti of imagenya) {
teks += ` *⨠ ${LenTesti}*\n`
}
teks += `\n*Total Testimoni : ${imagenya.length}*`
lenwyreply(teks)
}
break

case 'deltesti':{
if (!isCreator) return lenwyreply(mess.owner)
if (args.length < 1) return lenwyreply('*Masukkan Nama Imagenya*')
if (!imagenya.includes(q)) return lenwyreply(`*${q} Tidak Ditemukan Dalam Database*`)
let wanu = imagenya.indexOf(q)
imagenya.splice(wanu, 1)
fs.writeFileSync('./database/Lenwytesti.json', JSON.stringify(imagenya))
fs.unlinkSync(`./database/Testilenwy/${q}.jpg`)
lenwyreply(`*Sukses Menghapus ${q} Dalam Database*`)
}
break 

case 'tambah':{
if (!text.includes('+')) return lenwyreply(`*Contoh : 10.000 + 20.000*`)
arg = args.join(' ')
lenwy1 = arg.split('+')[0]
lenwy2 = arg.split('+')[1]
var lenwy_1 = Number(lenwy1)
var lenwy_2 = Number(lenwy2)
lenwyreply(`*Hasil :* ${lenwy_1 + lenwy_2}`)}
break

case 'kurang':{
if (!text.includes('-')) return lenwyreply(`*Contoh : 20 - 10*`)
arg = args.join(' ')
lenwy1 = arg.split('-')[0]
lenwy2 = arg.split('-')[1]
var lenwy_1 = Number(lenwy1)
var lenwy_2 = Number(lenwy2)
lenwyreply(`*Hasil :* ${lenwy_1 - lenwy_2}`)}
break

case 'kali':{
if (!text.includes('*')) return lenwyreply(`*Contoh : 5 * 10*`)
arg = args.join(' ')
lenwy1 = arg.split('*')[0]
lenwy2 = arg.split('*')[1]
var lenwy_1 = Number(lenwy1)
var lenwy_2 = Number(lenwy2)
lenwyreply(`*Hasil :* ${lenwy_1 * lenwy_2}`)}
break

case 'bagi':{
if (!text.includes('/')) return lenwyreply(`*Contoh : 10 / 2*`)
arg = args.join(' ')
lenwy1 = arg.split('/')[0]
lenwy2 = arg.split('/')[1]
var lenwy_1 = Number(lenwy1)
var lenwy_2 = Number(lenwy2)
lenwyreply(`*Hasil :* ${lenwy_1 / lenwy_2}`)}
break

case 'order':
case 'pesanan': {
let lenwy_txt = args[0]
if (!text) return lenwyreply('*Mana Teksnya?*')
if (text.length > 15) return lenwyreply(`*Maksimal 15 Karakter*`)    
lenwyreply('*Pesanan Berhasil Terkirim*\n*Pesanan Anda Akan Dibalas Secepatnya, Terimakasih*')
lenwy.sendMessage(`${mess.owner2}@s.whatsapp.net`, { text: `*Pesanan Nih*\n*Dari :* @${sender.split('@')[0]}\n*Nomor :* ${sender.split('@')[0]}\n*Pemesan :* wa.me/${sender.split('@')[0]}\n*Order :* ${q}\n\n*Pesanan Ini Dikirim Oleh Bot Kayzu*`, mentions: [sender]}, { quoted: m })
}
break

case 'pay':
case 'paymet': {
    // Kirim pesan tunggu
    await lenwyreply('Menyiapkan QRIS...');

    // Kirim gambar QRIS dengan backticks
    await lenwy.sendMessage(m.chat, { image: { url: 'https://files.catbox.moe/ry1rfi.jpg' }, caption: 'Pembayaran Lain:\n```\n- Dana:  6285274156161 (AN/AF)\n- Gopay: 628979847953  (AN/KH)\n- OVO:   6289673462138 (AN/AS)\n- QRIS lainnya: Mocipay, Orkut\n```' }, { quoted: m });
}
break

case 'saran':{
let lenwy_txt = args[0]
if (!text) return lenwyreply('*Mana Teksnya?*')
if (text.length > 300) return lenwyreply(`*Maksimal 300 Karakter*`)    
lenwyreply('*Saran Berhasil Terkirim, Terimakasih*')
lenwy.sendMessage(`${mess.owner2}@s.whatsapp.net`, { text: `*Saran / Masukan*\n*Dari :* @${sender.split('@')[0]}\n*Pesan :* ${q}\n\n *Saran Ini Dikirim Oleh Bot Kayzu*`, mentions: [sender]}, { quoted: m })
}
break

case 'reportbug':{
let lenwy_txt = args[0]
if (!text) return lenwyreply('*Mana Teksnya?*')
if (text.length > 100) return lenwyreply(`*Maksimal 100 Karakter*`)    
lenwyreply('*Report Berhasil Terkirim, Terimakasih*')
lenwy.sendMessage(`${mess.owner2}@s.whatsapp.net`, { text: `*Report Bug*\n*Dari :* @${sender.split('@')[0]}\n*Pesan :* ${q}\n\n *Laporan Ini Dikirim Oleh Bot Kayzu*`, mentions: [sender]}, { quoted: m })
}
break

case 'bot': {
    lenwyreply(`🤖 Bot Kayzu Aktif  
📌 Version: Elit Prime  
⏱️ Runtime: ${runtime(process.uptime())}  
📱 WhatsApp: wa.me/6289673462138  
📢 Telegram: t.me/kayzuMD  
ℹ️ For Information: Bot bisa digunakan pribadi asal sewa/buy.`);
}
break

case 'Linkgb':
case 'Ch': {
lenwyreply(`*Link Sc Kayzu Ada Di Deskripsi GB :*\n*#1* : https://chat.whatsapp.com/LgClK7WdFVJ6SS4mzG38TZ\n*#2* : https://chat.whatsapp.com/HvMo6WN8hZHLQwAbRrMtk8\n\n*Jangan Lupa Follow Ch*\n*#1* : https://whatsapp.com/channel/0029VatjTeULo4hk0RJlly0V\n*#2* : https://whatsapp.com/channel/0029Vb0wTu0LSmbkK0HSOL0x`)
}
break

case 'malas': {
if (!isCreator) return 
const t3xt = require(`./database/teks/${command}.json`)
const r4andT3xt = t3xt[Math.floor(Math.random() * t3xt.length)]
lenwy.sendMessage(from, { text: r4andT3xt }, { quoted: m })
}
break

case "listscfree": case 'listscfreebykay': case 'scfreebykay': {
lenwyreply(`*->*  sᴄʀɪᴘᴛ ᴀʟʟғɪᴛᴜʀ ᴡᴏʀᴋ ʙʏ ᴋᴀʏᴢᴜ
*->*  sᴄ ᴘᴜsʜ ᴋᴏɴᴛᴀᴋ sɪᴍᴘʟᴇ + ʙʀᴜᴛᴀʟ
*->*  ᴀɢ sᴛᴏʀᴇ (ɪɴsᴛᴏɴʟʏ)
*->*  ᴀʟᴘʜᴀ ʙᴏᴛᴠ 𝟷𝟾.𝟹
*->*  ʙʟᴀᴄᴋ ᴀɴɢɢᴇʟ 𝟸.𝟻 ᴇɴᴄ
*->*  ᴄᴘᴀɴᴇʟ ʟʏɴᴢᴢ ᴠ𝟻 ғɪxᴇᴅ
*->*  ᴏsᴀʀᴀɢɪ ᴠ𝟸.𝟶
*->*  ᴄᴘᴀɴᴇʟ ɴᴏ ʙᴜᴛᴛᴏɴ ғɪxᴇᴅ
*->*  ᴄᴘᴀɴᴇʟ ᴘʀɪᴠᴀᴛᴇ sʟɪᴍᴇ
*->*  ᴢᴇᴜs ᴠ𝟸
*->*  ʀᴜᴋᴀᴍᴅ ғɪx 𝟷.𝟽
*->*  xeonbugv8 vvip
*->*  ғɪɴɪᴄ ᴠ𝟼
*->*  ᴘᴇʀᴍᴇɴᴍɪsᴄ ᴠ𝟷𝟷\n\nᴊɪᴋᴀ ᴍᴀᴜ ᴅᴏɴᴡʟᴏᴀᴅ sᴄ ғʀᴇᴇ ᴄᴜᴋᴜᴘ ᴋᴇᴛɪᴋ\nᴋᴀʏ`)
}
break

case 'about':
case 'About':
case 'ABOUT': {
  lenwyreply(`*Tentang Bot Ini:*\n\nBot ini dirancang untuk memberikan kenyamanan dan kemudahan dalam berinteraksi di grup. Dilengkapi dengan berbagai fitur, bot ini dapat membantu dalam pengelolaan informasi, berbagi link penting, serta memberikan hiburan dan motivasi setiap harinya.\n\n*Fitur Utama:*\n- Menyediakan tautan grup dan channel yang relevan.\n- Memberikan kata-kata motivasi atau quotes untuk memulai hari.\n- Pengingat jadwal atau acara penting di grup.\n- Bantuan 24/7 untuk menjawab pertanyaan terkait bot dan grup.\n\nBot ini terus berkembang, dan kami senantiasa berusaha untuk memberikan yang terbaik untuk para penggunanya.\n\nJika kamu membutuhkan bantuan atau memiliki pertanyaan lebih lanjut, ketik *#help* atau hubungi admin kami.\n\nTerima kasih telah bergabung dan menggunakan bot ini! Kami berharap kamu mendapatkan manfaat sebanyak-banyaknya.`)
}
break

case 'credit': {
  lenwyreply(`☘️ Terimakasih kepada                                
Allah Swt
Kedua Orangtua Saya                     
Penyedia Apikey
Pengguna Bot Yang Selalu Support

📝 Credit : Lenwy
🎁 Base : Lenwy
🥇 Pengembang : (Kayzu—MD)

📣 Salam Hangat
Halo Semua, Sebelumnya Terimakasih Bagi Kalian Yang Sudah Menggunakan Atau Bahkan Mengembangkan Script Bot Lenwy Ini, Saya Sangat Berterimakasih Atas Segala Dukungan Yang Kalian Berikan, Disini Saya Mohon Bagi Kalian Yang Menggunakan Script Bot Lenwy Ini Tolong Untuk Tidak Menghapus Credit Yang Tertera Disini, Terimakasihh.

📑 Informasi Lebih Lengkap :
Whatsapp : wa.me/6283829814737
Telegram : t.me/ilenwy
Gmail : Ilenwyy@gmail.com
Instagram : ilenwy_
Youtube : Lenwy

📦 Seputar Informasi :
Grup Whatsapp : https://chat.whatsapp.com/LJViMFtwsTqLRSIY8aklKP
Saluran Whatsapp : https://whatsapp.com/channel/0029VaGdzBSGZNCmoTgN2K0u

Saya Lenwy Sangat Berterimakasih Dan Menghargai Tindakan Kalian Yang Sudah Membiarkan Credit Tertera Disini.

Perkenalkan gw Pengembangan Sc Lenwy
Nama : Kay
Umur : 16
kelas : 11
Hobi : Editing,Coding,BadmintonGaming
Alamat : Jalan Utama kabupaten Kepulauan Meranti (riau)

Salam Hangat dari Pengembang KiromiMD

Halo semuanya!
Lenwy, bot sederhana yang saya kembangkan dari awal, kini telah berevolusi menjadi KiromiMD, sebuah bot yang lebih canggih, lengkap, dan dirancang untuk memudahkan berbagai kebutuhan kalian.

Perjalanan ini penuh tantangan, tetapi setiap pembaruan adalah bukti dedikasi untuk memberikan yang terbaik bagi kalian. Dengan KiromiMD, saya berkomitmen untuk terus menghadirkan fitur inovatif yang relevan dan bermanfaat.

Dukungan kalian sangat berarti. Jika ada saran, kritik, atau sekadar ingin berdiskusi, jangan ragu untuk menghubungi saya di:
📩 Instagram : @kayzuoffc
📩 WhatsApp : 6289673462138

Grup Whatsapp : https://chat.whatsapp.com/LgClK7WdFVJ6SS4mzG38TZ
Terima kasih atas kepercayaan dan dukungannya. Mari kita terus berkembang bersama!

Salam hangat,
Kayzu – Pengembang KiromiMD`)
}
break

case 'nelz': {
    let teks = `TIDAK PERLU MENJADI BINTANG\nLANGIT JUGA TAU SIAPA YANG TERANG💫\n\n#NELZZ GAMTENG😝`;
    lenwyreply(teks);

    let audioPath = './mp3/nelz.mp3';
    if (fs.existsSync(audioPath)) {
        lenwy.sendMessage(from, { audio: { url: audioPath }, mimetype: 'audio/mp4', ptt: true }, { quoted: m });
    } else {
        lenwyreply('⚠️ Sound tidak ditemukan. Pastikan file ada di folder mp3.');
    }
}
break

case 'message': {
    let userId = m.sender;  // Mengambil ID pengguna yang mengirim pesan
    if (checkSpam(userId)) {
        lenwyreply('*⚠ Anda terdeteksi melakukan spam! Anda akan dibungkam sementara.*');
        // Membungkam pengguna atau memberi peringatan
        // Bisa mengirim perintah untuk membungkam, misalnya:
        // muteUser(userId); // Fungsi untuk membungkam pengguna, jika ada

        // Opsional: beri waktu hingga pengguna dapat mengirim pesan kembali
        setTimeout(() => {
            lenwyreply('*🟢 Anda sekarang dapat mengirim pesan lagi.*');
        }, 60000); // Setelah 60 detik, pengguna dapat mengirim pesan lagi
    } else {
        // Jika tidak spam, lanjutkan proses normal
        lenwyreply('*Pesan diterima!*');
    }
}
break

case 'sad':
case 'quotessad': {
  if (!isPrem) return lenwyreply('*Fitur Khusus Premium!*');
  
  let audioPath = './mp3/prank.mp3'; // Path lokasi file audio
  lenwy.sendMessage(m.chat, { audio: { url: audioPath }, mimetype: 'audio/mpeg', ptt: true }, { quoted: m });
}
break

case 'weather': {
    if (!text) return lenwyreply('*Masukkan nama lokasi yang ingin dicari cuacanya!*');
    lenwyreply('*One Moment, Please ☕*');

    try {
        const axios = require('axios');
        
        // URL API
        const apiURL = `https://botcahx.web.id/weather?text=${encodeURIComponent(text)}`;
        const { data } = await axios.get(apiURL);

        // Validasi respons
        if (data && data.status && data.result) {
            const weatherData = data.result;
            const result = `🌤️ *Info Cuaca untuk ${weatherData.location}*\n\n` +
                           `🔸 *Negara:* ${weatherData.country}\n` +
                           `🔸 *Cuaca:* ${weatherData.weather}\n` +
                           `🔸 *Suhu Saat Ini:* ${weatherData.currentTemp}\n` +
                           `🔸 *Suhu Maksimal:* ${weatherData.maxTemp}\n` +
                           `🔸 *Suhu Minimal:* ${weatherData.minTemp}\n` +
                           `🔸 *Kelembapan:* ${weatherData.humidity}\n` +
                           `🔸 *Kecepatan Angin:* ${weatherData.windSpeed}\n\n` +
                           `*Stay safe and plan your day accordingly!*`;
            lenwyreply(result.trim());
        } else {
            lenwyreply(`❌ *Tidak ada data cuaca untuk lokasi "${text}".*`);
        }
    } catch (error) {
        console.error("⚠ *Error Saat Mendapatkan Data Cuaca :*", error.message);
        lenwyreply("*Terjadi Kesalahan Dalam Proses Permintaan.*");
    }
}
break

case 'time':
case 'Time':
case 'TIME': {
  let currentTime = new Date().toLocaleTimeString('id-ID', { 
    hour: '2-digit', 
    minute: '2-digit', 
    second: '2-digit', 
    timeZone: 'Asia/Jakarta' // Menentukan zona waktu Jakarta
  });
  lenwyreply(`*Waktu Saat Ini:*\n\nSekarang adalah pukul ${currentTime}. Jangan lupa untuk menjaga waktu dan produktivitas!`)
}
break

case 'panel': {
lenwyreply(`
Daftar List Panel Private
List Panel Pterodactyl
Ram 1GB CPU 40% : Rp2.000
Ram 2GB CPU 80% : Rp4.000
Ram 3GB CPU 100% : Rp6.000
Ram 4GB CPU 120% : Rp8.000
Ram 5GB CPU 150% : Rp10.000
Ram 6GB CPU 175% : Rp12.000
Ram 7GB CPU 200% : Rp14.000
Ram 8GB CPU 245% : Rp16.000
Ram 9GB CPU 280% : Rp18.000
Panel Unlimited
20K/Bulan (Garansi 10 Hari)
30K/Bulan (Garansi 30 Hari)


Keuntungan
Garansi Full
Server Private Dijaga Setiap Hari
Anti Down/Anti DDoS
Anti Lag & Lebih Aman

Partner Panel
50.000 (Permanent)
Keuntungan PT Panel
Bisa jualan panel
Bebas edit panel dari 1-unlimited GB
Bisa open reseller
Bisa jual admin panel lagi
Bisa buat bot sepuasnya
Free Script Pribadi + All Script


Keuntungan Panel
Bisa buat panel sepuasnya
Bisa jual panel sepuasnya
Server (High Quality)
Bot Fast Respon
Garansi Full Anti Lari
Claim Garansi Mudah (Bawa Bukti Trx)

Note

Ada harga, ada kualitas
Server Private dijamin aman (Anti Colong Script)
Spek VPS RAM 16GB Core 4 (Public)
Spek VPS RAM 8GB Core 4 (Private)
Buy panel di sini sudah full garansi 100%
Dijamin ga nyesel

Mau beli? Bisa chat:
wa.me/6289673462138
wa.me/6289673462138
━━━━━━━━━━━━━━━━━━━━━━━━━━◧`)

}
break

case 'src': case 'scrape': case 'scraper': {
  lenwyreply(`*Scraper Beserta End Point*

*Mau Beli? Bisa Chat :*
*Chat :* wa.me/6289673462138
*Langsung Ke Tele :* t.me/kayzuMD

*Scraper AI*
*1. Ai4Chat : 5K*
*2. BlackboxAI : Free*
*3. GoodyAI : 5K*
*4. LenwyAI (Custom AI) : 5K*
*5. LuminAI : Free*
*6. ThinkanyAI : Free*

*Scraper Berita*
*1. Liputan6 : Free*
*2. MetroNews : 5K*
*3. TempoSearch : 5K*

*Scraper Downloader*
*1. YTDL Mp3 : 10K*
*2. YTDL Mp4 : 10K*
*3. TIktokDL : 5K*

*Scraper Search*
*1. An1 : 5K*
*2. Cinema : 5K*
*3. CountryLang : 5K*
*4. Fdroid : 5K*
*5. Film : 5K*
*6. FGT : 5k*
*7. Genshin : 5K*
*8. Goodreads : Free*
*9. InfoNegara : 5K*
*10. JadwalSholat : Free*
*11. JadwalTV : 5K*
*12. Liga : 10K*
*13. MataUang : 5K*
*14. MLMETA : 5K*
*15. PlayStore : 5K*
*16. RumaySho : Free*
*17. SimilarBand : 5K*
*18. Steam : 5K*
*19. Surah : Free*
*20. TurnBackHoax : 5K*
*21. Webtoons : 5K*
*22. WikiMedia : 5K*
*23. WikiQuote : 5K*
*24. Ypia : Free*
*25. ZeroChan : 5K*
*26. Guardian Tales : 10K*

*Scraper Tools*
*1. IP : 5K* 
*2. Morse : 5K*

*Disarankan Bertanya Sebelum Membeli ⚠*`)
}
break

case 'huft': {
if (!isCreator) return 
const t3xt = require(`./database/teks/${command}.json`)
const r4andT3xt = t3xt[Math.floor(Math.random() * t3xt.length)]
lenwy.sendMessage(from, { text: r4andT3xt }, { quoted: m })
}
break


case 'rate': {
if (!q) return lenwyreply(`*Contoh: ${prefix + command} Penampilan kayzu*`)
if (text.length > 40) return lenwyreply(`*Maksimal 40 Karakter*`)
const ra = ['5', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55', '60', '65', '70', '75', '80', '85', '90', '95', '100']
const te = ra[Math.floor(Math.random() * ra.length)]
lenwyreply(`*Rate : ${q}*\n*Jawaban : ${te}%*`)
}
break

case 'apakah': {
if (!q) return lenwyreply(`*Contoh: ${prefix + command} kayzu Marah*`)
if (text.length > 40) return lenwyreply(`*Maksimal 40 Karakter*`)
const apa = ['Iya', 'Tidak', 'Bisa Jadi', 'Betul']
const kah = apa[Math.floor(Math.random() * apa.length)]
lenwyreply(`*Pertanyaan : Apakah ${q}*\n*Jawaban : ${kah}*`)
}
break

case 'kapankah': {
if (!q) return lenwyreply(`*Contoh: ${prefix + command} Kayzu Marah*`)
if (text.length > 40) return lenwyreply(`*Maksimal 40 Karakter*`)
const kapan = ['5 Hari Lagi', '10 Hari Lagi', '15 Hari Lagi', '20 Hari Lagi', '25 Hari Lagi', '30 Hari Lagi', '35 Hari Lagi', '40 Hari Lagi', '45 Hari Lagi', '50 Hari Lagi', '55 Hari Lagi', '60 Hari Lagi', '65 Hari Lagi', '70 Hari Lagi', '75 Hari Lagi', '80 Hari Lagi', '85 Hari Lagi', '90 Hari Lagi', '95 Hari Lagi', '100 Hari Lagi', '5 Bulan Lagi', '10 Bulan Lagi', '15 Bulan Lagi', '20 Bulan Lagi', '25 Bulan Lagi', '30 Bulan Lagi', '35 Bulan Lagi', '40 Bulan Lagi', '45 Bulan Lagi', '50 Bulan Lagi', '55 Bulan Lagi', '60 Bulan Lagi', '65 Bulan Lagi', '70 Bulan Lagi', '75 Bulan Lagi', '80 Bulan Lagi', '85 Bulan Lagi', '90 Bulan Lagi', '95 Bulan Lagi', '100 Bulan Lagi', '1 Tahun Lagi', '2 Tahun Lagi', '3 Tahun Lagi', '4 Tahun Lagi', '5 Tahun Lagi', 'Besok', 'Lusa', `Abis Command Ini Juga Lu ${q}`]
const kapankah = kapan[Math.floor(Math.random() * kapan.length)]
lenwyreply(`*Pertanyaan : Kapankah ${q}*\n*Jawaban : ${kapankah}*`)
}
break

case 'bisakah': {
if (!q) return lenwyreply(`*Contoh: ${prefix + command} kayzu Marah*`)
if (text.length > 40) return lenwyreply(`*Maksimal 40 Karakter*`)
const bisa = ['Bisa', 'Gak Bisa', 'Gak Bisa Awokawok', 'TENTU KAMU PASTI BISA!!!!']
const ga = bisa[Math.floor(Math.random() * bisa.length)]
lenwyreply(`*Pertanyaan : Bisakah ${q}*\n*Jawaban : ${ga}*`)
}
break

case 'bagaimanakah': {
if (!q) return lenwyreply(`*Contoh: ${prefix + command} kayzu Marah*`)
if (text.length > 40) return lenwyreply(`*Maksimal 40 Karakter*`)
const gimana = ['Ya Begitulah', 'Gak Normal', 'Maaf Bot Tidak Bisa Menjawab', 'Coba Deh Cari Di Gugel', 'Kayaknya Lanjut Part 2', 'Kepo Kamu', 'Gimana Aja']
const ya = gimana[Math.floor(Math.random() * gimana.length)]
lenwyreply(`*Pertanyaan : Bagaimanakah ${q}*\n*Jawaban : ${ya}*`)
}
break

case 'gantengcek': case 'cekganteng': {
if (!q) return lenwyreply(`*Contoh: ${prefix + command} KayzuMD*`)
if (text.length > 40) return lenwyreply(`*Maksimal 40 Karakter*`)
const gan = ['Normal','Ganteng Njir','Ganteng Amat Bang','Jaga Penampilan Ya','Kurang :c','Lumayan','Boleh Juga']
const teng = gan[Math.floor(Math.random() * gan.length)]
lenwyreply(`*Nama ${q}*\n*Jawaban : ${teng}*`)
}
break

case 'cantikcek': case 'cekcantik': {
if (!q) return lenwyreply(`*Contoh: ${prefix + command} KayzuMD*`)
if (text.length > 40) return lenwyreply(`*Maksimal 40 Karakter*`)
const can = ['Normal','Cantik Njir','Cantik Amat Sih','Jaga Penampilan Ya','Kurang :c','Lumayan','Boleh Juga']
const tik = can[Math.floor(Math.random() * can.length)]
lenwyreply(`*Nama ${q}*\n*Jawaban : ${tik}*`)
}
break

case 'createqr': {
if (!isCreator) return lenwyreply(mess.owner)
LenwyLD()
const qrcode = require('qrcode')
if (!text) return lenwyreply(`*Contoh : Createqr kayzuMD*`)
const qyuer = await qrcode.toDataURL(text, { scale: 8 })
let data = new Buffer.from(qyuer.replace('data:image/png;base64,', ''), 'base64')
lenwy.sendMessage(from, { image: data, caption: mess.success }, { quoted: m })
}
break

case 'detectqr': {
if (!isCreator) return lenwyreply(mess.owner)
LenwyLD()
try {
mee = await lenwy.downloadAndSaveMediaMessage(quoted)
mem = await uptotelegra(mee)
const res = await fetch(`http://api.qrserver.com/v1/read-qr-code/?fileurl=${mem}`)
const data = await res.json() 
lenwyreply(util.format(data[0]))
} catch (err) {
lenwyreply(`*Mana Qrnya?*`)
}
}
break

case 'push':
case 'pushkontak':{
if (!isCreator) return lenwyreply(mess.owner)
if (m.isGroup) return lenwyreply(mess.private)
if (!text) return lenwyreply(`*Contoh : Pushkontak ID Group|Teks*\n*Untuk Mengetahui Id Group Ketik : Cekidgc*`)
global.idgcns = text.split("|")[0]
global.tekspushkon = text.split("|")[1]
const groupMetadataa = !m.isGroup? await lenwy.groupMetadata(global.idgcns).catch(e => {}) : ""
const participants = !m.isGroup? await groupMetadataa.participants : ""
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
if (isContacts) return
for (let mem of halls) {
contacts.push(mem)
fs.writeFileSync('./database/contacts.json', JSON.stringify(contacts))
if (/image/.test(mime)) {
media = await lenwy.downloadAndSaveMediaMessage(quoted)
memk = await uptotelegra(media)
await lenwy.sendMessage(mem, { image: { url: memk }, caption: global.tekspushkon })
await sleep(2000)
} else {
await lenwy.sendMessage(mem, { text: global.tekspushkon })
await sleep(2000)
}
}
lenwy.sendMessage("6289673462138@s.whatsapp.net", {text:`*Selesai*`})
}
break

case 'push2':
case 'pushkontak2':{
if (!isCreator) return lenwyreply(mess.owner)
if (!m.isGroup) return lenwyreply(mess.group)
if (!text) return lenwyreply(`*Contoh : Pushkontak2 ID Group|Teks*\n*Untuk Mengetahui Id Group Ketik : Cekidgc*`)
global.tekspushkonv2 = text
const groupMetadata = m.isGroup? await lenwy.groupMetadata(from).catch(e => {}) : ""
const participantts = m.isGroup? await groupMetadata.participants : ""
const halsss = await participantts.filter(v => v.id.endsWith('.net')).map(v => v.id)
if (isContacts) return
for (let men of halsss) {
contacts.push(men)
fs.writeFileSync('./database/contacts.json', JSON.stringify(contacts))
if (/image/.test(mime)) {
media = await lenwy.downloadAndSaveMediaMessage(quoted)
mem = await uptotelegra(media)
await lenwy.sendMessage(men, { image: { url: mem }, caption: global.tekspushkonv2 })
await sleep(3000)
} else {
await lenwy.sendMessage(men, { text: global.tekspushkonv2 })
await sleep(3000)
}
}
lenwy.sendMessage("6289673462138@s.whatsapp.net", {text:`*Selesai*`})
}
break

case 'savekontak': {
if (!isCreator) return lenwyreply(mess.owner)
lenwyreply(mess.wait)
try {
const uniqueContacts = [...new Set(contacts)];
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:WA [${index}] ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n");
return vcard; }).join("");
fs.writeFileSync("./database/contacts.vcf", vcardContent, "utf8");
} catch (err) {
lenwyreply(util.format(err))
} finally {
await lenwy.sendMessage(from, { document: fs.readFileSync("./database/contacts.vcf"), fileName: "contacts.vcf", caption: "*Selesai*", mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
fs.writeFileSync("./database/contacts.json", JSON.stringify(contacts))
}
}
break

case 'public': {
if (!isCreator) return lenwyreply(mess.owner) 
lenwy.public = true
lenwyreply('Sukses Change To Public')
}
break

case 'private': {
if (!isCreator) return lenwyreply(mess.owner) 
lenwy.public = false
lenwyreply('Sukses Change To Self')
}
break

case 'enc': {
            if (!isCreator) return lenwyreply(mess.owner)
            if (!q) return lenwyreply(`Contoh ${prefix+command} const adrian = require('adrian-api')`)
            let meg = await obfus(q)
            lenwyreply(`${meg.result}`)
        }
        break

case 'addprem':
if (!isCreator) return 
if (!args[0]) return lenwyreply(`*Mana Nomornya?*`)
bnnd = text.split("|")[0].replace(/[^0-9]/g, '')
let ceknye = await lenwy.onWhatsApp(bnnd + `@s.whatsapp.net`)
if (ceknye.length == 0) return lenwyreply(`*Nomor Tidak Valid!*`)
owner.push(bnnd)
fs.writeFileSync('./premium.json', JSON.stringify(owner))
lenwyreply(`*Nomor ${bnnd} Ditambahkan Kedalam Daftar Premium ☕*`)
break

case 'delprem':
if (!isCreator) return 
if (!args[0]) return lenwyreply(`*Mana Nomornya?*`)
yaki = text.split("|")[0].replace(/[^0-9]/g, '')
unp = owner.indexOf(yaki)
owner.splice(unp, 1)
fs.writeFileSync('./premium.json', JSON.stringify(owner))
lenwyreply(`*Nomor ${yaki} Di Hapus Dari Daftar Premium Anjir 😹*`)
break

case 'listprem':
 teksooo = '*List Premium*\n'
for (let i of owner) {
teksooo += `${i}\n`
}
teksooo += `\n*Total : ${owner.length}*`
lenwy.sendMessage(from, { text: teksooo.trim() }, 'extendedTextMessage', { quoted:m, contextInfo: { "mentionedJid": owner } })
break

case 'ban':  {
if (!isCreator) return lenwyreply(mess.owner)
if (!args[0]) return lenwyreply(`*Contoh : ${command} add 6289685155897*`)
if (args[1]) {
orgnye = args[1] + "@s.whatsapp.net"
} else if (m.quoted) {
orgnye = m.quoted.sender
}
const isBane = banned.includes(orgnye)
if (args[0] === "add") {
if (isBane) return lenwyreply('*Pengguna Ini telah Di Ban*')
banned.push(orgnye)
lenwyreply(`Succes ban Pengguna Ini`)
} else if (args[0] === "del") {
if (!isBane) return lenwyreply('*Pengguna Ini Telah Di hapus Dari Ban*')
let delbans = banned.indexOf(orgnye)
banned.splice(delbans, 1)
lenwyreply(`*Berhasil Menghapus Pengguna yang Di Ban*`)
} else {
lenwyreply("Error")
}
}
break

case 'unban': {
    if (!isCreator) return lenwyreply(mess.owner);
    if (!args[0]) return lenwyreply(`*Contoh : ${command} (62Xxx)*`);
    
    let orgnye;
    if (args[0]) {
        orgnye = args[0] + "@s.whatsapp.net";
    } else if (m.quoted) {
        orgnye = m.quoted.sender;
    }

    const isBane = banned.includes(orgnye); // Periksa apakah pengguna ada di daftar ban
    if (!isBane) {
        return lenwyreply('*Pengguna ini tidak ada dalam daftar ban.*');
    }

    // Menghapus pengguna dari daftar ban
    const delIndex = banned.indexOf(orgnye);
    banned.splice(delIndex, 1);

    lenwyreply(`*Pengguna @${orgnye.split('@')[0]} berhasil di-unban.*`);
}
break

case 'listban':
if (isBan) return lenwyreply('*Lu Di Ban Owner*')
 teksooop = `*List Ban*\n`
for (let ii of banned) {
teksooop += `⨠  ${ii}\n`
}
lenwyreply(teksooop)
break

case 'owner': case 'creator': {
await lenwy.sendContact(m.chat, author.map( i => i.split("@")[0]), m)
await lenwy.sendMessage(m.chat, {text: `*Halo Ini Kontak Ownerku Yaa*`}, {quoted: m})
}
break

case 'limit':{
if (isPrem) return lenwyreply('*Limit Kamu : Unlimited*')   
lenwyreply('*Sisa Limit Kamu : ' + (db.data.users[m.sender].limit) + ' Limit*')
}
break

case 'koin': case 'money': {
lenwyreply('💰 *Sisa Koin Kamu : ' + (db.data.users[m.sender].coin) + ' Koin Emas*')
}
break

case 'bonus': {
if (!m.isGroup) return lenwyreply(mess.group)
let user = db.data.users[m.sender]
let time = user.lenbonus + 86400000
if (new Date - user.lenbonus < 86400000) return lenwyreply(`⚠️ *Kamu Sudah Mengambil Bonus Harian*\n🕒 *Tunggu Selama ${LenTime(time - new Date())}*`)
let LenwyC = 20
user.coin += LenwyC * 1
user.lenbonus = new Date * 1
lenwyreply(`🎁 *Kamu Mendapatkan : +${LenwyC} Koin Emas*`)
}
break

case 'tidur': {
if (!m.isGroup) return lenwyreply(mess.group)
let user = db.data.users[m.sender]
let time = user.lentidur + 64800000
if (new Date - user.lentidur < 64800000) return lenwyreply(`⚠️ *Kamu Sudah Tertidur Sebelumnya*\n🕒 *Tunggu Selama ${LenTime(time - new Date())}*`)
const lent = await fetchJson(`https://raw.githubusercontent.com/Lenwyy/LenwyRPG/main/tidur.json`)
const len = lent[Math.floor(Math.random() * lent.length)]
let LenwyT = 50
user.stamina += LenwyT * 1
user.lentidur = new Date * 1
lenwyreply(`${len.LenwyRPG} ${len.LenwyRPG2}\n\n🍖 *Kamu Berhasil Memulihkan +${LenwyT} Stamina*`)
}
break

case 'makan': {
if (!m.isGroup) return lenwyreply(mess.group)
let user = db.data.users[m.sender]
let time = user.lenmakan + 1080000
if (new Date - user.lenmakan < 1080000) return lenwyreply(`⚠️ *Kamu Sudah Makan Sebelumnya*\n🕒 *Tunggu Selama ${LenTime(time - new Date())}*`)
const lent = await fetchJson(`https://raw.githubusercontent.com/Lenwyy/LenwyRPG/main/makan.json`)
const len = lent[Math.floor(Math.random() * lent.length)]
let LenwyM = Math.floor(Math.random() * 25)
user.stamina += LenwyM * 1
user.lenmakan = new Date * 1
lenwyreply(`${len.LenwyRPG}\n\n🍖 *Kamu Berhasil Memulihkan +${LenwyM} Stamina*`)
}
break

case 'minum': {
if (!m.isGroup) return lenwyreply(mess.group)
let user = db.data.users[m.sender]
let time = user.lenminum + 108000
if (new Date - user.lenminum < 108000) return lenwyreply(`⚠️ *Kamu Sudah Makan Sebelumnya*\n🕒 *Tunggu Selama ${LenTime(time - new Date())}*`)
const lent = await fetchJson(`https://raw.githubusercontent.com/Lenwyy/LenwyRPG/main/minum.json`)
const len = lent[Math.floor(Math.random() * lent.length)]
let LenwyMi = Math.floor(Math.random() * 15)
user.stamina += LenwyMi * 1
user.lenminum = new Date * 1
lenwyreply(`${len.LenwyRPG}\n\n🍖 *Kamu Berhasil Memulihkan +${LenwyMi} Stamina*`)
}
break

case 'bertarung': {
if (!m.isGroup) return lenwyreply(mess.group)
if (global.db.data.users[m.sender].stamina < 20) return lenwyreply('⚠️ *Kamu Tidak Memiliki Cukup Stamina*')
let user = db.data.users[m.sender]
let time = user.lentarung + 1080000
if (new Date - user.lentarung < 1080000) return lenwyreply(`⚠️ *Kamu Sudah Bertarung Sebelumnya*\n🕒 *Tunggu Selama ${LenTime(time - new Date())}*`)
const lent = await fetchJson(`https://raw.githubusercontent.com/Lenwyy/LenwyRPG/main/bertarung.json`)
const len = lent[Math.floor(Math.random() * lent.length)]
let LenwyTar = Math.floor(Math.random() * 25)
let LenwyTar1 = Math.floor(Math.random() * 20)
let LenwyTar2 = Math.floor(Math.random() * 40)
user.kekuatan += LenwyTar * 1
user.tahan += LenwyTar1 * 1
user.coin += LenwyTar2 * 1
user.lentarung = new Date * 1
lenwyreply(`${len.LenwyRPG} ${len.LenwyRPG2} ${len.LenwyRPG3}\n\n🎉 *Kamu Berhasil Meningkatkan*
*+${LenwyTar} Kekuatan* 
*+${LenwyTar1} Ketahanan*

💰 *Kamu Juga Mendapatkan +${LenwyTar2} Koin Emas*`)
}
db.data.users[m.sender].stamina -= 20
break

case 'berlatih': {
if (!m.isGroup) return lenwyreply(mess.group)
if (global.db.data.users[m.sender].stamina < 10) return lenwyreply('⚠️ *Kamu Tidak Memiliki Cukup Stamina*')
let user = db.data.users[m.sender]
let time = user.lenlatih + 180000
if (new Date - user.lenlatih < 180000) return lenwyreply(`⚠️ *Kamu Sudah Berlatih Sebelumnya*\n🕒 *Tunggu Selama ${LenTime(time - new Date())}*`)
const lent = await fetchJson(`https://raw.githubusercontent.com/Lenwyy/LenwyRPG/main/berlatih.json`)
const len = lent[Math.floor(Math.random() * lent.length)]
let LenwyBn = Math.floor(Math.random() * 15)
let LenwyBn1 = Math.floor(Math.random() * 10)
user.kekuatan += LenwyBn * 1
user.tahan += LenwyBn1 * 1
user.lenlatih = new Date * 1
lenwyreply(`${len.LenwyRPG}\n\n🎉 *Kamu Berhasil Meningkatkan*
*+${LenwyBn} Kekuatan* 
*+${LenwyBn1} Ketahanan*`)
}
db.data.users[m.sender].stamina -= 10
break

case 'memanah': {
if (!m.isGroup) return lenwyreply(mess.group)
if (global.db.data.users[m.sender].stamina < 10) return lenwyreply('⚠️ *Kamu Tidak Memiliki Cukup Stamina*')
let user = db.data.users[m.sender]
let time = user.lenpanah + 180000
if (new Date - user.lenpanah < 180000) return lenwyreply(`⚠️ *Kamu Sudah Memanah Sebelumnya*\n🕒 *Tunggu Selama ${LenTime(time - new Date())}*`)
const lent = await fetchJson(`https://raw.githubusercontent.com/Lenwyy/LenwyRPG/main/memanah.json`)
const len = lent[Math.floor(Math.random() * lent.length)]
let LenwyPn = Math.floor(Math.random() * 15)
let LenwyPn1 = Math.floor(Math.random() * 10)
user.kekuatan += LenwyPn * 1
user.tahan += LenwyPn1 * 1
user.lenpanah = new Date * 1
lenwyreply(`${len.LenwyRPG}\n\n🎉 *Kamu Berhasil Meningkatkan*
*+${LenwyPn} Kekuatan* 
*+${LenwyPn1} Ketahanan*`)
}
db.data.users[m.sender].stamina -= 10
break

case 'menebang': {
if (!m.isGroup) return lenwyreply(mess.group)
if (global.db.data.users[m.sender].stamina < 5) return lenwyreply('⚠️ *Kamu Tidak Memiliki Cukup Stamina*')
let user = db.data.users[m.sender]
let time = user.lennebang + 180000
if (new Date - user.lennebang < 180000) return lenwyreply(`⚠️ *Kamu Sudah Menebang Sebelumnya*\n🕒 *Tunggu Selama ${LenTime(time - new Date())}*`)
const lent = await fetchJson(`https://raw.githubusercontent.com/Lenwyy/LenwyRPG/main/menebang.json`)
const len = lent[Math.floor(Math.random() * lent.length)]
let LenwyMe = Math.floor(Math.random() * 10)
user.coin += LenwyMe * 1
user.lennebang = new Date * 1
lenwyreply(`${len.LenwyRPG}\n\n💰 *Kamu Berhasil Menghasilkan : +${LenwyMe} Koin Emas*`)
}
db.data.users[m.sender].stamina -= 5
break

case 'menambang': {
if (!m.isGroup) return lenwyreply(mess.group)
if (global.db.data.users[m.sender].stamina < 10) return lenwyreply('⚠️ *Kamu Tidak Memiliki Cukup Stamina*')
let user = db.data.users[m.sender]
let time = user.lentambang + 1080000
if (new Date - user.lentambang < 1080000) return lenwyreply(`⚠️ *Kamu Sudah Menebang Sebelumnya*\n🕒 *Tunggu Selama ${LenTime(time - new Date())}*`)
const lent = await fetchJson(`https://raw.githubusercontent.com/Lenwyy/LenwyRPG/main/menambang.json`)
const len = lent[Math.floor(Math.random() * lent.length)]
let LenwyMe = Math.floor(Math.random() * 20)
user.coin += LenwyMe * 1
user.lentambang = new Date * 1
lenwyreply(`${len.LenwyRPG}\n\n💰 *Kamu Berhasil Menghasilkan : +${LenwyMe} Koin Emas*`)
}
db.data.users[m.sender].stamina -= 10
break

case 'berburu': {
if (!m.isGroup) return lenwyreply(mess.group)
if (global.db.data.users[m.sender].stamina < 15) return lenwyreply('⚠️ *Kamu Tidak Memiliki Cukup Stamina*')
let user = db.data.users[m.sender]
let time = user.lenburu + 1080000
if (new Date - user.lenburu < 1080000) return lenwyreply(`⚠️ *Kamu Sudah Berburu Sebelumnya*\n🕒 *Tunggu Selama ${LenTime(time - new Date())}*`)
const lent = await fetchJson(`https://raw.githubusercontent.com/Lenwyy/LenwyRPG/main/berburu.json`)
const len = lent[Math.floor(Math.random() * lent.length)]
let LenwyBer = Math.floor(Math.random() * 20)
let LenwyBer1 = Math.floor(Math.random() * 10)
user.coin += LenwyBer * 1
user.kekuatan += LenwyBer1 * 1
user.lenburu = new Date * 1
lenwyreply(`${len.LenwyRPG}\n\n🎉 *Kamu Berhasil Mendapatkan* 
*+${LenwyBer} Koin Emas*
*+${LenwyBer1} Kekuatan*`)
}
db.data.users[m.sender].stamina -= 15
break

case 'memancing': {
if (!m.isGroup) return lenwyreply(mess.group)
if (global.db.data.users[m.sender].stamina < 10) return lenwyreply('⚠️ *Kamu Tidak Memiliki Cukup Stamina*')
let user = db.data.users[m.sender]
let time = user.lenmancing + 1080000
if (new Date - user.lenmancing < 1080000) return lenwyreply(`⚠️ *Kamu Sudah Memancing Sebelumnya*\n🕒 *Tunggu Selama ${LenTime(time - new Date())}*`)
const lent = await fetchJson(`https://raw.githubusercontent.com/Lenwyy/LenwyRPG/main/memancing.json`)
const len = lent[Math.floor(Math.random() * lent.length)]
let LenwyMa = Math.floor(Math.random() * 20)
user.coin += LenwyMa * 1
user.lenmancing = new Date * 1
lenwyreply(`${len.LenwyRPG}\n\n💰 *Kamu Berhasil Menghasilkan : +${LenwyMa} Koin Emas*`)
}
db.data.users[m.sender].stamina -= 10
break

case 'bertani': {
if (!m.isGroup) return lenwyreply(mess.group)
if (global.db.data.users[m.sender].stamina < 5) return lenwyreply('⚠️ *Kamu Tidak Memiliki Cukup Stamina*')
let user = db.data.users[m.sender]
let time = user.lentani + 1080000
if (new Date - user.lentani < 1080000) return lenwyreply(`⚠️ *Kamu Sudah Bertani Sebelumnya*\n🕒 *Tunggu Selama ${LenTime(time - new Date())}*`)
const lent = await fetchJson(`https://raw.githubusercontent.com/Lenwyy/LenwyRPG/main/bertani.json`)
const len = lent[Math.floor(Math.random() * lent.length)]
let LenwyTa = Math.floor(Math.random() * 20)
user.coin += LenwyTa * 1
user.lentani = new Date * 1
lenwyreply(`${len.LenwyRPG}\n\n💰 *Kamu Berhasil Menghasilkan : +${LenwyTa} Koin Emas*`)
}
db.data.users[m.sender].stamina -= 5
break

case 'berdagang': {
if (!m.isGroup) return lenwyreply(mess.group)
if (global.db.data.users[m.sender].stamina < 15) return lenwyreply('⚠️ *Kamu Tidak Memiliki Cukup Stamina*')
let user = db.data.users[m.sender]
let time = user.lendagang + 1080000
if (new Date - user.lendagang < 1080000) return lenwyreply(`⚠️ *Kamu Sudah Berdagang Sebelumnya*\n🕒 *Tunggu Selama ${LenTime(time - new Date())}*`)
const lent = await fetchJson(`https://raw.githubusercontent.com/Lenwyy/LenwyRPG/main/berdagang.json`)
const len = lent[Math.floor(Math.random() * lent.length)]
let LenwyDA = Math.floor(Math.random() * 25)
user.coin += LenwyDA * 1
user.lendagang = new Date * 1
lenwyreply(`${len.LenwyRPG}\n\n💰 *Kamu Berhasil Menghasilkan : +${LenwyDA} Koin Emas*`)
}
db.data.users[m.sender].stamina -= 15
break

case 'pengawal': {
if (!m.isGroup) return lenwyreply(mess.group)
if (global.db.data.users[m.sender].stamina < 20) return lenwyreply('⚠️ *Kamu Tidak Memiliki Cukup Stamina*')
let user = db.data.users[m.sender]
let time = user.lenwal + 1080000
if (new Date - user.lenwal < 1080000) return lenwyreply(`⚠️ *Kamu Sudah Mengawal Sebelumnya*\n🕒 *Tunggu Selama ${LenTime(time - new Date())}*`)
const lent = await fetchJson(`https://raw.githubusercontent.com/Lenwyy/LenwyRPG/main/pengawal.json`)
const len = lent[Math.floor(Math.random() * lent.length)]
let LenwyWAL = Math.floor(Math.random() * 40)
user.coin += LenwyWAL * 1
user.lenwal = new Date * 1
lenwyreply(`${len.LenwyRPG}\n\n💰 *Kamu Berhasil Menghasilkan : +${LenwyWAL} Koin Emas*`)
}
db.data.users[m.sender].stamina -= 20
break

case 'dungeon': {
if (!m.isGroup) return lenwyreply(mess.group)
if (global.db.data.users[m.sender].stamina < 30) return lenwyreply('⚠️ *Kamu Tidak Memiliki Cukup Stamina*')
let user = db.data.users[m.sender]
let time = user.lendun + 64800000
if (new Date - user.lendun < 64800000) return lenwyreply(`⚠️ *Kamu Sudah Dungeon Sebelumnya*\n🕒 *Tunggu Selama ${LenTime(time - new Date())}*`)
const lent = await fetchJson(`https://raw.githubusercontent.com/Lenwyy/LenwyRPG/main/dungeon.json`)
const len = lent[Math.floor(Math.random() * lent.length)]
let LenwyDU = Math.floor(Math.random() * 80)
user.coin += LenwyDU * 1
user.lendun = new Date * 1
lenwyreply(`${len.LenwyRPG} ${len.LenwyRPG2}\n\n💰 *Kamu Berhasil Mendapatkan : +${LenwyDU} Koin Emas*`)
}
db.data.users[m.sender].stamina -= 30
break

case 'stamina': {
lenwyreply('🍖 *Sisa Stamina Kamu : ' + (db.data.users[m.sender].stamina) + ' Stamina*')
}
break

case 'stat': case 'status': {
{
lenstat = '🔰 *Rpg Status*\n\n'
lenstat += '⚔️ *Kekuatan : +' + (db.data.users[m.sender].kekuatan) + '*\n'
lenstat += '🛡️ *Daya Tahan : +' + (db.data.users[m.sender].tahan) + '*\n'
lenstat += '🍖 *Stamina : ' + (db.data.users[m.sender].stamina) + ' Stamina*\n'
lenstat += '💰 *Kekayaan : ' + (db.data.users[m.sender].coin) + ' Koin Emas*'
}    
lenwyreply(lenstat)
}
break

case 'resetlimit': {
if (!isCreator) return lenwyreply(mess.owner)
let list = Object.entries(global.db.data.users)
	let lim = !args || !args[0] ? 50 : isNumber(args[0]) ? parseInt(args[0]) : 50
	lim = Math.max(1, lim)
	list.map(([user, data], i) => (Number(data.limit = lim)))
		lenwy.sendMessage(m.chat, {text: `*Limit Setiap User Berhasil Direset*`}, { quoted: len })
		}
break

case 'resetkoin': {
if (!isCreator) return lenwyreply(mess.owner)
let list = Object.entries(global.db.data.users)
    let lim = !args || !args[0] ? 15 : isNumber(args[0]) ? parseInt(args[0]) : 15
    lim = Math.max(1, lim)
    list.map(([user, data], i) => (Number(data.coin = lim)))
        lenwy.sendMessage(m.chat, {text: `*Koin Emas Setiap User Berhasil Direset*`}, { quoted: len })
        }
break

case 'addlimit': {
if (!isCreator) return lenwyreply(mess.owner)
if (!text) return lenwyreply('*Masukkan Jumlah Limit Yang Akan Diberi*')
    let who
    if (m.isGroup) who = m.mentionedJid[0]
    else who = m.chat
    if (!who) throw '*Tag Orangnya*'
    let txt = text.replace('@' + who.split`@`[0], '').trim()
    if (isNaN(txt)) throw '*Hanya Angka*'
    let poin = parseInt(txt)
    let limit = poin
    if (limit < 1) throw '*Minimal 1*'
    let user = global.db.data.users
    user[who].limit += poin
    if (limit > 999999999999) return lenwyreply('*Kebanyakan*') 
    lenwy.sendMessage(m.chat, {text: `*Sukses Menambahkan +${poin} Limit!*`}, {quoted:m})
    }
break

case 'dellimit': {
if (!isCreator) return lenwyreply(mess.owner)
if (!text) return lenwyreply('*Masukkan Jumlah Limit Yang Akan Dihapus*')
    let who
    if (m.isGroup) who = m.mentionedJid[0]
    else who = m.chat
    if (!who) throw '*Tag Orangnya*'
    let txt = text.replace('@' + who.split`@`[0], '').trim()
    if (isNaN(txt)) throw '*Hanya Angka*'
    let poin = parseInt(txt)
    let limit = poin
    if (limit < 1) throw '*Minimal 1*'
    let user = global.db.data.users
    user[who].limit -= poin
    if (limit > 999999999999) return lenwyreply('*Kebanyakan*') 
    lenwy.sendMessage(m.chat, {text: `*Sukses Menghapus -${poin} Limit!*`}, {quoted:m})
    }
break

case 'addkoin': {
if (!isCreator) return lenwyreply(mess.owner)
if (!text) return lenwyreply('*Masukkan Jumlah Koin Yang Akan Diberi*')
    let who
    if (m.isGroup) who = m.mentionedJid[0]
    else who = m.chat
    if (!who) throw '*Tag Orangnya*'
    let txt = text.replace('@' + who.split`@`[0], '').trim()
    if (isNaN(txt)) throw '*Hanya Angka*'
    let poin = parseInt(txt)
    let coin = poin
    if (coin < 1) throw '*Minimal 1*'
    let user = global.db.data.users
    user[who].coin += poin
    if (coin > 999999999999) return lenwyreply('*Kebanyakan*') 
    lenwy.sendMessage(m.chat, {text: `*Sukses Menambahkan +${poin} Koin Emas!*`}, {quoted:m})
    }
break

case 'delkoin': {
if (!isCreator) return lenwyreply(mess.owner)
if (!text) return lenwyreply('*Masukkan Jumlah Koin Yang Akan Diberi*')
    let who
    if (m.isGroup) who = m.mentionedJid[0]
    else who = m.chat
    if (!who) throw '*Tag Orangnya*'
    let txt = text.replace('@' + who.split`@`[0], '').trim()
    if (isNaN(txt)) throw '*Hanya Angka*'
    let poin = parseInt(txt)
    let coin = poin
    if (coin < 1) throw '*Minimal 1*'
    let user = global.db.data.users
    user[who].coin -= poin
    if (coin > 999999999999) return lenwyreply('*Kebanyakan*') 
    lenwy.sendMessage(m.chat, {text: `*Sukses Menghapus -${poin} koin Emas!*`}, {quoted:m})
    }
break

case 'addstamina': {
if (!isCreator) return lenwyreply(mess.owner)
if (!text) return lenwyreply('*Masukkan Jumlah Stamina Yang Akan Diberi*')
    let who
    if (m.isGroup) who = m.mentionedJid[0]
    else who = m.chat
    if (!who) throw '*Tag Orangnya*'
    let txt = text.replace('@' + who.split`@`[0], '').trim()
    if (isNaN(txt)) throw '*Hanya Angka*'
    let poin = parseInt(txt)
    let stamina = poin
    if (stamina < 1) throw '*Minimal 1*'
    let user = global.db.data.users
    user[who].stamina += poin
    if (stamina > 999999999999) return lenwyreply('*Kebanyakan*') 
    lenwy.sendMessage(m.chat, {text: `*Sukses Menambahkan +${poin} Stamina!*`}, {quoted:m})
    }
break

case 'delstamina': {
if (!isCreator) return lenwyreply(mess.owner)
if (!text) return lenwyreply('*Masukkan Jumlah Stamina Yang Akan Diberi*')
    let who
    if (m.isGroup) who = m.mentionedJid[0]
    else who = m.chat
    if (!who) throw '*Tag Orangnya*'
    let txt = text.replace('@' + who.split`@`[0], '').trim()
    if (isNaN(txt)) throw '*Hanya Angka*'
    let poin = parseInt(txt)
    let stamina = poin
    if (stamina < 1) throw '*Minimal 1*'
    let user = global.db.data.users
    user[who].stamina -= poin
    if (stamina > 999999999999) return lenwyreply('*Kebanyakan*') 
    lenwy.sendMessage(m.chat, {text: `*Sukses Menghapus -${poin} Stamina!*`}, {quoted:m})
    }
break

case 'polling': {
    if (!text.includes('|')) return lenwyreply('Format salah!\n\nContoh: .polling Malming ini kemana? | Jalan-jalan | Duduk di rumah | Lagi rebahan')

    let [question, ...options] = text.split('|').map(v => v.trim())
    if (options.length < 2) return lenwyreply('Minimal harus ada 2 pilihan!')

    let selectableCount = 1
    await lenwy.sendMessage(m.chat, { 
        poll: { 
            name: question, 
            values: options, 
            selectableCount 
        } 
    }, { quoted: m })
}
break

case 'hd': case 'hdr': case 'remini': {
  if (!quoted) return lenwyreply(`Fotonya Mana?`)
  if (!/image/.test(mime)) return lenwyreply(`*Fotonya Mana?*`)
  if (global.db.data.users[m.sender].limit < 1) return lenwyreply('*Limit Kamu Habis, Silahkan Hubunggi Kay/Tunggu besok*')

  // Menambahkan react dengan simbol ⏱️
  await lenwy.sendMessage(m.chat, {
    react: {
      text: "⏱️",
      key: m.key,
    }
  });

  let media = await quoted.download()
  let proses = await remini(media, "enhance");
  lenwy.sendMessage(m.chat, { image: proses, caption: '*Selesai*' }, { quoted: m })

  // Mengurangi limit meskipun notifikasi diganti
  if (!isPrem) db.data.users[m.sender].limit -= 5

  // Ganti emoji setelah proses selesai
  await lenwy.sendMessage(m.chat, {
    react: {
      text: "✅",
      key: m.key,
    }
  });
}
break

case 'hdvideo':
case 'hdvid': {
  if (!m.quoted) return lenwyreply("Reply video yang ingin di-HD-kan!");
  
  const mime = m.quoted.mimetype || '';
  if (!mime.includes('video')) return lenwyreply("Format tidak didukung! Reply video yang benar.");

  lenwyreply("Wait... proses agak lama cuy");

  const fs = require('fs');
  const { exec } = require('child_process');
  const path = require('path');

  const media = await m.quoted.download();
  const inputPath = path.join(__dirname, 'temp_input.mp4');
  const outputPath = path.join(__dirname, 'temp_output.mp4');

  fs.writeFileSync(inputPath, media);

  exec(`ffmpeg -i "${inputPath}" -s 1280x720 -c:v libx264 -c:a copy "${outputPath}"`, async (error, stdout, stderr) => {
    if (error) {
      console.error(`Error: ${error.message}`);
      lenwyreply('*Terjadi kesalahan saat memproses video!*');
      return;
    }

    console.log(`stdout: ${stdout}`);
    console.error(`stderr: ${stderr}`);

    await lenwy.sendMessage(m.chat, { caption: `_Success To Enhanced Video_`, video: fs.readFileSync(outputPath) }, { quoted: m });

    fs.unlinkSync(inputPath);
    fs.unlinkSync(outputPath);
  });
}
break

case 'toaudio': case 'audio': {
  if (isBan) return lenwyreply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*'); // Jika di-ban, kirim pesan
  
  // Pastikan media ada dan jenisnya sesuai
  if (!quoted) throw `*Send/Reply the Video/Audio You Want to Use as Audio With Caption* ${prefix + command}`;
  
  // Pastikan media yang diterima berupa audio atau video
  if (!/video/.test(mime) && !/audio/.test(mime)) throw `*Send/Reply the Video/Audio You Want to Use as Audio With Caption* ${prefix + command}`;
  
  // Unduh media yang dikirim
  let media = await lenwy.downloadMediaMessage(quoted);
  
  // Mengonversi file media menjadi audio (misalnya dari mp4 ke mp3)
  let { toAudio } = require('./lib/converter');
  let audio = await toAudio(media, 'mp4'); // Ubah format menjadi audio
  
  // Kirim audio yang sudah dikonversi
  lenwy.sendMessage(m.chat, { audio: audio, mimetype: 'audio/mpeg' }, { quoted: m });
}
break

case 'tovn': {
    if (!/video/.test(mime) && !/audio/.test(mime)) {
        return lenwyreply(`Kirim/Reply Video/Audio Yang Ingin Dijadikan Audio Dengan Caption ${prefix + command}`);
    }

    if (!quoted) {
        return lenwyreply(`Kirim/Reply Video/Audio Yang Ingin Dijadikan Audio Dengan Caption ${prefix + command}`);
    }

    // Kirim emoji "⏱️" sebagai tanda proses sedang berjalan
    await lenwy.sendMessage(m.chat, {
        react: {
            text: "⏱️",
            key: m.key,
        }
    });

    try {
        let media = await (m.quoted ? m.quoted.download() : m.download());
        
        // Kirim file audio dengan PTT format
        await lenwy.sendMessage(m.chat, {
            audio: media,
            mimetype: 'audio/mpeg',
            ptt: true
        }, { quoted: m });

    } catch (error) {
        lenwyreply(`Terjadi kesalahan saat mengonversi video/audio: ${error.message}`);
    }
}
break

case 'toptv': {
    if (!/video/.test(mime)) return lenwyreply(`Kirim/Reply Video Yang Ingin Dijadikan PTV Message Dengan Caption ${prefix + command}`);
    
    if ((m.quoted ? m.quoted.type : m.type) === 'videoMessage') {
        try {
            const anu = await (m.quoted ? m.quoted.download() : m.download());
            const msg = await generateWAMessageContent({ video: anu }, { upload: naze.waUploadToServer });
            await naze.relayMessage(m.chat, { ptvMessage: msg.videoMessage }, {});
        } catch (error) {
            lenwyreply(`Terjadi kesalahan saat memproses video: ${error.message}`);
        }
    } else {
        lenwyreply('Reply Video Yang Mau Di Ubah Ke PTV Message!');
    }
}
break

case 'rvo': case 'readvo': {
    if (!isQuotedViewOnce) return lenwyreply('Reply pesan view-once!');
    
    let type = Object.keys(m.quoted.message)[0];
    let quotedType = m.quoted.message[type];
    
    const { downloadContentFromMessage } = require("@whiskeysockets/baileys");
    let media = await downloadContentFromMessage(quotedType, type === "imageMessage" ? "image" : "video");
    
    let buffer = Buffer.from([]);
    for await (const chunk of media) {
        buffer = Buffer.concat([buffer, chunk]);
    }
    
    if (/video/.test(type)) {
        await lenwy.sendMessage(m.chat, { video: buffer, caption: quotedType.caption || "" }, { quoted: m });
    } else if (/image/.test(type)) {
        await lenwy.sendMessage(m.chat, { image: buffer, caption: quotedType.caption || "" }, { quoted: m });
    }
}
break

case 'toimg': {
  if (!m.quoted) return lenwyreply('Balas sticker dengan caption *toimg*');
  if (!/webp/.test(m.quoted.mimetype)) return lenwyreply('Yang kamu balas bukan stiker!');

  let media = await lenwy.downloadAndSaveMediaMessage(m.quoted);
  let outputFile = 'output.png';

  exec(`ffmpeg -i ${media} ${outputFile}`, (err) => {
    fs.unlinkSync(media); // Hapus file sementara
    if (err) {
      console.error(err);
      return lenwyreply('Terjadi kesalahan saat mengonversi stiker ke gambar.');
    }

    let buffer = fs.readFileSync(outputFile);
    lenwy.sendMessage(m.chat, { image: buffer }, { quoted: m });
    fs.unlinkSync(outputFile); // Hapus file output setelah dikirim
  });
}
break

case 'removebg': case 'nobg':{
if (!quoted) return lenwyreply(`Fotonya Mana?`)
if (!/image/.test(mime)) return lenwyreply(`*Mana Fotonya?*`)
if (global.db.data.users[m.sender].limit < 1) return lenwyreply('*Limit Kamu Habis, Silahkan Hubunggi Kay/Tunggu besok*')
lenwyreply('*5 Limit Digunakan*')
let media = await quoted.download()
let url = await uploadImage(media)
let anu = await fetch(`https://Meitang.xyz/removebg?url=${url}`)
let data = await anu.json()
await lenwy.sendFile(m.chat, data.url.result, 'Lenwy.jpg', '*Removebg Selesai*', { quoted: m})
}
if (!isPrem) return db.data.users[m.sender].limit -= 5
break

case 'toanime': case 'jadianime': {
if (!isPrem) return lenwyreply(mess.prem)
if (!quoted) return lenwyreply(`Fotonya Mana?`)
if (!/image/.test(mime)) return lenwyreply(`Send/Reply Foto Dengan Caption ${prefix + command}`)
lenwyreply(mess.wait)
const media = await lenwy.downloadAndSaveMediaMessage(quoted)
let anu = await TelegraPh(media)
lenwy.sendMessage(m.chat, { image: { url: `https://aemt.me/toanime?url=${anu}` }, caption: 'Selesai'}, { quoted: m})
}
break

/*case 'qc': {
const { quote } = require('./lib/quote.js')
if (!q) return lenwyreply(`*Contoh : Qc White Lenwy*\n*Kode Warna Ketik : Qckode*`)
if (text.length > 400) return lenwyreply(`*Maksimal 400 Karakter*`)
const isToxic = /(ewe|bangsad|mmk|koncol|puki|kojtol|kintil|momok|nigga|ajg|ewean|yatim|anjing|kontol|memek|bangsat|babi|goblok|goblog|kntl|pepek|ppk|ngentod|ngentd|ngntd|kentod|gblk|asu|jembut|memek|yapit|entot|puqi|kntd|bgst|anjg|anj|fuck|hitam|ireng|jawir|gay|asw|ktl|ngentot|ngewe|bokep|bkp)/i;
const Lenwyguard = isToxic.exec(m.text)
if (Lenwyguard) return lenwyreply('⚠ *Kayzu Melarang Penggunaan Bahasa Kotor Pada Fitur Qc*')
let ppnyauser = await await lenwy.profilePictureUrl(m?.sender, 'image').catch(_=> 'https://telegra.ph/file/6880771a42bad09dd6087.jpg')
const rest = await quote(text, pushname, ppnyauser)
lenwy.sendImageAsSticker(m?.chat, rest.result, m, { packname: `${global.packname}`, author: `${global.author}`})
}
break*/

case 'qc': {
if (!q) return lenwyreply(`*Contoh : Qc White Kayzu*\n*Kode Warna Ketik : Qckode*`)
if (text.length > 400) return lenwyreply(`*Maksimal 400 Karakter*`)
const isToxic = /(ewe|bangsad|mmk|koncol|puki|kojtol|kintil|momok|nigga|ajg|ewean|yatim|anjing|kontol|memek|bangsat|babi|goblok|goblog|kntl|pepek|ppk|ngentod|ngentd|ngntd|kentod|gblk|asu|jembut|memek|yapit|entot|puqi|kntd|bgst|anjg|anj|fuck|hitam|ireng|jawir|gay|asw|ktl|ngentot|ngewe|bokep|bkp)/i;
const Lenwyguard = isToxic.exec(m.text)
if (Lenwyguard) return lenwyreply('⚠ *Kayzu Melarang Penggunaan Bahasa Kotor Pada Fitur Qc*')     
let [color, ...message] = text.split(' ');
message = message.join(' ');
let backgroundColor;
switch(color) {
case 'pink':
backgroundColor = '#f68ac9';
break
case 'blue':
backgroundColor = '#6cace4';
break
case 'red':
backgroundColor = '#f44336';
break
case 'green':
backgroundColor = '#4caf50';
break
case 'transparan':
backgroundColor = 'rgba(0, 0, 0, 0)'; // Transparan
break
case 'yellow':
backgroundColor = '#ffeb3b';
break
case 'purple':
backgroundColor = '#9c27b0';
break
case 'darkblue':
backgroundColor = '#0d47a1';
break
case 'lightblue':
backgroundColor = '#03a9f4'; 
break
case 'ash':
backgroundColor = '#9e9e9e';
break
case 'orange':
backgroundColor = '#ff9800';
break
case 'black':
backgroundColor = '#000000';
break
case 'white':
backgroundColor = '#ffffff';
break
case 'teal':
backgroundColor = '#008080';
break
case 'lightpink':
backgroundColor = '#FFC0CB';
break
case 'chocolate':
backgroundColor = '#A52A2A';
case 'salmon':
backgroundColor = '#FFA07A'; 
break 
case 'magenta':
backgroundColor = '#FF00FF'; 
break 
case 'tan':
backgroundColor = '#D2B48C'; 
break
case 'wheat':
backgroundColor = '#F5DEB3'; 
break
case 'deeppink':
backgroundColor = '#FF1493'; 
break 
case 'fire':
backgroundColor = '#B22222';
break
case 'skyblue':
backgroundColor = '#00BFFF';
break 
case 'orange':
backgroundColor = '#FF7F50';
break
case 'brightskyblue':
backgroundColor = '#1E90FF'; 
break 
case 'hotpink':
backgroundColor = '#FF69B4'; 
break 
case 'lightskyblue':
backgroundColor = '#87CEEB'; 
break 
case 'seagreen':
backgroundColor = '#20B2AA'; 
break 
case 'darkred':
backgroundColor = '#8B0000'; 
break 
case 'orangered':
backgroundColor = '#FF4500'; 
break 
case 'cyan':
backgroundColor = '#48D1CC'; 
break 
case 'violet':
backgroundColor = '#BA55D3'; 
break 
case 'mossgreen':
backgroundColor = '#00FF7F'; 
break 
case 'darkgreen':
backgroundColor = '#008000'; 
break 
case 'navyblue':
backgroundColor = '#191970'; 
break 
case 'darkorange':
backgroundColor = '#FF8C00'; 
break 
case 'darkpurple':
backgroundColor = '#9400D3'; 
break 
case 'fuchsia':
backgroundColor = '#FF00FF'; 
break 
case 'darkmagenta':
backgroundColor = '#8B008B'; 
break
case 'darkgray':
backgroundColor = '#2F4F4F'; 
break
case 'peachpuff':
backgroundColor = '#FFDAB9'; 
break
case 'darkishgreen':
backgroundColor = '#BDB76B'; 
break
case 'darkishred':
backgroundColor = '#DC143C'; 
break
case 'goldenrod':
backgroundColor = '#DAA520'; 
break
case 'darkishgray':
backgroundColor = '#696969'; 
break
case 'darkishpurple':
backgroundColor = '#483D8B'; 
break
case 'gold':
backgroundColor = '#FFD700'; 
break
case 'silver':
backgroundColor = '#C0C0C0'; 
break
default:
return lenwyreply('*Kode Warna Tidak Ditemukan*\n*Contoh : Qc White Kayzu*\n*Tolong Gunakan Huruf Kecil Pada Kode Warna*')
}
let obj = {
type: 'quote',
format: 'png',
backgroundColor,
width: 512,
height: 768,
scale: 2,
messages: [
{
entities: [],
avatar: true,
from: {
id: 1,
name: pushname,
photo: { 
url: await lenwy.profilePictureUrl(m.sender, "image").catch(() => 'https://telegra.ph/file/6880771a42bad09dd6087.jpg'),
}
},
text: message,
replyMessage: {},
},
],
};
let response = await axios.post('https://bot.lyo.su/quote/generate', obj, {
headers: {
'Content-Type': 'application/json',
},
});
let buffer = Buffer.from(response.data.result.image, 'base64');
lenwy.sendImageAsSticker(m.chat, buffer, m, { packname: `${global.packname}`, author: `${global.author}`})
}
break

// https://bot.lyo.su/quote/generate
// https://qc.sazumi.moe/generate
// https://quotly.netorare.codes 

case 'qckode': {
lenwyreply(`*Kode Warna Qc*
 *⨠ Pink*
 *⨠ Blue*
 *⨠ Red*
 *⨠ Green*
 *⨠ Transparan
 *⨠ Yellow*
 *⨠ Purple*
 *⨠ Darkblue*
 *⨠ Lightblue*
 *⨠ Ash*
 *⨠ Orange*
 *⨠ Black*
 *⨠ White*
 *⨠ Teal*
 *⨠ Lightpink*
 *⨠ Chocolate*
 *⨠ Salmon*
 *⨠ Magenta*
 *⨠ Tan*
 *⨠ Wheat*
 *⨠ Deeppink*
 *⨠ Fire*
 *⨠ Skyblue*
 *⨠ Safron*
 *⨠ Brightskyblue*
 *⨠ Hotpink*
 *⨠ Lightskyblue*
 *⨠ Seagreen*
 *⨠ Darkred*
 *⨠ Orangered*
 *⨠ Cyan*
 *⨠ Violet*
 *⨠ Mossgreen*
 *⨠ Darkgreen*
 *⨠ Navyblue*
 *⨠ Darkorange*
 *⨠ Darkpurple*
 *⨠ Fuchsia*
 *⨠ Darkmagenta*
 *⨠ Darkgray*
 *⨠ Peachpuff*
 *⨠ Blackishgreen*
 *⨠ Darkishred*
 *⨠ Goldenrod*
 *⨠ Darkishgray*
 *⨠ Darkishpurple*
 *⨠ Gold*
 *⨠ Silver*

*Kalo Ada Error Bisa Chat Owner Ya*
`)
}
break

case 'fitur': case 'totalfitur': {
lenwyreply(`*Total Fitur Bot Kayzu : ${totalfitur()} Fitur*`)
}
break

case 'ai': {
  if (!q) return lenwyreply(`*Mau Nanya Apa Sama AI?*`);
  if (q.length > 500) return lenwyreply(`*Maksimal 500 Karakter*`);
  lenwyreply('*One Moment, Please ☕*');
  try {
      const lenai = await Ai4Chat(q);
      if (!lenai) {
          return lenwyreply("*Tidak Ada Respons *Dari AI.*");
      }
      await lenwyreply(lenai);
  } catch (error) {
      console.error("⚠ *Error Saat Mendapatkan Data :*", error.message);
      lenwyreply("*Terjadi Kesalahan Dalam Proses Permintaan.*");
  }
}
break

case 'ask': {
if (!q) return lenwyreply(`*Mau Nanya Apa Sama Ask?*`)
if (text.length > 500) return lenwyreply(`*Maksimal 500 Karakter*`)
lenwyreply('*Sabar Yaa*')
var lenwyai = await fetchJson(`https://Meitang.xyz/turbo?text=${q}`)
var lenai = lenwyai.result
await lenwyreply(lenai)
}
break

case 'kay': {
  if (!q) return lenwyreply(`*Mau Ngobrol Apa Sama Kayzu?*`);
  if (q.length > 500) return lenwyreply(`*Maksimal 500 Karakter*`);
  lenwyreply('*One Moment, Please ><*');
  try {
      const lenResult = await iLenwy(q);
      if (!lenResult) {
          return lenwyreply("*Tidak Ada Respons dari API.*");
      }
      await lenwyreply(lenResult);
  } catch (error) {
      console.error("⚠ *Error Saat Mendapatkan Data :", error.message);
      lenwyreply("*Terjadi Kesalahan Dalam Proses Permintaan.*");
  }
}
break

/*case 'aili': {
if (!q) return lenwyreply(`*Mau Nanya Apa Sama AILI?*`)
if (text.length > 500) return lenwyreply(`*Maksimal 500 Karakter*`)    
lenwyreply('*Sabar Yaa*')
var lenwyai = await fetchJson(`https://aemt.me/prompt/gpt?prompt=Lenwy&text=${q}`)
var lenai = lenwyai.result
await lenwyreply(lenai)
}
break*/

case 'gpt4': {
if (!q) return lenwyreply(`*Mau Nanya Apa Sama GPT4?*`)
if (text.length > 500) return lenwyreply(`*Maksimal 500 Karakter*`)    
lenwyreply('*Sabar Yaa*')
var lenwyai = await fetchJson(`https://Meitang.xyz/gpt4?text=${q}`)
var lenai = lenwyai.result
await lenwyreply(lenai)
}
break

case 'bing': {
if (!isPrem) return lenwyreply(mess.prem)    
if (!q) return lenwyreply(`*Mau Nanya Apa Sama Bing?*`)
if (text.length > 500) return lenwyreply(`*Maksimal 500 Karakter*`)    
lenwyreply('*Sabar Yaa*')
var lenwyai = await fetchJson(`https://Meitang.xyz/bingai?text=${q}`)
var lenai = lenwyai.result
await lenwyreply(lenai)
}
break

case 'gemini': {
if (!q) return lenwyreply(`*Mau Nanya Apa Sama Gemini?*`)
if (text.length > 500) return lenwyreply(`*Maksimal 500 Karakter*`)    
lenwyreply('*Sabar Yaa*')
var lenwyai = await fetchJson(`https://Meitang.xyz/gemini?text=${q}`)
var lenai = lenwyai.result
await lenwyreply(lenai)
}
break

/*case 'simi': {
if (!q) return lenwyreply(`*Mau Nanya Apa Sama Simi?*`)
if (text.length > 200) return lenwyreply(`*Maksimal 200 Karakter*`)
var lenwyai = await fetchJson(`https://itzpire.com/ai/simi-chat?text=${q}&lang=id&toxic=false`)
var lenai = lenwyai.result
await lenwyreply(lenai)
}
break*/

case 'img2txt':
if (!/image/.test(mime)) return lenwyreply(`*Gambarnya Mana?*`)
if (/image/.test(mime)) {
lenwyreply(mess.wait)
let mee = await lenwy.downloadAndSaveMediaMessage(quoted)
let mem = await TelegraPh(mee)
let len = await (await fetch(`https://itzpire.com/tools/img2text?url=${mem}`)).json()
let result = len.result
lenwy.sendMessage(m.chat,{image:{url: mem}, caption:`${result}`},{quoted: m})
}
break

case 'img2promt':
if (!/image/.test(mime)) return lenwyreply(`*Gambarnya Mana?*`)
if (/image/.test(mime)) {
lenwyreply(mess.wait)
let mee = await lenwy.downloadAndSaveMediaMessage(quoted)
let mem = await TelegraPh(mee)
let len = await (await fetch(`https://itzpire.com/tools/img2prompt?url=${mem}`)).json()
let result = len.result
lenwy.sendMessage(m.chat,{image:{url: mem}, caption:`${result}`},{quoted: m})
}
break

case 'gemini-img':{
if (!quoted) return lenwyreply('*Mana Gambarnya?*')
lenwyreply('*Sabar Yaa*')
if (!/image/.test(mime)) return lenwyreply("*Hanya Support Gambar*")
let media = await lenwy.downloadAndSaveMediaMessage(quoted)
let anu = await TelegraPh(media)
let { data } = await axios.get("https://gmni.vercel.app/api/img?imageUrl="+ anu +"&prompt=" + text)
lenwyreply(data.text)
}
break

case 'linkgroup': case 'linkgc': {
if (!m.isGroup) return lenwyreply(mess.group)
if (!isBotAdmins) return lenwyreply(mess.botAdmin)
let response = await lenwy.groupInviteCode(from)
lenwy.sendText(from, `*Name Group : ${groupMetadata.subject}*\n\n*Link Group : https://chat.whatsapp.com/${response}*`, m, { detectLink: true })
}
break

case 'resetlinkgc':
if (!isAdmins) return lenwyreply(mess.admin)
if (!m.isGroup) return lenwyreply(mess.group)
if (!isBotAdmins) return lenwyreply(mess.botAdmin)
lenwy.groupRevokeInvite(from)
break

case 'sendlinkgc': {
if (!isCreator) return lenwyreply(mess.owner)
if (!m.isGroup) return lenwyreply(mess.group)
if (!isBotAdmins) return lenwyreply(mess.botAdmin)
if (!args[0]) return lenwyreply(`*Contoh : Sendlinkgc|6289673462138*`)
bnnd = text.split("|")[0]+'@s.whatsapp.net'
let response = await lenwy.groupInviteCode(from)
lenwy.sendText(bnnd, `https://chat.whatsapp.com/${response}\n\n*Link Group :* ${groupMetadata.subject}`, len, { detectLink: true })

}
break

case 'kick': {
if (!m.isGroup) return lenwyreply(mess.group)
if (!isBotAdmins) return lenwyreply(mess.botAdmin)
if (!isAdmins) return lenwyreply(mess.admin)
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await lenwy.groupParticipantsUpdate(from, [users], 'remove')
}
break

case 'add': {
if (!isCreator) return lenwyreply(mess.owner)
if (!m.isGroup) return lenwyreply(mess.group)
if (!isBotAdmins) return lenwyreply(mess.botAdmin)
if (!isAdmins) return lenwyreply(mess.admin)
let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await lenwy.groupParticipantsUpdate(from, [users], 'add')
}
break

case 'promote': {
if (!m.isGroup) return lenwyreply(mess.group)
if (!isBotAdmins) return lenwyreply(mess.botAdmin)
if (!isAdmins) return lenwyreply(mess.admin)
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await lenwy.groupParticipantsUpdate(from, [users], 'promote')
}
break

case 'demote': {
if (!m.isGroup) return lenwyreply(mess.group)
if (!isBotAdmins) return lenwyreply(mess.botAdmin)
if (!isAdmins) return lenwyreply(mess.admin)
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await lenwy.groupParticipantsUpdate(from, [botNumber], 'demote')
}
break

case 'hidetag': {
  if (!isPrem) return lenwyreply(mess.prem)
  if (!m.isGroup) return lenwyreply(mess.group)
  if (!isAdmins) return lenwyreply(mess.admin)
  lenwy.sendMessage(from, { text : q ? q : '' , mentions: participants.map(a => a.id)}, {quoted:len})
  }
  break

case 'brat': {
    if (isBan) return lenwyreply('*Kamu Di Ban Owner!*');

    // Cek limit hanya untuk user non-premium
    if (!isPrem && global.db.data.users[m.sender].limit < 5) return lenwyreply('*Limit Kamu Habis, Silahkan Hubunggi Kay/Tunggu besok*');
    if (!isPrem) global.db.data.users[m.sender].limit -= 5; // Mengurangi limit hanya jika bukan premium

    const quo = args.length >= 1 ? args.join(" ") : m.quoted?.text || m.quoted?.caption || m.quoted?.description || null;
    if (!quo) return lenwyreply("Masukkan teksnya!");

    // Kirim reaksi proses
    await lenwy.sendMessage(m.chat, {
        react: {
            text: "⏱️",
            key: m.key,
        }
    });

    // Filter toxic
    const isToxic = /(ewe|bangsad|mmk|koncol|kontol|k0ntl|k0ntol|kont0l|k0nt0l|kontoI|puki|kojtol|kintil|momok|nigga|ajg|ewean|yatim|anjing|kontol|memek|bangsat|babi|gblk|goblok|goblog|kntl|pepek|ppk|ngentod|ngentd|ngntd|kentod|kntd|bgst|anjg|anj|fuck|hitam|ireng|jawir|gay|asw|ktl|ngentot|ngewe|bokep|bkp|lonte|lont|bh|perawan|prawan|tolol|tlol|itil|tobrut|tobrud|tbrut|tbrud|telanjang|tljang|sexy|sex|teu|asu|idiot|dancok|jancok|tempek|ceret|bego|ngocok|lontean|kuman|pelacur|genit|jijik|jelek|brengsek|kelamin|vagina|masturbasi|waria|bencong|homo|pantek|narsis|sange|berdosa|zombie|kafir)/i;
    const Lenwyguard = isToxic.exec(m.text);
    if (Lenwyguard) return lenwyreply('*Kayzu Melarang Penggunaan Bahasa Kotor!!*');

    async function brat(text) {
        try {
            return await new Promise((resolve, reject) => {
                if (!text) return reject("Missing text input");
                axios.get("https://brat.caliphdev.com/api/brat", {
                    params: {
                        text
                    },
                    responseType: "arraybuffer"
                }).then(res => {
                    const image = Buffer.from(res.data);
                    if (image.length <= 10240) return reject("Failed to generate brat");
                    return resolve({
                        success: true,
                        image
                    });
                });
            });
        } catch (e) {
            return {
                success: false,
                errors: e
            };
        }
    }

    try {
        const buf = await brat(quo);
        if (!buf.success) throw new Error(buf.errors || "Gagal membuat brat");
        await lenwy.sendImageAsSticker(m.chat, buf.image, m, { packname: "Kayzu MD", author: "wa: 6289673462138" });

        // Kirim reaksi selesai
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key,
            }
        });
    } catch (error) {
        console.error(error);
        lenwy.sendMessage(m.chat, { text: '*Terjadi Kesalahan!*' }, { quoted: m });
    }
}
break

case 'brv': {
  const fs = require('fs');
  const path = require('path');
  const axios = require('axios');
  const { execSync } = require('child_process');

  // Cek limit hanya untuk user non-premium
  if (!isPrem && global.db.data.users[m.sender].limit < 10) return lenwyreply('*Limit Kamu Habis*');
  if (!isPrem) {
    global.db.data.users[m.sender].limit -= 10; // Mengurangi limit hanya jika bukan premium
  }

  // Kirim reaksi loading
  await lenwy.sendMessage(m.chat, {
    react: {
      text: "⏱️",
      key: m.key,
    }
  });

  if (!text) return lenwyreply(`Contoh: ${prefix + command} hai`);
  if (text.length > 250) return lenwyreply(`Karakter terbatas, max 250!`);

  const words = text.split(" ");
  const tempDir = path.join(process.cwd(), 'lib');
  if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir);
  const framePaths = [];

  try {
    for (let i = 0; i < words.length; i++) {
      const currentText = words.slice(0, i + 1).join(" ");

      const res = await axios.get(
        `https://brat.caliphdev.com/api/brat?text=${encodeURIComponent(currentText)}`,
        { responseType: "arraybuffer" }
      ).catch((e) => e.response);

      const framePath = path.join(tempDir, `frame${i}.mp4`);
      fs.writeFileSync(framePath, res.data);
      framePaths.push(framePath);
    }

    const fileListPath = path.join(tempDir, "filelist.txt");
    let fileListContent = "";

    for (let i = 0; i < framePaths.length; i++) {
      fileListContent += `file '${framePaths[i]}'\n`;
      fileListContent += `duration 0.7\n`;
    }

    fileListContent += `file '${framePaths[framePaths.length - 1]}'\n`;
    fileListContent += `duration 2\n`;

    fs.writeFileSync(fileListPath, fileListContent);
    const outputVideoPath = path.join(tempDir, "output.mp4");
    execSync(
      `ffmpeg -y -f concat -safe 0 -i ${fileListPath} -vf "fps=30" -c:v libx264 -preset ultrafast -pix_fmt yuv420p ${outputVideoPath}`
    );

    // Mengirimkan stiker dengan watermark
    await lenwy.sendImageAsSticker(m.chat, outputVideoPath, m, {
      packname: 'Kayzu MD',
      author: 'wa: 6289673462138'
    });

    // Kirim reaksi selesai
    await lenwy.sendMessage(m.chat, {
      react: {
        text: "✅",
        key: m.key,
      }
    });

    // Membersihkan file sementara
    framePaths.forEach((frame) => {
      if (fs.existsSync(frame)) fs.unlinkSync(frame);
    });
    if (fs.existsSync(fileListPath)) fs.unlinkSync(fileListPath);
    if (fs.existsSync(outputVideoPath)) fs.unlinkSync(outputVideoPath);
  } catch (e) {
    console.error(e);
    lenwyreply('Terjadi kesalahan');
  }
}
break

case 'totag': {
  if (!m.isGroup) return lenwyreply(mess.group);
  if (!isAdmins) return lenwyreply(mess.admin);
  const messageToReply = m.quoted ? m.quoted.text : q;
  if (!messageToReply) return lenwyreply('⚠ *Masukkan Pesan Atau Reply Pesan*');
  lenwy.sendMessage(from, { text: messageToReply, mentions: participants.map(a => a.id) }, { quoted: len });
}
break

/*case 'randomsave': {
  if (!isCreator) return lenwyreply(mess.owner) // Pastikan hanya pemilik bot yang bisa menggunakan perintah ini
  if (!/image/.test(mime)) return lenwyreply(`*Mana Fotonya?*`) // Pastikan bahwa media yang dikirim adalah gambar

  let timestamp = new Date().getTime() // Menggunakan timestamp sebagai nama file unik
  let TestiLenwy = await lenwy.downloadAndSaveMediaMessage(quoted) // Mengunduh dan menyimpan media gambar
  imagenya.push(timestamp.toString()) // Menyimpan timestamp ke dalam array database
  
  let caption = m.mtype || 'imageMessage' // Mengambil caption dari gambar jika ada, atau memberikan string kosong jika tidak ada
  
  await fsx.copy(TestiLenwy, `./database/Testilenwy/${timestamp}.jpg`) // Menyimpan gambar ke folder database dengan nama file berupa timestamp
  fs.writeFileSync('./database/Lenwytesti.json', JSON.stringify(imagenya)) // Menyimpan nama (timestamp) gambar dalam file JSON database
  fs.unlinkSync(TestiLenwy) // Menghapus file sementara setelah disimpan ke database

  lenwy.sendMessage(m.chat, { // Mengirimkan kembali gambar yang disimpan
      image: fs.readFileSync(`./database/Testilenwy/${timestamp}.jpg`), // Membaca gambar dari database
      caption: caption // Menambahkan caption yang diambil dari pesan asli
  }, { quoted: m })
}
break*/

case 'grup':
case 'group': {   
    if (!m.isGroup) return lenwyreply(mess.group); // Pastikan ini grup
    if (!isAdmins) return lenwyreply(mess.admin); // Pastikan pengguna adalah admin grup

    if (args[0] === 'close') {
        await lenwy.groupSettingUpdate(from, 'announcement').catch((err) => lenwyreply(jsonformat(err)));
    } else if (args[0] === 'open') {
        await lenwy.groupSettingUpdate(from, 'not_announcement').catch((err) => lenwyreply(jsonformat(err)));
    } else {
        lenwyreply(`*Silahkan Ketik:*\n- *Group open*: Untuk membuka grup\n- *Group close*: Untuk menutup grup`);
    }
}
break

case 'editinfo': {
if (!m.isGroup) return lenwyreply(mess.group)
if (!isAdmins) return lenwyreply(mess.admin)
 if (args[0] === 'open'){
await lenwy.groupSettingUpdate(from, 'unlocked').then((res) => lenwyreply(`Sukses Membuka Edit Info Group 🫡`)).catch((err) => lenwyreply(jsonformat(err)))
 } else if (args[0] === 'close'){
await lenwy.groupSettingUpdate(from, 'locked').then((res) => lenwyreply(`Sukses Menutup Edit Info Group 🫡`)).catch((err) => lenwyreply(jsonformat(err)))
 } else {
 lenwy.sendMessage(m.chat, { image: ppnyauser, caption: ` Silahkan Ketik
Editinfo Open
Editinfo Close`}, {quoted:m}) 

}
}
break

case 'translate': {
    if (!text) return lenwyreply('*Masukkan teks yang ingin diterjemahkan!*');
    const [from, to, ...rest] = text.split(' ');
    const textToTranslate = rest.join(' ');

    try {
        const response = await axios.get(`https://api.mymemory.translated.net/get?q=${textToTranslate}&langpair=${from}|${to}`);
        const translatedText = response.data.responseData.translatedText;
        lenwyreply(`Terjemahan: ${translatedText}`);
    } catch (error) {
        console.error(error);
        lenwyreply('Terjadi kesalahan saat menerjemahkan.');
    }
}
break

case 'join': {
if (!isCreator) return lenwyreply(mess.owner)
if (!text) throw 'Masukkan Link Group!'
if (!isUrl(args[0]) && !args[0].includes('whatsapp.com')) throw 'Link Invalid! 🤔'
lenwyreply('*Sabar Yaa*')
let result = args[0].split('https://chat.whatsapp.com/')[1]
await lenwy.groupAcceptInvite(result).then((res) => lenwyreply(jsonformat(res))).catch((err) => lenwyreply(jsonformat(err)))
}
break

case 'leave': {
                if (!isCreator) return lenwyreply(mess.owner)
                lenwyreply("Selamat Tinggal")
                await lenwy.groupLeave(m.chat).then((res) => lenwyreply(jsonformat(res))).catch((err) => lenwyreply(jsonformat(err)))
        }
        break

case 'editsubjek': {
if (!m.isGroup) return lenwyreply(mess.group)
if (!isBotAdmins) return lenwyreply(mess.botAdmin)
if (!isAdmins) return lenwyreply(mess.admin)
if (!text) throw 'Text nya ?'
await lenwy.groupUpdateSubject(from, text).then((res)).catch((err) => lenwyreply(jsonformat(err)))
}
break

    case 'delgc':

  if (!isCreator) return lenwyreply(mess.owner)

    if (!isGroup) return lenwyreply(`Khusus Group`)

var ini = pler.indexOf(m.chat)

pler.splice(ini, 1)

fs.writeFileSync('./all/database/idgrup.json', JSON.stringify(pler))

lenwyreply(`${command} Sukses Menonaktifkan Fitur Domain Di Grup Ini`)

break

       case 'addgc':

    if (!isGroup) return lenwyreply(`Khusus Group`)         

if (!isCreator) return lenwyreply(mess.owner)

pler.push(m.chat)

fs.writeFileSync('./all/database/idgrup.json', JSON.stringify(pler))

lenwyreply(`${command} Sukses Mengaktifkan Fitur Domain Di Grup Ini`)

           break

case 'editdesk':{
if (!m.isGroup) return lenwyreply(mess.group)
if (!isBotAdmins) return lenwyreply(mess.botAdmin)
if (!isAdmins) return lenwyreply(mess.admin)
if (!text) throw 'Text Nya ?'
await lenwy.groupUpdateDescription(from, text).then((res)).catch((err) => lenwyreply(jsonformat(err)))
}
break

case 'tagall': {
if (!m.isGroup) return lenwyreply(mess.group)
if (!isAdmins) return lenwyreply(mess.admin)
let teks = `*Tag All*
*Pesan : ${q ? q : 'Kosong'}*\n\n`
for (let mem of participants) {
teks += `⨠ @${mem.id.split('@')[0]}\n`
}
lenwy.sendMessage(m.chat, { text: teks, mentions: participants.map(a => a.id) }, { quoted:m })
}
break

case 'sewa':
if (isBan) return lenwyreply('*Lu Di Ban Owner*')
lenwyreply(`
Berikut Harga Sewa (Termasuk Fitur Premium)

1. Sewa 1 Bulan
Harga: Rp 15.000
Fitur:
Akses penuh ke semua fitur bot (termasuk premium)
Update otomatis setiap bulan
Prioritas support
Akses fitur game, download, dan lainnya

2. Sewa 3 Bulan
Harga: Rp 40.000
Fitur:
Akses penuh ke semua fitur bot
Update otomatis setiap bulan
Prioritas support
Diskon 11% dibandingkan sewa bulanan
Akses fitur game, download, dan lainnya

3. Sewa 6 Bulan
Harga: Rp 60.000
Fitur:
Akses penuh ke semua fitur bot
Update otomatis setiap bulan
Prioritas support
Diskon 17% dibandingkan sewa bulanan
Akses fitur game, download, dan lainnya

4. Sewa 12 Bulan
Harga: Rp 70.000
Fitur:
Akses penuh ke semua fitur bot
Update otomatis setiap bulan
Prioritas support
Diskon 22% dibandingkan sewa bulanan
Akses fitur game, download, dan lainnya


List Harga Paket Premium

1. Paket Premium 1 Bulan
Harga: Rp 15.000
Fitur:
Akses penuh ke fitur premium bot
Akses ke fitur eksklusif (seperti game, download, premium tools)
Update otomatis
Prioritas support

2. Paket Premium 3 Bulan
Harga: Rp 40.000
Fitur:
Akses penuh ke fitur premium bot
Akses ke fitur eksklusif
Update otomatis
Prioritas support
Diskon 11% dibandingkan membeli bulanan

3. Paket Premium 6 Bulan
Harga: Rp 50.000
Fitur:
Akses penuh ke fitur premium bot
Akses ke fitur eksklusif
Update otomatis
Prioritas support
Diskon 17% dibandingkan membeli bulanan



Keuntungan untuk Kamu

Harga lebih terjangkau bagi pelanggan, namun tetap memberikan akses ke fitur premium bot.
Kamu bisa menawarkan harga lebih kompetitif di pasar tanpa mengurangi kualitas layanan.
Dengan harga yang lebih rendah, lebih banyak pelanggan bisa bergabung, yang pada gilirannya memberi keuntungan lebih dalam jumlah banyak.
Paket ini tetap memberikan margin keuntungan yang baik, sambil menjaga agar pelanggan merasa mendapatkan value yang besar!

`)
break

case 'sewabot':
if (isBan) return lenwyreply('*Lu Di Ban Owner*')
if (!isCreator) return lenwyreply(mess.owner)
if (!text) return lenwyreply(`*Contoh* :\n#sewabot (Nama Group) `)
let cret = await lenwy.groupCreate(args.join(" "), [])
let response = await lenwy.groupInviteCode(cret.id)
lenwy.sendMessage(m.chat, { text: `*Create Group Sewa Bot*
*Sewa Bot Selama ${text} Telah Di Proses, Silahkan Masuk Group Melalui Link Yang Sudah Di Sediakan*

*Bot : ${botname}*
*Time : ${moment(cret.creation * 1000).tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")} WIB* 
*Link Group : https://chat.whatsapp.com/${response}*
`, m})
lenwyreply('*Link Group Khusus Berhasil Dikirim Melalui Chat Pribadi Anda*')
break

case 'stiker': case 'sticker': case 's': case 'stickers': case 'sgif': {
if (isBan) return lenwyreply('*Kamu Di Ban Owner*')
 if (!quoted) lenwyreply `Balas Video/Image Dengan Caption ${prefix + command}`
if (/image/.test(mime)) {
let media = await quoted.download()
let encmedia = await lenwy.sendImageAsSticker(from, media, m, { packname: global.packname, author: global.author })
await fs.unlinkSync(encmedia)
} else if (/video/.test(mime)) {
if ((quoted.msg || quoted).seconds > 11) return lenwyreply('*Maksimal 9 Detik!*')
let media = await quoted.download()
let encmedia = await lenwy.sendVideoAsSticker(from, media, m, { packname: global.packname, author: global.author })
await fs.unlinkSync(encmedia)
} else {
lenwyreply(`*Kirim Gambar/Video Yang Ingin Dijadikan Sticker*\n*Durasi VIdeo Minimal 1 - 9 Detik*`)
}
}
break

case 'inspect': {
if (isBan) return lenwyreply('*Lu Di Ban Owner*')
LenwyLD()
if (!args[0]) return lenwyreply("Linknya?")
let linkRegex = args.join(" ")
let coded = linkRegex.split("https://chat.whatsapp.com/")[1]
if (!coded) return lenwyreply("Link Invalid 🤔")
lenwy.query({
tag: "iq",
attrs: {
type: "get",
xmlns: "w:g2",
to: "@g.us"
},
content: [{ tag: "invite", attrs: { code: coded } }]
}).then(async(res) => { 
tekse = `*Group Link Yang Di Inspect*

 *⨠ Nama Group : ${res.content[0].attrs.subject ? res.content[0].attrs.subject : "undefined"}*
 *⨠ Deskripsi Di Ubah : ${res.content[0].attrs.s_t ? moment(res.content[0].attrs.s_t *1000).tz("Asia/Jakarta").format("DD-MM-YYYY, HH:mm:ss") : "undefined"}*
 *⨠ Pembuat Group : ${res.content[0].attrs.creator ? "@" + res.content[0].attrs.creator.split("@")[0] : "undefined"}*
 *⨠ Group Di Buat : ${res.content[0].attrs.creation ? moment(res.content[0].attrs.creation * 1000).tz("Asia/Jakarta").format("DD-MM-YYYY, HH:mm:ss") : "undefined"}*
 *⨠ Total Member : ${res.content[0].attrs.size ? res.content[0].attrs.size : "undefined"} Member*

*⨠ ID Group  : ${res.content[0].attrs.id ? res.content[0].attrs.id : "undefined"}*
*By ${botname}*`
try {
pp = await lenwy.profilePictureUrl(res.content[0].attrs.id + "@g.us", "image")
} catch {
pp = "https://tse2.mm.bing.net/th?id=OIP.n1C1oxOvYLLyDIavrBFoNQHaHa&pid=Api&P=0&w=153&h=153"
}
lenwy.sendFile(from, pp, "", m, { caption: tekse, mentions: await lenwy.parseMention(tekse) })

})
}
break

case 'ping': case 'botstatus': {
    const used = process.memoryUsage();
    const cpus = os.cpus().map(cpu => {
        cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0);
        return cpu;
    });
    const cpu = cpus.reduce((last, cpu, _, { length }) => {
        last.total += cpu.total;
        last.speed += cpu.speed / length;
        last.times.user += cpu.times.user;
        last.times.nice += cpu.times.nice;
        last.times.sys += cpu.times.sys;
        last.times.idle += cpu.times.idle;
        last.times.irq += cpu.times.irq;
        return last;
    }, {
        speed: 0,
        total: 0,
        times: {
            user: 0,
            nice: 0,
            sys: 0,
            idle: 0,
            irq: 0
        }
    });

    let timestamp = speed();
    let latensi = speed() - timestamp;
    let neww = performance.now();
    let oldd = performance.now();

    const respon = `
*📊 BOT STATUS*  
Response Speed: ${latensi.toFixed(4)} detik  
Milisecond: ${(oldd - neww).toFixed(4)} ms  
Runtime: ${runtime(process.uptime())}  

*🖥️ INFO SERVER*  
💾 RAM Usage: ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}  

*🔧 CPU INFO*  
💻 Model: ${cpus[0].model.trim()}  
⚡ Kecepatan: ${cpu.speed} MHz  
🔢 Core(s): ${cpus.length} Core(s)  
${Object.keys(cpu.times).map(type => `🟢 ${type.toUpperCase()}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}

*📂 NODEJS MEMORY USAGE*  
${Object.keys(used).map((key) => `${key.padEnd(15)}: ${formatp(used[key])}`).join('\n')}

*🔍 CPU Core Usage*  
${cpus.map((cpu, i) => `${i + 1}. ${cpu.model.trim()} (${cpu.speed} MHz)\n${Object.keys(cpu.times).map(type => `- ${type.toUpperCase()}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}`).join('\n\n')}
    `.trim();

    // Kirim pesan dengan tambahan atribut visual
    await lenwy.sendMessage(m.chat, {
        text: respon,
        contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                title: 'Status Bot & Server',
                body: `${latensi.toFixed(4)} Detik`,
                thumbnailUrl: 'https://files.catbox.moe/fzgitz.jpg', // Ganti dengan thumbnail lain jika ingin
                sourceUrl: global.link || 'https://yourbotlink.com', // Ganti dengan link bot Anda
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: len });
}
break

case 'bcgc': case 'bcgroup': {
if (!isCreator) return lenwyreply(mess.owner)
LenwyLD()
if (!text) lenwyreply `*Contoh : ${prefix + command} Subscribe kayzu*`
let getGroups = await lenwy.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
let anu = groups.map(v => v.id)
for (let i of anu) {
await sleep(1500)
lenwy.sendMessage(i, {text: `${text}`}, {quoted:len})
    }
lenwyreply(`Sukses Mengirim Broadcast Ke ${anu.length} Group`)
}
break

case 'bcimg': case 'bcvid': case 'bcvideo': case 'share': {
if (!isCreator) return lenwyreply(`Maaf, Command ini Khusus untuk Developer Bot WhatsApp`);
if (m.isGroup) return lenwyreply(mess.private)
if (!text) return lenwyreply(`*Penggunaan Salah Silahkan Gunakan Seperti Ini*\n${prefix+command} teks\n\nReply Gambar Untuk Mengirim Gambar Ke Semua Group`)
lenwyreply(mess.wait)
let getGroups = await lenwy.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let anu = groups.map((v) => v.id)
global.teksjpm = text
for (let xnxx of anu) {
let metadat72 = await lenwy.groupMetadata(xnxx)
let participanh = await metadat72.participants
if (/image/.test(mime)) {
media = await lenwy.downloadAndSaveMediaMessage(quoted)
mem = await uptotelegra(media)
await lenwy.sendMessage(xnxx, { image: { url: mem }, caption: global.teksjpm, contextInfo:{ mentionedJid: participanh.map(a => a.id) } }, { quoted: len })
await sleep(2000)
} else {
if(/video/.test(mime)){
media1 = await lenwy.downloadAndSaveMediaMessage(quoted)
mem1 = await uptotelegra(media1)
await lenwy.sendMessage(xnxx, { video: { url: mem1 }, caption: global.teksjpm, contextInfo:{ mentionedJid: participanh.map(a => a.id) } }, { quoted: len })
await sleep(2000)
} else {
await lenwy.sendMessage(xnxx, { text: global.teksjpm, contextInfo:{ mentionedJid: participanh.map(a => a.id) } }, { quoted: len })
await sleep(2000)
}}
}
}
break            
            case 'antitoxic': {
                if (!m.isGroup) return lenwyreply(mess.group)
                if (!isAdmins && !isCreator) return lenwyreply(mess.admin)
                if (!isBotAdmins) return lenwyreply(mess.botAdmin)
                if (args[0] === "on") {
                    if (db.data.chats[m.chat].lenwy_antitoxic) return lenwyreply(`*Anti Toxic Sudah Aktif*`)
                    db.data.chats[m.chat].lenwy_antitoxic = true
                    lenwyreply(`*Anti Toxic Diaktifkan Didalam Group*`)
                } else if (args[0] === "off") {
                    if (!db.data.chats[m.chat].lenwy_antitoxic) return lenwyreply(`*Anti Toxic Sudah Dinonaktifkan*`)
                    db.data.chats[m.chat].lenwy_antitoxic = false
                    lenwyreply(`*Anti Toxic Dinonaktifkan Didalam Group*`)
                } else {
                    lenwyreply(`Mode ${command}\n\n\nKetik ${prefix + command} on/off`)
                }
            }
            break

            case 'antisticker': {
    if (!m.isGroup) return lenwyreply(mess.group);
    if (!isAdmins && !isCreator) return lenwyreply(mess.admin);
    if (!isBotAdmins) return lenwyreply(mess.botAdmin);
    
    if (args[0] === "on") {
        if (db.data.chats[m.chat].lenwy_antisticker) return lenwyreply(`*Anti Sticker Sudah Aktif*`);
        db.data.chats[m.chat].lenwy_antisticker = true;
        lenwyreply(`*Anti Sticker Diaktifkan Dalam Grup*`);
    } else if (args[0] === "off") {
        if (!db.data.chats[m.chat].lenwy_antisticker) return lenwyreply(`*Anti Sticker Sudah Dinonaktifkan*`);
        db.data.chats[m.chat].lenwy_antisticker = false;
        lenwyreply(`*Anti Sticker Dinonaktifkan Dalam Grup*`);
    } else {
        lenwyreply(`*Mode ${command}*\n\nKetik *${prefix + command} on/off*`);
    }
}
break

            case 'antilinkgcv1': {
                if (!m.isGroup) return lenwyreply(mess.group)
                if (!isAdmins && !isCreator) return lenwyreply(mess.admin)
                if (!isBotAdmins) return lenwyreply(mess.botAdmin)
                if (args[0] === "on") {
                    if (db.data.chats[m.chat].lenwy_antigc) return lenwyreply(`*Autokick Link Gc Aktif*`)
                    db.data.chats[m.chat].lenwy_antigc = true
                    lenwyreply(`*Autokick Link Gc Aktif*`)
                } else if (args[0] === "off") {
                    if (!db.data.chats[m.chat].lenwy_antigc) return lenwyreply(`*Autokick Link Gc Di Nonatifkan*`)
                    db.data.chats[m.chat].lenwy_antigc = false
                    lenwyreply(`*Autokick Nonaktif*`)
                } else {
                    lenwyreply(`*Ketik Antilinkgcv1 on/off*`)
                }
            }
            break

            case 'antilinkgc':
                if (!m.isGroup) return lenwyreply(mess.group)
                if (!isAdmins && !isCreator) return lenwyreply(mess.admin)
                if (!isBotAdmins) return lenwyreply(mess.botAdmin)
                if (args.length < 1) return lenwyreply(`*Contoh ${prefix + command} on/off*`)
                if (q == 'on'){
                    global.db.data.chats[m.chat].lenwy_antigc2 = true
                    lenwyreply(`*Berhasil Mengaktifkan Anti Link Group*\n*Ketik Antilinkgcv1 Untuk Mengaktifkan Autokick*`)
                } else if (q == 'off'){
                    global.db.data.chats[m.chat].lenwy_antigc2 = false
                    lenwyreply(`*Berhasil Mematikan Anti Link Group *`)
                }
            break

            case 'antiwame':
                if (!m.isGroup) return lenwyreply(mess.group)
                if (!isAdmins && !isCreator) return lenwyreply(mess.admin)
                if (!isBotAdmins) return lenwyreply(mess.botAdmin)
                if (args.length < 1) return lenwyreply(`*Contoh ${prefix + command} on/off*`)
                if (q == 'on'){
                    global.db.data.chats[m.chat].lenwy_antiwame = true
                    lenwyreply(`*Berhasil Mengaktifkan Anti Chat Wame*`)
                } else if (q == 'off'){
                    global.db.data.chats[m.chat].lenwy_antiwame = false
                    lenwyreply(`*Berhasil Mematikan Anti Chat Wame*`)
                }
            break

            case 'antilink':
                if (!m.isGroup) return lenwyreply(mess.group)
                if (!isAdmins && !isCreator) return lenwyreply(mess.admin)
                if (!isBotAdmins) return lenwyreply(mess.botAdmin)
                if (args.length < 1) return lenwyreply(`*Contoh ${prefix + command} on/off*`)
                if (q == 'on'){
                    global.db.data.chats[m.chat].lenwy_antilink = true
                    lenwyreply(`*Berhasil Mengaktifkan Anti Link*`)
                } else if (q == 'off'){
                    global.db.data.chats[m.chat].lenwy_antilink = false
                    lenwyreply(`*Berhasil Mematikan Anti Link*`)
                }
            break

            case 'antipanel':
                if (!m.isGroup) return lenwyreply(mess.group)
                if (!isAdmins && !isCreator) return lenwyreply(mess.admin)
                if (!isBotAdmins) return lenwyreply(mess.botAdmin)
                if (args.length < 1) return lenwyreply(`*Contoh ${prefix + command} on/off*`)
                if (q == 'on'){
                    global.db.data.chats[m.chat].lenwy_antipanel = true
                    lenwyreply(`*Berhasil Mengaktifkan Anti Promosi Panel*`)
                } else if (q == 'off'){
                    global.db.data.chats[m.chat].lenwy_antipanel = false
                    lenwyreply(`*Berhasil Mematikan Anti Promosi Panel*`)
                }
            break

            case 'antilinktt':
                if (!m.isGroup) return lenwyreply(mess.group)
                if (!isAdmins && !isCreator) return lenwyreply(mess.admin)
                if (!isBotAdmins) return lenwyreply(mess.botAdmin)
                if (args.length < 1) return lenwyreply(`*Contoh ${prefix + command} on/off*`)
                if (q == 'on'){
                    global.db.data.chats[m.chat].lenwy_antitiktok = true
                    lenwyreply(`*Berhasil Mengaktifkan Anti Link Tiktok*`)
                } else if (q == 'off'){
                    global.db.data.chats[m.chat].lenwy_antitiktok = false
                    lenwyreply(`*Berhasil Mematikan Anti Link Tiktok*`)
                }
            break

            case 'antilinkyt':
                if (!m.isGroup) return lenwyreply(mess.group)
                if (!isAdmins && !isCreator) return lenwyreply(mess.admin)
                if (!isBotAdmins) return lenwyreply(mess.botAdmin)
                if (args.length < 1) return lenwyreply(`*Contoh ${prefix + command} on/off*`)
                if (q == 'on'){
                    global.db.data.chats[m.chat].lenwy_antiyoutube = true
                    lenwyreply(`*Berhasil Mengaktifkan Anti Link Youtube*`)
                } else if (q == 'off'){
                    global.db.data.chats[m.chat].lenwy_antiyoutube = false
                    lenwyreply(`*Berhasil Mematikan Anti Link Youtube*`)
                }
            break

            case 'antich':
                if (!m.isGroup) return lenwyreply(mess.group)
                if (!isAdmins && !isCreator) return lenwyreply(mess.admin)
                if (!isBotAdmins) return lenwyreply(mess.botAdmin)
                if (args.length < 1) return lenwyreply(`*Contoh ${prefix + command} on/off*`)
                if (q == 'on'){
                    global.db.data.chats[m.chat].lenwy_antich = true
                    lenwyreply(`*Berhasil Mengaktifkan Anti Link Channel Wa*`)
                } else if (q == 'off'){
                    global.db.data.chats[m.chat].lenwy_antich = false
                    lenwyreply(`*Berhasil Mematikan Anti Link Channel Wa*`)
                }
            break

            case 'kayzuoffc':
                if (!m.isGroup) return lenwyreply(mess.group)
                if (!isAdmins && !isCreator) return lenwyreply(mess.admin)
                if (!isBotAdmins) return lenwyreply(mess.botAdmin)
                if (args.length < 1) return lenwyreply(`*Contoh KayzuOffc on/off*`)
                if (q == 'on'){
                    global.db.data.chats[m.chat].lenwy_antich = true
                    global.db.data.chats[m.chat].lenwy_antigc2 = true
                    db.data.chats[m.chat].lenwy_antigc = true
                    lenwyreply(`*KayzuOffc Berhasil Diaktifkan Didalam Group*`)
                } else if (q == 'off'){
                    global.db.data.chats[m.chat].lenwy_antich = false
                    global.db.data.chats[m.chat].lenwy_antigc2 = false
                    db.data.chats[m.chat].lenwy_antigc = false
                    lenwyreply(`*KayzuOffc Dinonaktifkan Dalam Group!*`)
                }
            break

            case 'antispam':{
                if (!m.isGroup) return lenwyreply(mess.group)
                if (!isAdmins && !isCreator) return lenwyreply(mess.admin)
                if (!isBotAdmins) return lenwyreply(mess.botAdmin)
               if (args.length < 1) return lenwyreply('*Contoh AntiSpam on/off*')
               if (args[0] === 'on') {
                  db.data.chats[from].antispam = true
                  lenwyreply(`*AntiSpam Berhasil Diaktifkan Didalam Group*`)
               } else if (args[0] === 'off') {
                  db.data.chats[from].antispam = false
                  lenwyreply(`*AntiSpam Dinonaktifkan Dalam Group!*`)
               }
               }
            break

            case 'autoread':
            if (!isCreator) return lenwyreply(mess.owner)
            if (args.length < 1) return lenwyreply(`Contoh ${prefix + command} on/off`)
            if (q === 'on'){
            global.db.data.settings[botNumber].autoread = true
            lenwyreply(`Berhasil mengubah autoread ke ${q}`)
            } else if (q === 'off'){
            global.db.data.settings[botNumber].autoread = false
            lenwyreply(`Berhasil mengubah autoread ke ${q}`)
            }
            break

/*case 'photomenu': {
if (isBan) return lenwyreply('*Kamu Di Ban Owner*')
LenwyLD()
await sleep(1000)
lenwyreply(`*Photooxy Menu*
 *⨠ Flaming*   
 *⨠ Stars*
 *⨠ Shadow*
 *⨠ Burnpaper*
 *⨠ Grass*
 *⨠ Underwater*
 *⨠ Whitecube*
 *⨠ Smokyneon*
 *⨠ Fabric*
 *⨠ Glowing*
 *⨠ Honey*
 *⨠ Vintage*
 *⨠ Gradient*
 *⨠ Fur*
 *⨠ Striking*

*Kalo Ada Error Bisa Chat Owner Ya*
`)
}
break 

*Photooxy Menu*
 *⨠ Flaming*   
 *⨠ Stars*
 *⨠ Shadow*
 *⨠ Burnpaper*
 *⨠ Grass*
 *⨠ Underwater*
 *⨠ Whitecube*
 *⨠ Smokyneon*
 *⨠ Fabric*
 *⨠ Glowing*
 *⨠ Honey*
 *⨠ Vintage*
 *⨠ Gradient*
 *⨠ Fur*
 *⨠ Striking*

*Kalo Ada Error Bisa Chat Owner Ya*           

case 'flaming':{
if (args.length == 0) return lenwyreply(`*Mana Teksnya?*`)
if (text.length > 20) return lenwyreply(`*Maksimal 20 Karakter*`)    
lenwyreply(mess.wait)
let lenwy_txt = args.join(" ")
var lenwyhasil = `https://api.loviecho.biz.id/api/photooxy/realistic-flaming-text-effect?api_key=sk-qpic1vg2czjkv0pto&text=${lenwy_txt}`
lenwy.sendMessage(from, {image: {url:lenwyhasil}, caption: `${mess.success}`}, { quoted: m})
.catch((err) => lenwyreply('*Kayaknya Ada Yang Error*'))
}
break

case 'stars':{
if (args.length == 0) return lenwyreply(`*Mana Teksnya?*`)
if (text.length > 20) return lenwyreply(`*Maksimal 20 Karakter*`)    
lenwyreply(mess.wait)
let lenwy_txt = args.join(" ")
var lenwyhasil = `https://api.loviecho.biz.id/api/photooxy/write-stars-text-on-the-night-sky?api_key=sk-qpic1vg2czjkv0pto&text=${lenwy_txt}`
lenwy.sendMessage(from, {image: {url:lenwyhasil}, caption: `${mess.success}`}, { quoted: m})
.catch((err) => lenwyreply('*Kayaknya Ada Yang Error*'))
}
break

case 'shadow':{
if (args.length == 0) return lenwyreply(`*Mana Teksnya?*`)
if (text.length > 20) return lenwyreply(`*Maksimal 20 Karakter*`)    
lenwyreply(mess.wait)
let lenwy_txt = args.join(" ")
var lenwyhasil = `https://api.loviecho.biz.id/api/photooxy/shadow-text-effect-in-the-sky?api_key=sk-qpic1vg2czjkv0pto&text=${lenwy_txt}`
lenwy.sendMessage(from, {image: {url:lenwyhasil}, caption: `${mess.success}`}, { quoted: m})
.catch((err) => lenwyreply('*Kayaknya Ada Yang Error*'))
}
break

case 'burnpaper':{
if (args.length == 0) return lenwyreply(`*Mana Teksnya?*`)
if (text.length > 20) return lenwyreply(`*Maksimal 20 Karakter*`)    
lenwyreply(mess.wait)
let lenwy_txt = args.join(" ")
var lenwyhasil = `https://api.loviecho.biz.id/api/photooxy/write-text-on-burn-paper?api_key=sk-qpic1vg2czjkv0pto&text=${lenwy_txt}`
lenwy.sendMessage(from, {image: {url:lenwyhasil}, caption: `${mess.success}`}, { quoted: m})
.catch((err) => lenwyreply('*Kayaknya Ada Yang Error*'))
}
break

case 'grass':{
if (args.length == 0) return lenwyreply(`*Mana Teksnya?*`)
if (text.length > 20) return lenwyreply(`*Maksimal 20 Karakter*`)    
lenwyreply(mess.wait)
let lenwy_txt = args.join(" ")
var lenwyhasil = `https://api.loviecho.biz.id/api/photooxy/make-quotes-under-grass?api_key=sk-qpic1vg2czjkv0pto&text=${lenwy_txt}`
lenwy.sendMessage(from, {image: {url:lenwyhasil}, caption: `${mess.success}`}, { quoted: m})
.catch((err) => lenwyreply('*Kayaknya Ada Yang Error*'))
}
break

case 'underwater':{
if (args.length == 0) return lenwyreply(`*Mana Teksnya?*`)
if (text.length > 20) return lenwyreply(`*Maksimal 20 Karakter*`)    
lenwyreply(mess.wait)
let lenwy_txt = args.join(" ")
var lenwyhasil = `https://api.loviecho.biz.id/api/photooxy/creating-an-underwater-ocean?api_key=sk-qpic1vg2czjkv0pto&text=${lenwy_txt}`
lenwy.sendMessage(from, {image: {url:lenwyhasil}, caption: `${mess.success}`}, { quoted: m})
.catch((err) => lenwyreply('*Kayaknya Ada Yang Error*'))
}
break

case 'whitecube':{
if (args.length == 0) return lenwyreply(`*Mana Teksnya?*`)
if (text.length > 20) return lenwyreply(`*Maksimal 20 Karakter*`)    
lenwyreply(mess.wait)
let lenwy_txt = args.join(" ")
var lenwyhasil = `https://api.loviecho.biz.id/api/photooxy/3d-text-effect-under-white-cube?api_key=sk-qpic1vg2czjkv0pto&text=${lenwy_txt}`
lenwy.sendMessage(from, {image: {url:lenwyhasil}, caption: `${mess.success}`}, { quoted: m})
.catch((err) => lenwyreply('*Kayaknya Ada Yang Error*'))
}
break

case 'smokyneon':{
if (args.length == 0) return lenwyreply(`*Mana Teksnya?*`)
if (text.length > 20) return lenwyreply(`*Maksimal 20 Karakter*`)    
lenwyreply(mess.wait)
let lenwy_txt = args.join(" ")
var lenwyhasil = `https://api.loviecho.biz.id/api/photooxy/make-smoky-neon-glow-effect?api_key=sk-qpic1vg2czjkv0pto&text=${lenwy_txt}`
lenwy.sendMessage(from, {image: {url:lenwyhasil}, caption: `${mess.success}`}, { quoted: m})
.catch((err) => lenwyreply('*Kayaknya Ada Yang Error*'))
}
break

case 'fabric':{
if (args.length == 0) return lenwyreply(`*Mana Teksnya?*`)
if (text.length > 20) return lenwyreply(`*Maksimal 20 Karakter*`)    
lenwyreply(mess.wait)
let lenwy_txt = args.join(" ")
var lenwyhasil = `https://api.loviecho.biz.id/api/photooxy/army-camouflage-fabric-text-effect?api_key=sk-qpic1vg2czjkv0pto&text=${lenwy_txt}`
lenwy.sendMessage(from, {image: {url:lenwyhasil}, caption: `${mess.success}`}, { quoted: m})
.catch((err) => lenwyreply('*Kayaknya Ada Yang Error*'))
}
break

case 'glowing':{
if (args.length == 0) return lenwyreply(`*Mana Teksnya?*`)
if (text.length > 20) return lenwyreply(`*Maksimal 20 Karakter*`)    
lenwyreply(mess.wait)
let lenwy_txt = args.join(" ")
var lenwyhasil = `https://api.loviecho.biz.id/api/photooxy/create-a-3d-glowing-text-effect?api_key=sk-qpic1vg2czjkv0pto&text=${lenwy_txt}`
lenwy.sendMessage(from, {image: {url:lenwyhasil}, caption: `${mess.success}`}, { quoted: m})
.catch((err) => lenwyreply('*Kayaknya Ada Yang Error*'))
}
break

case 'honey':{
if (args.length == 0) return lenwyreply(`*Mana Teksnya?*`)
if (text.length > 20) return lenwyreply(`*Maksimal 20 Karakter*`)    
lenwyreply(mess.wait)
let lenwy_txt = args.join(" ")
var lenwyhasil = `https://api.loviecho.biz.id/api/photooxy/honey-text-effect?api_key=sk-qpic1vg2czjkv0pto&text=${lenwy_txt}`
lenwy.sendMessage(from, {image: {url:lenwyhasil}, caption: `${mess.success}`}, { quoted: m})
.catch((err) => lenwyreply('*Kayaknya Ada Yang Error*'))
}
break

case 'vintage':{
if (args.length == 0) return lenwyreply(`*Mana Teksnya?*`)
if (text.length > 20) return lenwyreply(`*Maksimal 20 Karakter*`)    
lenwyreply(mess.wait)
let lenwy_txt = args.join(" ")
var lenwyhasil = `https://api.loviecho.biz.id/api/photooxy/vintage-text-style?api_key=sk-qpic1vg2czjkv0pto&text=${lenwy_txt}`
lenwy.sendMessage(from, {image: {url:lenwyhasil}, caption: `${mess.success}`}, { quoted: m})
.catch((err) => lenwyreply('*Kayaknya Ada Yang Error*'))
}
break

case 'gradient':{
if (args.length == 0) return lenwyreply(`*Mana Teksnya?*`)
if (text.length > 20) return lenwyreply(`*Maksimal 20 Karakter*`)    
lenwyreply(mess.wait)
let lenwy_txt = args.join(" ")
var lenwyhasil = `https://api.loviecho.biz.id/api/photooxy/gradient-avatar-text-effect?api_key=sk-qpic1vg2czjkv0pto&text=${lenwy_txt}`
lenwy.sendMessage(from, {image: {url:lenwyhasil}, caption: `${mess.success}`}, { quoted: m})
.catch((err) => lenwyreply('*Kayaknya Ada Yang Error*'))
}
break

case 'fur':{
if (args.length == 0) return lenwyreply(`*Mana Teksnya?*`)
if (text.length > 20) return lenwyreply(`*Maksimal 20 Karakter*`)    
lenwyreply(mess.wait)
let lenwy_txt = args.join(" ")
var lenwyhasil = `https://api.loviecho.biz.id/api/photooxy/fur-text-effect-generator?api_key=sk-qpic1vg2czjkv0pto&text=${lenwy_txt}`
lenwy.sendMessage(from, {image: {url:lenwyhasil}, caption: `${mess.success}`}, { quoted: m})
.catch((err) => lenwyreply('*Kayaknya Ada Yang Error*'))
}
break

case 'striking':{
if (args.length == 0) return lenwyreply(`*Mana Teksnya?*`)
if (text.length > 20) return lenwyreply(`*Maksimal 20 Karakter*`)    
lenwyreply(mess.wait)
let lenwy_txt = args.join(" ")
var lenwyhasil = `https://api.loviecho.biz.id/api/photooxy/striking-3d-text-effect?api_key=sk-qpic1vg2czjkv0pto&text=${lenwy_txt}`
lenwy.sendMessage(from, {image: {url:lenwyhasil}, caption: `${mess.success}`}, { quoted: m})
.catch((err) => lenwyreply('*Kayaknya Ada Yang Error*'))
}
break*/

case 'cuaca':{
if (!text) return lenwyreply('*Mana Lokasinya?*')
    lenwyreply('*Sabar Yaa*')
if (text.length > 20) return lenwyreply(`*Maksimal 20 Karakter*`)
            let wdata = await axios.get(
                `https://api.openweathermap.org/data/2.5/weather?q=${text}&units=metric&appid=060a6bcfa19809c2cd4d97a212b19273&language=id`
            );
            let Lenwy_txt = ""
            Lenwy_txt += `*Cuaca Dari : ${text}*\n`
            Lenwy_txt += `☁️ *Cuaca :* *${wdata.data.weather[0].main}*\n`
            Lenwy_txt += `🧾 *Deskripsi :* *${wdata.data.weather[0].description}*\n`
            Lenwy_txt += `🌡️ *Suhu Rata Rata :* *${wdata.data.main.temp}*\n`
            Lenwy_txt += `💨 *Tekanan :* *${wdata.data.main.pressure}*\n`
            Lenwy_txt += `🧴 *kelembapan :* *${wdata.data.main.humidity}*\n`
            Lenwy_txt += `🛳️ *Garis Bujur :* *${wdata.data.coord.lat}*\n`
            Lenwy_txt += `🌏 *Negara :* *${wdata.data.sys.country}*\n`

           lenwy.sendMessage(
                m.chat, {
                    text: Lenwy_txt,
                }, {
                    quoted: m,
                }
           )
           }
           break

case 'imdb': {
if (!text) return lenwyreply(`⚠ *Tolong Masukkan Judul FIlmnya*`);
lenwyreply('*Mencari Data Film ☕*');
if (text.length > 100) return lenwyreply(`⚠ *Maksimal 100 Karakter*`);

try {
const movie = await IMDB(text);

if (movie === 'Movie not found') {
return lenwyreply(`*Film Tidak Ditemukan Di IMDB*`);
}

let Lenwy_txt = "*IMDB Search*\n\n";
 Lenwy_txt += `*Judul :* _${movie.title}_\n`;
 Lenwy_txt += `*Tahun :* _${movie.year}_\n`;
 Lenwy_txt += `*Rilis :* _${movie.released}_\n`;
 Lenwy_txt += `*Durasi :* _${movie.runtime}_\n`;
 Lenwy_txt += `*Genre :* _${movie.genre}_\n`;
 Lenwy_txt += `*Direktur :* _${movie.director}_\n`;
 Lenwy_txt += `*Penulis :* _${movie.writer}_\n`;
 Lenwy_txt += `*Aktor :* _${movie.actors}_\n`;
 Lenwy_txt += `*Bahasa :* _${movie.language}_\n`;
 Lenwy_txt += `*Negara :* _${movie.country}_\n`;
 Lenwy_txt += `*Penghargaan :* _${movie.awards}_\n`;
 Lenwy_txt += `*Keuntungan :* _${movie.boxOffice || 'Tidak Tersedia'}_\n`;
 Lenwy_txt += `*Nilai :* _${movie.imdbRating}_\n`;
 Lenwy_txt += `*Pemungutan Suara :* _${movie.imdbVotes}_\n\n`;
 Lenwy_txt += `*Plot :*\n_${movie.plot}_`;

await lenwy.sendMessage(m.chat, { image: { url: movie.poster, },
caption: Lenwy_txt, }, {quoted: m,});
    } catch (error) {
        console.error("Error:", error.message);
        lenwyreply("Terjadi kesalahan saat mengambil data dari IMDB.");
    }
  }
break           

case 'asmaulhusna': {
const t3xt = require(`./database/teks/${command}.json`)
const r4andT3xt = t3xt[Math.floor(Math.random() * t3xt.length)]
lenwy.sendMessage(from, { text: r4andT3xt }, { quoted: m })
}
break

case 'ayatkursi': {
let lenwycap = `*Ayat Kursi*

✉️ *Arab :*
اللَّهُ لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ وَلَا يَئُودُهُ حِفْظُهُمَا وَهُوَ الْعَلِيُّ الْعَظِيمُ

✉️ *Latin :*
*“Alloohu laa ilaaha illaa huwal hayyul qoyyuum, laa ta’khudzuhuu sinatuw walaa naum. Lahuu maa fissamaawaati wa maa fil ardli man dzal ladzii yasyfa’u ‘indahuu illaa biidznih, ya’lamu maa baina aidiihim wamaa kholfahum wa laa yuhiithuuna bisyai’im min ‘ilmihii illaa bimaa syaa’ wasi’a kursiyyuhus samaawaati wal ardlo walaa ya’uuduhuu hifdhuhumaa wahuwal ‘aliyyul ‘adhiim.”*

✉️ *Artinya:*
Allah, tidak ada Tuhan (yang berhak disembah) melainkan Dia Yang Hidup kekal lagi terus menerus mengurus (makhluk-Nya); tidak mengantuk dan tidak tidur. Kepunyaan-Nya apa yang di langit dan di bumi. Tiada yang dapat memberi syafa'at di sisi Allah tanpa izin-Nya.
Allah mengetahui apa-apa yang di hadapan mereka dan di belakang mereka, dan mereka tidak mengetahui apa-apa dari ilmu Allah melainkan apa yang dikehendaki-Nya. Kursi Allah meliputi langit dan bumi. Dan Allah tidak merasa berat memelihara keduanya, dan Allah Maha Tinggi lagi Maha Besar." 
*(QS. Al Baqarah: 255)*`
lenwy.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/afb17800d56775ad1791d.png' }, caption: lenwycap}, { quoted: m });
}

break


case 'kisahnabi':{
if (!text) return lenwyreply(`*Tolong Masukkan Nama Nabi*`) 
try{
let ilenwy = await fetchJson(`https://api.zeeoneofc.my.id/api/islam/kisahnabi?apikey=QIO8xicLNkEV43Y&nabi=${text}`)
const namanabi = ilenwy.result.name
const kelahiran = ilenwy.result.birth
const wafat = ilenwy.result.death_age
const asal = ilenwy.result.country_from
const ceritanabi = ilenwy.result.story
var lenwy_result = `*Kisah Nabi*
☪️ *Nama Nabi : ${namanabi}*
🗓️ *Hari Kelahiran : ${kelahiran}*
🕒 *Wafat Pada Umur : ${wafat}*
🌏 *Asal : ${asal}*

*Kisah Dari Nabi ${namanabi} :*
${ceritanabi}`
lenwyreply(lenwy_result) 
} catch (error) {
    return lenwyreply(mess.error);
}
}
break

case 'doa':{
if (!text) return lenwyreply(`*Tolong Masukkan Doa Yang Ingin Dicari*`) 
try{
lenwyreply(mess.wait)
let ilenwy = await fetchJson(`https://doa-doa-api-ahmadramadhan.fly.dev/api/doa/${text}`)
const namadoa = ilenwy.doa
const ayat = ilenwy.ayat
const latin = ilenwy.latin
var lenwy_result = `*Pencarian : ${namadoa}*

*${ayat}*

*${latin}*`
lenwyreply(lenwy_result) 
} catch (error) {
    return lenwyreply(mess.error);
}
}
break

case 'surah': {
  if (isBan) return lenwyreply('*Kamu Di Ban Owner*');
  if (!q) return lenwyreply('*Masukkan Nomor Surah*');
  const surahNumber = q.toLowerCase();
  try {
    const result = await LenSurah(surahNumber);
    if (result.ayat && result.ayat.length > 0) {
      let Lenwyy = `*Audio Surah :* _${result.audio}_\n`;
      result.ayat.forEach((ayat, index) => {
        Lenwyy += `\n*Ayat ${index + 1}*\n`;
        Lenwyy += `*Arab :* ${ayat.arab}\n`;
        Lenwyy += `*Latin :* _${ayat.latin}_\n\n`;
        Lenwyy += ` _${ayat.indo}_\n`;
        Lenwyy += '\n==============================\n';
      });
      Lenwyy += `\n*${result.watermark}*`;
      lenwyreply(Lenwyy);
    } else {
      lenwyreply('*Data Surah Tidak Ditemukan!*');
    }
  } catch (error) {
    console.error(error);
    lenwyreply('*Terjadi Kesalahan, Coba Lagi Nanti!*');
  }
}
break

case 'jadwalsholat': {
const { scrapeJadwalSholat } = require('./kiromi/kay/jadwalsholat.js');
    try {
        if (!args[0]) return await lenwy.sendMessage(m.chat, { text: '❌ Masukkan nama kota! Contoh: *!jadwalsholat Jakarta*' }, { quoted: m });

        let kota = args.join(' ');

        let data = await scrapeJadwalSholat(kota);
        if (!data) return await lenwy.sendMessage(m.chat, { text: '❌ Gagal mengambil jadwal sholat. Coba lagi nanti.' }, { quoted: m });

        let caption = `🕌 *JADWAL SHOLAT ${data.kota.toUpperCase()}* 🕌\n\n📅 *Tanggal:* ${data.tanggal}\n\n🌅 *Imsak:* ${data.imsak}\n🕋 *Subuh:* ${data.subuh}\n🌄 *Terbit:* ${data.terbit}\n🕌 *Dzuhur:* ${data.dzuhur}\n🌇 *Ashar:* ${data.ashar}\n🌆 *Maghrib:* ${data.maghrib}\n🌃 *Isya:* ${data.isya}`;

        await lenwy.sendMessage(m.chat, { text: caption }, { quoted: m });
    } catch (error) {
        console.error('❌ Error mengambil jadwal sholat:', error);
        await lenwy.sendMessage(m.chat, { text: '❌ Terjadi kesalahan, coba lagi nanti.' }, { quoted: m });
    }
}
break;

case 'selectsurah': {
    const { getSurah } = require('./kiromi/kay/quran.js');

    if (!args[0] || isNaN(args[0])) {
        return lenwyreply("🚫 *Masukkan nomor surah yang valid.* Contoh: *!selectsurah 1*");
    }

    let surahIndex = parseInt(args[0]);
    await lenwyreply("⏱️ Sedang mengambil data surah...");

    getSurah(surahIndex).then(response => {
        lenwyreply(response);
    }).catch(err => {
        console.error(err);
        lenwyreply("🚫 *Terjadi kesalahan saat mengambil data surah.*");
    });
}
break

case 'history': {
    if (!args[0]) return lenwyreply('Harap masukkan nama nabi atau kata kunci!');

    let keyword = args.join(' '); // Kata kunci dari pengguna

    try {
        lenwyreply('Sebentar ya, sedang mencari sejarah nabi...');

        // Panggil API untuk mendapatkan informasi sejarah nabi
        let res = await axios.get('https://fastrestapis.fasturl.cloud/religious/prophetstory', {
            params: {
                name: keyword
            }
        });

        // Parsing hasil API
        let result = res.data.result;
        if (res.data.status !== 200 || !result) {
            return lenwyreply('Gagal menemukan sejarah nabi dengan kata kunci tersebut.');
        }

        // Mengirim semua informasi dari setiap hasil
        for (let item of result) {
            let prophetInfo = `*🔶 Nama Nabi:* ${item.name}\n` +
                              `📅 *Tahun Kelahiran:* ${item.bornYear}\n` +
                              `🕰️ *Usia:* ${item.age}\n` +
                              `🌍 *Tempat:* ${item.place}\n` +
                              `📖 *Deskripsi:* ${item.description}`;

            // Kirim gambar dari setiap hasil
            await lenwy.sendMessage(m.chat, { 
                image: { url: item.imageUrl }, // Gambar dari URL
                caption: prophetInfo
            }, { quoted: m });
        }

    } catch (err) {
        console.error(err);
        lenwyreply('Terjadi kesalahan saat memproses permintaan.');
    }
}
break

case 'wirid': {
    try {
        lenwyreply('Sebentar ya, sedang mencari wirid...');

        // Panggil API untuk mendapatkan semua informasi wirid
        let res = await axios.get('https://fastrestapis.fasturl.cloud/religious/wirid');

        // Parsing hasil API
        let result = res.data.result;
        if (res.data.status !== 200 || !result) {
            return lenwyreply('Gagal menemukan wirid.');
        }

        // Menyusun pesan yang menarik
        let replyMessage = `*🌙 Daftar Wirid yang Tersedia:* \n\n`;
        for (let item of result) {
            let wiridInfo = `*🔹 ID:* ${item.id}\n` +
                            `*⏱️ Jumlah Pengulangan:* ${item.times} kali\n` +
                            `*📝 Teks Arab:* ${item.arabic}\n` +
                            `*📜 Petunjuk:* ${item.instruction || 'Tidak ada petunjuk'}\n`;

            replyMessage += `\n━━━━━━━━━━━━━━━━━\n${wiridInfo}━━━━━━━━━━━━━━━━━\n`;
        }

        // Mengirim pesan yang sudah diformat
        lenwyreply(replyMessage);

    } catch (err) {
        console.error(err);
        lenwyreply('Terjadi kesalahan saat memproses permintaan.');
    }
}
break


case 'audiosurah': {
    let wrong = `_*Contoh Penggunaan :*_\naudiosurah 1

*List Surah :*
1 : Al-Fatihah
2 : Al-Baqarah
3 : Ali 'Imran
4 : An-Nisa'
5 : Al-Ma'idah
6 : Al-An'am
7 : Al-A’raf
8 : Al-Anfal
9 : At-Taubah
10 : Yunus
11 : Hud
12 : Yusuf
13 : Ar-Ra’d
14 : Ibrahim
15 : Al-Hijr
16 : An-Nahl
17 : Al-Isra'
18 : Al-Kahf
19 : Maryam
20 : Ta Ha
21 : Al-Anbiya
22 : Al-Hajj
23 : Al-Mu’minun
24 : An-Nur
25 : Al-Furqan
26 : Asy-Syu'ara'
27 : An-Naml
28 : Al-Qasas
29 : Al-'Ankabut
30 : Ar-Rum
31 : Luqman
32 : As-Sajdah
33 : Al-Ahzab
34 : Saba’
35 : Fatir
36 : Ya Sin
37 : As-Saffat
38 : Sad
39 : Az-Zumar
40 : Ghafir
41 : Fussilat
42 : Asy-Syura
43 : Az-Zukhruf
44 : Ad-Dukhan
45 : Al-Jasiyah
46 : Al-Ahqaf
47 : Muhammad
48 : Al-Fath
49 : Al-Hujurat
50 : Qaf
51 : Az-Zariyat
52 : At-Tur
53 : An-Najm
54 : Al-Qamar
55 : Ar-Rahman
56 : Al-Waqi’ah
57 : Al-Hadid
58 : Al-Mujadilah
59 : Al-Hasyr
60 : Al-Mumtahanah
61 : As-Saff
62 : Al-Jumu’ah
63 : Al-Munafiqun
64 : At-Tagabun
65 : At-Talaq
66 : At-Tahrim
67 : Al-Mulk
68 : Al-Qalam
69 : Al-Haqqah
70 : Al-Ma’arij
71 : Nuh
72 : Al-Jinn
73 : Al-Muzzammil
74 : Al-Muddassir
75 : Al-Qiyamah
76 : Al-Insan
77 : Al-Mursalat
78 : An-Naba’
79 : An-Nazi’at
80 : 'Abasa
81 : At-Takwir
82 : Al-Infitar
83 : Al-Tatfif
84 : Al-Insyiqaq
85 : Al-Buruj
86 : At-Tariq
87 : Al-A’la
88 : Al-Gasyiyah
89 : Al-Fajr
90 : Al-Balad
91 : Asy-Syams
92 : Al-Lail
93 : Ad-Duha
94 : Al-Insyirah
95 : At-Tin
96 : Al-'Alaq
97 : Al-Qadr
98 : Al-Bayyinah
99 : Az-Zalzalah
100 : Al-'Adiyat
101 : Al-Qari'ah
102 : At-Takasur
103 : Al-'Asr
104 : Al-Humazah
105 : Al-Fil
106 : Quraisy
107 : Al-Ma’un
108 : Al-Kausar
109 : Al-Kafirun
110 : An-Nasr
111 : Al-Lahab
112 : Al-Ikhlas
113 : Al-Falaq
114 : An-Nas`;

    if (!text) return lenwyreply(wrong);

    try {
        // Memberi reaksi terlebih dahulu
        await lenwy.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }});

        // Kirim audio surah dari API
        await lenwy.sendMessage(m.chat, {
            audio: { url: `https://api.lolhuman.xyz/api/quran/audio/${text}?apikey=5be94ede1b5591e1d3d85392` },
            mimetype: 'audio/mpeg'
        }, { quoted: m });

    } catch (err) {
        console.error(err);
        lenwyreply('Terjadi kesalahan saat memproses permintaan.');
    }
}
break
/*
case 'play': case 'song': {
if (isBan) return lenwyreply('*Kamu Di Ban Owner*')
if (!text) return lenwyreply(`*Contoh: Play Boa-Duvet*`)
if (text.length > 40) return lenwyreply(`*Maksimal 40 Karakter*`)
lenwyreply("🔎 *Mencari Lagu*")    
let yts = require ('yt-search')
let search = await yts(`${text}`)
let link = search.all[0].url
let lenplay = `🎧 *Playing Music*\n\n📃 *Judul : ${search.all[0].title}*\n🕒 *Durasi : ${search.all[0].timestamp}*\n📅 *Upload : ${search.all[0].ago}*`
            let lenwyp = generateWAMessageFromContent(from, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: lenplay
          }),
          header: proto.Message.InteractiveMessage.Header.create({
                ...(await prepareWAMessageMedia({ image : { url : search.all[0].thumbnail }}, { upload: lenwy.waUploadToServer})), 
                  title: ``,
                  gifPlayback: true,
                  hasMediaAttachment: false  
                }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":"🎧 Audio","id":"${prefix}ytmp3 ${link}"}`
              }
           ],
          }),
          contextInfo: {
            mentionedJid: [m.sender], 
            isForwarded: true, 
            forwardedNewsletterMessageInfo: {
            serverMessageId: -1
            },
                }
        })
    }
  }
}, {})

await lenwy.relayMessage(lenwyp.key.remoteJid, lenwyp.message, {
messageId: lenwyp.key.id
})
}
break
*/ 

/*
case 'play': case 'song': {
  if (isBan) return lenwyreply('*Kamu Di Ban Owner*');
  if (!text) return lenwyreply(`*Contoh: Play Boa-Duvet*`);
  if (text.length > 40) return lenwyreply(`*Maksimal 40 Karakter*`);

  lenwyreply("🔍 *Mencari Lagu*");

  const yts = require('yt-search');

  (async () => {
    try {
      const search = await yts(`${text}`);
      const results = search.all.slice(0, 3);

      const push = [];
      for (const result of results) {
        push.push({
          body: proto.Message.InteractiveMessage.Body.fromObject({
            text: ` *Judul :* _${result.title}_\n *Durasi :* _${result.timestamp}_\n *Upload :* _${result.ago}_`
          }),
          header: proto.Message.InteractiveMessage.Header.fromObject({
            title: ` *Lenwy Play ☕*`,
            hasMediaAttachment: true,
            imageMessage: await createImage(result.thumbnail)
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
            buttons: [
              {
                "name": "quick_reply",
                "buttonParamsJson": `{"display_text":" Play", "id": "${prefix}ytmp3 ${result.url}"}`
              },
              {
                "name": "cta_url",
                "buttonParamsJson": `{"display_text":" YouTube", "url": "${result.url}", "merchant_url": "${result.url}"}`
              }
            ]
          })
        });
      }

      const bot = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2
            },
            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
              body: proto.Message.InteractiveMessage.Body.create({
                text: `*Ditemukan ${results.length} Lagu*`
              }),
              header: proto.Message.InteractiveMessage.Header.create({
                hasMediaAttachment: false
              }),
              carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                cards: [...push]
              })
            })
          }
        }
      }, {});

      await lenwy.relayMessage(m.chat, bot.message, {
        messageId: bot.key.id
      });
    } catch (err) {
      console.error(err);
      lenwyreply('❌ *Maaf, terjadi kesalahan saat mencari lagu*');
    }
  })();
}
break
*/

case 'play': 
case 'song': {
  if (isBan) return lenwyreply('*Kamu Di Ban Owner*');
  if (!text) return lenwyreply(`*Contoh: Play Boa-Duvet*`);

  // Cek limit hanya untuk user non-premium
  if (!isPrem && global.db.data.users[m.sender].limit < 5) return lenwyreply('*Limit Kamu Habis, Silahkan Hubunggi Kay/Tunggu besok*');
  if (!isPrem) global.db.data.users[m.sender].limit -= 5; // Mengurangi limit hanya jika bukan premium

  const yts = require('yt-search');
  const axios = require('axios');

  (async () => {
    try {
      // Mengirim emoji proses
      await lenwy.sendMessage(m.chat, { react: { text: '⏱️', key: m.key } });

      const search = await yts(`${text}`);
      const result = search.videos[0];

      if (!result) {
        await lenwy.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        return lenwyreply("⚠ *Lagu Tidak Ditemukan*");
      }

      const { title, url, views, author, ago, duration, thumbnail } = result;

      // Menyiapkan detail informasi lagu
      const detail = `🎧 *Informasi Audio YouTube* 🎵\n\n` +
                     `📌 *Judul*    : ${title}\n` +
                     `👀 *Penonton* : ${views}\n` +
                     `🎤 *Pengarang*: ${author.name}\n` +
                     `📅 *Diunggah* : ${ago}\n` +
                     `⏱️ *Durasi*   : ${duration}\n` +
                     `🔗 *URL*      : ${url}\n\n` +
                     `⏱️ *Proses Pengunduhan Audio...*`;

      // Mengirim informasi detail lagu dengan thumbnail
      await lenwy.sendMessage(m.chat, { 
        image: { url: thumbnail }, 
        caption: detail 
      });

      const mp3Result = await LenwyMp3(url);
      const data = JSON.parse(mp3Result);

      if (data.error) {
        await lenwy.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        return lenwyreply(data.error);
      }

      const { image, download_url } = data;

      // Mengunduh file audio menggunakan axios
      const audioBuffer = await axios.get(download_url, { responseType: 'arraybuffer' });

      // Mengirim pesan dengan file audio
      await lenwy.sendMessage(m.chat, { 
        audio: Buffer.from(audioBuffer.data), 
        mimetype: 'audio/mpeg',
        fileName: `${title}.mp3`, 
        caption: `*Judul :* _${title}_`, 
        contextInfo: {
          externalAdReply: {
            title: title,
            body: "Kayzu MP3 Downloader",
            thumbnailUrl: image, // Thumbnail yang akan dikirim bersama file audio
            sourceUrl: url,
            mediaType: 1,
          }
        }
      }, { quoted: m });

      // React selesai setelah pengiriman berhasil
      await lenwy.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

    } catch (err) {
      console.error(err);
      await lenwy.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      lenwyreply('❌ *Maaf, terjadi kesalahan saat mencari atau mengunduh lagu*');
    }
  })();
}
break

case 'chord':{
if (!text) return lenwyreply(`*Tolong Masukkan judul Lagu*`)
lenwyreply(mess.wait) 
try{
let lenwy_chord = await fetchJson(`https://Meitang.xyz/chord?query=${text}`)
const judul = lenwy_chord.result.title
const chordlagu = lenwy_chord.result.chord
var lenwy_result = `*Chord Lagu*
*Nama Lagu : ${judul}*
*Chord Lagu :*\n${chordlagu}`
lenwyreply(lenwy_result) 
}catch (error) {
lenwyreply(`*Nama Lagu Tidak Ditemukan*`);
}
}
break

case 'done':
case 'd': {
    if (isBan) return lenwyreply('*Kamu Di Ban Owner*');
    
    // Pisahkan input text dengan koma
    let s = text.split(',');
    let barang = s[0];
    let nominal = s[1];
    
    // Validasi input
    if (s.length < 2) return lenwyreply(`*Format salah!*\nPenggunaan:\n${command} barang,nominal`);
    if (!barang) return lenwyreply(`Contoh penggunaan: ${command} barang,nominal\n\nMisal: ${command} vipies,60000`);
    if (!nominal) return lenwyreply(`Contoh penggunaan: ${command} barang,nominal\n\nMisal: ${command} panel,1000`);

    // Format tanggal dan waktu
    let date = new Date().toLocaleDateString('id-ID', { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    });
    let time = new Date().toLocaleTimeString('id-ID', { 
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit', 
        timeZone: 'Asia/Jakarta' 
    });

    // Pesan selesai transaksi
    let text_done = `「 𝗧𝗥𝗔𝗡𝗦𝗔𝗞𝗦𝗜 𝗕𝗘𝗥𝗛𝗔𝗦𝗜𝗟 」

📦 Barang: ${barang}
💸 Nominal: ${nominal}
📆 Tanggal: ${date}
🕰️ Waktu: ${time}
✨ Status: Berhasil

𝗧𝗲𝗿𝗶𝗺𝗮𝗸𝗮𝘀𝗶𝗵 𝗧𝗲𝗹𝗮𝗵 𝗢𝗿𝗱𝗲𝗿 𝗗𝗶 KayzuMD
𝗗𝗶 𝗧𝘂𝗻𝗴𝗴𝘂 𝗢𝗿𝗱𝗲𝗿𝗮𝗻 𝗦𝗲𝗹𝗮𝗻𝗷𝘂𝘁𝗻𝘆𝗮☺️`;

    // Kirim pesan selesai transaksi
    await lenwy.sendMessage(m.chat, { text: text_done }, { quoted: m });
}
break

case 'closetime':
    if (!m.isGroup) return m.reply('ᴋʜᴜsᴜs ɢʀᴏᴜᴘ');
    if (!isBotAdmins) return reply(mess.badm);

    // Mengatur timer berdasarkan unit waktu
    let timerClose;
    if (args[1] == "detik") {
        timerClose = args[0] * 1000; // Detik
    } else if (args[1] == "menit") {
        timerClose = args[0] * 60000; // Menit
    } else if (args[1] == "jam") {
        timerClose = args[0] * 3600000; // Jam
    } else if (args[1] == "hari") {
        timerClose = args[0] * 86400000; // Hari
    } else {
        return m.reply("*pilih:*\ndetik\nmenit\njam\n\n*contoh*\n10 detik");
    }

    m.reply(`Close time ${args[0]} ${args[1]} dimulai dari sekarang`);

    // Set timeout untuk menutup pengaturan grup
    setTimeout(async () => {
        const close = `*Tepat waktu* grup ditutup oleh admin\nsekarang hanya admin yang dapat mengirim pesan`;
        await lenwy.groupSettingUpdate(from, 'announcement').catch((err) => lenwyreply(jsonformat(err)));
        m.reply(close);
    }, timerClose);
    break

case 'opentime':
    if (!m.isGroup) return m.reply('ᴋʜᴜsᴜs ɢʀᴏᴜᴘ');
    if (!isBotAdmins) return reply(mess.badm);

    // Mengatur timer berdasarkan unit waktu
    let timerOpen;
    if (args[1] == "detik") {
        timerOpen = args[0] * 1000; // Detik
    } else if (args[1] == "menit") {
        timerOpen = args[0] * 60000; // Menit
    } else if (args[1] == "jam") {
        timerOpen = args[0] * 3600000; // Jam
    } else if (args[1] == "hari") {
        timerOpen = args[0] * 86400000; // Hari
    } else {
        return m.reply("*pilih:*\ndetik\nmenit\njam\n\n*contoh*\n10 detik");
    }

    m.reply(`Open time ${args[0]} ${args[1]} dimulai dari sekarang`);

    // Set timeout untuk membuka pengaturan grup
    setTimeout(async () => {
        const open = `*Tepat waktu* grup dibuka oleh admin\nsekarang member dapat mengirim pesan`;
        await lenwy.groupSettingUpdate(from, 'not_announcement').catch((err) => lenwyreply(jsonformat(err)));
        m.reply(open);
    }, timerOpen);
    break
    
/*case 'mp3': case 'ytmp3': {
if (isBan) return lenwyreply('*Kamu Di Ban Owner*')
if (!q) return lenwyreply(`*Kirim Link Youtube*`)
if (!isUrl(args[0])) return lenwyreply(mess.link)
lenwyreply(mess.wait)
downloadMp3(text)
}
break*/

/*case 'mp3': case 'ytmp3': {
if (isBan) return lenwyreply('*Kamu Di Ban Owner*')
if (!q) return lenwyreply(`*Kirim Link Youtube*`)
if (!isUrl(args[0])) return lenwyreply(mess.link)    
try {
lenwyreply(mess.wait)
let proces = await (await fetch(`https://Meitang.xyz/download/ytdl?url=${text}`)).json()
let audio = proces.result; lenwy.sendMessage(m.chat,{audio:{url: audio.mp3 }, mimetype: 'audio/mpeg' },{quoted: m})
} catch (e) {
lenwyreply(mess.error);
}
}
break*/

/*case 'mp3': case 'ytmp3': {
if (isBan) return lenwyreply('*Kamu Di Ban Owner*')
if (!q) return lenwyreply(`*Kirim Link Youtube*`)
try {
lenwyreply(mess.wait)
let proces = await (await fetch(`https://api-lenwy.vercel.app/mp3?url=${text}`)).json()
let audio = proces.result; lenwy.sendMessage(m.chat,{audio:{url: audio.download_url }, mimetype: 'audio/mpeg' },{quoted: m})
} catch (e) {
lenwyreply(mess.error);
}
}
break*/

case 'mp3': {
  if (isBan) return lenwyreply('*Kamu Di Ban Owner*');
  if (!args[0] || !isUrl(args[0])) return lenwyreply(`*Link Youtubenya Mana?*`);
  
  lenwyreply('*One Moment, Please ☕*');
  const url = args[0];
  try {
      const mp3Result = await LenwyMp3(url);
      const data = JSON.parse(mp3Result);

      if (data.error) {
          return lenwyreply(data.error);
      }
      
      const { title, image, download_url } = data;
      const audioBuffer = await axios.get(download_url, { responseType: 'arraybuffer' });
      
      await lenwy.sendMessage(m.chat, { 
          audio: Buffer.from(audioBuffer.data), 
          mimetype: 'audio/mpeg',
          fileName: `${title}.mp3`,
          caption: `Title: ${title}`,
          contextInfo: {
              externalAdReply: {
                  title: title,
                  body: "Kayzu MP3 Downloader",
                  thumbnailUrl: image,
                  sourceUrl: url,
                  mediaType: 1,
              }
          }
      }, { quoted: m });
  } catch (error) {
      console.error("Error in ytmp3 case:", error);
      lenwy.sendMessage(m.chat, { text: '⚠ *Terjadi Kesalahan, Coba Lagi Nanti*' }, { quoted: m });
  }
}
break

/*case 'yt': case 'ytmp4': {
const lenwyvid = require('./lib/ytdl')
if (args.length < 1 || !isUrl(text) || !lenwyvid.isYTUrl(text)) lenwyreply(`*Link Youtubenya Mana?*`)
if (!isUrl(args[0])) return lenwyreply(mess.link)
const vid=await lenwyvid.mp4(text)
lenwyreply(mess.wait)
const lenwycap=`*Youtube Selesai*
🕒 *Durasi : ${vid.duration} Detik*
*Kualitas : ${vid.quality}*`
await lenwy.sendMessage(m.chat,{
    video: {url:vid.videoUrl},
    caption: lenwycap
},{quoted:m}).catch((err) => lenwyreply(mess.error))
}
break*/

/*case 'yt': case 'ytmp4': {
if (isBan) return lenwyreply('*Kamu Di Ban Owner*')
if (!q) return lenwyreply(`*Kirim Link Youtube*`)
if (!isUrl(args[0])) return lenwyreply(mess.link)    
try {
lenwyreply(mess.wait)
let proces = await (await fetch(`https://Meitang.xyz/download/ytdl?url=${text}`)).json()
let video = proces.result; lenwy.sendMessage(m.chat,{video:{url: video.mp4 }, caption: "*Youtube Selesai*"},{quoted: m})
} catch (e) {
lenwyreply(mess.error);
}
}
break*/

/*case 'yt': case 'ytmp4': {
if (isBan) return lenwyreply('*Kamu Di Ban Owner*')
if (!q) return lenwyreply(`*Kirim Link Youtube*`)
try {
lenwyreply(mess.wait)
let proces = await (await fetch(`https://api-lenwy.vercel.app/mp4?url=${text}`)).json()
let video = proces.result; lenwy.sendMessage(m.chat,{video:{url: video.download_url }, caption: "*Youtube Selesai*"},{quoted: m})
} catch (e) {
lenwyreply(mess.error);
}
}
break*/

case 'mp4': {
    if (isBan) return lenwyreply('*Kamu Di Ban Owner*');
    if (args.length < 1 || !isUrl(text)) {
      return lenwyreply(`*Link Youtubenya Mana?*`);  
    }
    lenwyreply('*One Moment, Please ☕*')
    const url = args[0];
    try {
      let result = await LenwyMp4(url);
      if (result.success === false && result.message === 'Invalid URL') {
        return lenwyreply('*URL yang dimasukkan tidak valid. Pastikan URL berasal dari sumber yang didukung.*');
      }
      let { title, image, download_url } = result;
      const videoBuffer = await axios.get(download_url, { responseType: 'arraybuffer' });
      await lenwy.sendMessage(m.chat, { 
        video: Buffer.from(videoBuffer.data), 
        caption: `*Youtube Selesai*`,
        mimetype: 'video/mp4',
        contextInfo: {
          externalAdReply: {
            title: title,
            body: "Kayzu MP4 Downloader",
            thumbnailUrl: image,
            sourceUrl: url,
            mediaType: 1
          }
        }
      }, { quoted: m });
    } catch (error) {
      console.error(error);
      lenwy.sendMessage(m.chat, { text: '⚠ *Terjadi Kesalahan, Coba Lagi Nanti*' }, { quoted: m });
    }
  }
break  

case 'git': case 'gitclone':
if (isBan) return lenwyreply('*Kamu Di Ban Owner*')
                if (!args[0]) return lenwyreply(`Mana link nya?`)
                if (!isUrl(args[0]) && !args[0].includes('github.com')) return lenwyreply(`Link invalid!! 🤔`)
                LenwyLD()
                let regex1 = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
                let [, user, repo] = args[0].match(regex1) || []
                repo = repo.replace(/.git$/, '')
                let url = `https://api.github.com/repos/${user}/${repo}/zipball`
                let filename = (await fetch(url, {method: 'HEAD'})).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
                lenwy.sendMessage(m.chat, { document: { url: url }, fileName: filename, mimetype: 'application/zip' }, { quoted: m }).catch((err) => lenwyreply(mess.error))
            .catch(console.error)
            break

case 'tt': {
    if (!args[0]) return lenwyreply('❌ Harap masukkan URL TikTok!');

    let url = args[0].trim();
    
    try {
        await lenwy.sendMessage(m.chat, {
            react: { text: "⏱️", key: m.key }
        });

        let { tiktokScraper } = require('./kiromi/kay/tiktokscraper.js');
        let data = await tiktokScraper(url);

        if (data.error) return lenwyreply(`❌ ${data.error}`);

        let caption = `
🎥 *TikTok Video*
📌 *Judul:* ${data.title}
⏱️ *Durasi:* ${data.duration}
📆 *Diunggah:* ${data.taken_at}
🌍 *Region:* ${data.region}

👤 *Pembuat Konten:*
- Nama: ${data.author.fullname} (@${data.author.username})
- Avatar: ${data.author.avatar}

🎶 *Musik:*
- Judul: ${data.music.title}
- Artis: ${data.music.author}
- Link Musik: ${data.music.url}

📊 *Statistik:*
👁️ *Views:* ${data.stats.views}
👍 *Likes:* ${data.stats.likes}
💬 *Komentar:* ${data.stats.comments}
📤 *Shares:* ${data.stats.shares}
⬇️ *Unduhan:* ${data.stats.downloads}
        `.trim();

        // Kirim video tanpa watermark HD jika ada, kalau nggak pakai yang biasa
        let videoUrl = data.video.nowatermark_hd || data.video.nowatermark;
        if (!videoUrl) return lenwyreply('❌ Video tanpa watermark tidak ditemukan.');

        await lenwy.sendMessage(m.chat, {
            video: { url: videoUrl },
            caption
        }, { quoted: m });

        // Kirim audio jika ada
        if (data.music.url) {
            await lenwy.sendMessage(m.chat, {
                audio: { url: data.music.url },
                mimetype: 'audio/mpeg',
                fileName: `${data.music.title}.mp3`
            }, { quoted: m });
        }

        await lenwy.sendMessage(m.chat, {
            react: { text: "✅", key: m.key }
        });

    } catch (err) {
        console.error("[TikTok Scraper Error]", err);
        lenwyreply('❌ Terjadi kesalahan saat memproses permintaan.');
    }
}
break


case 'ttsearch':
case 'tiktoksearch': {
    try {
        const query = args.join(' '); // Ambil query dari user
        if (!query) return lenwyreply('Masukkan kata kunci untuk mencari video TikTok 😋🗿');

        // Kirim emoji react ⏱️ sebagai indikator pencarian
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "⏱️",
                key: m.key,
            }
        });

        // Fetch data dari API
        const response = await fetch(`https://api.agatz.xyz/api/tiktoksearch?message=${encodeURIComponent(query)}`);
        const result = await response.json();

        // Cek status response
        if (result.status !== 200 || !result.data) {
            return lenwyreply('Video tidak ditemukan atau terjadi kesalahan 😢');
        }

        // Kirim emoji ✅ sebagai indikasi proses selesai
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key,
            }
        });

        // Kirim video tanpa watermark
        await lenwy.sendMessage(m.chat, { 
            video: { url: result.data.no_watermark }, 
            caption: `🎥 *Judul*: ${result.data.title}\n🎵 *Musik*: ${result.data.music}`
        }, { quoted: m });

    } catch (error) {
        console.error(error);
        lenwyreply('Terjadi kesalahan saat mencari video 😢');
    }
}
break

/*case 'ig':
case 'igdl': {
if (!text) return lenwyreply(`
*Link Instagramnya Mana?*`)
if (!isUrl(args[0])) return lenwyreply(mess.link)
lenwyreply(mess.wait)
const { igdl, igdl2 } = require('./lib/igdl.js')
const res = await igdl(args[0])
const url = res.data[0]
let lenwycap = `*Instagram Selesai*`
lenwy.sendMessage(m.chat, {video: { url: url}, mimetype: 'video/mp4', caption : lenwycap}, {quoted: m}).catch((err) => lenwyreply(mess.error))
}
break*/

/*case 'ig':
case 'igdl':
  if (!text) return lenwyreply("🔍 *Link Instagramnya Mana?*"); 
    lenwyreply(`*One Moment, Please ☕*`);
    try {
        const type = types.includes(text) ? text : 'video';
        const result = await LenwyIgdl(text, type);
        if (!result.success) {
            lenwyreply(`⚠ *Gagal Mengambil Media :* _${result.message}_`);
        } else {
            const { thumbnail, video } = result;
            
            // Mengirim pesan dengan media yang diunduh
            if (type === 'video') {
                await lenwy.sendMessage(m.chat, {
                    video: { url: video },
                    caption: `ム* Video Instagram Selesai*`,
                    thumbnail: thumbnail,
                    contextInfo: {
                        externalAdReply: {
                            title: "Instagram Video Downloader",
                            body: "Lenwy IGDL",
                            thumbnailUrl: thumbnail,
                            sourceUrl: text
                        }
                    }
                }, { quoted: m });
            } else {
                await lenwy.sendMessage(m.chat, {
                    image: { url: thumbnail },
                    caption: `ム* Image Instagram Selesai`,
                    contextInfo: {
                        externalAdReply: {
                            title: "Instagram Image Downloader",
                            body: "Lenwy IGDL",
                            thumbnailUrl: thumbnail,
                            sourceUrl: text
                        }
                    }
                }, { quoted: m });
            }
        }
  } catch (error) {
    lenwyreply("⚠ *Terjadi Kesalahan*");
    console.error("Error:", error);
}
break*/

case "igdl": {
    if (!text) return lenwyreply("Masukkan URL Instagram!");

    await lenwy.sendMessage(m.chat, {
        react: {
            text: "⏱️",
            key: m.key,
        }
    });

    try {
        let res = await fetch(`https://fastrestapis.fasturl.cloud/downup/igdown?url=${encodeURIComponent(text)}`);
        let json = await res.json();

        if (json.status !== 200 || !json.result.status) return lenwyreply("Gagal mengunduh video!");

        let videoUrl = json.result.data[0].url;

        await lenwy.sendMessage(m.chat, {
            video: { url: videoUrl },
            mimetype: "video/mp4"
        }, { quoted: m });

        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key,
            }
        });
    } catch (e) {
        console.error(e);
        lenwyreply("Terjadi kesalahan saat mengunduh video!");
    }
}
break

case 'ig': {
    const { instagramScraper } = require('./kiromi/kay/ig.js');

    if (!args[0]) {
        return lenwyreply("⚠️ Masukkan link Instagram yang ingin di-download.\nContoh: *!instadown https://www.instagram.com/reel/DCPHUxuyKW1/*");
    }

    let url = args[0];

    // Kirim reaksi proses ⏱️
    await lenwy.sendMessage(m.chat, {
        react: {
            text: "⏱️",
            key: m.key,
        }
    });

    instagramScraper(url).then(async (result) => {
        if (result.error) {
            return lenwyreply("🚫 *Gagal mengambil data.* Pastikan link yang dimasukkan benar atau coba lagi nanti.");
        }

        let mediaUrl = result.video.url; // Ambil link video

        // Kirim media
        await lenwy.sendMessage(m.chat, { video: { url: mediaUrl } }, { quoted: m });

        // Ubah reaksi ke ✅ setelah sukses
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key,
            }
        });
    }).catch(async () => {
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key,
            }
        });
        lenwyreply("🚫 *Terjadi kesalahan saat mengambil media.*");
    });
}
break

case 'fb': {
    if (!args[0]) return lenwyreply('❌ Harap masukkan URL Facebook!');

    let url = args[0].trim();

    try {
        await lenwy.sendMessage(m.chat, {
            react: { text: "⏱️", key: m.key }
        });

        let { facebookScraper } = require('./kiromi/kay/fbscraper.js'); // Ganti dengan file fbScraper.js
        let data = await facebookScraper(url);

        if (data.error) return lenwyreply(`❌ ${data.error}`);

        await lenwy.sendMessage(m.chat, {
            video: { url: data.videoUrl } // Hanya kirim video tanpa thumbnail
        }, { quoted: m });

        await lenwy.sendMessage(m.chat, {
            react: { text: "✅", key: m.key }
        });

    } catch (err) {
        console.error("[Facebook Scraper Error]", err);
        lenwyreply('❌ Terjadi kesalahan saat memproses permintaan.');
    }
}
break;

case 'fb2': {
  if (isBan) return lenwyreply('*Kamu Di Ban Owner*');
  if (!q) return lenwyreply('*Masukkan URL Facebook yang ingin didownload!*');

  // Emoji saat memulai proses
  lenwy.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key } }); // Emoji jam pasir

  const axios = require('axios');
  const url = q; // URL Facebook dari pengguna

  try {
    // Panggil API untuk mendapatkan link video
    const response = await axios.get(`https://api.lolhuman.xyz/api/facebook?apikey=5be94ede1b5591e1d3d85392&url=${encodeURIComponent(url)}`);
    const { result } = response.data;

    // Jika tidak ada hasil, kirim emoji gagal
    if (!result || result.length === 0) {
      lenwy.sendMessage(m.chat, { react: { text: `❌`, key: m.key } }); // Emoji silang jika gagal
      return;
    }

    // Pilih video dengan kualitas pertama (atau ubah sesuai kebutuhan)
    const videoUrl = result[0];

    // Unduh video
    const videoBuffer = await axios.get(videoUrl, { responseType: 'arraybuffer' });

    // Kirim video
    await lenwy.sendMessage(m.chat, {
      video: videoBuffer.data,
      caption: `*Facebook Video Downloader*\n\n🎥 Video berhasil diunduh!`,
    }, { quoted: m });

    // Emoji berhasil
    lenwy.sendMessage(m.chat, { react: { text: `✅`, key: m.key } }); // Emoji centang
  } catch (err) {
    console.error(err);

    // Emoji jika terjadi error
    lenwy.sendMessage(m.chat, { react: { text: `❌`, key: m.key } }); // Emoji silang
  }
}
break
case 'mediafire': {
    if (!args[0]) return lenwyreply('Harap masukkan URL MediaFire!');

    let url = args[0]; // URL MediaFire dari pengguna

    try {
        // Kirim emoji react ⏱️ sebagai indikator proses
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "⏱️",
                key: m.key,
            }
        });

        // Panggil API untuk mendapatkan data file dari MediaFire
        const apiUrl = `https://api.agatz.xyz/api/mediafire?url=${encodeURIComponent(url)}`;
        const response = await axios.get(apiUrl);
        const result = response.data;

        // Cek status response
        if (result.status !== 200 || !result.data || !result.data[0]) {
            return lenwyreply('Gagal mendapatkan data dari MediaFire.');
        }

        // Ambil detail file dari API
        const file = result.data[0];
        const { nama, size, link } = file;

        // Beritahu pengguna tentang detail file
        lenwyreply(`📄 *Nama File*: ${nama}\n📦 *Ukuran*: ${size}\n\nSedang mengunduh file, harap tunggu...`);

        // Unduh file dari link unduhan
        const fileBuffer = await axios.get(link, { responseType: 'arraybuffer' });

        // Kirim file ke pengguna
        await lenwy.sendMessage(m.chat, { 
            document: Buffer.from(fileBuffer.data), 
            mimetype: 'application/octet-stream', 
            fileName: nama 
        }, { quoted: m });

    } catch (error) {
        console.error(error);
        lenwyreply('Terjadi kesalahan saat memproses permintaan.');
    }
}
break

case 'gdrive': {
    if (!text) return lenwyreply(`*Masukkan URL Google Drive-nya!*`);
    lenwyreply('*Tunggu sebentar, sedang memproses permintaan...*');

    try {
        const axios = require('axios');

        // URL API dengan parameter URL Google Drive
        const apiURL = `https://api.botcahx.eu.org/api/download/gdrive?url=${text}&apikey=kayganzz`;

        // Panggil API
        const response = await axios.get(apiURL);
        const result = response.data.result;

        // Jika data berhasil diperoleh
        if (result && result.data) {
            // Kirim informasi file terlebih dahulu
            const infoMessage = `*GDrive Download Info:*\n\n` +
                `• *Nama File:* ${result.fileName}\n` +
                `• *Ukuran File:* ${result.fileSize}\n` +
                `• *MIME Type:* ${result.mimetype}\n` +
                `• *Creator API:* ${result.creator}\n\n` +
                `*Sedang mengirim file, harap tunggu...*`;
            lenwyreply(infoMessage);

            // Kirim file langsung dari URL
            await lenwy.sendMessage(m.chat, {
                document: { url: result.data }, // File URL
                mimetype: result.mimetype,     // Tipe file
                fileName: result.fileName,     // Nama file
            }, { quoted: m });

            lenwyreply(`*File berhasil dikirim: ${result.fileName}*`);
        } else {
            lenwyreply('*Gagal mendapatkan file. Cek URL atau API key Anda.*');
        }
    } catch (error) {
        console.error("⚠ Error:", error.message);
        lenwyreply('*Terjadi kesalahan dalam memproses permintaan.*');
    }
}
break

case 'ssweb': {
    if (!q) return lenwyreply(`*Contoh ${prefix + command} https://example.com*`);
    lenwyreply(mess.wait);

    try {
        // API URL
        const apiUrl = `https://api.ryzendesu.vip/api/tool/ssweb?url=${encodeURIComponent(q)}&mode=handphone`;

        // Fetch hasil screenshot menggunakan axios
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });

        // Kirim gambar sebagai output
        await lenwy.sendMessage(from, { image: response.data, caption: mess.success }, { quoted: m });
    } catch (err) {
        lenwyreply(`Terjadi kesalahan: ${err.message}`);
    }
}
break

case 'wm': {
if (isBan) return lenwyreply('*Kamu Di Ban Owner*')
let teks = `${text}`
try {
 if (!quoted) lenwyreply `Balas Video/Image Dengan Caption ${prefix + command}`
if (/image/.test(mime)) {
let media = await quoted.download()
let encmedia = await lenwy.sendImageAsSticker(from, media, m, { packname: `${teks}`, author: global.author })
await fs.unlinkSync(encmedia)
}
} catch (e) {
lenwyreply(mess.error)
}
}
break

/*case 'pin': case 'pinterest':{
if (isBan) return lenwyreply('*Kamu Di Ban Owner*')
if (!isPrem) return lenwyreply(mess.prem)
if (!text) return lenwyreply(`*Contoh ${prefix+command} Anime*`)
    if (global.db.data.users[m.sender].limit < 1) return lenwyreply('*Limit Kamu Habis, Silahkan Hubunggi Kay/Tunggu besok*')
                db.data.users[m.sender].limit -= 10
lenwyreply('*10 Limit Digunakan*')
let anu = await pinterest(text)
let result = anu[Math.floor(Math.random() * anu.length)]
lenwy.sendMessage(m.chat, { image: { url: result }, caption: '*Selesai*'}, { quoted: m })
}
break*/

case 'pinterest': case 'pin': {
if (!text) return lenwyreply(`*Contoh : Pin Minecraft*`);
const isToxic = /(ewe|bangsad|mmk|koncol|kontol|k0ntl|k0ntol|kont0l|k0nt0l|kontoI|puki|kojtol|kintil|momok|nigga|ajg|ewean|yatim|anjing|kontol|memek|bangsat|babi|gblk|goblok|goblog|kntl|pepek|ppk|ngentod|ngentd|ngntd|kentod|kntd|bgst|anjg|anj|fuck|hitam|ireng|jawir|gay|asw|ktl|ngentot|ngewe|bokep|bkp|lonte|lont|bh|perawan|prawan|tolol|tlol|itil|tobrut|tobrud|tbrut|tbrud|Telanjang|telanjang|tljang|sexy|sex|Sexy)/i;
const Lenwyguard = isToxic.exec(m.text)
if (Lenwyguard) return lenwyreply('⚠ *Kayzu Melarang Penggunaan Bahasa Kotor Pada Fitur Pin*') 
if (global.db.data.users[m.sender].limit < 5) return lenwyreply('*Limit Kamu Habis, Silahkan Hubunggi Kay/Tunggu besok*')
lenwyreply('*5 Limit Digunakan*')
async function createImage(url) {
const { imageMessage } = await generateWAMessageContent({
image: {url}}, {upload: lenwy.waUploadToServer});
return imageMessage;
}
function shuffleArray(array) {
for (let i = array.length - 1; i > 0; i--) {
const j = Math.floor(Math.random() * (i + 1));
[array[i], array[j]] = [array[j], array[i]];
}
}  
let push = [];
let { data } = await axios.get(`https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${text}&data=%7B%22options%22%3A%7B%22isPrefetch%22%3Afalse%2C%22query%22%3A%22${text}%22%2C%22scope%22%3A%22pins%22%2C%22no_fetch_context_on_resource%22%3Afalse%7D%2C%22context%22%3A%7B%7D%7D&_=1619980301559`);
let res = data.resource_response.data.results.map(v => v.images.orig.url);  
shuffleArray(res);
let ult = res.splice(0, 10);
let i = 1;
for (let lucuy of ult) {
    push.push({
      body: proto.Message.InteractiveMessage.Body.fromObject({
        text: `*Pencarian : ${text}*`
      }),
      header: proto.Message.InteractiveMessage.Header.fromObject({
        title: `*Gambar ${i++}*`,
        hasMediaAttachment: true,
        imageMessage: await createImage(lucuy)
      }),
      nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
        buttons: [
          {
            "name": "cta_url",
            "buttonParamsJson": `{"display_text":"Pinterest","url":"https://www.pinterest.com/search/pins/?rs=typed&q=${text}","merchant_url":"https://www.pinterest.com/search/pins/?rs=typed&q=${text}"}`
          }
        ]
      })
    });
  }
  
  const bot = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `*Berhasil Memuat 10 Gambar*`
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            hasMediaAttachment: false
          }),
          carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
            cards: [
              ...push
            ]
          })
        })
      }
    }
  }, {})
  
  await lenwy.relayMessage(m.chat, bot.message, {
    messageId: bot.key.id
  }).catch((err) => lenwyreply(mess.error))
}
if (!isPrem) return db.data.users[m.sender].limit -= 5
break

case 'kaypin': case 'pinkay': {
    if (!isCreator) return lenwyreply('*Fitur Ini Hanya Untuk Kay 😹*'); // Hanya creator (Kay) yang bisa pakai fitur ini
    if (!text) return lenwyreply(`*Contoh : Pin Minecraft*`);
    if (global.db.data.users[m.sender].limit < 5) return lenwyreply('*Limit Kamu Habis, Silahkan Hubunggi Kay/Tunggu besok*');
    lenwyreply('*5 Limit Digunakan*');

    async function createImage(url) {
        const { imageMessage } = await generateWAMessageContent({
            image: {url}}, {upload: lenwy.waUploadToServer});
        return imageMessage;
    }

    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
    }

    let push = [];
    let { data } = await axios.get(`https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${text}&data=%7B%22options%22%3A%7B%22isPrefetch%22%3Afalse%2C%22query%22%3A%22${text}%22%2C%22scope%22%3A%22pins%22%2C%22no_fetch_context_on_resource%22%3Afalse%7D%2C%22context%22%3A%7B%7D%7D&_=1619980301559`);
    let res = data.resource_response.data.results.map(v => v.images.orig.url);  
    shuffleArray(res);
    let ult = res.splice(0, 10);
    let i = 1;
    for (let lucuy of ult) {
        push.push({
            body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Pencarian : ${text}*`
            }),
            header: proto.Message.InteractiveMessage.Header.fromObject({
                title: `*Gambar ${i++}*`,
                hasMediaAttachment: true,
                imageMessage: await createImage(lucuy)
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                    {
                        "name": "cta_url",
                        "buttonParamsJson": `{"display_text":"Pinterest","url":"https://www.pinterest.com/search/pins/?rs=typed&q=${text}","merchant_url":"https://www.pinterest.com/search/pins/?rs=typed&q=${text}"}`
                    }
                ]
            })
        });
    }
  
    const bot = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: `*Berhasil Memuat 10 Gambar*`
                    }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        hasMediaAttachment: false
                    }),
                    carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                        cards: [
                            ...push
                        ]
                    })
                })
            }
        }
    }, {})
  
    await lenwy.relayMessage(m.chat, bot.message, {
        messageId: bot.key.id
    }).catch((err) => lenwyreply(mess.error))
}
if (!isPrem) return db.data.users[m.sender].limit -= 5
break

case 'zerochan': {
  if (!text) return lenwyreply(`🔍 *Mau Cari Gambar Anime Apa?*`);
  const isToxic = /(ewe|bangsad|mmk|koncol|kontol|k0ntl|k0ntol|kont0l|k0nt0l|kontoI|puki|kojtol|kintil|momok|nigga|ajg|ewean|yatim|anjing|kontol|memek|bangsat|babi|gblk|goblok|goblog|kntl|pepek|ppk|ngentod|ngentd|ngntd|kentod|kntd|bgst|anjg|anj|fuck|hitam|ireng|jawir|gay|asw|ktl|ngentot|ngewe|bokep|bkp|lonte|lont|bh|perawan|prawan|tolol|tlol|itil|tobrut|tobrud|tbrut|tbrud|Telanjang|telanjang|tljang|sexy|sex|Sexy)/i;
  const Lenwyguard = isToxic.exec(m.text);
  if (Lenwyguard) return lenwyreply('⚠ *Kayzu Melarang Penggunaan Bahasa Kotor Pada Fitur Zerochan*');
  if (global.db.data.users[m.sender].limit < 5) return lenwyreply('*Limit Kamu Habis, Silahkan Hubunggi Kay/Tunggu besok*');
  lenwyreply('*5 Limit Digunakan*');
  try {
      const imageUrls = await Zerochan(text);
      if (!imageUrls || imageUrls.length === 0) {
          return lenwyreply("*Tidak ditemukan gambar dengan pencarian tersebut di Zerochan.*");
      }
      function shuffleArray(array) {
          for (let i = array.length - 1; i > 0; i--) {
              const j = Math.floor(Math.random() * (i + 1));
              [array[i], array[j]] = [array[j], array[i]];
          }
      }
      shuffleArray(imageUrls);
      const selectedImages = imageUrls.slice(0, 5);
      let push = [];
      let i = 1;
      async function createImage(url) {
          const { imageMessage } = await generateWAMessageContent({
              image: { url }
          }, { upload: lenwy.waUploadToServer });
          return imageMessage;
      }
      for (let img of selectedImages) {
          push.push({
              body: proto.Message.InteractiveMessage.Body.fromObject({
                  text: `*Pencarian : ${text}*`
              }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                  title: `*Gambar ${i++}*`,
                  hasMediaAttachment: true,
                  imageMessage: await createImage(img)
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                  buttons: [
                      {
                          "name": "cta_url",
                          "buttonParamsJson": `{"display_text":"Zerochan","url":"https://www.zerochan.net/search?q=${text}","merchant_url":"https://www.zerochan.net/search?q=${text}"}`
                      }
                  ]
              })
          });
      }
      const bot = generateWAMessageFromContent(m.chat, {
          viewOnceMessage: {
              message: {
                  messageContextInfo: {
                      deviceListMetadata: {},
                      deviceListMetadataVersion: 2
                  },
                  interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                      body: proto.Message.InteractiveMessage.Body.create({
                          text: `*Berhasil Memuat 5 Gambar*`
                      }),
                      header: proto.Message.InteractiveMessage.Header.create({
                          hasMediaAttachment: false
                      }),
                      carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                          cards: [...push]
                      })
                  })
              }
          }
      }, {});

      await lenwy.relayMessage(m.chat, bot.message, {
          messageId: bot.key.id
      }).catch((err) => lenwyreply(mess.error));

      if (!isPrem) return db.data.users[m.sender].limit -= 5;
  } catch (error) {
      console.error("Error:", error.message);
      lenwyreply("*Terjadi kesalahan saat mengambil gambar dari Zerochan.*");
  }
}
break

case 'enka':
            case 'profilgi':
            if (isBan) return lenwyreply('*Kamu Di Ban Owner*')
			if (args.length == 0) return lenwyreply(`*Contoh: ${prefix + command}* 800000001`)
            lenwyreply('*Sabar Yaa*')
			global.sh = `https://enka.network/u/${args[0]}`
let krt = await ssweb(global.sh)
			axios.get(`https://enka.network/api/uid/${args[0]}?info`).then(({ data }) => {
				var caption = `*Profile Genshin*\n\n  *⨠ Nickname* : *${data.playerInfo.nickname}*\n`
				caption += `  *⨠ Adventure Rank* : *${data.playerInfo.level}*\n`
				caption += `  *⨠ Signature* : *${data.playerInfo.signature}*\n`
				caption += `  *⨠ World Level* : *${data.playerInfo.worldLevel}*\n\n`
				caption += `  *⨠ Achievement* : *${data.playerInfo.finishAchievementNum}*\n`
				caption += `  *⨠ Abyss* : *Floor ${data.playerInfo.towerFloorIndex} Chamber ${data.playerInfo.towerLevelIndex}*\n\n`
				caption += `*Lebih Lengkap Cek Disini :* https://enka.network/u/${args[0]}\n`
				lenwy.sendMessage(from ,{ image: krt.result, caption: caption },{ quoted: m })
			})
			.catch(console.error)
			break

case 'neko':
case 'waifu': {
if (isBan) return lenwyreply('*Kamu Di Ban Owner*')
let res = await fetch(`https://waifu.pics/api/sfw/${command}`)
let json = await res.json()
let cap = `*Sukses* 😋`
lenwy.sendMessage(from, {image: { url: json.url },caption:`*Alamak* 😋`},{ quoted:m }).catch(err => {
 return('Error!')
})
}
break

case 'cry': case 'kill': case 'hug': case 'pat': case 'lick': 
case 'kiss': case 'bite': case 'yeet': case 'bully': case 'bonk':
case 'wink': case 'poke': case 'nom': case 'slap': case 'smile': 
case 'wave': case 'awoo': case 'blush': case 'smug': case 'glomp': 
case 'happy': case 'dance': case 'cringe': case 'cuddle': case 'highfive': 
case 'handhold':
if (isBan) return lenwyreply('*Kamu Di Ban Owner*')
 axios.get(`https://api.waifu.pics/sfw/${command}`)
.then(({data}) => {
lenwy.sendImageAsSticker(from, data.url, m, { packname: global.packname, author: global.author })
})
break

case 'bucin': case 'dare': case 'faktaunik': case 'fml': case 'katabijak': case 'katacinta': case 'katagalau': case 'katahacker': case 'katailham': case 'katasenja': case 'katasindiran': case 'motivasi': case 'nickff': case 'pantun': case 'puisi': case 'quotesislamic': case 'quotespubg': case 'truth': {
  if (isBan) return lenwyreply('*Kamu Di Ban Owner*');
  
  // Pilih teks secara acak
  const t3xt = require(`./database/teks/${command}.json`);
  const r4andT3xt = t3xt[Math.floor(Math.random() * t3xt.length)];
  
  // Kirim teks
  lenwy.sendMessage(from, { text: r4andT3xt }, { quoted: m });
}
break

case 'quotes':
if (isBan) return lenwyreply('*Kamu Di Ban Owner*')
var resi = await Quotes()
teks = `\n*Author: ${resi.author}*\n`
teks = `\n*Quotes:*\n`
teks = `*${resi.quotes}*\n`
lenwyreply(teks)
break

case 'quotesanime': {
if (isBan) return lenwyreply('*Kamu Di Ban Owner*')
const an1 = JSON.parse(fs.readFileSync("./data/quotesanime.json"))
const r4ndan1 = an1[Math.floor(Math.random() * an1.length)]
const tgt99 = `Random Quotes Anime*

🍁 *Nama Anime : ${r4ndan1.anime}*
🍁 *Nama Character : ${r4ndan1.character}*
🍁 *Episode : ${r4ndan1.episode}*

*Quotes : ${r4ndan1.quotes}*`
lenwy.sendMessage(from, { text: tgt99 }, { quoted: len })
}
break

case 'kompasnews':
if (isBan) return lenwyreply('*Kamu Di Ban Owner*')
LenwyLD()
KompasNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n*⨠ Berita ${no.toString()}*\n`
teks += ` *⨠ Berita: ${i.berita}*\n`
teks += ` *⨠ Upload: ${i.berita_diupload}*\n`
teks += ` *⨠ Jenis: ${i.berita_jenis}*\n`
teks += ` *⨠ Link:* ${i.berita_url}\n`
}
teks += ""
lenwy.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
break

case 'detiknews':
if (isBan) return lenwyreply('*Kamu Di Ban Owner*')
LenwyLD()
DetikNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n*⨠ Berita ${no.toString()}*\n`
teks += ` *⨠ Berita: ${i.berita}*\n`
teks += ` *⨠ Upload: ${i.berita_diupload}*\n`
teks += ` *⨠ Link:* ${i.berita_url}\n`
}
teks += ""
lenwy.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
break

case 'dailynews':
if (isBan) return lenwyreply('*Kamu Di Ban Owner*')
LenwyLD()
DailyNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n*⨠ Berita ${no.toString()}*\n`
teks += ` *⨠ Berita: ${i.berita}*\n`
teks += ` *⨠ Link:* ${i.berita_url}\n`
}
teks += ""
lenwy.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
break

case 'inews':
if (isBan) return lenwyreply('*Kamu Di Ban Owner*')
LenwyLD()
iNews().then(async(res) => {
no = 0
teks = ""
for (let i of res) {
no += 1
teks += `\n*⨠ Berita ${no.toString()}*\n`
teks += ` *⨠ Berita: ${i.berita}*\n`
teks += ` *⨠ Upload: ${i.berita_diupload}*\n`
teks += ` *⨠ Jenis: ${i.berita_jenis}*\n`
teks += ` *⨠ Link:* ${i.berita_url}\n`
}
teks += ""
lenwyreply(teks) 
})
break

case 'kontan':
if (isBan) return lenwyreply('*Kamu Di Ban Owner*')
LenwyLD()
KontanNews().then(async (res) => {
teks = ""
no = 0
for (let i of res) {
no += 1
teks += `\n*⨠ Berita ${no.toString()}*\n`
teks += ` *⨠ Berita: ${i.berita}*\n`
teks += ` *⨠ Jenis: ${i.berita_jenis}*\n`
teks += ` *⨠ Link:* ${i.berita_url}\n`
}
teks += ""
lenwy.sendMessage(m.chat, { image : { url : res[0].berita_thumb }, caption: teks }, { quoted:m })
})
break

case 'meme':
var reis = await JalanTikusMeme()
teks = ""
teks += "*Random Meme*\n"
teks += `*Source Meme :* ${reis}`
teks += ""
lenwy.sendMessage(m.chat, { image : { url : reis }, caption: teks }, { quoted:m })
break

case 'tourl': {
if (!isPrem) return lenwyreply(mess.prem)
  if (!quoted) return lenwyreply('*Reply Ke Media Yang Ingin Diunggah!*');
  
  lenwyreply(mess.wait);
  try {
      console.log('⏱️ Mengunduh media...');
      let media = await lenwy.downloadAndSaveMediaMessage(quoted);

      const mime = quoted.mimetype || '';
      if (!/image/.test(mime)) {
          console.log('❌ File bukan gambar.');
          return lenwyreply('⚠ *Hanya Mendukung File Gambar Untuk Saat Ini!*');
      }

      console.log('✅ File terdeteksi sebagai gambar.');
      let url = await CatboxMoe(media);
      console.log('🌐 URL berhasil dibuat:', url);
      
      lenwyreply(`*Media Berhasil Diunggah!*\n${url}`);
      await fs.unlinkSync(media);
  } catch (e) {
      console.error('❌ Error di case "tourl":', e.message);
      lenwyreply('*Terjadi Kesalahan Saat Mengunggah Media.*');
  }
}
break

case 'tt2': {
    if (isBan) return lenwyreply('*Kamu Di Ban Owner*')
    if (args.length == 0) return lenwyreply('*Link Tiktoknya Mana?*')
    if (!isUrl(args[0])) return lenwyreply(mess.link)

    // Mengirim emoji ⏱️ untuk menunjukkan proses sedang berlangsung
    await lenwy.sendMessage(m.chat, {
        react: {
            text: "⏱️",
            key: m.key,
        }
    });

    lenwyreply(mess.wait)

    try {
        // Atur timezone ke Asia/Jakarta
        let options = { timeZone: 'Asia/Jakarta', day: '2-digit', month: 'long', year: 'numeric' }
        let date = new Date().toLocaleDateString('id-ID', options)
        let time = new Date().toLocaleTimeString('id-ID', { timeZone: 'Asia/Jakarta', hour: '2-digit', minute: '2-digit', second: '2-digit' })

        let lenwycap = `📥 Download Berhasil\n📅 Tanggal : ${date}\n🕒 Waktu : ${time}\n🌐 Diunduh via: Tiktok\n🤖 Bot Name: KiromiMD`

        // Ambil data dari API
        let response = await axios.get(`https://api.siputzx.my.id/api/tiktok?url=${args[0]}`)
        let res = response.data

        if (!res.status || !res.data || !res.data.urls || res.data.urls.length === 0) {
            return lenwyreply('*Gagal mengambil data, coba link lain!*')
        }

        // Ambil URL video (tanpa watermark)
        let videoUrl = res.data.urls[0]

        // Kirim video
        lenwy.sendMessage(m.chat, { 
            video: { 
                url: videoUrl 
            }, 
            caption: lenwycap, 
            fileName: `tiktok.mp4`, 
            mimetype: 'video/mp4' 
        })

        // Ganti emoji dengan ✅ setelah video dikirim
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key,
            }
        });

    } catch (error) {
        console.error(error)
        lenwyreply('*Terjadi kesalahan saat memproses permintaan. Pastikan link valid atau coba lagi nanti.*')

        // Ganti emoji dengan ✅ jika terjadi kesalahan
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key,
            }
        });
    }
}
break

case 'tt': {
    if (!args[0]) return lenwyreply('Harap masukkan URL TikTok!');

    let url = args[0]; // URL TikTok dari pengguna
    try {
        // Reaksi emoji saat permintaan diproses
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "⏱️",
                key: m.key,
            }
        });

        // Panggil API TikTok
        let response = await axios.get(`https://api.agatz.xyz/api/tiktok`, {
            params: { url: url }
        });

        let { status, data } = response.data;
        if (status !== 200 || !data.status) return lenwyreply('❌ Gagal mengambil data TikTok.');

        // Parsing data API
        let {
            title,
            taken_at,
            region,
            duration,
            cover,
            music_info,
            stats,
            author,
            data: videoData
        } = data;

        // Cari video tanpa watermark
        let nowatermarkVideo = videoData.find(v => v.type === 'nowatermark').url;
        if (!nowatermarkVideo) return lenwyreply('❌ Video tanpa watermark tidak ditemukan.');

        // Buat caption detail
        let caption = `
🎥 *Video TikTok*\n
📌 *Judul:* ${title}
⏱️ *Durasi:* ${duration}
📆 *Diunggah:* ${taken_at}
🌍 *Region:* ${region}

👤 *Pembuat Konten:*
- Nama: ${author.fullname} (@${author.nickname})
- ID: ${author.id}
- Avatar: ${author.avatar}

🎶 *Musik:*
- Judul: ${music_info.title}
- Artis: ${music_info.author}
- Album: ${music_info.album}
- Link Musik: ${music_info.url}

📊 *Statistik:*
- Views: ${stats.views}
- Likes: ${stats.likes}
- Komentar: ${stats.comment}
- Shares: ${stats.share}
- Unduhan: ${stats.download}
        `.trim();

        // Kirim video tanpa watermark dengan caption
        await lenwy.sendMessage(m.chat, { 
            video: { url: nowatermarkVideo }, 
            caption: caption
        }, { quoted: m });

        // Kirim audio jika tersedia
        if (music_info.url) {
            await lenwy.sendMessage(m.chat, { 
                audio: { url: music_info.url }, 
                mimetype: 'audio/mpeg', 
                fileName: `${music_info.title}.mp3`
            }, { quoted: m });
        }

        // Setelah semua berhasil terkirim, ubah emoji ke ✅
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key,
            }
        });
        
    } catch (err) {
        console.error(err);
        lenwyreply('❌ Terjadi kesalahan saat memproses permintaan.');
    }
}
break

case 'tt4': {
    if (isBan) return lenwyreply('*Kamu Di Ban Owner*');
    if (args.length == 0) return lenwyreply(`*Link Tiktoknya Mana?*`);
    if (!isUrl(args[0])) return lenwyreply('*Link Tidak Valid*');

    const url = args[0];
    const apiUrl = `https://api.lolhuman.xyz/api/tiktok?apikey=5be94ede1b5591e1d3d85392&url=${encodeURIComponent(url)}`;

    try {
        // Reaksi emoji saat permintaan diproses
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "⏱️",
                key: m.key,
            }
        });

        const response = await fetch(apiUrl);
        const result = await response.json();

        // Cek status API response
        if (result.status !== 200 || !result.result) {
            return lenwyreply('*Gagal mengambil data. Pastikan URL valid atau data tidak ditemukan.*');
        }

        const data = result.result;

        // Data dari API
        let title = data.title || 'Tidak ada judul';
        let username = data.author?.username || 'Tidak diketahui';
        let nickname = data.author?.nickname || 'Tidak diketahui';
        let avatar = data.author?.avatar || '';
        let playCount = data.statistic?.play_count || '0';
        let likeCount = data.statistic?.like_count || '0';
        let shareCount = data.statistic?.share_count || '0';
        let commentCount = data.statistic?.comment_count || '0';
        let videoUrl = data.link || '';

        // Membuat caption yang lebih cantik dan rapi
        let caption = `
🌟 *Video TikTok* 🌟

⚛️ *Judul*: ${title}
👤 *Username*: ${username} (${nickname})

📊 *Statistik*:
👀 *Dilihat*: ${playCount}
👍 *Likes*: ${likeCount}
💬 *Komentar*: ${commentCount}
🔁 *Dibagikan*: ${shareCount}

🎬 *Tonton Video*: ${videoUrl}
`.trim();

        // Kirim foto avatar dengan caption author
        if (avatar) {
            await lenwy.sendMessage(m.chat, {
                image: { url: avatar },
                caption: `👤 *Author TikTok*\n✡️ *Username*: ${username}\n🔹 *Nama*: ${nickname}`
            });
        }

        // Kirim video dengan caption lengkap
        if (videoUrl) {
            await lenwy.sendMessage(m.chat, {
                video: { url: videoUrl },
                caption: caption
            });
        }
    } catch (error) {
        console.error(error);
        lenwyreply('*Terjadi kesalahan saat memproses permintaan.*');
    }
}
break

case 'tt5': {
    const axios = require('axios');
    
    if (!text) return lenwyreply(`Contoh: ${prefix + command} https://vt.tiktok.com/...`);
    
    const url = encodeURIComponent(text);
    const apikey = 'kayganzz';
    const apiUrl = `https://api.botcahx.eu.org/api/dowloader/tiktok?url=${url}&apikey=${apikey}`;

    try {
        // Menambahkan emoji reaksi saat memproses
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "⏱️", // Emoji untuk menunjukkan proses sedang berjalan
                key: m.key,
            }
        });

        const res = await axios.get(apiUrl);
        
        console.log(res.data);  // Cek seluruh respons API
        
        if (res.data.status === true) {
            const title = res.data.result.title || 'Tidak ada judul';
            const videoUrl = res.data.result.video[0];
            const audioUrl = res.data.result.audio[0];
            const thumbnail = res.data.result.thumbnail || 'Tidak ada thumbnail';

            // Membuat pesan dengan emoji untuk informasi
            let message = `
🎬 *Judul:* ${title}
🎥 *Video URL:* ${videoUrl}
🎶 *Audio URL:* ${audioUrl}
📸 *Thumbnail:* ${thumbnail}
`.trim();

            // Kirim video
            await lenwy.sendMessage(m.chat, { video: { url: videoUrl }, caption: message }, { quoted: m });

            // Mengubah emoji setelah selesai proses
            await lenwy.sendMessage(m.chat, {
                react: {
                    text: "✅", // Emoji selesai
                    key: m.key,
                }
            });
        } else {
            lenwyreply("❌ Gagal mendapatkan data dari TikTok. Coba lagi nanti.");
        }
    } catch (e) {
        console.error(e);
        lenwyreply("⚠️ Terjadi kesalahan dalam memproses permintaan.");

        // Mengubah emoji setelah terjadi kesalahan
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "❌", // Emoji kesalahan
                key: m.key,
            }
        });
    }
}
break

case 'ttv2': {
    if (!args[0]) return lenwyreply('Masukkan URL TikTok.');

    const url = args[0];
    const apiUrl = `https://api.agatz.xyz/api/tiktok?url=${encodeURIComponent(url)}`;

    try {
        // Menambahkan emoji reaksi saat memproses
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "⏱️", // Emoji untuk menunjukkan proses sedang berjalan
                key: m.key,
            }
        });

        // Mengambil data dari API
        const response = await fetch(apiUrl);
        const result = await response.json();

        if (!result.status) {
            return lenwyreply('❌ Gagal mengambil data TikTok. Pastikan URL valid.');
        }

        // Mengambil data dari API
        const videoUrl = result.data.data[1].url;  // URL tanpa watermark
        const videoHdUrl = result.data.data[2].url; // URL HD tanpa watermark
        const coverImage = result.data.cover;  // Thumbnail video
        const title = result.data.title;  // Judul video
        const views = result.data.stats.views;  // Views
        const likes = result.data.stats.likes;  // Likes
        const comments = result.data.stats.comment;  // Comments
        const shares = result.data.stats.share;  // Shares
        const musicUrl = result.data.music_info.url; // URL musik

        // Kirim info video ke pengguna menggunakan emoji
        let infoMessage = `
🎬 *Judul:* ${title}
👀 *Views:* ${views}
👍 *Likes:* ${likes}
💬 *Komentar:* ${comments}
🔁 *Shares:* ${shares}
⏱️ *Durasi:* ${result.data.duration}

🎶 *Musik:* [Original Sound](${musicUrl})
`.trim();

        await lenwyreply(infoMessage);

        // Kirim video tanpa watermark
        await lenwy.sendMessage(m.sender, { 
            video: { url: videoUrl },
            caption: '🎥 Video TikTok berhasil diunduh! 😎' 
        });

        await lenwy.sendMessage(m.sender, { 
            text: '✅ Download TikTok selesai!' 
        });

        // Mengubah emoji setelah selesai proses
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅", // Emoji selesai
                key: m.key,
            }
        });

    } catch (error) {
        console.error(error);
        return lenwyreply('⚠️ Terjadi kesalahan saat memproses permintaan.');

        // Mengubah emoji setelah terjadi kesalahan
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "❌", // Emoji kesalahan
                key: m.key,
            }
        });
    }
}
break

case 'ttslide2': {
    if (isBan) return lenwyreply('*Kamu Di Ban Owner*');
    if (args.length == 0) return lenwyreply(`*Link Tiktoknya Mana?*`);
    if (!isUrl(args[0])) return lenwyreply(mess.link);

    const url = args[0];
    const apiUrl = `https://api.agatz.xyz/api/tiktok?url=${encodeURIComponent(url)}`;

    try {
        lenwyreply('Sabar, sedang memproses... 🪐');
        const response = await fetch(apiUrl);
        const result = await response.json();

        // Cek status API response
        if (!result.status || !result.data) {
            return lenwyreply('*Gagal mengambil data. Pastikan URL valid atau data tidak ditemukan.*');
        }

        const data = result.data;

        let title = data.title || 'Tidak ada judul';
        let takenAt = data.taken_at || 'Tidak diketahui';
        let musicTitle = data.music_info?.title || 'Tidak ada musik';
        let musicAuthor = data.music_info?.author || 'Tidak ada pengarang';
        let views = data.stats?.views || '0';
        let likes = data.stats?.likes || '0';
        let comments = data.stats?.comment || '0';
        let shares = data.stats?.share || '0';
        let downloads = data.stats?.download || '0';
        let photoUrl = data.data?.[0]?.url || '';
        let audioUrl = data.music_info?.url || '';

        let caption = `🎬 Video Tiktok\n\n` +
                      `📅 *Judul*: ${title}\n` +
                      `⌛ *Tanggal Diambil*: ${takenAt}\n` +
                      `🎶 *Musik*: ${musicTitle} - ${musicAuthor}\n\n` +
                      `📊 *Statistik*:\n` +
                      `💬 *Komentar*: ${comments}\n` +
                      `👍 *Likes*: ${likes}\n` +
                      `🔁 *Share*: ${shares}\n` +
                      `👀 *Views*: ${views}\n` +
                      `📥 *Download*: ${downloads}`;

        // Kirim foto asli dengan caption
        if (photoUrl) {
            await lenwy.sendMessage(m.chat, {
                image: { url: photoUrl },
                caption: caption
            });
        }

        // Kirim audio jika ada
        if (audioUrl) {
            await lenwy.sendMessage(m.chat, {
                audio: { url: audioUrl },
                mimetype: 'audio/mp3'
            });
        }

        // Kirim pesan selesai setelah semua media dikirim
        await lenwyreply('Download Tiktok selesai!');

    } catch (error) {
        console.error(error);
        lenwyreply('Terjadi kesalahan saat memproses permintaan.');
    }
}
break

case 'chatgptgo': {
if (!isPrem) return lenwyreply(mess.prem)
    if (!text) return lenwyreply(`*Masukkan pertanyaannya!*`);
    lenwyreply(mess.wait);

    try {
        const axios = require('axios'); // Pastikan axios sudah diinstal
        
        // URL API
        const apiURL = `https://api.tioprm.eu.org/gptgo?text=${encodeURIComponent(text)}`;
        
        // Panggil API menggunakan axios
        const { data } = await axios.get(apiURL);
        
        // Validasi respons
        if (data && data.status && data.result) {
            lenwyreply(`🤖 *Jawaban dari GPTgo:*\n${data.result}`);
        } else {
            lenwyreply(`❌ *Maaf, tidak ada jawaban yang valid dari API.*`);
        }
    } catch (error) {
        console.error("Error di case 'chatgptgo':", error.message);
        lenwyreply(`❌ *Terjadi kesalahan saat memproses permintaan.*`);
    }
}
break

case 'luminai': {
    if (!isPrem) return lenwyreply(mess.prem);
    if (!text) return lenwyreply(`*Masukkan pertanyaannya!*`);
    lenwyreply(mess.wait);

    try {
        const axios = require('axios'); // Pastikan axios sudah diinstal
        
        // URL API
        const apiURL = `https://api.siputzx.my.id/api/ai/luminai?content=${encodeURIComponent(text)}`;
        
        // Panggil API menggunakan axios
        const { data } = await axios.get(apiURL);
        
        // Validasi respons
        if (data && data.status && data.data) {
            lenwyreply(`🤖 *Jawaban dari Luminai:*\n${data.data}`);
        } else {
            lenwyreply(`❌ *Maaf, tidak ada jawaban yang valid dari API.*`);
        }
    } catch (error) {
        console.error("Error di case 'luminai':", error.message);
        lenwyreply(`❌ *Terjadi kesalahan saat memproses permintaan.*`);
    }
}
break

case 'openai': {
    if (!isPrem) return lenwyreply(mess.prem);
    if (!q) return lenwyreply(`*Mau Nanya Apa Sama OpenAi?*`);
    lenwyreply('*One Moment, Please ☕*');
    try {
        // URL API baru
        const apiUrl = `https://api.ryzendesu.vip/api/ai/chatgpt?text=${encodeURIComponent(q)}`;

        // Menggunakan axios untuk melakukan request
        const response = await axios.get(apiUrl);

        // Memeriksa apakah respons berhasil dan ada hasil dari AI
        if (response.data.success && response.data.response) {
            lenwyreply(response.data.response);
        } else {
            lenwyreply("*Tidak Ada Respons Dari AI.*");
        }
    } catch (error) {
        console.error("⚠ *Error Saat Mendapatkan Data :*", error.message);
        lenwyreply("*Terjadi Kesalahan Dalam Proses Permintaan.*");
    }
}
break

case 'metaai': {
if (!isPrem) return lenwyreply(mess.prem)
    if (!text) return lenwyreply(`*Masukkan pertanyaan atau teks yang ingin dikirim ke Meta AI!*`);
    lenwyreply('*One Moment, Please ☕*');

    try {
        const axios = require('axios'); // Pastikan axios sudah diinstal
        
        // URL API dengan query teks pengguna
        const apiURL = `https://api.siputzx.my.id/api/ai/metaai?query=${encodeURIComponent(text)}`;
        
        // Panggil API untuk mendapatkan respons AI
        const { data } = await axios.get(apiURL);

        // Pastikan respons valid
        if (data && data.data) {
            lenwyreply(`🤖 *Jawaban Meta AI:*\n${data.data}`);
        } else {
            lenwyreply(`❌ *Maaf, API tidak memberikan jawaban yang valid.*`);
        }
    } catch (error) {
        console.error('Error di case "metaai":', error.message);
        lenwyreply(`❌ *Terjadi kesalahan saat memproses permintaan.*`);
    }
}
break

case 'translate': {
if (!isPrem) return lenwyreply(mess.prem)
    if (!text) return lenwyreply('*Masukkan teks yang ingin diterjemahkan!*');
    const [from, to, ...rest] = text.split(' ');
    const textToTranslate = rest.join(' ');

    // Jika tidak ada kode bahasa yang dimasukkan
    if (!from || !to) {
        return lenwyreply('*Cara penggunaan:* \nKetik perintah translate diikuti dengan kode bahasa sumber, kode bahasa tujuan, dan teks yang ingin diterjemahkan.\n\nContoh: `translate en id I love coding`\n\nKeterangan:\n`en` adalah kode bahasa Inggris (sumber), `id` adalah kode bahasa Indonesia (tujuan), dan `I love coding` adalah teks yang ingin diterjemahkan.\n\nJika ingin melihat kode bahasa yang tersedia, ketik `kodebahasa`');
    }

    try {
        const response = await axios.get(`https://api.mymemory.translated.net/get?q=${textToTranslate}&langpair=${from}|${to}`);
        const translatedText = response.data.responseData.translatedText;
        lenwyreply(`Terjemahan: ${translatedText}`);
    } catch (error) {
        console.error(error);
        lenwyreply('❌ *Terjadi kesalahan saat menerjemahkan.* Pastikan formatnya benar dan coba lagi.');
    }
}
break

case 'resep': {
    // Mengambil query dari input pengguna, pastikan input ada setelah command
    const query = m.text.split(' ').slice(1).join(' '); // Mengambil teks setelah command

    if (!query) {
        lenwyreply("Mohon masukkan nama resep yang ingin dicari.");
        return;
    }

    const apiUrl = `https://api.siputzx.my.id/api/s/resep?query=${query}`;

    try {
        lenwyreply("Memproses, mohon tunggu...");

        // Mengambil data dari API
        const res = await axios.get(apiUrl);

        // Memastikan API memberikan data yang valid
        if (res.data.status && res.data.data && res.data.data.length > 0) {
            const resep = res.data.data[0];

            const { judul, waktu_masak, hasil, tingkat_kesulitan, thumb, bahan, langkah_langkah } = resep;

            const message = `
🍽️ *Judul*: ${judul}
⏱️ *Waktu Masak*: ${waktu_masak}
🍴 *Hasil*: ${hasil}
⚖️ *Tingkat Kesulitan*: ${tingkat_kesulitan}

📝 *Bahan-bahan*:
${bahan}

📋 *Langkah-langkah*:
${langkah_langkah}
            `;

            // Kirim pesan dengan informasi resep dan gambar
            await lenwy.sendMessage(m.chat, { text: message, image: { url: thumb } }, { quoted: m });
        } else {
            lenwyreply("Resep tidak ditemukan, coba lagi nanti.");
        }
    } catch (e) {
        console.error("Error:", e);
        lenwyreply("Terjadi kesalahan, coba lagi nanti.");
    }
}
break

case 'afk': {
    if (!isCreator) return lenwy.sendMessage(m.chat, { text: '❌ Perintah ini hanya bisa digunakan oleh owner!' }, { quoted: m });

    if (global.db.data.users[m.sender].afkTime > -1) return lenwy.sendMessage(m.chat, { text: '⚠️ Kamu sudah dalam mode AFK!' }, { quoted: m });

    let reason = text ? text : 'Tidak ada alasan yang disebutkan~ 🤭';

    // Simpan status AFK
    global.db.data.users[m.sender].afkTime = Date.now();
    global.db.data.users[m.sender].afkReason = reason;

    // Kirim pesan konfirmasi dengan mention
    await lenwy.sendTextWithMentions(
        m.chat,
        `🌙 *Mode AFK Aktif!* 🌙\n` +
        `👤 *@${m.sender.split('@')[0]}* sedang AFK!\n` +
        `💬 *Alasan:* ${reason}\n\n` +
        `⏳ Sampai jumpa nanti! 😊✨`,
        m
    );
}
break

case 'pairing': {
    if (!isCreator) return lenwyreply(mess.owner); // Validasi hanya Creator
    if (!text) return lenwyreply(`*Contoh:* ${prefix + command} +628xxxxxx|1`);

    lenwyreply(mess.wait); // Balasan saat diproses

    let [peenis, pepekk = "1"] = text.split("|"); // Memisahkan input nomor & jumlah spam
    let target = peenis.replace(/[^0-9]/g, '').trim(); // Membersihkan nomor hanya angka
    if (!target) return lenwyreply('Harap masukkan nomor yang valid!');

    try {
        // Memuat module baileys
        let { default: makeWaSocket, useMultiFileAuthState, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys');
        let { state } = await useMultiFileAuthState('pepek'); // Lokasi penyimpanan auth
        let { version } = await fetchLatestBaileysVersion(); // Mendapatkan versi terbaru
        let pino = require("pino");

        // Membuat koneksi WA socket
        let sucked = await makeWaSocket({
            auth: state,
            version,
            logger: pino({ level: 'fatal' }),
        });

        let results = []; // Menyimpan hasil pairing

        // Melakukan spam pairing
        for (let i = 0; i < pepekk; i++) {
            await sleep(1500); // Menunggu 1,5 detik sebelum eksekusi berikutnya
            let prc = await sucked.requestPairingCode(target); // Meminta pairing code
            
            // Tambahkan log untuk memastikan kode diterima
            console.log(`Spam Pairing - Number: ${target}, Code: ${prc}`);

            if (prc) {
                results.push(`Kode: ${prc}`); // Menambahkan hasil ke dalam daftar jika kode valid
            } else {
                console.log(`Gagal mendapatkan kode untuk nomor: ${target}`);
            }
        }

        // Pastikan array `results` terisi dengan kode yang valid
        if (results.length > 0) {
            // Kirimkan semua hasil pairing dalam satu pesan
            lenwyreply(`Berhasil Spam Pairing ke nomor ${target} sebanyak ${pepekk} kali! \n\n${results.join('\n')}`);
        } else {
            lenwyreply('Tidak ada kode pairing yang berhasil didapatkan!');
        }

        // Memberi reaksi setelah selesai
        await lenwy.sendMessage(m.chat, { react: { text: `✅`, key: m.key }});

        await sleep(15000); // Waktu tunggu untuk eksekusi selanjutnya
    } catch (err) {
        console.error(err); // Log error
        lenwyreply('Terjadi kesalahan saat menjalankan perintah spam pairing!');
    }
}
break

case 'statusvideo':
case 'upswvideo': {
    if (!isCreator) return lenwyreply(mess.owner); // Cek apakah pengguna adalah creator

    if (/video/.test(mime)) {
        // Unduh video dari pesan yang di-reply
        var videosw = await lenwy.downloadAndSaveMediaMessage(quoted);  // Menggunakan lenwy untuk mengunduh video

        // Dapatkan informasi default untuk caption
        let fileSize = quoted.fileLength ? `${(quoted.fileLength / 1024 / 1024).toFixed(2)} MB` : 'Tidak diketahui';
        let mediaType = mime || 'Tidak diketahui';
        let sendTime = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
        let sender = `${m.pushName || ownerName}`;

        // Buat caption default
        let defaultCaption = `📁 *Ukuran File:* ${fileSize}\n` +
        `🎥 *Tipe Media:* ${mediaType}\n` +
        `⏰ *Waktu Dikirim:* ${sendTime}\n` +
        `👤 *Dikirim oleh:* ${sender}`;

        // Kirim video ke status WhatsApp
        await lenwy.sendMessage('status@broadcast', {
            video: { url: videosw },
            caption: q ? q : defaultCaption
        }, {
            statusJidList: Object.keys(db.data.users)
        });

        await lenwyreply('✅ Video berhasil dikirim ke status WhatsApp dengan caption bawaan!');
    } else {
        lenwyreply('⚠️ Tolong reply ke video dulu ya, Kak! 🎥');
    }
}
break

case 'statustext':
case 'upswtext':
case 'upswteks': {
    if (!isCreator) return lenwyreply(mess.owner);
    if (!q) return lenwyreply('Teksnya mana?');
    
    // Mengirim status teks ke semua user
    await lenwy.sendMessage('status@broadcast', { 
        text: q 
    }, { 
        backgroundColor: '#FF000000', 
        font: 3, 
        statusJidList: Object.keys(db.data.users)
    });

    lenwyreply('Sukses kirim status teks!');
}
break

case 'statusaudio':
case 'upswaudio': {
    if (!isCreator) return lenwyreply(mess.owner); // Cek apakah pengguna adalah creator

    if (/audio/.test(mime)) {
        var audiosw = await lenwy.downloadAndSaveMediaMessage(quoted);

        // Kirim audio ke status WhatsApp
        await lenwy.sendMessage('status@broadcast', {
            audio: { url: audiosw },
            mimetype: 'audio/mpeg',
            ptt: true
        }, {
            backgroundColor: '#FF000000',
            statusJidList: Object.keys(db.data.users)
        });

        lenwyreply('✅ Sukses kirim status audio!');
    } else {
        lenwyreply('⚠️ Reply audio dulu, ya!');
    }
}
break

case 'statusimg':
case 'statusimage':
case 'upswimg': {
    if (!isCreator) return lenwyreply(mess.owner); // Cek apakah pengguna adalah creator

    if (/image/.test(mime)) {
        // Unduh gambar dari pesan yang di-reply
        var imagesw = await lenwy.downloadAndSaveMediaMessage(quoted);

        // Dapatkan informasi default untuk caption
        let fileSize = quoted.fileLength ? `${(quoted.fileLength / 1024 / 1024).toFixed(2)} MB` : 'Tidak diketahui';
        let mediaType = mime || 'Tidak diketahui';
        let sendTime = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
        let sender = `${m.pushName || ownerName}`;

        // Buat caption default
        let defaultCaption = `📁 *Ukuran File:* ${fileSize}\n` +
            `🖼️ *Tipe Media:* ${mediaType}\n` +
            `⏰ *Waktu Dikirim:* ${sendTime}\n` +
            `👤 *Dikirim oleh:* ${sender}`;

        // Kirim gambar ke status WhatsApp
        await lenwy.sendMessage('status@broadcast', {
            image: { url: imagesw },
            caption: q ? q : defaultCaption
        }, {
            statusJidList: Object.keys(db.data.users)
        });

        lenwyreply('✅ Gambar berhasil dikirim ke status WhatsApp dengan caption bawaan! 🖼️✨');
    } else {
        lenwyreply('⚠️ Tolong reply ke gambar dulu ya, Kak! 🖼️');
    }
}
break

case 'pinslide':
case 'pinterestslide': {
    if (isBan) return lenwyreply('*Kamu Di Ban Owner*');
    if (!text) return lenwyreply(`*Link Pinterestnya mana?*`);
    if (!isUrl(args[0])) return lenwyreply(mess.link);

    // Kurangi limit sebanyak 5 jika bukan premium
    if (!isPrem) {
        user.limit -= 5;
    }

    try {
        // Kirim emoji react ⏱️ sebagai indikator proses
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "⏱️",
                key: m.key,
            }
        });

        // Panggil API
        let anu = await fetch(`https://api.siputzx.my.id/api/d/pinterest?url=${encodeURIComponent(text)}`);
        if (!anu.ok) throw new Error("Gagal mengakses API.");
        
        let json = await anu.json();

        // Validasi respons
        if (!json.status || !json.data || !json.data.url) {
            return;
        }

        // Kirim gambar
        let imageUrl = json.data.url;
        await lenwy.sendFile(m.chat, imageUrl, '', m);

        // Ubah emoji menjadi ✅ setelah selesai
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key,
            }
        });

    } catch (error) {
        console.error("Error:", error.message);
    }
}
break

case 'bluearchive': {
    lenwyreply('*One Moment, Please ☕*');

    try {
        const axios = require('axios'); // Pastikan axios sudah diinstal

        // URL API untuk gambar dari Korea
        const apiURL = `https://api.siputzx.my.id/api/r/blue-archive`;

        // Panggil API untuk mendapatkan gambar
        const { data } = await axios.get(apiURL, { responseType: 'arraybuffer' });

        // Mengkonversi data gambar ke Buffer
        const imageBuffer = Buffer.from(data, 'binary');

        // Kirim gambar ke pengguna
        await lenwy.sendMessage(m.chat, {
            image: imageBuffer,
            caption: `*Done 😋*`,
        }, { quoted: m });
    } catch (error) {
        console.error("⚠ *Error Saat Mendapatkan Gambar :*", error.message);
        lenwyreply("*Terjadi Kesalahan Dalam Proses Permintaan.*");
    }
}
break

case 'kalender': {
    if (!text) return lenwyreply('*Masukkan bulan dan tahun dengan format: <bulan-tahun>*\nContoh: 2-2025');
    lenwyreply('*One Moment, Please ☕*');

    try {
        const axios = require('axios');
        
        // Memisahkan input bulan dan tahun
        const [bulan, tahun] = text.split('-');
        if (!bulan || !tahun) return lenwyreply('*Format salah! Gunakan format: <bulan-tahun>*');
        
        // URL API
        const apiURL = `https://botcahx.web.id/kalender?bulan=${bulan}&tahun=${tahun}`;
        const { data } = await axios.get(apiURL);

        // Validasi respons
        if (data && data.status && data.result.length > 0) {
            let result = `📅 *Kalender ${bulan}-${tahun}:*\n\n`;
            data.result.forEach((holiday) => {
                result += `🔸 *Tanggal:* ${holiday.holiday_date}\n`;
                result += `🔸 *Nama Libur:* ${holiday.holiday_name}\n`;
                result += `🔸 *Libur Nasional:* ${holiday.is_national_holiday ? 'Ya' : 'Tidak'}\n\n`;
            });
            lenwyreply(result.trim());
        } else {
            lenwyreply(`❌ *Tidak ada data hari libur untuk bulan ${bulan} tahun ${tahun}.*`);
        }
    } catch (error) {
        console.error("⚠ *Error Saat Mendapatkan Data Kalender :*", error.message);
        lenwyreply("*Terjadi Kesalahan Dalam Proses Permintaan.*");
    }
}
break

case 'calendar': {
    if (!q) return lenwyreply(`*Masukkan bulan dan tahun dengan format: bulan|tahun*\nContoh: ${prefix+command} 2|2026`);
    lenwyreply('*Sedang Membuat Kalender, Tunggu Sebentar ☕*');
    try {
        // Memisahkan input bulan dan tahun
        const [month, year] = q.split('|').map(Number);

        // Validasi input
        if (!month || !year || month < 1 || month > 12 || year < 1000 || year > 9999) {
            return lenwyreply(`*Format Tidak Valid! Masukkan bulan (1-12) dan tahun (4 digit)*`);
        }

        // URL API dengan parameter
        const apiUrl = `https://api.ryzendesu.vip/api/image/calendar?month=${month}&year=${year}`;

        // Mendapatkan data dari API
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });

        // Mengirim gambar kalender
        const imageBuffer = Buffer.from(response.data, 'binary');
        lenwy.sendMessage(from, { image: imageBuffer, caption: `*Kalender untuk Bulan ${month}, Tahun ${year}*` }, { quoted: m });
    } catch (error) {
        console.error("⚠ *Error Saat Mengambil Kalender :*", error.message);
        lenwyreply("*Terjadi Kesalahan Dalam Proses Permintaan.*");
    }
}
break

case 'kucing': {
    lenwyreply('*One Moment, Please ☕*');

    try {
        const axios = require('axios'); // Pastikan axios sudah diinstal

        // URL API untuk gambar dari Korea
        const apiURL = `https://api.siputzx.my.id/api/r/cats`;

        // Panggil API untuk mendapatkan gambar
        const { data } = await axios.get(apiURL, { responseType: 'arraybuffer' });

        // Mengkonversi data gambar ke Buffer
        const imageBuffer = Buffer.from(data, 'binary');

        // Kirim gambar ke pengguna
        await lenwy.sendMessage(m.chat, {
            image: imageBuffer,
            caption: `*Done 😋*`,
        }, { quoted: m });
    } catch (error) {
        console.error("⚠ *Error Saat Mendapatkan Gambar :*", error.message);
        lenwyreply("*Terjadi Kesalahan Dalam Proses Permintaan.*");
    }
}
break

case 'terabox': {
    // Memastikan user memiliki status premium
    if (!isPrem) {
        return lenwyreply('*⚠️ Kamu bukan member premium! Fitur ini hanya tersedia untuk member premium.*');
    }

    // Meminta URL dari TeraBox
    let url = args[0];
    if (!url) {
        return lenwyreply('*⚠️ Silahkan masukkan URL TeraBox yang valid.*');
    }

    // Mengambil data dari API TeraBox
    let teraboxData = await fetch(`https://vapis.my.id/api/terabox?url=${url}`)
        .then(res => res.json())
        .catch(err => lenwyreply('*⚠️ Terjadi kesalahan saat mengambil data dari TeraBox.*'));

    if (teraboxData.status) {
        // Menampilkan file yang tersedia di TeraBox
        let fileInfo = teraboxData.data.map(file => `
Nama File: ${file.fileName}
Tipe: ${file.type}
Thumbnail: ${file.thumb}
Link Download: ${file.url_1}
        `).join('\n');

        lenwyreply(`*Berikut adalah informasi file dari TeraBox:* \n\n${fileInfo}`);
    } else {
        lenwyreply('*⚠️ Gagal mengambil data dari TeraBox. Pastikan URL yang diberikan benar.*');
    }
}
break

case 'twitter': {
    // Memastikan user memiliki status premium
    if (!isPrem) {
        return lenwyreply('*⚠️ Kamu bukan member premium! Fitur ini hanya tersedia untuk member premium.*');
    }

    // Meminta URL Twitter
    let url = args[0];
    if (!url) {
        return lenwyreply('*⚠️ Silahkan masukkan URL Twitter yang valid.*');
    }

    // Mengambil data dari API Twitter
    let twitterData = await fetch(`https://vapis.my.id/api/twitter?url=${url}`)
        .then(res => res.json())
        .catch(err => lenwyreply('*⚠️ Terjadi kesalahan saat mengambil data dari Twitter.*'));

    if (twitterData.status) {
        // Menampilkan informasi tweet
        let tweetInfo = `
📝 *Deskripsi:* ${twitterData.data.desc}
🎥 *Video SD:* ${twitterData.data.video_sd}
🎬 *Video HD:* ${twitterData.data.video_hd}
🔊 *Audio:* ${twitterData.data.audio}
🖼️ *Thumbnail:* ${twitterData.data.thumb}
        
*Dengarkan atau tonton tweet dari ${url}!*
        `;
        lenwyreply(tweetInfo);
    } else {
        lenwyreply('*⚠️ Gagal mengambil data dari Twitter. Pastikan URL yang diberikan benar.*');
    }
}
break

case 'lirik': {
    if (!q) return m.reply('Masukkan kata kunci pencarian!');

    const query = encodeURIComponent(q); // Menyandikan query
    const apiUrl = `https://vapis.my.id/api/googlev1?q=${query}`;
    
    try {
        // Mengambil data dari API
        const res = await fetch(apiUrl);
        const data = await res.json();

        if (data.status && data.data.length > 0) {
            let result = 'Hasil Pencarian:\n\n';
            
            // Mengambil informasi dari hasil data API
            data.data.forEach((item, index) => {
                result += `*${index + 1}. ${item.title}*\n`;
                result += `Deskripsi: ${item.desc}\n`;
                result += `Link: ${item.link}\n\n`;
            });

            m.reply(result);
        } else {
            m.reply('Tidak ditemukan hasil pencarian.');
        }
    } catch (err) {
        console.error(err);
        m.reply('Terjadi kesalahan saat mengambil data.');
    }
}
break

case 'spotifys': {
    try {
        if (!text) return lenwyreply('Masukkan kata kunci untuk mencari lagu.\nContoh: *spotify ada aku*');

        lenwyreply(`Sebentar... sedang mencari lagu berdasarkan kata kunci "${text}"...`);

        let apiUrl = `https://api.agatz.xyz/api/spotify?message=${encodeURIComponent(text)}`;
        let res = await axios.get(apiUrl);

        // Log response untuk debugging
        console.log(res.data);

        if (res.data.status === 200 && res.data.data && res.data.data.length > 0) {
            let tracks = res.data.data; // Akses data lagu dari response

            let result = `*Hasil Pencarian Lagu: "${text}"*\n\n`;

            tracks.forEach((track, index) => {
                result += `${index + 1}. *${track.trackName}* - ${track.artistName}\n`;
                result += `   🎶 Album: ${track.albumName}\n`;
                result += `   ⏱️ Durasi: ${track.duration}\n`;
                result += `   🌐 Link: ${track.externalUrl}\n\n`;
            });

            lenwyreply(result); // Kirim hasil pencarian ke pengguna

        } else {
            lenwyreply(`Tidak ditemukan lagu dengan kata kunci "${text}". Coba kata kunci lain.`);
        }

    } catch (err) {
        console.error(err);
        lenwyreply('Terjadi kesalahan saat memproses permintaan.');
    }
}
break

case 'muslimai': {
if (!isPrem) return lenwyreply(mess.prem)
    if (!text) return lenwyreply('*Masukkan pertanyaan atau pernyataan yang ingin diajukan kepada Muslim AI!*');
    
    const axios = require('axios');
    const query = encodeURIComponent(text);
    const apiURL = `https://api.siputzx.my.id/api/ai/muslimai?query=${query}`;
    
    try {
        lenwyreply('*⏱️ Sedang memproses jawaban, harap tunggu...*');
        const { data } = await axios.get(apiURL);
        
        if (data && data.data) {
            lenwyreply(`*🤖 Muslim AI Menjawab:*\n\n${data.data}`);
        } else {
            lenwyreply('*⚠️ Tidak ada jawaban yang ditemukan. Silakan coba lagi dengan pertanyaan yang berbeda.*');
        }
    } catch (error) {
        console.error("⚠ Error Muslim AI:", error.message);
        lenwyreply('*⚠️ Terjadi kesalahan saat memproses permintaan Anda. Coba lagi nanti.*');
    }
}
break

case 'yousearch': {
if (!isPrem) return lenwyreply(mess.prem)
    if (!text) return lenwyreply('*Masukkan kata kunci untuk pencarian informasi!*');
    
    const axios = require('axios');
    const query = encodeURIComponent(text);
    const apiURL = `https://api.siputzx.my.id/api/ai/yousearch?text=${query}`;
    
    try {
        lenwyreply('*🔍 Sedang mencari informasi, tunggu sebentar...*');
        const { data } = await axios.get(apiURL);

        if (data && data.status) {
            lenwyreply(`*🌐 Hasil Pencarian:*\n\n${data.data}`);
        } else {
            lenwyreply('*⚠️ Tidak ada hasil yang ditemukan. Silakan coba lagi dengan kata kunci berbeda.*');
        }
    } catch (error) {
        console.error("⚠ Error YouSearch:", error.message);
        lenwyreply('*⚠️ Terjadi kesalahan saat memproses permintaan Anda. Coba lagi nanti.*');
    }
}
break

case 'likee': {
    if (!text) return lenwyreply(`*Masukkan URL Likee-nya!*\nContoh: /likee https://l.likee.video/v/tmj1oh`);
    lenwyreply('*Tunggu sebentar, sedang memproses permintaan...*');

    try {
        const axios = require('axios');

        // URL API dengan parameter URL Likee
        const apiURL = `https://api.botcahx.eu.org/api/download/likee?url=${text}&apikey=kayganzz`;

        // Panggil API
        const response = await axios.get(apiURL);
        const result = response.data.result;

        // Jika data berhasil diperoleh
        if (result) {
            const { title, withwm, nowm } = result;

            // Tampilkan informasi video
            const infoMessage = `*Likee Video Download:*\n\n` +
                `• *Judul:* ${title}\n` +
                `• *Tanpa Watermark:* [Klik di sini](${nowm})\n` +
                `• *Dengan Watermark:* [Klik di sini](${withwm})\n\n` +
                `*Sedang mengirim video tanpa watermark, harap tunggu...*`;
            lenwyreply(infoMessage);

            // Kirim video tanpa watermark langsung
            await lenwy.sendMessage(m.chat, {
                video: { url: nowm }, // Video tanpa watermark
                caption: `*Likee Video:*\n${title}\n\nVideo tanpa watermark dari Likee berhasil diunduh!`,
            }, { quoted: m });
        } else {
            lenwyreply('*Gagal mendapatkan data video. Cek URL atau API key Anda.*');
        }
    } catch (error) {
        console.error("⚠ Error:", error.message);
        lenwyreply('*Terjadi kesalahan dalam memproses permintaan.*');
    }
}
break

case 'snackvid': {
    if (!text) return lenwyreply('Masukkan URL SnackVideo yang valid! Contoh: snackvid url')
    try {
        // Pesan sementara saat proses berlangsung
        lenwyreply('⏱️ Sabar ya, lagi di proses...')

        // Ambil data dari API
        let res = await fetchJson(`https://api.siputzx.my.id/api/d/snackvideo?url=${text}`)
        if (res.status) {
            let { url, title, description, thumbnail, uploadDate, videoUrl, duration, interaction, creator } = res.data
            let caption = `
🎥 *SnackVideo Downloader*

📌 *Judul:* ${title}
📝 *Deskripsi:* ${description}
📅 *Upload Date:* ${uploadDate}
⏱️ *Durasi:* ${duration}

👤 *Creator:* ${creator.name}
🔗 *Profile:* ${creator.profileUrl}
💬 *Bio:* ${creator.bio}

📈 *Interaksi:*  
👀 *Views:* ${interaction.views.toLocaleString()}  
❤️ *Likes:* ${interaction.likes.toLocaleString()}  
🔄 *Shares:* ${interaction.shares.toLocaleString()}

🔗 *Original URL:* ${url}
            `.trim()

            // Kirim video dengan caption
            await lenwy.sendMessage(m.chat, {
                video: { url: videoUrl },
                caption: caption
            }, { quoted: len })
        } else {
            lenwyreply('❌ Gagal mengambil data. Pastikan URL valid atau coba lagi nanti!')
        }
    } catch (err) {
        console.error(err)
        lenwyreply('❌ Terjadi kesalahan. Mohon coba lagi nanti.')
    }
}
break

case 'ytplay': {
    if (!text) return lenwyreply(`*⚠️ Masukkan judul atau link YouTube yang ingin dicari!*\nContoh: /ytplay serana`);
    lenwyreply('*🔄 Tunggu sebentar, sedang memproses permintaan...*');

    try {
        const axios = require('axios');
        const apiURL = `https://api.diioffc.web.id/api/search/ytplay?query=${text}`;
        const response = await axios.get(apiURL);
        const result = response.data.result;

        if (result) {
            const {
                title,
                url,
                description,
                thumbnail,
                duration: { timestamp },
                ago,
                views,
                author: { name, url: authorUrl },
                download: { url: downloadUrl, filename }
            } = result;

            // Informasi YouTube
            const caption = `*🎶 YouTube Audio Download:*\n\n` +
                `📌 *Judul:* ${title}\n` +
                `📤 *Durasi:* ${timestamp}\n` +
                `👀 *Dilihat:* ${views} kali\n` +
                `🕒 *Dirilis:* ${ago}\n` +
                `🎙️ *Channel:* [${name}](${authorUrl})\n` +
                `🔗 *Link YouTube:* [Klik di sini](${url})\n` +
                `📝 *Deskripsi:* ${description}\n\n` +
                `*Audio sedang dikirim... Tunggu sebentar!*`;

            // Kirim thumbnail dan audio bersamaan
            await lenwy.sendMessage(m.chat, {
                image: { url: thumbnail },
                caption: caption,
            }, { quoted: m });

            await lenwy.sendMessage(m.chat, {
                audio: { url: downloadUrl },
                mimetype: 'audio/mpeg',
                fileName: filename,
            }, { quoted: m });
        } else {
            lenwyreply('*❌ Gagal mendapatkan data dari API. Cek input Anda!*');
        }
    } catch (error) {
        console.error("⚠ Error:", error.message);
        lenwyreply('*❌ Terjadi kesalahan dalam memproses permintaan.*');
    }
}
break



case 'kuliner': {
    async function ku(ajur) {
        const cheerio = require('cheerio');
        const axios = require('axios');

        try {
            const response = await axios.get(`https://info-kuliner.com/category/masakan-${ajur}/`);
            const $ = cheerio.load(response.data);
            const result = [];

            $('.post').each((index, element) => {
                const nama = $(element).find('.entry-title').text().trim();
                const link = $(element).find('.entry-title a').attr('href');
                const ct = $(element).find('.entry-content').text().trim();

                result.push({
                    creator: 'Kayzu',
                    status: 200,
                    nama: nama,
                    link: link,
                    ct: ct
                });
            });

            return result;
        } catch (error) {
            throw error;
        }
    }

    async function zaenar(url) {
        const cheerio = require('cheerio');
        const axios = require('axios');

        try {
            const response = await axios.get(url);
            const $ = cheerio.load(response.data);
            let hasil = [];
            let deskripsiText = '';

            const unwantedStrings = [
                'Your email address will not be published.',
                'Comment',
                'Name *',
                'Email *',
                'Website',
                'Save my name, email, and website in this browser for the next time I comment.',
                'Shark Magazine by Shark Themes',
                'Shark Magazine',
                'by Shark Themes',
                'Copyright © 2019 | All Rights Reserved',
                'Info Kuliner',
                'Rumah Makan | Restoran | Tempat Makan | Cafe'
            ];

            $('p').each((index, element) => {
                const deskripsi = $(element).text().trim();
                if (!unwantedStrings.some(unwanted => deskripsi.includes(unwanted))) {
                    deskripsiText += `${deskripsi}\n`;
                }
            });

            const ogImageUrl = $('meta[property="og:image"]').attr('content');

            hasil.push({
                creator: 'Kayzu',
                result: deskripsiText.trim(),
                gambar: ogImageUrl
            });

            return hasil;
        } catch (error) {
            throw error;
        }
    }

    if (!text) return lenwyreply(`*Format Seperti Ini:* ${prefix + command} sunda`);

    if (text.includes('https://info-kuliner')) {
        try {
            const response = await zaenar(text);
            const formattedResult = response[0].result.replace(/\n\s*\n/g, '\n\n').trim();
            lenwyreply(formattedResult);
        } catch (error) {
            console.error('Error:', error.message);
            lenwyreply('Terjadi kesalahan dalam mengambil data. Silakan coba lagi nanti.');
        }
    } else {
        try {
            const result = await ku(text);

            if (result.length > 0) {
                let replyText = `*Daftar Tempat Kuliner ${text}:*\n\n*Ketik ${prefix + command} <url> Untuk Melihat Info Rumah Makan*\n\n`;

                result.forEach((entry, index) => {
                    replyText += `*${index + 1}. ${entry.nama}*\n   ${entry.link}\n   ${entry.ct}\n\n`;
                });

                lenwyreply(replyText);
            } else {
                lenwyreply(`Maaf, tidak ada data kuliner ${text} yang ditemukan.`);
            }
        } catch (error) {
            console.error('Error:', error.message);
            lenwyreply(`Terjadi kesalahan dalam mengambil data ${error.message}. Silakan coba lagi nanti.`);
        }
    }
}
break

case 'ytplay2': {
    try {
        if (!q) return lenwyreply("Masukkan judul lagu yang ingin dicari!");

        await lenwy.sendMessage(m.chat, {
            react: {
                text: "⏱️",
                key: m.key,
            }
        });

        let response = await fetchJson(`https://api.diioffc.web.id/api/search/ytplay?query=${encodeURIComponent(q)}`);

        if (!response?.status) return lenwyreply("Gagal mengambil data dari YouTube.");

        let data = response.result;
        let teks = `*YT PLAY*\n\n🎵 *Judul:* ${data.title}\n👤 *Channel:* ${data.author.name}\n👀 *Views:* ${data.views}\n⏱️ *Durasi:* ${data.duration.timestamp}\n📅 *Upload:* ${data.ago}\n🔗 *Link:* [Tonton di YouTube](${data.url})\n\n_Sedang mengirim audio..._`;

        let message = {
            image: { url: data.thumbnail },
            caption: teks
        };

        await lenwy.sendMessage(m.chat, message, { quoted: m });

        let audioMessage = {
            audio: { url: data.download.url },
            mimetype: 'audio/mpeg',
            fileName: data.download.filename
        };

        await lenwy.sendMessage(m.chat, audioMessage, { quoted: m });

        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key,
            }
        });

    } catch (err) {
        console.error(err);
        lenwyreply("Terjadi kesalahan saat mengambil atau mengirim data.");
    }
}
break

case "scdl": {
    if (!text) return lenwyreply("Masukkan URL SoundCloud!");

    await lenwy.sendMessage(m.chat, {
        react: {
            text: "⏱️",
            key: m.key,
        }
    });

    try {
        let res = await fetch(`https://fastrestapis.fasturl.cloud/downup/soundclouddown?url=${encodeURIComponent(text)}`);
        let json = await res.json();

        if (json.status !== 200) return lenwyreply("Gagal mengunduh audio!");

        await lenwy.sendMessage(m.chat, {
            audio: { url: json.data.file },
            mimetype: 'audio/mpeg'
        }, { quoted: m });

        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key,
            }
        });
    } catch (e) {
        console.error(e);
        lenwyreply("Terjadi kesalahan saat mengunduh audio!");
    }
}
break

case 'chatgpt': {
if (!isPrem) return lenwyreply(mess.prem)
    if (!text) return lenwyreply(`*Masukkan pertanyaannya!*`);
    lenwyreply(mess.wait);
    try {
        const axios = require('axios'); // Pastikan axios sudah diinstal
        
        // URL API Anda
        const apiURL = `https://api.tioo.eu.org/openai?text=${encodeURIComponent(text)}`;
        
        // Panggil API menggunakan axios
        const { data } = await axios.get(apiURL);
        
        // Pastikan data respons valid
        if (data && data.status && data.result) {
            lenwyreply(`🤖 *Jawaban:*\n${data.result}`);
        } else {
            lenwyreply(`❌ *Maaf, API tidak memberikan jawaban yang valid.*`);
        }
    } catch (error) {
        console.error("Error di case 'chatgpt':", error.message);
        lenwyreply(`❌ *Terjadi kesalahan saat memproses permintaan.*`);
    }
}
break


case 'igslide': {
    if (!args[0]) return lenwyreply('Masukkan URL Instagram.');
    const url = args[0];
    const apiUrl = `https://api.botcahx.eu.org/api/dowloader/igdowloader?url=${encodeURIComponent(url)}&apikey=kayganzz`;

    try {
        // Kirim emoji react ⏱️ sebagai indikator proses
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "⏱️",
                key: m.key,
            }
        });

        const response = await fetch(apiUrl);
        const result = await response.json();

        if (!result.status || !result.result || result.result.length === 0) {
            return lenwyreply('Gagal mengambil data. Pastikan URL valid.');
        }

        let mediaLinks = result.result.map(item => item.url); // Ambil daftar media URLs

        // Batasi pengiriman maksimal 7 foto
        let limitedMedia = mediaLinks.slice(0, 7);

        // Kirim notifikasi bahwa media akan dikirim di chat pribadi
        await lenwyreply('📤 Foto akan dikirim di chat pribadi.');

        // Kirim media ke pengguna secara pribadi (DM) satu per satu
        for (let i = 0; i < limitedMedia.length; i++) {
            const media = limitedMedia[i];
            await lenwy.sendMessage(m.sender, { 
                image: { url: media }, 
                caption: `🖼️ (Media ${i + 1})` 
            });
        }

        await lenwyreply('✅ Download Instagram selesai!');
    } catch (error) {
        console.error(error);
        lenwyreply('❌ Terjadi kesalahan saat memproses permintaan.');
    }
}
break

case 'ttslide':
case 'tiktokslide': {
    if (isBan) return lenwyreply('*Kamu Di Ban Owner*');
    if (!text) return lenwyreply(`📌 Masukkan link TikTok!`);
    if (!isUrl(args[0])) return lenwyreply(mess.link);

    // Kurangi limit sebanyak 5 jika bukan premium
    if (!isPrem) {
        user.limit -= 5;
    }

    try {
        // Kirim emoji react ⏱️ sebagai indikator proses
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "⏱️",
                key: m.key,
            }
        });

        // Panggil fungsi ttslide
        let result = await ttslide(text);

        // Cek jika ada gambar
        if (!result || !result.imgSrc || result.imgSrc.length === 0) {
            return;
        }

        // Kirim gambar satu per satu
        for (let i = 0; i < result.imgSrc.length; i++) {
            await sleep(40);
            await lenwy.sendMessage(m.chat, { 
                image: { url: result.imgSrc[i] }
            });
        }

        // Ubah emoji menjadi ✅ setelah selesai
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key,
            }
        });
    } catch (error) {
        console.error(error);
    }
}
break

case 'dalle': {
    if (!text) return lenwyreply(`*Masukkan deskripsi gambar!*`);
    lenwyreply('*One Moment, Please ☕*');

    try {
        const axios = require('axios'); // Pastikan axios sudah diinstal

        // URL API dengan deskripsi gambar yang dimasukkan
        const apiURL = `https://api.tioo.eu.org/dalle?text=${encodeURIComponent(text)}`;

        // Panggil API untuk mendapatkan gambar
        const { data } = await axios.get(apiURL, { responseType: 'arraybuffer' });

        // Mengkonversi data gambar ke Buffer
        const imageBuffer = Buffer.from(data, 'binary');

        // Kirim gambar ke pengguna
        await lenwy.sendMessage(m.chat, {
            image: imageBuffer,
            caption: `🖼️ *Gambar Berdasarkan Deskripsi:* ${text}`,
        }, { quoted: m });
    } catch (error) {
        console.error("⚠ *Error Saat Mendapatkan Gambar :*", error.message);
        lenwyreply("*Terjadi Kesalahan Dalam Proses Permintaan.*");
    }
}
break

case 'simsimi': {
    if (!isPrem) return lenwyreply(mess.prem); // Hanya untuk pengguna premium
    if (!text) return lenwyreply('*Masukkan pertanyaannya!*');

    try {
        const axios = require('axios');
        
        // URL API
        const apiURL = `https://api.siputzx.my.id/api/fun/simsimi?text=${encodeURIComponent(text)}`;
        const { data } = await axios.get(apiURL);

        // Validasi respons
        if (data && data.status && data.message) {
            lenwyreply(data.message);
        } else {
            lenwyreply(`❌ *Maaf, SimiSimi tidak bisa menjawab saat ini.*`);
        }
    } catch (error) {
        console.error("⚠ *Error Saat Mendapatkan Jawaban :*", error.message);
        lenwyreply("*Terjadi Kesalahan Dalam Proses Permintaan.*");
    }
}
break

case 'stably': {
if (!isPrem) return lenwyreply(mess.prem)
    if (!text) return lenwyreply(`*Masukkan deskripsi gambar!*`);
    lenwyreply('*One Moment, Please ☕*');

    try {
        const axios = require('axios'); // Pastikan axios sudah diinstal

        // URL API dengan deskripsi gambar yang dimasukkan
        const apiURL = `https://api.siputzx.my.id/api/ai/stable-diffusion?prompt=${encodeURIComponent(text)}`;

        // Panggil API untuk mendapatkan gambar
        const { data } = await axios.get(apiURL, { responseType: 'arraybuffer' });

        // Mengkonversi data gambar ke Buffer
        const imageBuffer = Buffer.from(data, 'binary');

        // Kirim gambar ke pengguna
        await lenwy.sendMessage(m.chat, {
            image: imageBuffer,
            caption: `*Berikut hasilnya, Tuan! 🦎⚡:* ${text}`,
        }, { quoted: m });
    } catch (error) {
        console.error("⚠ *Error Saat Mendapatkan Gambar :*", error.message);
        lenwyreply("*Terjadi Kesalahan Dalam Proses Permintaan.*");
    }
}
break

case 'fluximage': {
if (!isPrem) return lenwyreply(mess.prem)
    if (!text) return lenwyreply(`*Masukkan deskripsi gambar!*`);
    lenwyreply('*One Moment, Please ☕*');

    try {
        const axios = require('axios'); // Pastikan axios sudah diinstal

        // URL API dengan deskripsi gambar yang dimasukkan
        const apiURL = `https://api.siputzx.my.id/api/ai/flux?prompt=${encodeURIComponent(text)}`;

        // Panggil API untuk mendapatkan gambar
        const { data } = await axios.get(apiURL, { responseType: 'arraybuffer' });

        // Mengkonversi data gambar ke Buffer
        const imageBuffer = Buffer.from(data, 'binary');

        // Kirim gambar ke pengguna
        await lenwy.sendMessage(m.chat, {
            image: imageBuffer,
            caption: `*Berikut hasilnya, Tuan! 🦎⚡:* ${text}`,
        }, { quoted: m });
    } catch (error) {
        console.error("⚠ *Error Saat Mendapatkan Gambar :*", error.message);
        lenwyreply("*Terjadi Kesalahan Dalam Proses Permintaan.*");
    }
}
break

case 'confes':
case 'confess':
case 'menfes':
case 'menfess':
if (!text) return lenwyreply(`*Format : Menfess Nomor|Pengirim|Pesan*\n\n*Contoh : Menfes 6289673462138|Naee|Semangat Yah*`)
let nomor = q.split('|')[0] ? q.split('|')[0] : q
let lenwy_nama = q.split('|')[1] ? q.split('|')[1] : q
let lenwychat = q.split('|')[2] ? q.split('|')[2] : ''
if (lenwychat.length < 1) return lenwyreply(`*Tolong Isi Semua Data Dengan Baik*`)
let lenwy_txt = `*Halo Ada Menfess Nih*\n*Dari : ${lenwy_nama}* \n*Pesan :*\n${lenwychat}\n\n*Menfess Ini Dikirim Oleh Bot kayzuMD*`
lenwy.sendMessage(`${nomor}@s.whatsapp.net`, { caption: lenwy_txt, image: {url: `https://pomf2.lain.la/f/9cv3rl3j.jpg`}})
lenwyreply(`*Sukses Mengirim Menfess*`)     
break

case 'readmore': {
if (isBan) return lenwyreply('*Kamu Di Ban Owner*')
if (!q) return lenwyreply('⚠ *Contoh : Readmore Halo Aku kayzu|Subscribe kayzu*')
let [a, b] = text.split`|`
if (!a) a = ''
if (!b) b = ''
lenwyreply(a + readmore + b)
}
break

case 'morse': {
  if (!q) return lenwyreply('⚠ *Masukkan Teks Yang Ingin Diubah Menjadi Sandi Morse*');
  try {
      const morseCode = await Morse(q);
      let responseMessage = `*Teks Asli :*\n_${q}_\n\n*Sandi Morse:*\n${morseCode}`;
      lenwyreply(responseMessage);
  } catch (err) {
      console.error(err);
      lenwyreply('*Terjadi Kesalahan Saat Mengonversi Teks Menjadi Sandi Morse!*');
  }
}
break

case 'ip': {
  if (!q) return lenwyreply('⚠ *Masukkan IP Dan Prefix Yang Akan Dihitung*');
  const ipFormat = /^(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\.(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/;
  if (!ipFormat.test(q)) {
      return lenwyreply('*Format Salah, Contoh : 192.268.10.1/24*');
  }
  try {
      const ipInfo = await LenIp(q);
      let result = '';
      result += `*Prefix (CIDR) :* _/${ipInfo.prefix}_\n`;
      result += `*IP Address :* _${ipInfo.ipAddress}_\n`;
      result += `*Network Address :* _${ipInfo.networkAddress}_\n`;
      result += `*Broadcast Address :* _${ipInfo.broadcastAddress}_\n`;
      result += `*Subnet Mask :* _${ipInfo.subnetMask}_\n`;
      result += `*Jumlah Host :* _${ipInfo.totalHosts}_`;
      lenwyreply(result);
  } catch (err) {
      console.error(err);
      lenwyreply('*Terjadi Kesalahan Saat Menghitung IP Address!*');
  }
}
break

case 'acak': {
  if (!q) return lenwyreply('*Contoh Format : Acak 6 36*');
  let [input, pengecualian] = q.includes('|') ? q.split('|').map(part => part.trim()) : [q, null];
  let [kelompok, anggota] = input.split(' ').map(Number);
  if (!kelompok || !anggota || isNaN(kelompok) || isNaN(anggota)) {
      return lenwyreply('*Format Tidak valid! Contoh : Acak 6 36 | 2 4 6 8 9 10*');
  }
  let ketua = pengecualian ? pengecualian.split(' ').map(Number).filter(n => !isNaN(n)) : [];
  let setKetua = new Set(ketua);
  if (setKetua.size !== ketua.length) {
      return lenwyreply('*Daftar Ketua Mengandung Duplikasi!*');
  }
  if (ketua.length && ketua.length !== kelompok) {
      return lenwyreply(`*Jumlah Ketua Tidak Sesuai Dengan Jumlah Kelompok (${kelompok})*`);
  }
  let daftarAnggota = Array.from({ length: anggota }, (_, i) => i + 1).filter(n => !ketua.includes(n));
  daftarAnggota.sort(() => Math.random() - 0.5);
  let hasilKelompok = [];
  let anggotaPerKelompok = Math.floor(daftarAnggota.length / kelompok);
  let sisaAnggota = daftarAnggota.length % kelompok;
  for (let i = 0; i < kelompok; i++) {
      let jumlahAnggotaKelompok = anggotaPerKelompok + (i < sisaAnggota ? 1 : 0);
      let anggotaKelompok = daftarAnggota.splice(0, jumlahAnggotaKelompok);
      if (ketua.length) {
          hasilKelompok.push(`*Kelompok ${i + 1} ( ${ketua[i]} ) :*\n*${anggotaKelompok.join(', ')}*`);
      } else {
          hasilKelompok.push(`*Kelompok ${i + 1} :*\n*${anggotaKelompok.join(', ')}*`);
      }
  }
  lenwyreply(hasilKelompok.join('\n\n'));
}
break

case 'reminder': {
if (isBan) return lenwyreply('*Kamu Di Ban Owner*')
if (!args[0] || !args[1] || !args[2]) return lenwyreply('*Format : Reminder Waktu Detik/Menit/Jam Pesan*\n*Contoh : Reminder 30 Menit Jangan Lupa Sholat*')
const time = parseInt(args[0]) * (args[1].match(/(m|minute)/i) ? 60 : args[1].match(/(h|hour)/i) ? 3600 : 1) * 1000
const message = args.slice(2).join(' ')
setTimeout(() => {
lenwy.sendMessage(from, { text : `*Reminder Untuk @${sender.split("@")[0]}*\n\n*Dengan Pesan :* ${message}`, contextInfo:{mentionedJid:[sender]}}, { quoted: m })}, time)
lenwyreply(`*Berhasil Mengatur Reminder Untuk ${args[0]} ${args[1]} Ke Depan*`)
}
break

case 'google': {
if (!isPrem) return lenwyreply(mess.prem)
if (!q) return lenwyreply(`*Contoh : ${prefix + command} Youtube kayzu*`)
let google = require('google-it')
google({'query': text}).then(res => {
let teks = `*Google Search From : ${text}*\n\n`
for (let g of res) {
teks += ` *⨠ Title* : ${g.title}\n`
teks += ` *⨠ Description* : ${g.snippet}\n`
teks += ` *⨠ Link* : ${g.link}\n\n────────────────────────\n\n`
} 
lenwyreply(teks)
})
}
break

case 'gempa': {
    try {
        // Kirim reaksi emoji
        await lenwy.sendMessage(m.chat, { react: { text: '🌍', key: m.key } });

        // Fetch data dari API
        let res = await fetch('https://api.botcahx.eu.org/api/search/gempa?apikey=kayganzz');
        let json = await res.json();

        // Cek status API
        if (!json.status || json.code !== 200) throw 'Gagal mengambil data!';

        let result = json.result.result;

        // Format caption
        let caption = `*Info Gempa Terkini:*\n\n` +
            `📆 *Tanggal*: ${result.tanggal}\n` +
            `🕒 *Waktu*: ${result.jam}\n` +
            `📍 *Lintang*: ${result.Lintang}\n` +
            `📍 *Bujur*: ${result.Bujur}\n` +
            `💥 *Magnitudo*: ${result.Magnitudo}\n` +
            `🌊 *Kedalaman*: ${result.Kedalaman}\n` +
            `📢 *Potensi*: ${result.Potensi}\n` +
            `📌 *Wilayah*: ${result.Wilayah}\n\n` +
            `*Sumber*: BMKG`;

        // URL gambar dari API
        let photoUrl = result.image;

        // Kirim foto dengan caption
        if (photoUrl) {
            await lenwy.sendMessage(m.chat, {
                image: { url: photoUrl },
                caption: caption
            });
        } else {
            // Jika gambar tidak tersedia, kirim hanya teks
            lenwyreply(caption);
        }
    } catch (e) {
        console.error(e);
        lenwyreply('Terjadi kesalahan saat mengambil data gempa. Mohon coba lagi nanti.');
    }
}
break

case 'infogempa': {
const { scrapeGempa } = require('./kiromi/kay/infogempa.js'); // Sesuaikan path-nya
    try {
        let data = await scrapeGempa();
        if (!data) return await lenwy.sendMessage(m.chat, { text: '❌ Gagal mengambil data gempa. Coba lagi nanti.' }, { quoted: m });

        let caption = `🌍 *INFO GEMPA BMKG*\n\n📅 *Tanggal:* ${data.tanggal}\n🕒 *Waktu:* ${data.jam}\n📍 *Lokasi:* ${data.wilayah}\n📌 *Lintang:* ${data.lintang}\n📌 *Bujur:* ${data.bujur}\n💢 *Magnitudo:* ${data.magnitudo}\n📏 *Kedalaman:* ${data.kedalaman}\n⚠️ *Potensi:* ${data.potensi}`;

        await lenwy.sendMessage(m.chat, { image: { url: data.image }, caption: caption }, { quoted: m });
    } catch (error) {
        console.error('❌ Error mengambil data gempa:', error);
        await lenwy.sendMessage(m.chat, { text: '❌ Terjadi kesalahan, coba lagi nanti.' }, { quoted: m });
    }
}
break;

case 'mc': case 'mcserver': 
            if (args.length == 0) return lenwyreply(`*Java / Bedrock*`)
            if (args[0] === 'bedrock') {
                lenwyreply(mess.wait)
axios.get(`https://api.mcstatus.io/v2/status/bedrock/${args[1]}`).then(({ data }) => {
                var caption = `*⨠ Minecraft Bedrock Server*\n`
                caption += ` *⨠ IP : ${data.host}*\n`
                caption += ` *⨠ Port : ${data.port}*\n`
                caption += ` *⨠ IP Address : ${data.ip_address}*\n\n`
                caption += `*⨠ Server Information*\n`
                caption += ` *⨠ Gamemode : ${data.gamemode}*\n`
                caption += ` *⨠ Player Online : ${data.players.online}/${data.players.max}*\n`
                caption += ` *⨠ Version : ${data.version.name}*\n`
                caption += ` *⨠ Edition : ${data.edition}*\n`
                lenwy.sendMessage(from , {image: { url: `https://pomf2.lain.la/f/tnx9di0.jpg` }, caption: caption },{ quoted: m })
            })
} else if (args[0] === 'java') {
    lenwyreply(mess.wait)
axios.get(`https://api.mcstatus.io/v2/status/java/${args[1]}`).then(({ data }) => {
                var caption = `*⨠ Minecraft Java Server*\n`
                caption += ` *⨠ IP : ${data.host}*\n`
                caption += ` *⨠ Port : ${data.port}*\n`
                caption += ` *⨠ IP Address : ${data.ip_address}*\n\n`
                caption += `*⨠ Server Information*\n`
                caption += ` *⨠ Player Online : ${data.players.online}/${data.players.max}*\n`
                caption += ` *⨠ Mods : ${data.mods.name}*\n`
                caption += ` *⨠ Plugins : ${data.plugins.name}*\n`
                caption += ` *⨠ Version : ${data.version.name_clean}*\n`
                lenwy.sendMessage(from , {image: { url: `https://pomf2.lain.la/f/tnx9di0.jpg` }, caption: caption },{ quoted: m })
            })
} else {
lenwyreply('*Nama Server Tidak Ditemukan*')
}
            break

case 'jarak':{
if (!text) return lenwyreply(`*Contoh: ${prefix + command} Jakarta|Bandung*`)
if (text.length > 80) return lenwyreply(`*Maksimal 80 Karakter*`)    
lenwyreply(mess.wait)
let [from, to] = text.split(/[^\w\s]/g)
    if (!(from && to)) return lenwyreply (`*Contoh: ${prefix + command} Jakarta|Bandung*`) 
    let data = await jarak(from, to)
    if (data.img) return lenwy.sendMessage(m.chat, { image: data.img, caption: data.desc }, { quoted: m })
    else lenwyreply(data.desc)
}
break

case 'apksearch': {
if (!text) return lenwyreply(`*Masukkan Nama Apk*`)
var js = await fetch(`https://dikaardnt.com/api/search/apk?q=${q}`)
lenwyreply(mess.wait)
var json = await js.json()
var lenwycap = `
*Nama :* ${json[0].title}
*Developer :* ${json[0].developer}
*Rating :* ${json[0].rating}
*Link Download :* 
${json[0].url}
`;
await lenwy.sendMessage(m.chat, { image: { url: json[0].thumbnail }, caption: lenwycap }, { quoted: m })
}
break

case 'drakorsearch': {
if (!text) return lenwyreply(`*Masukkan Nama Drakor*`)
var js = await fetch(`https://dikaardnt.com/api/search/drakor?q=${q}`)
lenwyreply(mess.wait)
var json = await js.json()
var lenwycap = `
*Judul :* ${json[0].title}
*Genre :* ${json[0].genres}
*Link :* ${json[0].url}
`;
await lenwy.sendMessage(m.chat, { image: { url: json[0].thumbnail }, caption: lenwycap }, { quoted: m })
}
break

case 'otakudesu': {
if (!text) return lenwyreply(`*Masukkan Nama Anime*`)
var js = await fetch(`https://otakudesu-anime-api.vercel.app/api/v1/search/${q}`)
lenwyreply(mess.wait)
var json = await js.json()
var lenwycap = `
*Judul :* ${json[0].title}
*Genre :* ${json[0].genres}
*Status :* ${json[0].status}
*Nilai :* ${json[0].rating}
*Link :* ${json[0].url}
`;
await lenwy.sendMessage(m.chat, { image: { url: json[0].image }, caption: lenwycap }, { quoted: m })
}
break

case 'npms':{
  if (!text) return lenwyreply('⚠ *Masukkan Nama Node Package (NPM)*')
  let res = await fetch(`http://registry.npmjs.com/-/v1/search?text=${text}`)
  lenwyreply('🔍 *Mencari Node Package*')
  let { objects } = await res.json()
  if (!objects.length) return lenwyreply (`⚠ *Package Tidak Ditemukan*`)
  let txt = objects.map(({ package: len }) => {
  return `*Nama : ${len.name}* (v${len.version})\n*Link :* _${len.links.npm}_\n*Deskripsi :* _${len.description}_\n\n==============================`}).join`\n\n`
  lenwyreply(`🔍 *Hasil Pencarian Dari : ${text}*\n\n${txt}`)
}
break

case 'alosehat': {
  if (!q) return lenwyreply("🔍 *Mau Cari Apa Di Alosehat?*");
  try {
    lenwyreply('🔍 *Dalam Pencarian*')
    const results = await alosehat(q);
    const { total, results: articles } = results;    
    if (total === 0) {
      return lenwyreply("⚠ *Hasil Tidak Ditemukan");
    }    
    const response = articles.map((item, index) => (
      `\n\n*${index + 1}. ${item.title}*\n*Penulis : ${item.author}*\n*Tanggal : ${item.time}*\n\n*Deskripsi : ${item.desc}*\n\n*Link Artikel :* _${item.link}_\n\n==============================`
    )).join('');
    lenwyreply(`🔍 *Hasil Pencarian Untuk ${q} (${total} Hasil)*${response}`);    
  } catch (error) {
    lenwyreply(`⚠ *Kayaknya Ada Error Nih : ${error.message}*`);
  }
}
break

case 'obat': {
  if (!q) return lenwyreply('*Masukkan Nama Penyakit*');
  try {
      lenwyreply('*Mencari Artikel ☕*');
      const hasil = await Obat(q);
      if (typeof hasil === 'string' && hasil.startsWith('Error')) {
          lenwyreply(hasil);
      } else if (hasil.length === 0) {
          lenwyreply('*Tidak ditemukan artikel terkait penyakit tersebut!*');
      } else {
          let result = `*Artikel Terkait :* _${q}_\n\n`;
          hasil.forEach((item, index) => {
              result += `*Judul :* _${item.judul}_\n`;
              result += `*Deskripsi :* _${item.deskripsi}_\n\n`;
              result += `*Kategori :* _${item.kategori.join(', ')}_\n\n`;
              result += `*Link :* _${item.tautan}_\n\n======================================\n\n`;
          });
          lenwyreply(result);
      }
  } catch (error) {
      console.error(error);
      lenwyreply('*Terjadi kesalahan saat mengambil data dari Halodoc!*');
  }
}
break

case 'an1': {
  const query = args.join(" ");
  try {
      const hasil = await An1(query);

      if (hasil.data.length === 0) {
          lenwyreply('Tidak Ada Hasil Yang Ditemukan');
      } else {
          let result = `*Hasil Pencarian Untuk :* _${query}_\n\n`;
          hasil.data.forEach((item, index) => {
              result += `*Nama :* _${item.judul}_\n`;
              result += `*Developer :* _${item.dev}_\n`;
              result += `*Rating :* _${item.rating}_\n\n`;
              result += `*Link :* ${item.link}\n\n*=============================*\n\n`;
          });
          lenwyreply(result);
      }
  } catch (error) {
      console.error(error);
      lenwyreply('Terjadi kesalahan saat mengambil data dari AN1!');
  }
}
break

case 'caribuku': {
  const query = args.join(" ");
  if (!query) return lenwyreply("🔍 *Mau Cari Buku Apa?*");

  try {
    lenwyreply('🔍 *Dalam Pencarian*');
    const hasil = await Lenread(query);

    if (hasil.length === 0) {
      lenwyreply("🔍 *Tidak Ada Hasil, Pastikan Nama Buku Valid*");
    } else {
      let result = `🔍 *Hasil Pencarian Dari : ${query}*\n\n`;
      hasil.forEach((buku, index) => {
        result += `*${index + 1}. ${buku.title}*\n`;
        result += `*Rating :* _${buku.rating}_\n\n`;
        result += `*Link Buku :* \n_${buku.link}_\n\n==============================\n`;
      });
      lenwyreply(result);
    }
  } catch (error) {
    console.error(error);
    lenwyreply("*Terjadi Kesalahan Saat Mengambil Data Buku*");
  }
}
break

case 'film': {
  const query = args.join(" ");
  if (!query) return lenwyreply("🔍 *Mau Cari Film Apa?*");

  try {
    lenwyreply('🔍 *Dalam Pencarian*');
    const hasil = await RuangMovie(query);

    if (hasil.status === 404) {
      lenwyreply("*Terjadi Kesalahan, Pastikan Nama Film Valid*");
    } else if (hasil.result.length === 0) {
      lenwyreply("🔍 *Tidak Ada Hasil, Pastikan Nama Film Valid*");
    } else {
      let result = `🔍 *Hasil Pencarian Dari : ${query}*\n\n`;
      hasil.result.forEach((movie, index) => {
        result += `*${index + 1}. ${movie.title}*\n`;
        result += `*Tag :* _${movie.relTag.join(', ')}_\n\n`;
        result += `*Link Film :* \n_${movie.link}_\n\n==============================\n`;
      });
      lenwyreply(result);
    }
  } catch (error) {
    console.error(error);
    lenwyreply("*Terjadi Kesalahan Saat Mengambil Data Film*");
  }
}
break

case 'cinema':
    lenwyreply('*Mengambil Daftar Film Terkini ☕*');
    try {
        const films = await cinema.release();
        if (films.error) {
            return lenwyreply(`⚠ *Terjadi Kesalahan: ${films.message}*`);
        }
        if (films.length === 0) {
            return lenwyreply("⚠ *Tidak Ada Film Tersedia Saat Ini*");
        }

        let message = "*Daftar Film Terkini*\n\n";
        films.forEach(film => {
            message += `*Judul :* _${film.title}_\n`;
            message += `*Tipe :* _${film.type}_\n`;
            message += `*Rating :* _${film.rating}_\n\n`;
            message += `*Link Detail :*\n_${film.detailsLink}_\n\n*===================================*\n\n`;
        });
        await lenwy.sendMessage(m.chat, {
            image: { url: films[0].image },
            caption: message
        }, { quoted: m });
        
    } catch (error) {
    lenwyreply(`⚠ *Terjadi Kesalahan: ${error.message}*`);
    console.error("Error:", error);
}
break

case 'playstore': {
  const query = args.join(" ");
  if (!query) return lenwyreply("🔍 *Mau Cari Aplikasi Apa?*");

  try {
    lenwyreply('🔍 *Dalam Pencarian*');
    const hasil = await PlayStore(query);

    if (hasil.length === 0) {
      lenwyreply("*Tidak Ada Hasil, Pastikan Nama Aplikasi Valid*");
    } else {
      const app = hasil[0];

      let result = `🔍 *Hasil Pencarian Dari : ${query}*\n\n`;
      result += `*Nama :* _${app.nama}_\n`;
      result += `*Developer :* _${app.developer}_\n`;
      result += `*Rating :* _${app.rate}_\n\n`;
      result += `*Link Aplikasi :* _${app.link}_\n`;
      result += `*Link Developer :* _${app.link_dev}_\n`;

      await lenwy.sendMessage(from, {
        image: { url: app.img },
        caption: result
      }, { quoted: len });

    }
  } catch (error) {
    console.error(error);
    lenwyreply("*Terjadi Kesalahan Saat Mengambil Data Dari Play Store*");
  }
}
break

case 'infoch': {
    if (!text) return lenwyreply(`⚠ *Tolong Masukkan Link Channel WA*`);
    lenwyreply('*Mengambil Informas ☕i*');
    try {
        const channelData = await LenwyCH(text);
        
        if (!channelData) {
            return lenwyreply(`⚠ *Link Tidak Dikenali*`);
        }

        let infoTxt = "*Informasi Channel*\n\n";
        infoTxt += `*Nama :* _${channelData.name}_\n`;
        infoTxt += `*Pengikut :* _${channelData.follower}_\n\n`;
        infoTxt += `*Deskripsi :*\n ${channelData.description}\n`;

        await lenwy.sendMessage(m.chat, {
            image: { url: channelData.img },
            caption: infoTxt,
        }, { quoted: m });
    } catch (error) {
        console.error("Error:", error.message);
        lenwyreply("Terjadi kesalahan saat mengambil data dari channel.");
    }
}
break

case 'yahooimg':
    if (!text) return lenwyreply("🔍 *Mau Cari Gambar Apa Di Yahoo?*");
    lenwyreply(`*Mencari Gambar ☕*`);
    try {
        const images = await Yimg(text);
        if (images.length === 0) {
            lenwyreply("Tidak ada gambar yang ditemukan.");
        } else {
            const image = images[0];
            let imageText = `*Judul :* _${image.title}_\n`;
            imageText += `*Ukuran :* _${image.size}_\n`;
            imageText += `*Dimensi :* _${image.width}x${image.height}_\n\n`;
            imageText += `*Sumber :* _${image.url}_\n`;

            await lenwy.sendMessage(m.chat, {
                image: { url: image.url },
                caption: imageText,
            }, { quoted: m });
        }
    } catch (error) {
        lenwyreply("❌ Terjadi kesalahan saat mengambil gambar.");
        console.error(error);
    }
break

case 'samehadaku':
    if (!text) return lenwyreply("🔍 *Mau Cari Anime Apa?*");
    lenwyreply(`*One Moment, Please ☕*`);
    try {
        const result = await samehadaku.search(text);
        if (result.length === 0) {
            lenwyreply("⚠ *Tidak Ada Hasil*");
        } else {
            let message = "*Samehadaku*\n\n";
            result.forEach(anime => {
                message += `*${anime.title}*\n`
                message += `*Rating :* _${anime.rating}_\n`;
                message += `*Status :* _${anime.status}_\n`;
                message += `*Genre :* _${anime.genres.join(', ')}_\n`;
                message += `*Deskripsi :* _${anime.description}_\n\n`;
                message += `*Link :*\n_${anime.link}_\n\n*===================================*\n\n`;
            });
            await lenwy.sendMessage(m.chat, {
                image: { url: result[0].image },
                caption: message
            }, { quoted: m });
        }
  } catch (error) {
      lenwyreply(`⚠ *Terjadi Kesalahan: ${error.message}*`);
      console.error("Error:", error);
}
break

case 'samehadapage':
    if (!text) return lenwyreply("🔍 *Masukkan Angka Page*");
    if (!/^\d+$/.test(text)) {
        return lenwyreply("⚠ *Input Hanya Berupa Angka!*");
    }
    lenwyreply(`*One Moment, Please ☕*`);
    try {
        const page = parseInt(text);
        if (page < 1 || page > 18) {
            return lenwyreply('*Halaman Harus Antara 1 Hingga 18!*');
        }
        const animeList = await samehadaku.searchPage(page);

        if (animeList.length === 0) {
            return lenwyreply("⚠ *Tidak Ada Hasil*");
        }

        let message = "*Samehadaku Page*\n\n";
        animeList.forEach(anime => {
            message += `*${anime.title}*\n`;
            message += `*Rating :* _${anime.rating}_\n`;
            message += `*Status :* _${anime.status}_\n`;
            message += `*Genre :* _${anime.genres.join(', ')}_\n`;
            message += `*Deskripsi :* _${anime.description}_\n\n`;
            message += `*Link :*\n_${anime.link}_\n\n*===================================*\n\n`;
        });

        await lenwy.sendMessage(m.chat, {
            image: { url: animeList[0].image },
            caption: message
        }, { quoted: m });
        
    } catch (error) {
    lenwyreply(`⚠ *Terjadi Kesalahan: ${error.message}*`);
    console.error("Error:", error);
}
break

case 'moewall':
    if (!text) return lenwyreply("🔍 *Mau cari Wallpaper Apa?*");
    lenwyreply(`*One Moment, Please ☕*`);
    try {
        const result = await moewalls(text);
        if (result.total === 0) {
            return lenwyreply("⚠ *Tidak Ada Hasil Wallpaper*");
        }
        let message = `*Hasil Pencarian Wallpaper:*\n\n`;
        result.wallpapers.forEach((wallpaper, index) => {
            message += `*${index + 1}. ${wallpaper.title}*\n`;
            message += `*Link :*\n_${wallpaper.source}_\n`;
            message += `*Video Link :*\n_${wallpaper.video}_\n`;
            message += `*Thumbnail :*\n_${wallpaper.thumbnail}_\n`;
            message += `\n==============================\n\n`;
        });
        await lenwy.sendMessage(m.chat, {
            image: { url: result.wallpapers[0].thumbnail },
            caption: message
        }, { quoted: m });
    } catch (error) {
    lenwyreply(`⚠ *Terjadi Kesalahan: ${error.message}*`);
    console.error("Error:", error);
}
break

case 'gsm': {
  if (!q) return lenwyreply(`🔍 *Tolong Masukkan Nama Perangkat*`);
  lenwyreply('*Mencari Informasi Perangkat ☕*');
  try {
      const searchResults = await GSM(q);
      if (!searchResults || searchResults.length === 0) {
        return lenwyreply("*Perangkat Tidak Ditemukan Di Gsmarena*");
      }
      let resultMessage = `🔍 *Hasil Pencarian*\n\n`;
      searchResults.slice(0, 5).forEach((device, index) => {
          resultMessage += `*${index + 1}. ${device.name}*\n`;
          resultMessage += `*Deskripsi :* _${device.description}_\n`;
          resultMessage += `*Link :* _https://gsmarena.com/${device.id}.php_\n\n`;
          resultMessage += `==============================\n\n`;
      });
      await lenwyreply(resultMessage);
  } catch (error) {
      console.error("*Error :*", error.message);
      lenwyreply("*Terjadi Kesalahan Dalam Proses Permintaan.*");
  }
}
break

case 'westmanga':
    if (!text) return lenwyreply("🔍 *Mau Cari Mange Apa?*");
    lenwyreply(`*One Moment, Please ☕*`);
    try {
        const results = await wManga.searchManga(text);
        if (results.length === 0) {
            return lenwyreply("⚠ *Tidak Ada Hasil Manga*");
        }

        let message = `*Hasil Pencarian Manga:*\n\n`;
        results.forEach((manga, index) => {
            message += `*${index + 1}. ${manga.title}*\n`;
            message += `*Chapter:* _${manga.chapter}_\n`;
            message += `*Link Manga :* _${manga.mangaUrl}_\n`;
            message += `\n==============================\n\n`;
        });

        await lenwy.sendMessage(m.chat, {
            image: { url: results[0].imgUrl },
            caption: message
        }, { quoted: m });

    } catch (error) {
    lenwyreply(`⚠ *Terjadi Kesalahan: ${error.message}*`);
    console.error("Error:", error);
}
break

case 'webtoons': {
  const query = args.join(" ");
  if (!query) return lenwyreply("🔍 *Mau Cari Webtoon Apa?*");

  try {
    lenwyreply("🔍 *Dalam Pencarian*");
    const hasil = await Webtoons(query);

    if (hasil.length === 0) {
      lenwyreply("*Webtoon Tidak Ditemukan*");
    } else {
      let result = `🔍 *Hasil Pencarian Dari :* _${query}_\n\n`;
      const maxResults = Math.min(hasil.length, 5);

      for (let i = 0; i < maxResults; i++) {
        const webtoon = hasil[i];
        result += `*Judul :* _${webtoon.judul}_\n`;
        result += `*Creator :* _${webtoon.creator}_\n`;
        result += `*Genre :* _${webtoon.genre}_\n`;
        result += `*Like :* _${webtoon.like}_\n`;
        result += `*Link :* _${webtoon.url}_\n\n*=============================*\n\n`;
      }

      lenwyreply(result);
    }
  } catch (error) {
    console.error(error);
    lenwyreply("*Terjadi Kesalahan Saat Mengambil Data Dari Webtoons*");
  }
}
break

case 'upload': {
    if (!m.quoted) return lenwyreply('❌ Balas media yang ingin diupload!');

    let quoted = m.quoted;
    let mime = quoted.mtype || '';
    if (!mime.includes('image') && !mime.includes('video') && !mime.includes('audio') && !mime.includes('document')) {
        return lenwyreply('❌ Hanya bisa mengupload gambar, video, audio, atau dokumen!');
    }

    let media = await quoted.download();
    lenwyreply('⏱️ Sedang mengunggah file...');

    try {
        const { uploadFile } = require('./kiromi/kay/uploader.js');
        let link = await uploadFile(media);
        let caption = `📤 *File Berhasil Diupload!*\n\n🔗 *Link:* ${link}`;

        await lenwy.sendMessage(m.chat, { text: caption }, { quoted: m });
    } catch (error) {
        console.error('❌ Error Upload:', error);
        lenwyreply('❌ Terjadi kesalahan saat mengunggah file.');
    }
}
break

case 'steam': {
  const query = args.join(" ");
  if (!query) return lenwyreply("🔍 *Mau Cari Apa Di Steam?*");

  try {
    lenwyreply("🔍 *Dalam Pencarian*");
    const hasil = await Steam(query);

    if (!hasil || hasil.length === 0) {
      lenwyreply("*Game Tidak Ditemukan Di Steam!*");
    } else {
      const game = hasil[0];
      let gameInfo = '';
      gameInfo += `*Nama :* _${game.judul}_\n`;
      gameInfo += `*Rilis :* _${game.rilis.trim() || "Tanggal Rilis Tidak Tersedia"}_\n`;
      gameInfo += `*Harga :* _${game.harga !== "Harga Tidak Ditemukan" ? game.harga : "Gratis"}_\n\n`;
      gameInfo += `*Rating :*\n_${game.rating !== "Rating Tidak Ditemukan" ? game.rating : "Belum Ada Rating"}_\n\n`;
      gameInfo += `*Link :*\n_${game.link}_\n`;

      await lenwy.sendMessage(from, { 
        image: { url: game.img.replace('_sm_120', '_616x353') },
        caption: gameInfo 
      }, { quoted: len });
    }
  } catch (err) {
    console.error(err);
    lenwyreply("*Terjadi Kesalahan Saat Mengambil Data Dari Steam!*");
  }
}
break

case 'gt': {
  const query = args.join(" ");
  if (!query) return lenwyreply("🔍 *Mau Cari Karakter Apa di Guardian Tales?*");

  try {
    lenwyreply("🔍 *Sedang Mencari Karakter*");
    const character = await Guardian(query);

    if (!character) {
      lenwyreply("*Karakter Tidak Ditemukan Di Guardian Tales!*");
    } else {
      let characterInfo = '';
      characterInfo += `*Nama :* _${character.name}_\n`;
      characterInfo += `*Elemen :* _${character.school || "Tidak diketahui"}_\n`;
      characterInfo += `*Group Buff :* _${character.groupBuff || "Tidak tersedia"}_\n`;
      characterInfo += `*Diperkenalkan :* _${character.introduced || "Tidak tersedia"}_\n\n`;

      characterInfo += `*========================================*\n\n`;

      characterInfo += `*Kemampuan :*\n`;
      characterInfo += `*Normal Attack :* _${character.skills.normalAtk.description}_\n\n`;
      characterInfo += `*Chain Skill :* _${character.skills.chainSkill.description}_\n\n`;
      characterInfo += `*Special Ability :* _${character.skills.specialAbility.description}_\n\n`;
      characterInfo += `*Ex Weapon :* _${character.skills.exWeapon.description}_\n\n`;

      characterInfo += `*========================================*\n\n`;

      if (character.metaRankings.length > 0) {
        characterInfo += `*Peringkat Meta :*\n`;
        character.metaRankings.forEach((ranking) => {
          characterInfo += `*${ranking.rankTitle}*\n`;
          characterInfo += `_Rank : ${ranking.rankNumber} | Top ${ranking.percentageTop}_\n`;
          if (ranking.additionalInfo) characterInfo += `_${ranking.additionalInfo}_\n`;
          characterInfo += `\n`;
        });
      }

      await lenwy.sendMessage(from, {
        image: { url: character.imgSrc },
        caption: characterInfo
      }, { quoted: len });
    }
  } catch (err) {
    console.error(err);
    lenwyreply("*Terjadi Kesalahan Saat Mengambil Data Karakter dari Guardian Tales!*");
  }
}
break

case 'wikipedia': {
    if (!text) return lenwyreply('Masukkan teks pencarian!');
    const axios = require('axios');

    const url = `https://api.betabotz.eu.org/api/search/wikipedia?text=${encodeURIComponent(text)}&apikey=PXYo4sxf`;

    // Tambahkan reaksi emoji 🌎 ke pesan
    await lenwy.sendMessage(m.chat, { react: { text: '🌎', key: m.key }});

    try {
        // Ambil data dari API
        const { data } = await axios.get(url);

        if (data && data.status) {
            const result = data.result;

            // Format respons
            const response = `
*Wikipedia Search*
📖 *Title*: ${result.title}
🌐 *Isi*: ${result.isi}
🔗 *Thumbnail*: ${result.thumb ? 'Tersedia' : 'Tidak ada'}
            `;

            // Kirim pesan
            if (result.thumb) {
                // Kirim pesan dengan gambar jika thumbnail tersedia
                await lenwy.sendMessage(
                    m.chat,
                    { 
                        image: { url: result.thumb },
                        caption: response,
                    },
                    { quoted: m }
                );
            } else {
                // Kirim pesan teks jika thumbnail tidak tersedia
                lenwyreply(response);
            }
        } else {
            lenwyreply('Hasil pencarian tidak ditemukan.');
        }
    } catch (error) {
        console.log(error.response?.data || error.message); // Untuk debugging
        lenwyreply('Terjadi kesalahan saat mengakses API.');
    }
}
break 

case 'wikimedia': {
  if (!text) return lenwyreply(`🔍 *Mau Cari Gambar Apa di Wikimedia?*`);
  const isToxic = /(ewe|bangsad|mmk|koncol|kontol|k0ntl|k0ntol|kont0l|k0nt0l|kontoI|puki|kojtol|kintil|momok|nigga|ajg|ewean|yatim|anjing|kontol|memek|bangsat|babi|gblk|goblok|goblog|kntl|pepek|ppk|ngentod|ngentd|ngntd|kentod|kntd|bgst|anjg|anj|fuck|hitam|ireng|jawir|gay|asw|ktl|ngentot|ngewe|bokep|bkp|lonte|lont|bh|perawan|prawan|tolol|tlol|itil|tobrut|tobrud|tbrut|tbrud|Telanjang|telanjang|tljang|sexy|sex|Sexy)/i;
  const Lenwyguard = isToxic.exec(m.text);
  if (Lenwyguard) return lenwyreply('⚠ *Kayzu Melarang Penggunaan Bahasa Kotor Pada Fitur Wikimedia*');
  if (global.db.data.users[m.sender].limit < 5) return lenwyreply('*Limit Kamu Habis, Silahkan Hubunggi Kay/Tunggu besok*');
  lenwyreply('*5 Limit Digunakan*');
  try {
    const images = await WikiMedia(text);
    if (!images || images.length === 0) {
      return lenwyreply("*Tidak ditemukan gambar dengan pencarian tersebut di Wikimedia.*");
    }
    function shuffleArray(array) {
      for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
      }
    }
    shuffleArray(images);
    const selectedImages = images.slice(0, 5);
    let push = [];
    let i = 1;
    async function createImage(url) {
      const { imageMessage } = await generateWAMessageContent({
        image: { url }
      }, { upload: lenwy.waUploadToServer });
      return imageMessage;
    }
    for (let img of selectedImages) {
      push.push({
        body: proto.Message.InteractiveMessage.Body.fromObject({
          text: `*Pencarian : ${text}*`
        }),
        header: proto.Message.InteractiveMessage.Header.fromObject({
          title: `*Gambar ${i++}*`,
          hasMediaAttachment: true,
          imageMessage: await createImage(img.image)
        }),
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
          buttons: [
            {
              "name": "cta_url",
              "buttonParamsJson": `{"display_text":"Wikimedia","url":"${img.source}","merchant_url":"${img.source}"}`
            }
          ]
        })
      });
    }
    const bot = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2
          },
          interactiveMessage: proto.Message.InteractiveMessage.fromObject({
            body: proto.Message.InteractiveMessage.Body.create({
              text: `*Berhasil Memuat 5 Gambar*`
            }),
            header: proto.Message.InteractiveMessage.Header.create({
              hasMediaAttachment: false
            }),
            carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
              cards: [...push]
            })
          })
        }
      }
    }, {});

    await lenwy.relayMessage(m.chat, bot.message, {
      messageId: bot.key.id
    }).catch((err) => lenwyreply(mess.error));

    if (!isPrem) return db.data.users[m.sender].limit -= 5;
  } catch (error) {
    console.error("Error:", error.message);
    lenwyreply("*Terjadi kesalahan saat mengambil gambar dari Wikimedia.*");
  }
}
break

case 'ffw': {
  try {
      const hasil = await FFW();

      if (typeof hasil === 'string' && hasil.startsWith('Error')) {
          lenwyreply(hasil);
      } else if (hasil.length === 0) {
          lenwyreply('*Tidak ada informasi senjata yang ditemukan!*');
      } else {
          let result = `*Daftar Senjata Free Fire*\n\n`;
          hasil.forEach((item, index) => {
              result += `*Nama Senjata :* _${item.name}_\n`;
              result += `*Damage :* _${item.damage}_\n`; 
              result += `*Kategori :* _${item.tags.join(', ')}_\n\n`;
              result += `*Deskripsi :* _${item.description}_\n\n========================\n\n`;
          });
          lenwyreply(result);
      }
  } catch (error) {
      console.error(error);
      lenwyreply('*Terjadi kesalahan saat mengambil data senjata!*');
  }
}
break

case 'searchmusic': {
    // Mengambil query dari input pengguna, pastikan input ada setelah command
    const query = m.text.split(' ').slice(1).join(' '); // Mengambil teks setelah command

    if (!query) {
        lenwyreply("Mohon masukkan nama lagu yang ingin dicari.");
        return;
    }

    const apiUrl = `https://api.siputzx.my.id/api/s/applemusic?query=${query}&region=id`;

    try {
        lenwyreply("Memproses, mohon tunggu...");

        // Mengambil data dari API
        const res = await axios.get(apiUrl);

        // Memastikan API memberikan data yang valid
        if (res.data.status && res.data.data.result && res.data.data.result.length > 0) {
            const musicResults = res.data.data.result;

            // Kirim hasil pencarian musik
            for (let music of musicResults) {
                const { title, artist, link, image } = music;

                const message = `
🎵 *Judul*: ${title}
🎤 *Artis*: ${artist}
🔗 *Link*: ${link}
📸 *Gambar*: ${image}
                `;

                // Kirim pesan dengan informasi musik
                await lenwy.sendMessage(m.chat, { text: message }, { quoted: m });
            }
        } else {
            lenwyreply("Musik tidak ditemukan, coba lagi nanti.");
        }
    } catch (e) {
        console.error("Error:", e);
        lenwyreply("Terjadi kesalahan, coba lagi nanti.");
    }
}
break

case 'cekasalmember': {
    if (!m.isGroup) return lenwyreply(mess.group);

    try {
        const participants = await lenwy.groupMetadata(m.chat).then(metadata => metadata.participants);
        
        let countIndonesia = 0;
        let countMalaysia = 0;
        let countUSA = 0;
        let countOther = 0;

        participants.forEach(participant => {
            const phoneNumber = participant.id.split('@')[0];

            if (phoneNumber.startsWith("62")) {
                countIndonesia++;
            } else if (phoneNumber.startsWith("60")) {
                countMalaysia++;
            } else if (phoneNumber.startsWith("1") || phoneNumber.startsWith("+1")) {
                countUSA++;
            } else {
                countOther++;
            }
        });

        const replyMessage = `📊 *Jumlah Anggota Grup Berdasarkan Negara:*\n\n` +
            `🇮🇩 *Indonesia:* ${countIndonesia}\n` +
            `🇲🇾 *Malaysia:* ${countMalaysia}\n` +
            `🇺🇲 *USA:* ${countUSA}\n` +
            `🏳️ *Negara Lain:* ${countOther}`;

        lenwyreply(replyMessage);
    } catch (error) {
        console.error(error);
        lenwyreply("Terjadi kesalahan dalam mengambil data grup.");
    }
}
break

case 'cekkontol': {
    if (isBan) return lenwyreply('Lu di ban kocak awokwok') 

    // Menghapus pengecekan limit
    if (!text) return lenwyreply('Ketik Namanya Tolol!')

    // Mengirimkan reaction emoji ⏱️ saat proses
    await lenwy.sendMessage(m.chat, {
        react: {
            text: "⏱️",
            key: m.key,
        }
    });

    let result = `
╭━━━━°「 *Komtol ${text}* 」°
┃
┊• Nama : ${text}
┃• komtol : ${pickRandom(['ih item','Belang wkwk','Muluss','Putih Mulus','Black Doff','Pink wow','Item Glossy'])}
┊• ukuran : ${pickRandom(['5cm','10cm','7cm','9cm','15cm','100cm'])}
┃• jembut : ${pickRandom(['lebat','ada sedikit','gada jembut','tipis','muluss'])}
╰═┅═━––––––๑
    `;

    // Mengirimkan hasil
    try {
        await lenwy.sendMessage(m.chat, { text: result })

        // Mengirim reaction emoji ✅ saat selesai
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key,
            }
        });
    } catch (err) {
        lenwyreply("Error dalam mengirim pesan!")
    }
}
break

case "cekmemek": {
    if (!text) return lenwyreply("Siapa Yang Mau di Cek Memeknya?!");

    // Mengirimkan reaction emoji ⏱️ saat proses
    await lenwy.sendMessage(m.chat, {
        react: {
            text: "⏱️",
            key: m.key,
        }
    });

    const memek = pickRandom([
        "Putih mulus",
        "Hitam",
        "Pink",
        "Pink Mulus",
        "Hitam mulus",
    ]);
    const jembut = pickRandom([
        "Lebat",
        "Tipis",
        "Gada",
        "Jembut",
        "Bersih",
    ]);
    const lobang = pickRandom([
        "Perawan",
        "Ga Perawan",
        "Besar",
        "Sempit",
        "dobrak",
    ]);

    const respond = `
╭━━━━°「 *Memeknya ${text}* 」°
┊• Nama : ${text}
┃• Memek : ${memek}
┊• Jembut : ${jembut}
┃• Lobang : ${lobang}
╰═┅═━––––––๑
    `.trim();

    // Mengirimkan hasil
    try {
        await lenwy.sendMessage(m.chat, { text: respond });

        // Mengirim reaction emoji ✅ saat selesai
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key,
            }
        });
    } catch (err) {
        lenwyreply("Error dalam mengirim pesan!");
    }
}
break

case 'cekkhodam': {
    if (!text) return lenwyreply("Ketik nama lu anjg");

    // Mengirimkan reaction emoji ⏱️ saat proses
    await lenwy.sendMessage(m.chat, {
        react: {
            text: "⏱️",
            key: m.key,
        }
    });

    const khodam = pickRandom([
        "Kaleng Cat Avian",
        "Pipa Rucika",
        "Botol Tupperware",
        "Badut Mixue",
        "Sabun GIV",
        "Sandal Swallow",
        "Jarjit",
        "Ijat",
        "Fizi",
        "Mail",
        "Ehsan",
        "Upin",
        "Ipin",
        "sungut lele",
        "Tok Dalang",
        "Opah",
        "Opet",
        "Alul",
        "Pak Vinsen",
        "Maman Resing",
        "Pak RT",
        "Admin ETI",
        "Bung Towel",
        "Lumpia Basah",
        "Martabak Manis",
        "Baso Tahu",
        "Tahu Gejrot",
        "Dimsum",
        "Seblak Ceker",
        "Telor Gulung",
        "Tahu Aci",
        "Tempe Mendoan",
        "Nasi Kucing",
        "Kue Cubit",
        "Tahu Sumedang",
        "Nasi Uduk",
        "Wedang Ronde",
        "Kerupuk Udang",
        "Cilok",
        "Cilung",
        "Kue Sus",
        "Jasuke",
        "Seblak Makaroni",
        "Sate Padang",
        "Sayur Asem",
        "Kromboloni",
        "Marmut Pink",
        "Belalang Mullet",
        "Kucing Oren",
        "Lintah Terbang",
        "Singa Paddle Pop",
        "Macan Cisewu",
        "Vario Mber",
        "Beat Mber",
        "Supra Geter",
        "Oli Samping",
        "Knalpot Racing",
        "Jus Stroberi",
        "Jus Alpukat",
        "Alpukat Kocok",
        "Es Kopyor",
        "Es Jeruk",
        "Cappucino Cincau",
        "Jasjus Melon",
        "Teajus Apel",
        "Pop ice Mangga",
        "Teajus Gulabatu",
        "Air Selokan",
        "Air Kobokan",
        "TV Tabung",
        "Keran Air",
        "Tutup Panci",
        "Kotak Amal",
        "Tutup Termos",
        "Tutup Botol",
        "Kresek Item",
        "Kepala Casan",
        "Ban Serep",
        "Kursi Lipat",
        "Kursi Goyang",
        "Kulit Pisang",
        "Warung Madura",
        "Gorong-gorong",
    ]);

    const response = `
╭━━━━°「 *Cekkodam* 」°
┃
┊• *Nama :* ${text}
┃• *Khodam :* ${khodam}
╰═┅═━––––––๑
    `.trim();

    // Mengirimkan hasil
    try {
        await lenwy.sendMessage(m.chat, { text: response });

        // Mengirim reaction emoji ✅ saat selesai
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key,
            }
        });
    } catch (err) {
        lenwyreply("Error dalam mengirim pesan!");
    }
}
break

case 'wangy': {
    if (!m.isGroup) return lenwyreply("Hanya dapat digunakan di grup.");
    if (!q) return lenwyreply(`Contoh : ${prefix}wangy kayMD`);
  
    // Mengirimkan reaction emoji ⏱️ saat proses
    await lenwy.sendMessage(m.chat, {
        react: {
            text: "⏱️",
            key: m.key,
        }
    });

    let qq = q.toUpperCase();
    let awikwok = `${qq} ${qq} ${qq} ❤️ ❤️ ❤️ WANGY WANGY WANGY WANGY HU HA HU HA HU HA, aaaah baunya rambut ${qq} wangyy aku mau nyiumin aroma wangynya ${qq} AAAAAAAAH ~ Rambutnya.... aaah rambutnya juga pengen aku elus-elus ~~ AAAAAH ${qq} keluar pertama kali di anime juga manis ❤️ ❤️ ❤️ banget AAAAAAAAH ${qq} AAAAA LUCCUUUUUUUUUUUUUUU............ ${qq} AAAAAAAAAAAAAAAAAAAAGH ❤️ ❤️ ❤️apa ? ${qq} itu gak nyata ? Cuma HALU katamu ? nggak, ngak ngak ngak ngak NGAAAAAAAAK GUA GAK PERCAYA ITU DIA NYATA NGAAAAAAAAAAAAAAAAAK PEDULI BANGSAAAAAT !! GUA GAK PEDULI SAMA KENYATAAN POKOKNYA GAK PEDULI. ❤️ ❤️ ❤️ ${qq} gw ... ${qq} di laptop ngeliatin gw, ${qq} .. kamu percaya sama aku ? aaaaaaaaaaah syukur ${q} aku gak mau merelakan ${qq} aaaaaah ❤️ ❤️ ❤️ YEAAAAAAAAAAAH GUA MASIH PUNYA ${qq} SENDIRI PUN NGGAK SAMA AAAAAAAAAAAAAAH`;

    try {
        await lenwy.sendMessage(m.chat, { text: awikwok });

        // Mengirim reaction emoji ✅ saat selesai
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key,
            }
        });
    } catch (err) {
        lenwyreply("Error dalam mengirim pesan!");
    }
}
break

case 'emojimix': { 
    if (isBan) return lenwyreply('Lu di ban kay wkwk');
    
    // Fungsi loading untuk memberi tanda proses sedang berlangsung
    async function loading() {
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "⏱️",
                key: m.key,
            }
        });
    }

    await loading();

    let [emoji1, emoji2] = text.split`+`;
    if (!emoji1) throw `Contoh: ${prefix + command} 😅+🤔`;
    if (!emoji2) throw `Contoh: ${prefix + command} 😅+🤔`;

    let anu = await fetchJson(`https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(emoji1)}_${encodeURIComponent(emoji2)}`);

    for (let res of anu.results) {
        let encmedia = await lenwy.sendImageAsSticker(from, res.url, m, { packname: global.packname, author: global.author, categories: res.tags });
        await fs.unlinkSync(encmedia);
    }

    // Mengirim reaction emoji saat selesai
    await lenwy.sendMessage(m.chat, {
        react: {
            text: "✅",
            key: m.key,
        }
    });
}
break

case 'toqr': case 'qr': {
    if (!text) return m.reply(`Ubah Text ke Qr dengan *${prefix + command}* textnya`)
    m.reply(mess.wait)
    await lenwy.sendMessage(m.chat, { image: { url: 'https://api.qrserver.com/v1/create-qr-code/?size=1000x1000&data=' + text }, caption: 'Nih Bro' }, { quoted: m })
}
break

case 'wanumber': case 'searchno': case 'searchnumber': {
    if (!text) return m.reply(`Provide Number with last number x\n\nExample: ${prefix + command} 91690913721x`)

    var inputnumber = text.split(" ")[0]
    m.reply(`Searching for WhatsApp account in given range...`)

    function countInstances(string, word) {
        return string.split(word).length - 1
    }

    var number0 = inputnumber.split('x')[0]
    var number1 = inputnumber.split('x')[countInstances(inputnumber, 'x')] ? inputnumber.split('x')[countInstances(inputnumber, 'x')] : ''
    var random_length = countInstances(inputnumber, 'x')
    var randomxx
    if (random_length == 1) {
        randomxx = 10
    } else if (random_length == 2) {
        randomxx = 100
    } else if (random_length == 3) {
        randomxx = 1000
    }
    var text66 = `*==[ List of Whatsapp Numbers ]==*\n\n`
    var nobio = `\n*Bio:* || \nHey there! I am using WhatsApp.\n`
    var nowhatsapp = `\n*Numbers with no WhatsApp account within provided range.*\n`

    for (let i = 0; i < randomxx; i++) {
        var nu = ['1', '2', '3', '4', '5', '6', '7', '8', '9']
        var status1 = nu[Math.floor(Math.random() * nu.length)]
        var status2 = nu[Math.floor(Math.random() * nu.length)]
        var status3 = nu[Math.floor(Math.random() * nu.length)]
        var dom4 = nu[Math.floor(Math.random() * nu.length)]
        var random21

        if (random_length == 1) {
            random21 = `${status1}`
        } else if (random_length == 2) {
            random21 = `${status1}${status2}`
        } else if (random_length == 3) {
            random21 = `${status1}${status2}${status3}`
        } else if (random_length == 4) {
            random21 = `${status1}${status2}${status3}${dom4}`
        }

        var anu = await lenwy.onWhatsApp(`${number0}${i}${number1}@s.whatsapp.net`)
        var anuu = anu.length !== 0 ? anu : false
        try {
            try {
                var anu1 = await lenwy.fetchStatus(anu[0].jid)
            } catch {
                var anu1 = '401'
            }

            if (anu1 == '401' || anu1.status.length == 0) {
                nobio += `wa.me/${anu[0].jid.split("@")[0]}\n`
            } else {
                text66 += `🪀 *Number:* wa.me/${anu[0].jid.split("@")[0]}\n 🎗️*Bio :* ${anu1.status}\n🧐*Last update :* ${moment(anu1.setAt).tz('Asia/Kolkata').format('HH:mm:ss DD/MM/YYYY')}\n\n`
            }
        } catch {
            nowhatsapp += `${number0}${i}${number1}\n`
        }
    }
    m.reply(`${text66}${nobio}${nowhatsapp}`)
}
break

case 'tagsw': {
    if (!isCreator) return lenwyreply('Khusus Creator');
    if (!text) return lenwyreply(`Example: ${prefix + command} Hello Or Reply Video/Image With Caption: ${prefix + command}`);

    let mediaContent = null;
    let msgOptions = {};
    const BackgroundColor = ['#f68ac9', '#6cace4', '#f44336', '#4caf50', '#ffeb3b', '#9c27b0', '#0d47a1', '#03a9f4', '#9e9e9e', '#ff9800', '#000000', '#ffffff', '#008080', '#FFC0CB', '#A52A2A', '#FFA07A', '#FF00FF', '#D2B48C', '#F5DEB3', '#FF1493', '#B22222', '#00BFFF', '#1E90FF', '#FF69B4', '#87CEEB', '#20B2AA', '#8B0000', '#FF4500', '#48D1CC', '#BA55D3', '#00FF7F', '#008000', '#191970', '#FF8C00', '#9400D3', '#FF00FF', '#8B008B', '#2F4F4F', '#FFDAB9', '#BDB76B', '#DC143C', '#DAA520', '#696969', '#483D8B', '#FFD700', '#C0C0C0'];
    const pickedColor = BackgroundColor[Math.floor(Math.random() * BackgroundColor.length)];
    const jids = [m.sender, m.chat];

    if (quoted) {
        const mime = quoted.mtype || quoted.mediaType;
        if (mime?.includes('image')) {
            mediaContent = await lenwy.downloadAndSaveMediaMessage(quoted);
            msgOptions = {
                image: mediaContent,
                caption: text || quoted.text || '',
            };
        } else if (mime?.includes('video')) {
            mediaContent = await lenwy.downloadAndSaveMediaMessage(quoted);
            msgOptions = {
                video: mediaContent,
                caption: text || quoted.text || '',
            };
        } else {
            msgOptions = {
                text: text || quoted.text || '',
            };
        }
    } else {
        msgOptions = {
            text: text,
        };
    }

    try {
        const groupMetadata = await lenwy.groupMetadata(m.chat);
        const participants = groupMetadata.participants.map(a => a.id);

        return lenwy.sendMessage("status@broadcast", msgOptions, {
            backgroundColor: pickedColor,
            textArgb: 0xffffffff,
            font: 0,
            statusJidList: participants,
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: {},
                    content: [
                        {
                            tag: "mentioned_users",
                            attrs: {},
                            content: jids.map(jid => ({
                                tag: "to",
                                attrs: { jid: m.chat },
                                content: undefined,
                            })),
                        },
                    ],
                },
            ],
        });
    } catch (err) {
        console.log(err);
        return lenwyreply("Gagal mengirim pesan.");
    }
}
break

case 'friend':
case 'searchfriend': {
    lenwy.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key } });
    let teman = pickRandom(dansyaverifikasiuser);

    setTimeout(() => {
    }, 1000);

    setTimeout(() => {
        lenwyreply('Berhasil Mendapatkan Satu Orang');
    }, 5000);

    setTimeout(() => {
        lenwy.sendMessage(from, { text: `Di Sini @${teman.split("@")[0]}`, mentions: [teman] }, { quoted: m });
    }, 9000);
}
break

case 'assalamualaikum': 
case 'assalamualaikum wr. wb.': 
case 'assalamualaikum wr wb': {
    let caption = `*Waalaikummussalam warahmatullahi wabarokatuh*


_📚 Baca yang dibawah ya!_
"Orang yang mengucapkan salam seperti ini maka ia mendapatkan 30 pahala, kemudian, orang yang dihadapan atau mendengarnya membalas dengan kalimat yang sama yaitu “Wa'alaikum salam warahmatullahi wabarakatuh” atau ditambah dengan yang lain (waridhwaana). Artinya selain daripada do'a selamat juga meminta pada Allah SWT"`;

    lenwyreply(`${caption}`);
}
break

case 'couple': {
lenwyreply(mess.wait)
let anu = await fetchJson('https://raw.githubusercontent.com/iamriz7/kopel_/main/kopel.json')
let random = anu[Math.floor(Math.random() * anu.length)]
lenwy.sendMessage(from, { image: { url: random.male }, caption: `*Couple Male*` }, {quoted:m})
lenwy.sendMessage(from, { image: { url: random.female }, caption: `*Couple Female*` }, {quoted:m})
}
break

case 'getname': {
if (qtod === "true") {
namenye = await lenwy.getName(m.quoted.sender)
lenwyreply(namenye)
} else if (qtod === "false") {
lenwy.sendMessage(from, {text:"✉️ *Reply Orangnya*"}, {quoted:m})
}
}
break

case 'getpic': {
if (!isPrem) return lenwyreply(mess.prem)
if (qtod === "true") {
try {
pporg = await lenwy.profilePictureUrl(m.quoted.sender, 'image')
} catch {
pporg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
}
lenwy.sendMessage(from, { image : { url : pporg }, caption:`*Selesai*` }, {quoted:m})
} else if (qtod === "false") {
try {
pporgs = await lenwy.profilePictureUrl(from, 'image')
} catch {
pporgs = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
}
lenwy.sendMessage(from, { image : { url : pporgs }, caption:`*Selesai*` }, {quoted:m})
}
}
break

case 'block': {
if (!isCreator) return lenwyreply(mess.owner)
LenwyLD()
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await lenwy.updateBlockStatus(users, 'block').then((res) => lenwyreply(jsonformat(res))).catch((err) => lenwyreply(jsonformat(err)))
}
break

case 'unblock': {
if (!isCreator) return lenwyreply(mess.owner)
LenwyLD()
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await lenwy.updateBlockStatus(users, 'unblock').then((res) => lenwyreply(jsonformat(res))).catch((err) => lenwyreply(jsonformat(err)))
}
break

case 'cwr': {
if (!text) return lenwyreply('*Format : Cwr [Total Match] [Winrate Saat Ini] [Target Winrate]*\n\n*Contoh : Cwr 1200 67% 89%*')
var cwl = text.split(' ')
if (!cwl || cwl.length !== 3) return lenwyreply('*Format : Cwr [Total Match] [Winrate Saat Ini] [Target Winrate]*\n\n*Contoh : Cwr 1200 67% 89%*')          
const tMatch = parseFloat(cwl[0])
const tWr = parseFloat(cwl[1])
const wrReq = parseFloat(cwl[2])          
if (isNaN(tMatch) || isNaN(tWr) || isNaN(wrReq)) {
return lenwyreply('*Pastikan Semuanya Berupa Angka*');
}          
const resultNum = cwr(tMatch, tWr, wrReq);
const tekl = `*Winrate Calc Mobile Legend*

*⨠ Data Yang Diberikan*
 *⨠ Total Petandingan : ${tMatch}*
 *⨠ Winrate Saat Ini : ${tWr}%*
 *⨠ Target Winrate : ${wrReq}%*

*Hasil :*
*Butuh ${resultNum} Pertandingan Tanpa Kalah Untuk Mencapai ${wrReq}% Winrate*`;
lenwyreply(tekl);
}
break

case 'getdb': {
if (!isCreator) return lenwyreply(mess.owner)
lenwyreply('*Mengambil Seluruh Database')
let sesi = await fs.readFileSync('./src/database.json')
lenwy.sendMessage(m.chat, { document: sesi, mimetype: 'application/json', fileName: 'database.json' }, { quoted: len })
}
break

//================================================================================
case 'listcase': {
   const listCase = () => {
      const code = fs.readFileSync("./message.js", "utf8");
      var regex = /case\s+'([^']+)':/g;
      var matches = [];
      var match;
      while ((match = regex.exec(code))) {
         matches.push(match[1]);
      }

      if (matches.length === 0) return "Tidak ada case yang aktif.";

      let teks = `╭─── 〔 *List Case Aktif* 〕───╮\n`;
      teks += `├ 📌 Total Case: *${matches.length}*\n`;
      teks += `├──────────────\n`;

      matches.forEach((x, i) => {
         teks += `│ ${i + 1}. ${x}\n`;
      });

      teks += `╰──────────────\n`;
      return teks;
   };

   lenwyreply(listCase());
}
break
//================================================================================
case 'addcase': {
    if (!isCreator) return lenwyreply(mess.owner);
    if (!text) return lenwyreply("*🌸 Case-nya mana? Tuliskan case yang ingin ditambahkan.*");

    const fs = require('fs');
    const namaFile = './lenwy.js';
    const caseBaru = `${text.trim()}\n`;
    const posisiReferensi = "switch (command) {";

    try {
        let data = fs.readFileSync(namaFile, 'utf8');
        const caseNameMatch = text.match(/case\s+['"]([^'"]+)['"]:/);
        if (!caseNameMatch) return lenwyreply("❌ *Case tidak valid! Pastikan formatnya benar.*");

        const caseName = caseNameMatch[1];
        if (data.includes(`case '${caseName}':`) || data.includes(`case "${caseName}":`)) {
            return lenwyreply(`❌ *Case '${caseName}' sudah ada! Tidak bisa ditambahkan ulang.*`);
        }

        const posisiAwal = data.indexOf(posisiReferensi);
        if (posisiAwal !== -1) {
            const posisiInsert = data.indexOf("\n", posisiAwal) + 1;
            const kodeBaruLengkap = data.slice(0, posisiInsert) + '    ' + caseBaru + data.slice(posisiInsert);
            fs.writeFileSync(namaFile, kodeBaruLengkap, 'utf8');

            lenwyreply(`🌟 *Case Baru Ditambahkan!* 🌟\n\n🎉 *Selamat! Case '${caseName}' berhasil ditambahkan!*\n\n🛠️ *Case kini telah terintegrasi ke dalam sistem. Pastikan untuk mengujinya segera!*`);
        } else {
            lenwyreply("❌ *Struktur tidak ditemukan. Pastikan format file benar.*");
        }
    } catch (error) {
        console.error(error);
        lenwyreply("❌ *Gagal menambahkan case. Periksa kembali file lenwy.js atau format kode case.*");
    }
}
break;
//================================================================================
case 'delcase': {
    if (!isCreator) return lenwyreply(mess.owner);
    if (!text) return lenwyreply("*🌸 Case mana yang ingin dihapus? Tuliskan nama case yang ingin dihapus.*");

    const fs = require('fs');
    const namaFile = './lenwy.js';
    const caseName = text.trim();

    try {
        let data = fs.readFileSync(namaFile, 'utf8');
        const regex = new RegExp(`case\\s+['"]${caseName}['"](:|:\\s*case\\s+['"].*['"])+\\s*{[\\s\\S]*?break;`, 'g');

        if (!regex.test(data)) {
            return lenwyreply(`❌ *Case '${caseName}' tidak ditemukan! Pastikan case sudah ada di file.*`);
        }

        const updatedData = data.replace(regex, '').trim();
        fs.writeFileSync(namaFile, updatedData, 'utf8');

        lenwyreply(`🍃 *Semua case terkait '${caseName}' berhasil dihapus dari sistem!*\n\n🔥 *Pastikan untuk merefresh bot jika diperlukan.*`);
    } catch (error) {
        console.error(error);
        lenwyreply("❌ *Gagal menghapus case. Periksa kembali file lenwy.js atau format case.*");
    }
}
break;
//================================================================================
case 'getcase': {
    if (!isCreator) return lenwyreply(mess.owner);
    if (!text) return lenwyreply("*🌸 Case mana yang ingin diambil? Tuliskan nama case yang ingin dihapus.*");

    const fs = require('fs');
    const namaFile = './lenwy.js';
    const caseDicari = text.trim();

    try {
        let data = fs.readFileSync(namaFile, 'utf8');
        const regex = new RegExp(`case\\s+["']${caseDicari}["']:([\\s\\S]*?)break;`, 'g');
        let match = regex.exec(data);

        if (!match) return lenwyreply(`❌ *Case '${caseDicari}' tidak ditemukan!*`);

        let caseCode = match[0];
        if (caseCode.length > 50000) {
            return lenwyreply("⚠️ *Kode terlalu panjang untuk ditampilkan di WhatsApp!*");
        }

        lenwyreply(`📝 *Kode Case '${caseDicari}':*\n\`\`\`${caseCode}\`\`\``);
    } catch (error) {
        console.error(error);
        lenwyreply("❌ *Gagal membaca file lenwy.js. Pastikan file tersebut ada dan dapat diakses!*");
    }
}
break;
//================================================================================


case 'backup': {
    if (!isCreator) return lenwyreply(mess.owner);
    
    await lenwy.sendMessage(m.chat, {
        react: {
            text: "⏱️",
            key: m.key,
        }
    });

    const { execSync } = require("child_process");
    const fs = require("fs");

    try {
        // Daftar file & folder yang akan dibackup, kecuali yang tidak diperlukan
        const ls = execSync("ls")
            .toString()
            .split("\n")
            .filter((pe) =>
                pe !== "node_modules" &&
                pe !== "lenwy" &&
                pe !== "package-lock.json" &&
                pe !== "yarn.lock" &&
                pe !== ""
            );

        // Membuat file zip
        execSync(`zip -r ZenithMD.zip ${ls.join(" ")}`);

        // Mengirim file zip ke chat
        await lenwy.sendMessage(m.chat, {
            document: fs.readFileSync("./ZenithMD.zip"),
            mimetype: "application/zip",
            fileName: "ZenithMD.zip",
        }, { quoted: m });

        // Hapus file zip setelah dikirim
        execSync("rm -rf ZenithMD.zip");

        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key,
            }
        });
    } catch (e) {
        console.error(e);
        lenwyreply('Terjadi kesalahan saat melakukan backup.');
    }
}
break

case 'getuser': {
if (!isCreator) return lenwyreply(mess.owner)
lenwyreply('*Mengambil User Database')
let sesi = await fs.readFileSync('./database/user.json')
lenwy.sendMessage(m.chat, { document: sesi, mimetype: 'application/json', fileName: 'user.json' }, { quoted: len })
}
break

case 'tebakkarakterff': {
    lenwyreply('*Sedang Memuat Soal, Tunggu Sebentar ☕*');

    try {
        const axios = require('axios');

        // URL API Tebak Karakter Free Fire
        const apiURL = `https://api.siputzx.my.id/api/games/karakter-freefire`;
        const { data } = await axios.get(apiURL);

        // Validasi jika API memberikan data yang valid
        if (data && data.status && data.data) {
            const { name, gambar } = data.data;

            // Kirim gambar kepada pengguna
            await lenwy.sendMessage(m.chat, {
                image: { url: gambar },
                caption: `*🎮 Tebak Karakter Free Fire!*\n\n` +
                         `Lihat gambar karakter berikut dan ketikkan nama karakter yang sesuai!\n\n` +
                         `Cara Menjawab: *jawab_tebakkarakterff <nama karakter>*`,
            }, { quoted: m });

            // Simpan jawaban yang benar untuk verifikasi
            global.tebakKarakterFF = global.tebakKarakterFF || {};
            global.tebakKarakterFF[m.chat] = name.toLowerCase();

            // Timer 15 detik untuk menampilkan jawaban
            setTimeout(() => {
                if (global.tebakKarakterFF[m.chat]) {
                    lenwy.sendMessage(m.chat, {
                        text: `*⏰ Waktu Habis!*\nJawaban yang benar adalah: *${name}*`,
                    });
                    delete global.tebakKarakterFF[m.chat];
                }
            }, 15000); // 15 detik dalam milidetik
        } else {
            lenwyreply('*Gagal Memuat Data, Coba Lagi Nanti!*');
        }
    } catch (error) {
        console.error("⚠ *Error Saat Memuat Data :*", error.message);
        lenwyreply("*Terjadi Kesalahan Dalam Proses Permintaan.*");
    }
}
break

// Cek jawaban
case 'jawab_tebakkarakterff': {
    if (!global.tebakKarakterFF || !global.tebakKarakterFF[m.chat]) {
        return lenwyreply('*Tidak ada soal Tebak Karakter Free Fire aktif untuk ditebak.*');
    }

    const userAnswer = args.join(' ').toLowerCase();
    const correctAnswer = global.tebakKarakterFF[m.chat];

    if (userAnswer === correctAnswer) {
        lenwyreply(`*🎉 Selamat! Jawabanmu benar: ${correctAnswer.charAt(0).toUpperCase() + correctAnswer.slice(1)}!*`);
        delete global.tebakKarakterFF[m.chat];
    } else {
        lenwyreply('*❌ Jawabanmu salah, coba lagi!*');
    }
}
break

case 'nyerahff': {
    if (!global.tebakKarakterFF || !global.tebakKarakterFF[m.chat]) {
        return lenwyreply('*Tidak ada soal Tebak Karakter Free Fire yang aktif untuk menyerah.*');
    }

    const correctAnswer = global.tebakKarakterFF[m.chat];
    lenwyreply(`*Kamu menyerah!*\nJawaban yang benar adalah: *${correctAnswer.charAt(0).toUpperCase() + correctAnswer.slice(1)}*`);
    delete global.tebakKarakterFF[m.chat];
}
break

case 'tebakheroml': {
    lenwyreply('*Sedang Memuat Soal, Tunggu Sebentar ☕*');

    try {
        const axios = require('axios');

        // URL API Tebak Hero Mobile Legends
        const apiURL = `https://api.siputzx.my.id/api/games/tebakheroml`;
        const { data } = await axios.get(apiURL);

        // Validasi jika API memberikan data yang valid
        if (data && data.status && data.data) {
            const { name, audio } = data.data;

            // Kirim petunjuk + audio kepada pengguna
            await lenwy.sendMessage(m.chat, { 
                text: `*🎮 Tebak Hero Mobile Legends!*\n\n` +
                      `🎧 Dengarkan suara skill hero berikut dan ketikkan nama hero yang sesuai!\n\n` +
                      `*Cara Menjawab:* \n` +
                      `*jawab_tebakheroml <nama hero>*\n\n` +
                      `⏰ *Waktu Menjawab: 15 detik*`, 
            }, { quoted: m });

            await lenwy.sendMessage(m.chat, {
                audio: { url: audio },
                mimetype: 'audio/mpeg',
                ptt: true, // Mengirim sebagai voice note
            });

            // Simpan jawaban yang benar untuk verifikasi
            global.tebakHeroML = global.tebakHeroML || {};
            global.tebakHeroML[m.chat] = name.toLowerCase();

            // Timer 15 detik untuk menampilkan jawaban
            setTimeout(() => {
                if (global.tebakHeroML[m.chat]) {
                    lenwy.sendMessage(m.chat, {
                        text: `*⏰ Waktu Habis!*\nJawaban yang benar adalah: *${name}*`,
                    });
                    delete global.tebakHeroML[m.chat];
                }
            }, 15000); // 15 detik dalam milidetik
        } else {
            lenwyreply('*Gagal Memuat Data, Coba Lagi Nanti!*');
        }
    } catch (error) {
        console.error("⚠ *Error Saat Memuat Data :*", error.message);
        lenwyreply("*Terjadi Kesalahan Dalam Proses Permintaan.*");
    }
}
break

// Cek jawaban
case 'jawab_tebakheroml': {
    if (!global.tebakHeroML || !global.tebakHeroML[m.chat]) {
        return lenwyreply('*Tidak ada soal Tebak Hero MLBB aktif untuk dijawab.*');
    }

    const userAnswer = args.join(' ').toLowerCase();
    const correctAnswer = global.tebakHeroML[m.chat];

    if (userAnswer === correctAnswer) {
        lenwyreply(`*🎉 Selamat! Jawabanmu benar: ${correctAnswer.charAt(0).toUpperCase() + correctAnswer.slice(1)}!*`);
        delete global.tebakHeroML[m.chat];
    } else {
        lenwyreply('*❌ Jawabanmu salah, coba lagi!*');
    }
}
break

case 'nyerahml': {
    if (!global.tebakHeroML || !global.tebakHeroML[m.chat]) {
        return lenwyreply('*Tidak ada soal aktif untuk menyerah.*');
    }

    const correctAnswer = global.tebakHeroML[m.chat];

    lenwyreply(`*Kamu menyerah! Jawaban yang benar adalah: ${correctAnswer.charAt(0).toUpperCase() + correctAnswer.slice(1)}*`);
    delete global.tebakHeroML[m.chat];
}
break

case 'siapakahaku': {
    lenwyreply('*Sedang Memuat Soal, Tunggu Sebentar ☕*');

    try {
        const axios = require('axios');

        // URL API Siapakah Aku
        const apiURL = `https://api.siputzx.my.id/api/games/siapakahaku`;
        const { data } = await axios.get(apiURL);

        // Validasi jika API memberikan data yang valid
        if (data && data.status && data.data) {
            const { soal, jawaban } = data.data;

            // Kirim soal kepada pengguna
            await lenwy.sendMessage(m.chat, {
                text: `*🧐 Tebak Siapakah Aku!*\n\n` +
                      `${soal}\n\n` +
                      `Cara Menjawab: *jawab_siapakahaku <jawaban>*`,
            }, { quoted: m });

            // Simpan jawaban yang benar untuk verifikasi
            global.siapakahaku = global.siapakahaku || {};
            global.siapakahaku[m.chat] = jawaban.toLowerCase();

            // Timer 30 detik untuk menampilkan jawaban
            setTimeout(() => {
                if (global.siapakahaku[m.chat]) {
                    lenwy.sendMessage(m.chat, {
                        text: `*⏰ Waktu Habis!*\nJawaban yang benar adalah: *${jawaban}*`,
                    });
                    delete global.siapakahaku[m.chat];
                }
            }, 30000); // 30 detik dalam milidetik
        } else {
            lenwyreply('*Gagal Memuat Data, Coba Lagi Nanti!*');
        }
    } catch (error) {
        console.error("⚠ *Error Saat Memuat Data :*", error.message);
        lenwyreply("*Terjadi Kesalahan Dalam Proses Permintaan.*");
    }
}
break

// Cek jawaban
case 'jawab_siapakahaku': {
    if (!global.siapakahaku || !global.siapakahaku[m.chat]) {
        return lenwyreply('*Tidak ada soal Siapakah Aku aktif untuk ditebak.*');
    }

    const userAnswer = args.join(' ').toLowerCase();
    const correctAnswer = global.siapakahaku[m.chat];

    if (userAnswer === correctAnswer) {
        lenwyreply(`*🎉 Selamat! Jawabanmu benar: ${correctAnswer.charAt(0).toUpperCase() + correctAnswer.slice(1)}!*`);
        delete global.siapakahaku[m.chat];
    } else {
        lenwyreply('*❌ Jawabanmu salah, coba lagi!*');
    }
}
break

case 'tebakwarna': {
    lenwyreply('*Sedang Memuat Soal, Harap Tunggu ☕*');

    try {
        const axios = require('axios');

        // URL API Tebak Warna
        const apiURL = `https://api.siputzx.my.id/api/games/tebakwarna`;
        const { data } = await axios.get(apiURL);

        // Validasi jika API memberikan data yang valid
        if (data && data.status && data.data) {
            const { plate, correct, image } = data.data;

            // Kirim gambar dan soal kepada pengguna
            await lenwy.sendMessage(m.chat, {
                image: { url: image },
                caption: `*🎨 Tebak Warna!*\n\n` +
                         `Berapa angka yang terlihat pada gambar ini?\n\n` +
                         `Jawab dengan format: *jawab_tebakwarna <angka>*\n\n` +
                         `Waktu menjawab: 30 detik ⏰`,
            }, { quoted: m });

            // Simpan jawaban yang benar untuk verifikasi
            global.tebakwarna = global.tebakwarna || {};
            global.tebakwarna[m.chat] = correct.toString();

            // Timer 30 detik untuk menampilkan jawaban
            setTimeout(() => {
                if (global.tebakwarna[m.chat]) {
                    lenwy.sendMessage(m.chat, {
                        text: `*⏰ Waktu Habis!*\nJawaban yang benar adalah: *${correct}*`,
                    });
                    delete global.tebakwarna[m.chat];
                }
            }, 30000); // 30 detik dalam milidetik
        } else {
            lenwyreply('*Gagal Memuat Data, Coba Lagi Nanti!*');
        }
    } catch (error) {
        console.error("⚠ *Error Saat Memuat Data :*", error.message);
        lenwyreply("*Terjadi Kesalahan Dalam Proses Permintaan.*");
    }
}
break

// Cek jawaban
case 'jawab_tebakwarna': {
    if (!global.tebakwarna || !global.tebakwarna[m.chat]) {
        return lenwyreply('*Tidak ada soal Tebak Warna aktif untuk ditebak.*');
    }

    const userAnswer = args.join(' ').toString();
    const correctAnswer = global.tebakwarna[m.chat];

    if (userAnswer === correctAnswer) {
        lenwyreply(`*🎉 Selamat! Jawabanmu benar: ${correctAnswer}!*`);
        delete global.tebakwarna[m.chat];
    } else {
        lenwyreply('*❌ Jawabanmu salah, coba lagi!*');
    }
}
break

case 'tebaklogo': {
    lenwyreply('*Sedang Memuat Soal, Harap Tunggu ☕*');

    try {
        const axios = require('axios');

        // URL API Tebak Logo
        const apiURL = `https://api.siputzx.my.id/api/games/tebaklogo`;
        const { data } = await axios.get(apiURL);

        // Validasi jika API memberikan data yang valid
        if (data && data.status && data.data && data.data.data) {
            const { image, jawaban } = data.data.data;

            // Kirim gambar dan soal kepada pengguna
            await lenwy.sendMessage(m.chat, {
                image: { url: image },
                caption: `*🎯 Tebak Logo!*\n\n` +
                         `Coba tebak nama logo yang ada pada gambar ini.\n\n` +
                         `Jawab dengan format: *jawab_tebaklogo <jawaban>*\n\n` +
                         `Waktu menjawab: 30 detik ⏰`,
            }, { quoted: m });

            // Simpan jawaban yang benar untuk verifikasi
            global.tebaklogo = global.tebaklogo || {};
            global.tebaklogo[m.chat] = jawaban.toLowerCase();

            // Timer 30 detik untuk menampilkan jawaban
            setTimeout(() => {
                if (global.tebaklogo[m.chat]) {
                    lenwy.sendMessage(m.chat, {
                        text: `*⏰ Waktu Habis!*\nJawaban yang benar adalah: *${jawaban}*`,
                    });
                    delete global.tebaklogo[m.chat];
                }
            }, 30000); // 30 detik dalam milidetik
        } else {
            lenwyreply('*Gagal Memuat Data, Coba Lagi Nanti!*');
        }
    } catch (error) {
        console.error("⚠ *Error Saat Memuat Data :*", error.message);
        lenwyreply("*Terjadi Kesalahan Dalam Proses Permintaan.*");
    }
}
break

// Cek jawaban
case 'jawab_tebaklogo': {
    if (!global.tebaklogo || !global.tebaklogo[m.chat]) {
        return lenwyreply('*Tidak ada soal Tebak Logo aktif untuk ditebak.*');
    }

    const userAnswer = args.join(' ').toLowerCase();
    const correctAnswer = global.tebaklogo[m.chat];

    if (userAnswer === correctAnswer) {
        lenwyreply(`*🎉 Selamat! Jawabanmu benar: ${correctAnswer.charAt(0).toUpperCase() + correctAnswer.slice(1)}!*`);
        delete global.tebaklogo[m.chat];
    } else {
        lenwyreply('*❌ Jawabanmu salah, coba lagi!*');
    }
}
break

// Teka-Teki Kimia
case 'tebakkimia': {
    lenwyreply('*Sedang Memuat Teka-Teki Kimia, Mohon Tunggu ☕*');

    try {
        const axios = require('axios');

        // URL API Teka-Teki Kimia
        const apiURL = `https://api.siputzx.my.id/api/games/tebakkimia`;
        const { data } = await axios.get(apiURL);

        // Validasi jika API memberikan data yang valid
        if (data && data.status && data.data) {
            const { unsur, lambang } = data.data;

            // Kirim soal kepada pengguna
            await lenwy.sendMessage(m.chat, {
                text: `*🧪 Teka-Teki Kimia!*\n\n` +
                      `Apa lambang dari unsur kimia: *${unsur}*?\n\n` +
                      `Jawab dengan format: *jawab_tebakkimia <lambang>*\n` +
                      `Waktu menjawab: 30 detik ⏰`,
            }, { quoted: m });

            // Simpan jawaban yang benar untuk verifikasi
            global.tebakkimia = global.tebakkimia || {};
            global.tebakkimia[m.chat] = lambang.toLowerCase();

            // Timer 30 detik untuk menampilkan jawaban
            setTimeout(() => {
                if (global.tebakkimia[m.chat]) {
                    lenwy.sendMessage(m.chat, {
                        text: `*⏰ Waktu Habis!*\nJawaban yang benar adalah: *${lambang}*`,
                    });
                    delete global.tebakkimia[m.chat];
                }
            }, 30000); // 30 detik dalam milidetik
        } else {
            lenwyreply('*Gagal Memuat Data, Coba Lagi Nanti!*');
        }
    } catch (error) {
        console.error("⚠ *Error Saat Memuat Data :*", error.message);
        lenwyreply("*Terjadi Kesalahan Dalam Proses Permintaan.*");
    }
}
break

// Cek jawaban (untuk tebakkimia)
case 'jawab_tebakkimia': {
    if (!global.tebakkimia || !global.tebakkimia[m.chat]) {
        return lenwyreply('*Tidak ada teka-teki kimia aktif untuk dijawab.*');
    }

    const userAnswer = args.join(' ').toLowerCase();
    const correctAnswer = global.tebakkimia[m.chat];

    if (userAnswer === correctAnswer) {
        lenwyreply(`*🎉 Selamat! Jawabanmu benar: ${correctAnswer.toUpperCase()}!*`);
        delete global.tebakkimia[m.chat];
    } else {
        lenwyreply('*❌ Jawabanmu salah, coba lagi!*');
    }
}
break

case 'tekateki': {
    lenwyreply('*Sedang Memuat Teka-Teki, Mohon Tunggu ☕*');

    try {
        const axios = require('axios');

        // URL API Teka-Teki
        const apiURL = `https://api.siputzx.my.id/api/games/tekateki`;
        const { data } = await axios.get(apiURL);

        // Validasi jika API memberikan data yang valid
        if (data && data.status && data.data) {
            const { soal, jawaban } = data.data;

            // Kirim soal kepada pengguna
            await lenwy.sendMessage(m.chat, {
                text: `*🧩 Teka-Teki!*\n\n` +
                      `Soal: ${soal}\n\n` +
                      `Jawab dengan format: *jawab_tekateki <jawaban>*\n` +
                      `Waktu menjawab: 30 detik ⏰`,
            }, { quoted: m });

            // Simpan jawaban yang benar untuk verifikasi
            global.tekateki = global.tekateki || {};
            global.tekateki[m.chat] = jawaban.toLowerCase();

            // Timer 30 detik untuk menampilkan jawaban
            setTimeout(() => {
                if (global.tekateki[m.chat]) {
                    lenwy.sendMessage(m.chat, {
                        text: `*⏰ Waktu Habis!*\nJawaban yang benar adalah: *${jawaban}*`,
                    });
                    delete global.tekateki[m.chat];
                }
            }, 30000); // 30 detik dalam milidetik
        } else {
            lenwyreply('*Gagal Memuat Data, Coba Lagi Nanti!*');
        }
    } catch (error) {
        console.error("⚠ *Error Saat Memuat Data :*", error.message);
        lenwyreply("*Terjadi Kesalahan Dalam Proses Permintaan.*");
    }
}
break

// Cek jawaban
case 'jawab_tekateki': {
    if (!global.tekateki || !global.tekateki[m.chat]) {
        return lenwyreply('*Tidak ada teka-teki aktif untuk dijawab.*');
    }

    const userAnswer = args.join(' ').toLowerCase();
    const correctAnswer = global.tekateki[m.chat];

    if (userAnswer === correctAnswer) {
        lenwyreply(`*🎉 Selamat! Jawabanmu benar: ${correctAnswer.charAt(0).toUpperCase() + correctAnswer.slice(1)}!*`);
        delete global.tekateki[m.chat];
    } else {
        lenwyreply('*❌ Jawabanmu salah, coba lagi!*');
    }
}
break

// Teka-Teki (Tebak-Tebakan)
case 'tebaktebakan': {
    lenwyreply('*Sedang Memuat Teka-Teki, Mohon Tunggu ☕*');

    try {
        const axios = require('axios');

        // URL API Teka-Teki
        const apiURL = `https://api.siputzx.my.id/api/games/tebaktebakan`;
        const { data } = await axios.get(apiURL);

        // Validasi jika API memberikan data yang valid
        if (data && data.status && data.data) {
            const { soal, jawaban } = data.data;

            // Kirim soal kepada pengguna
            await lenwy.sendMessage(m.chat, {
                text: `*🧩 Teka-Teki!*\n\n` +
                      `Soal: ${soal}\n\n` +
                      `Jawab dengan format: *jawab_tebaktebakan <jawaban>*\n` +
                      `Waktu menjawab: 30 detik ⏰`,
            }, { quoted: m });

            // Simpan jawaban yang benar untuk verifikasi
            global.tebaktebakan = global.tebaktebakan || {};
            global.tebaktebakan[m.chat] = jawaban.toLowerCase();

            // Timer 30 detik untuk menampilkan jawaban
            setTimeout(() => {
                if (global.tebaktebakan[m.chat]) {
                    lenwy.sendMessage(m.chat, {
                        text: `*⏰ Waktu Habis!*\nJawaban yang benar adalah: *${jawaban}*`,
                    });
                    delete global.tebaktebakan[m.chat];
                }
            }, 30000); // 30 detik dalam milidetik
        } else {
            lenwyreply('*Gagal Memuat Data, Coba Lagi Nanti!*');
        }
    } catch (error) {
        console.error("⚠ *Error Saat Memuat Data :*", error.message);
        lenwyreply("*Terjadi Kesalahan Dalam Proses Permintaan.*");
    }
}
break

// Cek jawaban (untuk tebaktebakan)
case 'jawab_tebaktebakan': {
    if (!global.tebaktebakan || !global.tebaktebakan[m.chat]) {
        return lenwyreply('*Tidak ada teka-teki aktif untuk dijawab.*');
    }

    const userAnswer = args.join(' ').toLowerCase();
    const correctAnswer = global.tebaktebakan[m.chat];

    if (userAnswer === correctAnswer) {
        lenwyreply(`*🎉 Selamat! Jawabanmu benar: ${correctAnswer.charAt(0).toUpperCase() + correctAnswer.slice(1)}!*`);
        delete global.tebaktebakan[m.chat];
    } else {
        lenwyreply('*❌ Jawabanmu salah, coba lagi!*');
    }
}
break

case 'family100': {
    lenwyreply('*Sedang Memuat Soal Family 100, Mohon Tunggu ☕*');

    try {
        const axios = require('axios');

        // URL API Family 100
        const apiURL = `https://api.siputzx.my.id/api/games/family100`;
        const { data } = await axios.get(apiURL);

        // Validasi jika API memberikan data yang valid
        if (data && data.status && data.data) {
            const { soal, jawaban } = data.data;

            // Kirim soal kepada pengguna
            await lenwy.sendMessage(m.chat, {
                text: `*🎮 Family 100 Game!*\n\n` +
                      `Soal: ${soal}\n\n` +
                      `Jawab dengan format: *jawab_family100 <jawaban kamu>*\n` +
                      `Terdapat ${jawaban.length} jawaban yang harus ditemukan! 🔍\n` +
                      `Waktu menjawab: 30 detik ⏰`,
            }, { quoted: m });

            // Simpan data permainan dalam variabel global
            global.family100 = global.family100 || {};
            global.family100[m.chat] = {
                answers: jawaban.map(ans => ans.toLowerCase()),
                found: [],
            };

            // Timer 30 detik untuk mengakhiri permainan
            setTimeout(() => {
                if (global.family100[m.chat]) {
                    const { answers, found } = global.family100[m.chat];
                    const missed = answers.filter(ans => !found.includes(ans));
                    lenwy.sendMessage(m.chat, {
                        text: `*⏰ Waktu Habis!*\n` +
                              `Jawaban yang belum ditemukan: ${missed.length > 0 ? missed.join(', ') : 'Semua jawaban telah ditemukan!'}\n` +
                              `Terima kasih telah bermain!`,
                    });
                    delete global.family100[m.chat];
                }
            }, 30000); // 30 detik dalam milidetik
        } else {
            lenwyreply('*Gagal Memuat Data, Coba Lagi Nanti!*');
        }
    } catch (error) {
        console.error("⚠ *Error Saat Memuat Data :*", error.message);
        lenwyreply("*Terjadi Kesalahan Dalam Proses Permintaan.*");
    }
}
break

// Cek jawaban
case 'jawab_family100': {
    if (!global.family100 || !global.family100[m.chat]) {
        return lenwyreply('*Tidak ada permainan Family 100 yang sedang berlangsung.*');
    }

    const userAnswer = args.join(' ').toLowerCase();
    const gameData = global.family100[m.chat];

    if (gameData.answers.includes(userAnswer)) {
        if (gameData.found.includes(userAnswer)) {
            lenwyreply('*❗ Jawaban sudah ditemukan sebelumnya, coba yang lain!*');
        } else {
            gameData.found.push(userAnswer);
            lenwyreply(`*✅ Benar! Jawaban ditemukan: ${userAnswer.charAt(0).toUpperCase() + userAnswer.slice(1)}!*`);

            // Cek jika semua jawaban telah ditemukan
            if (gameData.found.length === gameData.answers.length) {
                lenwyreply(`*🎉 Selamat! Semua jawaban telah ditemukan!*\nJawaban: ${gameData.answers.join(', ')}`);
                delete global.family100[m.chat];
            }
        }
    } else {
        lenwyreply('*❌ Salah! Jawaban tidak ditemukan, coba lagi!*');
    }
}
break

case 'asahotak': {
    lenwyreply('*Sedang Memuat Soal Asah Otak, Mohon Tunggu ☕*');

    try {
        const axios = require('axios');

        // URL API Asah Otak
        const apiURL = `https://api.siputzx.my.id/api/games/asahotak`;
        const { data } = await axios.get(apiURL);

        // Validasi jika API memberikan data yang valid
        if (data && data.status && data.data) {
            const { soal, jawaban } = data.data;

            // Kirim soal kepada pengguna
            await lenwy.sendMessage(m.chat, {
                text: `*🧠 Asah Otak!*\n\n` +
                      `Soal: ${soal}\n\n` +
                      `Jawab dengan format: *jawab_asah <jawaban kamu>*\n` +
                      `Waktu menjawab: 30 detik ⏰`,
            }, { quoted: m });

            // Simpan data permainan dalam variabel global
            global.asahotak = global.asahotak || {};
            global.asahotak[m.chat] = {
                answer: jawaban.toLowerCase(),
            };

            // Timer 30 detik untuk mengakhiri permainan
            setTimeout(() => {
                if (global.asahotak[m.chat]) {
                    lenwy.sendMessage(m.chat, {
                        text: `*⏰ Waktu Habis!*\n` +
                              `Jawaban yang benar adalah: *${jawaban}*\n` +
                              `Terima kasih telah bermain!`,
                    });
                    delete global.asahotak[m.chat];
                }
            }, 30000); // 30 detik dalam milidetik
        } else {
            lenwyreply('*Gagal Memuat Data, Coba Lagi Nanti!*');
        }
    } catch (error) {
        console.error("⚠ *Error Saat Memuat Data :*", error.message);
        lenwyreply("*Terjadi Kesalahan Dalam Proses Permintaan.*");
    }
}
break

// Cek jawaban
case 'jawab_asah': {
    if (!global.asahotak || !global.asahotak[m.chat]) {
        return lenwyreply('*Tidak ada permainan Asah Otak yang sedang berlangsung.*');
    }

    const userAnswer = args.join(' ').toLowerCase();
    const gameData = global.asahotak[m.chat];

    if (userAnswer === gameData.answer) {
        lenwyreply(`*✅ Benar! Jawaban kamu: ${userAnswer.charAt(0).toUpperCase() + userAnswer.slice(1)}!*`);
        delete global.asahotak[m.chat];
    } else {
        lenwyreply('*❌ Salah! Coba lagi!*');
    }
}
break

case 'tebakgambar': {
    lenwyreply('*Sedang Memuat Soal, Mohon Tunggu Sebentar...*');

    try {
        const axios = require('axios');
        const apiURL = `https://api.siputzx.my.id/api/games/tebakgambar`;

        // Ambil data dari API
        const { data } = await axios.get(apiURL);

        // Validasi jika data yang diterima benar
        if (data && data.status && data.data) {
            const { img, jawaban, deskripsi } = data.data;

            // Kirim gambar dan deskripsi kepada pengguna
            await lenwy.sendMessage(m.chat, {
                image: { url: img },
                caption: `*🎨 Tebak Gambar!*\n\n${deskripsi}\n\n` +
                         `Ketikkan jawabanmu dengan format: *jawab_tebakgambar <jawaban>*`
            }, { quoted: m });

            // Simpan jawaban yang benar untuk validasi
            global.tebakGambar = global.tebakGambar || {};
            global.tebakGambar[m.chat] = jawaban.toLowerCase();

            // Timer 30 detik untuk menjawab
            setTimeout(() => {
                if (global.tebakGambar[m.chat]) {
                    lenwy.sendMessage(m.chat, {
                        text: `*⏰ Waktu Habis!*\nJawaban yang benar adalah: *${jawaban}*`
                    });
                    delete global.tebakGambar[m.chat];
                }
            }, 30000); // 30 detik
        } else {
            lenwyreply('*Gagal Memuat Data, Coba Lagi Nanti!*');
        }
    } catch (error) {
        console.error("⚠ *Error Saat Memuat Data :*", error.message);
        lenwyreply("*Terjadi Kesalahan Dalam Proses Permintaan.*");
    }
}
break

// Cek jawaban
case 'jawab_tebakgambar': {
    if (!global.tebakGambar || !global.tebakGambar[m.chat]) {
        return lenwyreply('*Tidak ada soal Tebak Gambar aktif untuk dijawab.*');
    }

    const userAnswer = args.join(' ').toLowerCase();
    const correctAnswer = global.tebakGambar[m.chat];

    if (userAnswer === correctAnswer) {
        lenwyreply(`*🎉 Selamat! Jawabanmu benar: ${correctAnswer.charAt(0).toUpperCase() + correctAnswer.slice(1)}!*`);
        delete global.tebakGambar[m.chat];
    } else {
        lenwyreply('*❌ Jawabanmu salah, coba lagi!*');
    }
}
break

case 'tebakbendera': {
    lenwyreply('*Sedang Memuat, Tunggu Sebentar ☕*');

    try {
        const axios = require('axios');

        // URL API Tebak Bendera
        const apiURL = `https://api.tioo.eu.org/tebakbendera`;
        const { data } = await axios.get(apiURL);

        if (!data.status || !data.result) {
            return lenwyreply('*Gagal Memuat Data. Coba Lagi Nanti.*');
        }

        const { img, name } = data.result;

        // Kirim gambar bendera beserta instruksi tebak
        await lenwy.sendMessage(m.chat, {
            image: { url: img },
            caption: `*Tebak Bendera Ini!*\n\n` +
                     `Bendera negara apa ini? Coba tebak!\n` +
                     `Ketik jawabanmu dengan format: _tebak <jawaban>_\n\n` +
                     `_Kamu punya waktu 30 detik untuk menjawab!_`,
        }, { quoted: m });

        // Simpan jawaban yang benar untuk verifikasi
        global.tebakbendera = global.tebakbendera || {};
        global.tebakbendera[m.chat] = name.toLowerCase();

        // Timer 30 detik untuk menampilkan jawaban
        setTimeout(() => {
            if (global.tebakbendera[m.chat]) {
                lenwy.sendMessage(m.chat, {
                    text: `*Waktu Habis!*\nJawaban yang benar adalah: *${name}*`,
                });
                delete global.tebakbendera[m.chat];
            }
        }, 30000); // 30 detik dalam milidetik
    } catch (error) {
        console.error("⚠ *Error Saat Memuat Data :*", error.message);
        lenwyreply("*Terjadi Kesalahan Dalam Proses Permintaan.*");
    }
}
break

// Cek jawaban
case 'tebak': {
    if (!global.tebakbendera || !global.tebakbendera[m.chat]) {
        return lenwyreply('*Tidak ada pertanyaan aktif untuk ditebak.*');
    }

    const userAnswer = args.join(' ').toLowerCase();
    const correctAnswer = global.tebakbendera[m.chat];

    if (userAnswer === correctAnswer) {
        lenwyreply(`*Selamat! Jawabanmu benar: ${correctAnswer.charAt(0).toUpperCase() + correctAnswer.slice(1)} 🎉*`);
        delete global.tebakbendera[m.chat];
    } else {
        lenwyreply('*Jawabanmu salah, coba lagi!*');
    }
}
break

case 'susunkata': {
    lenwyreply('*Sedang Memuat, Tunggu Sebentar ☕*');

    try {
        const axios = require('axios');

        // URL API Susun Kata
        const apiURL = `https://api.tioo.eu.org/susunkata`;
        const { data } = await axios.get(apiURL);

        if (!data.status || !data.result) {
            return lenwyreply('*Gagal Memuat Data. Coba Lagi Nanti.*');
        }

        const { soal, jawaban } = data.result;

        // Kirim soal untuk disusun
        await lenwy.sendMessage(m.chat, {
            text: `*Soal Susun Kata*\n\n` +
                  `Tebak kata dari susunan berikut:\n` +
                  `${soal}\n\n` +
                  `Tipe: *${data.result.tipe}*\n` +
                  `Cara Jawab : susunkatacek _<tuliskan jawabannya!>_`,
        }, { quoted: m });

        // Simpan jawaban yang benar untuk verifikasi
        global.susunkata = global.susunkata || {};
        global.susunkata[m.chat] = jawaban.toLowerCase();

        // Timer 10 detik untuk menampilkan jawaban
        setTimeout(() => {
            if (global.susunkata[m.chat]) {
                lenwy.sendMessage(m.chat, {
                    text: `*Waktu Habis!*\nJawaban yang benar adalah: *${jawaban}*`,
                });
                delete global.susunkata[m.chat];
            }
        }, 10000); // 10 detik dalam milidetik
    } catch (error) {
        console.error("⚠ *Error Saat Memuat Data :*", error.message);
        lenwyreply("*Terjadi Kesalahan Dalam Proses Permintaan.*");
    }
}
break

// Cek jawaban
case 'susunkatacek': {
    if (!global.susunkata || !global.susunkata[m.chat]) {
        return lenwyreply('*Tidak ada soal susun kata aktif untuk ditebak.*');
    }

    const userAnswer = args.join(' ').toLowerCase();
    const correctAnswer = global.susunkata[m.chat];

    if (userAnswer === correctAnswer) {
        lenwyreply(`*Selamat! Jawabanmu benar: ${correctAnswer.charAt(0).toUpperCase() + correctAnswer.slice(1)} 🎉*`);
        delete global.susunkata[m.chat];
    } else {
        lenwyreply('*Jawabanmu salah, coba lagi!*');
    }
}
break

case 'tebak': {
if (isBan) return lenwyreply('*Kamu Di Ban Owner*')
 if (args[0] === "gambar") {
 if (tebakgambar.hasOwnProperty(m.sender.split('@')[0])) lenwyreply('*Masih Ada Sesi Yang Belum Diselesaikan!*')
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakgambar.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 lenwy.sendImage(from, result.img, `*𖣐 Silahkan Jawab Soal Di Atas Ini*\n*𖣐 Deskripsi :* ${result.deskripsi}\n\n🕒 *Waktu : 60s*`, m).then(() => {
 tebakgambar[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (tebakgambar.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 lenwy.sendMessage(m.chat, { image: { url: 'https://files.catbox.moe/cnsw60.jpg' }, caption: `🕒 *Waktu Habis*\n*Jawaban : ${tebakgambar[m.sender.split('@')[0]]}*\n*Ingin Bermain Lagi? Ketik Tebak Gambar*`}, {quoted:m}) 
 delete tebakgambar[m.sender.split('@')[0]]
 }
 } else if (args[0] === 'kata') {
 if (tebakkata.hasOwnProperty(m.sender.split('@')[0])) lenwyreply('*Masih Ada Sesi Yang Belum Diselesaikan!*')
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkata.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 lenwy.sendText(from, `*𖣐 Silahkan Jawab Pertanyaan Berikut :*\n*${result.soal}*\n\n🕒 *Waktu : 60s*`, m).then(() => {
 tebakkata[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (tebakkata.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 lenwy.sendMessage(m.chat, { image: { url: 'https://files.catbox.moe/cnsw60.jpg' }, caption: `🕒 *Waktu Habis*\n*Jawaban : ${tebakkata[m.sender.split('@')[0]]}*\n*Ingin Bermain Lagi? Ketik Tebak Kata*` }, {quoted:m}) 
 delete tebakkata[m.sender.split('@')[0]]
 }
 } else if (args[0] === 'kalimat') {
 if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0])) lenwyreply('*Masih Ada Sesi Yang Belum Diselesaikan!*')
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkalimat.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 lenwy.sendText(from, `*𖣐 Silahkan Jawab Pertanyaan Berikut :*\n*Pertanyaan :* ${result.soal}\n\n🕒 *Waktu : 60s*`, m).then(() => {
 tebakkalimat[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 lenwy.sendMessage(m.chat, { image: { url: 'https://files.catbox.moe/cnsw60.jpg' }, caption:`🕒 *Waktu Habis*\n*Jawaban : ${tebakkalimat[m.sender.split('@')[0]]}*\n*Ingin Bermain Lagi? Ketik Tebak Kalimat*`}, {quoted:m}) 
 delete tebakkalimat[m.sender.split('@')[0]]
 }
 } else if (args[0] === 'lirik') {
 if (tebaklirik.hasOwnProperty(m.sender.split('@')[0])) lenwyreply('*Masih Ada Sesi Yang Belum Diselesaikan!*')
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebaklirik.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 lenwy.sendText(from, `*Ini Adalah Lirik Dari Lagu? :* \n\n*${result.soal}?*\n\n🕒 *Waktu : 60s*`, m).then(() => {
 tebaklirik[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (tebaklirik.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 lenwy.sendMessage(m.chat, { image: { url: 'https://files.catbox.moe/cnsw60.jpg' }, caption: `🕒 *Waktu Habis*\n*Jawaban : ${tebaklirik[m.sender.split('@')[0]]}*\n*Ingin Bermain Lagi? Ketik Tebak Lirik*`} , {quoted:m}) 
 delete tebaklirik[m.sender.split('@')[0]]
 }
 } else if (args[0] === 'lontong') {
 if (caklontong.hasOwnProperty(m.sender.split('@')[0])) lenwyreply('*Masih Ada Sesi Yang Belum Diselesaikan!*')
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/caklontong.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 lenwy.sendText(from, `*Jawablah Pertanyaan Berikut :*\n*${result.soal}*\n🕒 *Waktu : 60s*`, m).then(() => {
 caklontong[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
caklontong_desk[m.sender.split('@')[0]] = result.deskripsi
 })
 await sleep(60000)
 if (caklontong.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 lenwy.sendMessage(m.chat, { image: { url: 'https://files.catbox.moe/cnsw60.jpg' }, caption:`🕒 *Waktu Habis*\n*Jawaban : ${caklontong[m.sender.split('@')[0]]}*\n*Deskripsi : ${caklontong_desk[m.sender.split('@')[0]]}* \n\n*Ingin Bermain Lagi? Ketik Tebak Lontong*`}, {quoted:m}) 
 delete caklontong[m.sender.split('@')[0]]
delete caklontong_desk[m.sender.split('@')[0]]
 }
 }
}
break

case 'kuismath': case 'math': {
if (isBan) return lenwyreply('*Kamu Di Ban Owner*')
 if (kuismath.hasOwnProperty(m.sender.split('@')[0])) lenwyreply('*Masih Ada Sesi Yang Belum Diselesaikan!*')
 let { genMath, modes } = require('./src/math')
 if (!text) lenwyreply `Mode: ${Object.keys(modes).join(' | ')}\nContoh penggunaan: ${prefix}math medium`
 let result = await genMath(text.toLowerCase())
 lenwy.sendText(from, `*Berapa Hasil Dari : ${result.soal.toLowerCase()}*?\n\n🕒 *Waktu : ${(result.waktu / 1000).toFixed(2)} detik*`, m).then(() => {
 kuismath[m.sender.split('@')[0]] = result.jawaban
 })
 await sleep(result.waktu)
 if (kuismath.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 lenwyreply("🕒 *Waktu Habis*\n*Jawaban :* " + kuismath[m.sender.split('@')[0]])
 delete kuismath[m.sender.split('@')[0]]
 }
}
break

case 'ttc': case 'ttt': case 'tictactoe': {
if (isBan) return lenwyreply('*Kamu Di Ban Owner*')
 let TicTacToe = require("./lib/tictactoe")
this.game = this.game ? this.game : {}
if (Object.values(this.game).find(room => room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender))) throw '*Kamu Masih Didalam Permainan*'
let room = Object.values(this.game).find(room => room.state === 'WAITING' && (text ? room.name === text : true))
if (room) {
lenwyreply('*Lawan Bermain Ditemukan*')
room.o = from
room.game.playerO = m.sender
room.state = 'PLAYING'
let arr = room.game.render().map(v => {
return {
X: '❌',
O: '⭕',
1: '1️⃣',
2: '2️⃣',
3: '3️⃣',
4: '4️⃣',
5: '5️⃣',
6: '6️⃣',
7: '7️⃣',
8: '8️⃣',
9: '9️⃣',
}[v]
})
let str = `Room ID: ${room.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

Menunggu @${room.game.currentTurn.split('@')[0]}

Ketik *nyerah* untuk menyerah dan mengakui kekalahan`
if (room.x !== room.o) await lenwy.sendText(room.x, str, m, { mentions: parseMention(str) } )
await lenwy.sendText(room.o, str, m, { mentions: parseMention(str) } )
} else {
room = {
id: 'tictactoe-' + (+new Date),
x: from,
o: '',
game: new TicTacToe(m.sender, 'o'),
state: 'WAITING'
}
if (text) room.name = text
lenwyreply('*Menunggu Lawan Bermain*' + (text ? ` mengetik command dibawah ini ${prefix}${command} ${text}` : ''))
this.game[room.id] = room
}
}
break

case 'claim': {
if (!m.isGroup) return lenwyreply(mess.group)
let user = db.data.users[m.sender]
let time = user.lenlimit + 86400000
if (new Date - user.lenlimit < 86400000) return lenwyreply(`*Kamu Sudah Mengambil Limit Harian*\n🕒 *Tunggu Selama ${LenTime(time - new Date())}*`)
let LenwyL = 50
user.limit += LenwyL * 1
user.lenlimit = new Date * 1
lenwyreply(`*Kamu Mendapatkan : +${LenwyL} Limit*`)
}
break

case 'bonus': {
if (!m.isGroup) return lenwyreply(mess.group)
let user = db.data.users[m.sender]
let time = user.lenbonus + 86400000
if (new Date - user.lenbonus < 86400000) return lenwyreply(`*Kamu Sudah Mengambil Bonus Harian*\n🕒 *Tunggu Selama ${LenTime(time - new Date())}*`)
let LenwyC = 20
user.coin += LenwyC * 1
user.lenbonus = new Date * 1
lenwyreply(`*Kamu Mendapatkan : +${LenwyC} Koin Emas*`)
}
break

case 'del':
case 'delete': {
    // Cek apakah pengguna adalah admin
    if (!isAdmins) return lenwyreply('*Perintah ini hanya bisa digunakan oleh admin grup!*');

    // Cek apakah ada pesan yang dikutip
    if (!m.quoted) {
        return lenwyreply('Balas pesan yang ingin dihapus!');
    }

    try {
        // Hapus pesan yang dikutip
        await lenwy.sendMessage(m.chat, {
            delete: {
                remoteJid: m.chat,
                fromMe: m.quoted.fromMe, 
                id: m.quoted.id,
                participant: m.quoted.sender,
            },
        });
    } catch (error) {
        // Jika terjadi kesalahan, kirim pesan error
        console.error("Error di case 'delete':", error.message);
        lenwyreply('Gagal menghapus pesan.');
    }
}
break

case 'proses': {
    if (!m.isGroup) return lenwyreply('⚠️ Fitur ini hanya dapat digunakan di dalam grup!');
    if (!m.quoted) return lenwyreply('⚠️ Reply pesan pesanan yang ingin diproses.');

    let tek = m.quoted.text; // Mengambil teks dari pesan yang direply
    if (!tek) return lenwyreply('⚠️ Pesanan tidak ditemukan di pesan yang direply.');

    let proses = `── 「 *DETAIL PESANAN* 」 ──\n\n\`\`\`› Status : 「 Transaksi Pending 」\n› Pesanan : @user\n› Date : @tanggal\n› Clock : @jam\n› Status Pesanan : Diproses ⌛\n› Catatan Pesanan 📝 :\`\`\`\n*@pesanan*\n\n_*Tunggu sebentar, orderan kamu sedang diproses oleh admin @admin.*_`;

    // Mengganti placeholder di teks
    let pesanFinal = proses
        .replace('@pesanan', tek) // Isi pesanan
        .replace('@user', '@' + m.quoted.sender.split('@')[0]) // Mention user
        .replace('@admin', pushname) // Nama admin
        .replace('@jam', time) // Waktu saat ini
        .replace('@tanggal', tanggal(new Date())); // Tanggal saat ini

    // Kirim pesan ke grup dengan mention
    lenwy.sendTextWithMentions(m.chat, pesanFinal, m);
}
break

case 'd': 
case 'done': {
    if (!m.isGroup) return lenwyreply('⚠️ Fitur ini hanya dapat digunakan di dalam grup!');
    if (!m.quoted) return lenwyreply('⚠️ Reply pesan pesanan yang telah diproses.');

    let tek = m.quoted.text; // Mengambil teks dari pesan yang direply
    if (!tek) return lenwyreply('⚠️ Pesanan tidak ditemukan di pesan yang direply.');

    let sukses = `── 「 *DETAIL PESANAN* 」 ──\n\n\`\`\`› Status : 「 Transaksi Success 」\n› Pesanan : @user\n› Date : @tanggal\n› Clock : @jam\n› Status Pesanan : Terkirim ✅\n› Catatan Pesanan 📝 :\`\`\`\n*@pesanan*\n\n_*Terimakasih sudah order di @group*_\n*_Kami tunggu orderan berikutnya_* 🤗🤗`;

    // Mengganti placeholder di teks
    let pesanFinal = sukses
        .replace('@pesanan', tek) // Isi pesanan
        .replace('@user', '@' + m.quoted.sender.split('@')[0]) // Mention user
        .replace('@admin', pushname) // Nama admin
        .replace('@group', groupMetadata.subject) // Nama grup
        .replace('@jam', time) // Waktu saat ini
        .replace('@tanggal', tanggal(new Date())); // Tanggal saat ini

    // Kirim pesan ke grup dengan mention
    lenwy.sendTextWithMentions(m.chat, pesanFinal, m);
}
break

case 'searchyt':
case 'ytsearch': {
    let query = text || args.join(" ");
    if (!query) return lenwyreply("📌 Mohon masukkan kata kunci pencarian.");

    try {
        // Kirim emoji react ⏱️ sebagai indikator proses
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "⏱️",
                key: m.key,
            }
        });

        // Fetch data dari API
        let res = await fetch(`https://api.ryzendesu.vip/api/search/yt?query=${encodeURIComponent(query)}`);
        if (!res.ok) throw new Error("Gagal mengakses API.");

        let data = await res.json();
        if (!data.videos || data.videos.length === 0) {
            // Kirim emoji ❌ jika tidak ditemukan video
            await lenwy.sendMessage(m.chat, {
                react: {
                    text: "❌",
                    key: m.key,
                }
            });
            return lenwyreply("❌ Tidak ditemukan video yang cocok.");
        }

        // Kirim emoji ✅ jika pencarian selesai dan ditemukan hasil
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key,
            }
        });

        // Buat tampilan hasil pencarian
        let response = `📺 *Hasil Pencarian YouTube:*\n\n`;
        data.videos.slice(0, 10).forEach((video, i) => {
            response += `*${i + 1}. ${video.title}*\n`;
            response += `   ⏱️ *Durasi*: ${video.duration.timestamp}\n`;
            response += `   👀 *Ditonton*: ${video.views.toLocaleString()} kali\n`;
            response += `   🔗 [Tonton di YouTube](${video.url})\n\n`;
        });

        lenwyreply(response);
    } catch (err) {
        console.error(err);
        lenwyreply("❌ Terjadi kesalahan saat mencari video.");
    }
}
break

case 'yts': {
    if (!args[0]) return lenwyreply('❌ Harap masukkan kata kunci pencarian!');

    let query = args.join(' '); // Gabungkan semua argumen menjadi satu string pencarian
    let apiUrl = `https://restapi.apibotwa.biz.id/api/search-yts?message=${encodeURIComponent(query)}`;

    try {
        // Kirim reaksi ⏱️ saat pencarian dimulai
        await lenwy.sendMessage(m.chat, {
            react: { text: "⏱️", key: m.key }
        });

        // Panggil API untuk mencari video YouTube
        let res = await axios.get(apiUrl);
        let data = res.data;

        // Validasi hasil API
        if (data.status !== 200 || !data.data.response.video.length) {
            return lenwyreply('❌ Tidak ditemukan hasil untuk pencarian ini.');
        }

        let result = data.data.response.video.slice(0, 10); // Ambil maksimal 10 hasil

        let message = `🔍 *Hasil Pencarian YouTube*\n\n`;
        for (let vid of result) {
            message += `🎵 *Judul:* ${vid.title}\n`;
            message += `👤 *Channel:* ${vid.authorName}\n`;
            message += `⏱️ *Durasi:* ${vid.duration}\n`;
            message += `👁 *Dilihat:* ${vid.viewH}\n`;
            message += `📅 *Waktu Upload:* ${vid.publishedTime}\n`;
            message += `📜 *Deskripsi:* ${vid.description}\n`;
            message += `🔗 *URL:* ${vid.url}\n\n`;
        }

        // Kirim hasil pencarian dengan thumbnail video pertama
        await lenwy.sendMessage(m.chat, { 
            image: { url: result[0].thumbnail }, 
            caption: message 
        }, { quoted: m });

        // Kirim reaksi ✅ setelah selesai
        await lenwy.sendMessage(m.chat, {
            react: { text: "✅", key: m.key }
        });

    } catch (err) {
        console.error(err);
        lenwyreply('❌ Terjadi kesalahan saat mengambil data.');
    }
}
break

case 'yt': case 'ytvid': case 'ytvideo': {
    if (!args[0]) return lenwyreply('❌ Harap masukkan URL YouTube!');

    let url = args[0].trim();
    
    try {
        await lenwy.sendMessage(m.chat, {
            react: { text: "⏱️", key: m.key }
        });

        let { youtubeScraper } = require('./kiromi/kay/yt.js'); // Ganti path sesuai lokasi yt.js
        let data = await youtubeScraper(url);

        if (data.error) return lenwyreply(`❌ ${data.error}`);

        let caption = `
📌 *Judul:* ${data.title}
📄 *Deskripsi:* ${data.description || 'Tidak ada deskripsi'}
⏱️ *Durasi:* ${data.duration} detik
👤 *Penulis:* ${data.author}
🌍 *Link Sumber:* ${data.source}
        `.trim();

        // Kirim video
        await lenwy.sendMessage(m.chat, {
            video: { url: data.mp4 },
            caption
        }, { quoted: m });

        // Kirim audio
        await lenwy.sendMessage(m.chat, {
            audio: { url: data.mp3 },
            mimetype: 'audio/mpeg',
            fileName: `${data.title}.mp3`
        }, { quoted: m });

        await lenwy.sendMessage(m.chat, {
            react: { text: "✅", key: m.key }
        });

    } catch (err) {
        console.error("[YouTube Scraper Error]", err);
        lenwyreply('❌ Terjadi kesalahan saat memproses permintaan.');
    }
}
break

case 'ytmp4': {
    const { getYtMp4 } = require('./kiromi/kay/ytdl.js');

    if (!text) return lenwyreply(`Masukkan URL YouTube!\n• *Contoh:* ${command} https://www.youtube.com/watch?v=xxxx`);
    if (!/http.+youtu/.test(text)) return lenwyreply('❌ URL tidak valid!');

    // Kirim reaksi loading ⏱️
    await lenwy.sendMessage(m.chat, {
        react: {
            text: "⏱️",
            key: m.key,
        }
    });

    let data = await getYtMp4(text);
    if (!data) return lenwyreply('❌ Gagal mengambil data!');

    try {
        // Kirim video MP4
        await lenwy.sendMessage(m.chat, { 
            video: { url: data.download },
            mimetype: 'video/mp4',
            caption: '🎬 *YouTube Video Downloader*\n\n✅ *Berhasil diunduh!*'
        }, { quoted: m });

        // Reaksi selesai ✅
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key,
            }
        });

    } catch (err) {
        console.error(err);
        return lenwyreply('❌ Gagal mengirim video!');
    }
}
break

case 'ytshorts': {
    if (!args[0]) return lenwyreply('❌ Harap masukkan URL YouTube!');

    let url = args[0]; // URL YouTube
    let apiUrl = `https://api.betabotz.eu.org/api/download/yt?url=${encodeURIComponent(url)}&apikey=PXYo4sxf`;

    try {
        // Tambahkan emoji ⏱️ pada pesan saat proses dimulai
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "⏱️", // Emoji saat proses
                key: m.key,
            }
        });

        // Panggil API untuk mendapatkan metadata dan link download
        let res = await axios.get(apiUrl);
        let data = res.data;

        // Validasi hasil API
        if (!data.status || !data.result) {
            return lenwyreply('❌ Gagal mendapatkan data video.');
        }

        let video = data.result;
        let message = `🎥 *YouTube Downloader*\n\n`;
        message += `🎵 *Judul:* ${video.title}\n`;
        message += `📜 *Deskripsi:* ${video.description}\n`;
        message += `⏱️ *Durasi:* ${video.duration} detik\n`;
        message += `🔗 *Link Video:* ${video.source}\n\n`;

        // Kirim video dengan informasi
        await lenwy.sendMessage(m.chat, {
            video: { url: video.mp4 },
            caption: message,
        });

        // Kirim link download MP3 dan MP4
        message = `🎧 *MP3 Download Link:* ${video.mp3}\n`;
        message += `🎬 *MP4 Download Link:* ${video.mp4}\n\n`;

        await lenwyreply(message);

        // Setelah proses selesai, beri reaksi dengan emoji ✅
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅", // Emoji selesai
                key: m.key,
            }
        });

    } catch (err) {
        console.error(err);
        lenwyreply('❌ Terjadi kesalahan saat memproses permintaan.');
    }
}
break


case 'ytmpv4': {
    if (!args[0]) return lenwyreply('Harap masukkan URL YouTube!'); // Validasi input URL

    let url = args[0]; // URL YouTube
    let quality = args[1] || '360p'; // Resolusi default 360p

    try {
        // Mengirim emoji ⏱️ saat memulai proses
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "⏱️", // Emoji saat proses
                key: m.key,
            }
        });

        lenwyreply('Sabar ya... Sedang diproses');

        // Panggil API untuk mendapatkan data video
        let res = await axios.get(`https://api.ryzendesu.vip/api/downloader/ytmp4`, {
            params: { 
                url: url, 
                quality: quality 
            }
        });

        // Parsing hasil API
        let result = res.data;
        if (!result.url) return lenwyreply('Gagal mendapatkan link download video.');

        // Caption untuk dikirim bersama video
        let caption = `*🎥 YTMP4 Downloader*\n\n` +
                      `🎵 *Judul:* ${result.title}\n` +
                      `👤 *Author:* ${result.author}\n` +
                      `⏱️ *Durasi:* ${result.lengthSeconds}\n` +
                      `👁 *Views:* ${result.views}\n` +
                      `📅 *Upload:* ${result.uploadDate}\n\n` +
                      `Diunduh oleh KayzuMD • wa.me/6289673462138`;

        // Unduh video dari URL
        let videoBuffer = await axios.get(result.url, { responseType: 'arraybuffer' });

        // Kirim video dengan caption
        await lenwy.sendMessage(m.chat, { 
            video: Buffer.from(videoBuffer.data), 
            caption: caption 
        }, { quoted: m });

        // Mengirim emoji ✅ setelah proses selesai
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅", // Emoji selesai
                key: m.key,
            }
        });

    } catch (err) {
        console.error(err);
        lenwyreply('Terjadi kesalahan saat memproses permintaan.');
    }
}
break


case 'ytmp3': {
    const { getYtMp3 } = require('./kiromi/kay/ytmp3.js');

    if (!text) return lenwyreply(`Masukkan URL YouTube!\n• *Contoh:* ${command} https://www.youtube.com/watch?v=xxxx`);
    if (!/http.+youtu/.test(text)) return lenwyreply('❌ URL tidak valid!');

    // Kirim reaksi loading ⏱️
    await lenwy.sendMessage(m.chat, {
        react: {
            text: "⏱️",
            key: m.key,
        }
    });

    let data = await getYtMp3(text);
    if (!data) return lenwyreply('❌ Gagal mengambil data!');

    try {
        // Kirim thumbnail dulu
        await lenwy.sendMessage(m.chat, {
            image: { url: data.thumbnail },
            caption: `🎵 *YouTube MP3 Downloader*\n\n📌 *Title:* ${data.title}\n📺 *Channel:* ${data.channelTitle}\n📖 *Description:* ${data.description.substring(0, 100)}...\n\n📥 *Downloading...*`
        }, { quoted: m });

        // Kirim audio MP3
        await lenwy.sendMessage(m.chat, { 
            audio: { url: data.download },
            mimetype: 'audio/mp4',
            ptt: false
        }, { quoted: m });

        // Reaksi selesai ✅
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key,
            }
        });

    } catch (err) {
        console.error(err);
        return lenwyreply('❌ Gagal mengirim audio!');
    }
}
break

case 'ytmpv3': {
    if (!args[0]) return lenwyreply('Masukkan URL YouTube yang valid.');

    const url = args[0];
    const apiUrl = `https://api.betabotz.eu.org/api/download/ytmp3?url=${encodeURIComponent(url)}&apikey=PXYo4sxf`;

    try {
        // Mengirim emoji ⏱️ saat memulai proses
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "⏱️", // Emoji proses
                key: m.key,
            }
        });

        // Fetch data dari API
        const response = await fetch(apiUrl);
        const result = await response.json();

        if (!result.status) {
            return lenwyreply('Gagal mendapatkan data. Pastikan URL valid dan API berfungsi.');
        }

        // Ambil data yang dibutuhkan dari API
        const { title, mp3, duration, description, thumb } = result.result;

        // Membuat pesan informasi video
        let infoMessage = `
*YouTube MP3 Downloader*:
*Judul*: ${title}
*Deskripsi*: ${description.slice(0, 150)}... 
*Durasi*: ${Math.floor(duration / 60)} menit ${duration % 60} detik

*Audio sedang diproses dan akan segera dikirim.* 🎶
        `;

        // Kirim informasi bersama dengan thumbnail dalam satu pesan
        await lenwy.sendMessage(m.chat, {
            image: { url: thumb }, 
            caption: infoMessage
        });

        // Kirim file audio ke sumber permintaan (grup atau pribadi)
        await lenwy.sendMessage(m.chat, {
            audio: { url: mp3 },
            mimetype: 'audio/mpeg',
            caption: `*Audio berhasil diunduh!*\n\nJudul: ${title}`
        });

        // Mengirim emoji ✅ setelah proses selesai
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅", // Emoji selesai
                key: m.key,
            }
        });

    } catch (error) {
        console.error(error);
        lenwyreply('Terjadi kesalahan saat memproses permintaan. Coba lagi nanti.');
    }
}
break

case 'xnxxs':
{
  if (!text) return lenwyreply(`*Gunakan Dengan*\n\nexample : ${prefix+command} japanese`);

  // Cek apakah pengguna adalah premium
  if (!isPrem) return lenwyreply('Fitur ini hanya tersedia untuk pengguna premium.');

  // React dengan emoji "⏱️" saat memproses
  await lenwy.sendMessage(m.chat, {
    react: {
      text: "⏱️", // Emoji untuk proses
      key: m.key,
    }
  });

  // Mengambil data dari API
  let anu = await fetchJson(`https://api.lolhuman.xyz/api/xnxxsearch?apikey=5be94ede1b5591e1d3d85392&query=${text}`);

  // Mengecek jika respons statusnya sukses dan ada hasil
  if (anu.status === 200 && anu.result && anu.result.length > 0) {
    let results = anu.result;

    // Mengirimkan hasil tanpa batas
    for (let i = 0; i < results.length; i++) {
      let video = results[i];
      let teks = `*Title* : ${video.title}\n`;
      teks += `*Views* : ${video.views}\n`;
      teks += `*Duration* : ${video.duration}\n`;
      teks += `*Uploader* : ${video.uploader}\n`;
      teks += `*Link* : ${video.link}\n\n───────────────\n\n`;

      // Kirim informasi dan thumbnail per video
      await lenwy.sendMessage(m.chat, { 
        caption: teks,
        image: { url: video.thumbnail } 
      }, { quoted: m });
    }

    // React dengan emoji "✅" setelah selesai
    await lenwy.sendMessage(m.chat, {
      react: {
        text: "✅", // Emoji untuk selesai
        key: m.key,
      }
    });
  } else {
    lenwyreply("Tidak ada hasil yang ditemukan.");

    // React dengan emoji "❌" jika tidak ada hasil
    await lenwy.sendMessage(m.chat, {
      react: {
        text: "❌", // Emoji untuk gagal
        key: m.key,
      }
    });
  }
}
break

case 'xnxxdl':
{
  if (!text) return lenwyreply(`*Gunakan Dengan*\n\nexample : ${prefix+command} japanese`);

  // Cek apakah pengguna adalah premium
  if (!isPrem) return lenwyreply('Fitur ini hanya tersedia untuk pengguna premium.');

  // React dengan emoji "⏱️" saat memproses
  await lenwy.sendMessage(m.chat, {
    react: {
      text: "⏱️", // Emoji untuk proses
      key: m.key,
    }
  });

  // Mengambil data dari API menggunakan URL video yang diberikan
  let anu = await fetchJson(`https://api.lolhuman.xyz/api/xnxx?apikey=5be94ede1b5591e1d3d85392&url=${text}`);

  // Mengecek jika respons statusnya sukses dan ada hasil
  if (anu.status === 200 && anu.result) {
    let video = anu.result;

    // Menyiapkan informasi yang akan dikirimkan
    let teks = `*Title* : ${video.title}\n`;
    teks += `*Views* : ${video.view}\n`;
    teks += `*Duration* : ${video.duration}\n`;
    teks += `*Rating* : ${video.rating}\n`;
    teks += `*Likes* : ${video.like}\n`;
    teks += `*Dislikes* : ${video.dislike}\n`;
    teks += `*Comments* : ${video.comment}\n`;
    teks += `*Tags* : ${video.tag.join(", ")}\n`;
    teks += `*Description* : ${video.description}\n\n───────────────\n\n`;

    // Mengirimkan informasi dan video (MP4)
    lenwy.sendMessage(m.chat, {
      caption: teks,
      video: { url: video.link[1].link }, // Mengirimkan video MP4
      mimetype: 'video/mp4'
    }, { quoted: m });

    // React dengan emoji "✅" setelah selesai
    await lenwy.sendMessage(m.chat, {
      react: {
        text: "✅", // Emoji untuk selesai
        key: m.key,
      }
    });
  } else {
    lenwyreply("Tidak ada hasil yang ditemukan.");

    // React dengan emoji "❌" jika tidak ada hasil
    await lenwy.sendMessage(m.chat, {
      react: {
        text: "❌", // Emoji untuk gagal
        key: m.key,
      }
    });
  }
}
break

case 'stalktiktok':
case 'tts': {
    if (!args[0]) return lenwyreply('❌ Harap masukkan username TikTok yang ingin di-stalk!');

    let username = args[0]; // Ambil username dari argumen
    try {
        lenwyreply('⏱️ Sedang mencari informasi...');

        // Panggil API
        let response = await axios.get(`https://api.ryzendesu.vip/api/stalk/tiktok`, {
            params: { username }
        });

        let { userInfo } = response.data;
        if (!userInfo) return lenwyreply('❌ Tidak dapat menemukan informasi pengguna.');

        // Parsing data API
        let { 
            id, username: user, name, avatar, bio, verified, 
            totalFollowers, totalFollowing, totalLikes, totalVideos, totalFriends 
        } = userInfo;

        // Kirim pesan dengan detail informasi
        await lenwy.sendMessage(m.chat, {
            image: { url: avatar },
            caption: `
📲 *Informasi TikTok User*\n
👤 *Nama*: ${name}
🆔 *Username*: ${user}
📄 *Bio*: ${bio || 'Tidak ada bio'}
✅ *Verified*: ${verified ? 'Ya' : 'Tidak'}

📊 *Statistik Akun*:
👥 *Followers*: ${totalFollowers}
👤 *Following*: ${totalFollowing}
❤️ *Likes*: ${totalLikes}
🎥 *Video*: ${totalVideos}
🤝 *Teman*: ${totalFriends}

🔗 *ID User*: ${id}
            `.trim()
        }, { quoted: m });

    } catch (err) {
        console.error(err);
        lenwyreply('❌ Terjadi kesalahan saat memproses permintaan.');
    }
}
break

case 'stalktiktok2':
case 'tts2': {
    if (!args[0]) return lenwyreply('Harap masukkan username TikTok!');

    let username = args.join(' '); // Username TikTok dari pengguna

    try {
        lenwyreply('Sebentar ya, sedang mencari informasi akun TikTok...');

        // Panggil API untuk mendapatkan informasi pengguna TikTok
        let res = await axios.get(`https://fastrestapis.fasturl.cloud/stalk/tiktok?username=${username}`);

        // Parsing hasil API
        let result = res.data.result;
        if (res.data.status !== 200 || !result) {
            return lenwyreply('Gagal menemukan informasi pengguna TikTok dengan username tersebut.');
        }

        // Menyusun pesan yang menarik
        let tiktokInfo = `*🎥 Username TikTok:* ${result.username}\n` +
                         `👤 *Nama Pengguna:* ${result.nickname}\n` +
                         `🌍 *Negara:* ${result.country || 'Tidak Diketahui'}\n` +
                         `🔗 *URL Profil:* [Klik Disini](${result.profileUrl})\n\n` +
                         `📊 *Statistik Akun:*\n` +
                         `👥 *Total Followers:* ${result.stats.totalFollowers || 'Tidak Diketahui'}\n` +
                         `❤️ *Total Likes:* ${result.stats.totalLikes || 'Tidak Diketahui'}\n` +
                         `🎬 *Total Video:* ${result.stats.totalVideos || 'Tidak Diketahui'}\n` +
                         `➡️ *Mengikuti:* ${result.stats.following || 'Tidak Diketahui'}\n\n` +
                         `📈 *Tingkat Keterlibatan:*\n` +
                         `👍 *Likes Rate:* ${result.engagementRates.likesRate}\n` +
                         `💬 *Comments Rate:* ${result.engagementRates.commentsRate}\n` +
                         `🔄 *Shares Rate:* ${result.engagementRates.sharesRate}\n` +
                         `🔢 *Overall Engagement:* ${result.engagementRates.overallEngagement}\n\n` +
                         `📊 *Performa Video Rata-Rata:*\n` +
                         `👀 *Views:* ${result.averageVideoPerformance.avgViews}\n` +
                         `❤️ *Likes:* ${result.averageVideoPerformance.avgLikes}\n` +
                         `💬 *Comments:* ${result.averageVideoPerformance.avgComments}\n` +
                         `🔄 *Shares:* ${result.averageVideoPerformance.avgShares}\n\n` +
                         `#️⃣ *Hashtags:* ${result.hashtags.length > 0 ? result.hashtags.join(', ') : 'Tidak Ada Hashtags'}\n`;

        // Kirim informasi akun TikTok
        await lenwyreply(tiktokInfo);

    } catch (err) {
        console.error(err);
        lenwyreply('Terjadi kesalahan saat memproses permintaan.');
    }
}
break

case 'ytsalk':
case 'stalkyoutube': {
    if (!args[0]) return lenwyreply('❌ Harap masukkan username YouTube yang ingin di-stalk!');

    let username = args[0]; // Ambil username dari argumen
    try {
        lenwyreply('⏱️ Sedang mencari informasi...');

        // Panggil API
        let response = await axios.get(`https://api.ryzendesu.vip/api/stalk/youtube`, {
            params: { username }
        });

        let { channelMetadata, videoDataList } = response.data;
        if (!channelMetadata) return lenwyreply('❌ Tidak dapat menemukan informasi channel.');

        // Parsing data API
        let { 
            username: channelName, subscriberCount, videoCount, avatarUrl, 
            channelUrl, description, isFamilySafe 
        } = channelMetadata;

        // Ambil video terakhir (jika ada)
        let latestVideo = videoDataList[0];
        let videoDetails = latestVideo ? `
🎥 *Video Terakhir*: 
• *Judul*: ${latestVideo.title}
• *Ditonton*: ${latestVideo.viewCount}
• *Durasi*: ${latestVideo.duration}
• *URL*: https://www.youtube.com${latestVideo.navigationUrl}
        `.trim() : '🎥 Tidak ada video yang tersedia.';

        // Kirim pesan dengan detail informasi
        await lenwy.sendMessage(m.chat, {
            image: { url: avatarUrl },
            caption: `
📺 *Informasi YouTube Channel*\n
👤 *Nama Channel*: ${channelName}
🔗 *Link Channel*: ${channelUrl}
✅ *Family Friendly*: ${isFamilySafe ? 'Ya' : 'Tidak'}
📄 *Deskripsi*: ${description || 'Tidak ada deskripsi'}

📊 *Statistik Channel*:
👥 *Subscriber*: ${subscriberCount || 'Tidak tersedia'}
🎥 *Jumlah Video*: ${videoCount || 'Tidak tersedia'}

${videoDetails}
            `.trim()
        }, { quoted: m });

    } catch (err) {
        console.error(err);
        lenwyreply('❌ Terjadi kesalahan saat memproses permintaan.');
    }
}
break

case 'igs':
case 'stalkig': {
    if (!args[0]) return lenwyreply('❌ Harap masukkan username Instagram yang ingin di-stalk! Contoh: .igstalk2 username');

    let username = args[0];
    try {
        lenwyreply('⏱️ Sedang mencari data...');

        // Request ke API
        let response = await axios.get(`https://api.botcahx.eu.org/api/stalk/ig?username=${username}&apikey=kayganzz`);
        let { status, result } = response.data;

        if (!status) return lenwyreply('❌ Username tidak ditemukan atau API gagal merespons.');

        let { username: uname, fullName, bio, followers, following, postsCount, photoUrl } = result;

        // Kirim hasil stalk
        let caption = `
✅ *Data Ditemukan!*

👤 *Username*: ${uname}
📛 *Nama Lengkap*: ${fullName}
📖 *Bio*: ${bio || 'Tidak ada bio.'}
👥 *Followers*: ${followers}
👤 *Following*: ${following}
📝 *Jumlah Postingan*: ${postsCount}

🌐 *URL Profil*: https://instagram.com/${uname}
        `.trim();

        await lenwy.sendMessage(m.chat, { image: { url: photoUrl }, caption }, { quoted: m });
    } catch (err) {
        console.error('Error saat stalk IG:', err.response?.data || err.message);
        lenwyreply('❌ Terjadi kesalahan saat memproses permintaan. Pastikan username benar atau coba lagi nanti.');
    }
}
break

case 'iplocation': {
    if (!args[0]) return lenwyreply('❌ Harap masukkan alamat IP yang ingin dilacak. Contoh: .iplocation 8.8.8.8');

    let ipAddress = args[0];

    try {
        lenwyreply('*One Moment, Please ☕*');

        // Request ke API
        let response = await axios.get(`https://vapis.my.id/api/cekipfull?ip=${ipAddress}`);
        let { status, data } = response.data;

        if (!status) return lenwyreply('❌ Gagal mendapatkan data lokasi IP.');

        // Ambil data dari beberapa provider
        let ipinfo = data.find(item => item.name === 'ipinfo.io')?.data;
        let ipapi = data.find(item => item.name === 'ip-api.com')?.data;
        let ipwhois = data.find(item => item.name === 'ipwhois.app')?.data;
        let ipapiCo = data.find(item => item.name === 'ipapi.co')?.data;

        // Menyusun informasi lokasi IP
        let locationInfo = `
✅ *Data Lokasi IP Ditemukan!*

🌍 *IP*: ${ipAddress}
🖥️ *Hostname*: ${ipinfo?.hostname || '-'}
📍 *Kota*: ${ipinfo?.city || '-'}
🌎 *Negara*: ${ipinfo?.country || '-'}
📌 *Region*: ${ipinfo?.region || '-'}
🌐 *Organisasi*: ${ipinfo?.org || '-'}
🗺️ *Koordinat*: ${ipinfo?.loc || '-'}
⏰ *Timezone*: ${ipinfo?.timezone || '-'}
        
🔗 *Sumber Data*:
- *IP-API*: ${ipapi?.city}, ${ipapi?.region}, ${ipapi?.country}
- *IPWhois*: ${ipwhois?.country}, ${ipwhois?.region}, ${ipwhois?.city}
- *IPAPI*: ${ipapiCo?.country}, ${ipapiCo?.region}, ${ipapiCo?.city}
`;

        // Kirim hasil lokasi IP
        lenwyreply(locationInfo);

    } catch (err) {
        console.error("⚠ *Error Saat Mendapatkan Lokasi IP :*", err.message);
        lenwyreply("*Terjadi Kesalahan Dalam Proses Permintaan.*");
    }
}
break

case 'stalkff': {
    if (!args[0]) return lenwyreply('❌ Harap masukkan ID akun Free Fire yang ingin di-stalk. Contoh: .ffstalk2 12345678');

    let accountId = args[0];

    try {
        lenwyreply('*One Moment, Please ☕*');

        // Request ke API
        let response = await axios.get(`https://vapis.my.id/api/ff-stalk?id=${accountId}`);
        let { status, data } = response.data;

        if (!status) return lenwyreply('❌ Gagal mendapatkan data akun Free Fire.');

        // Ambil data akun dari response
        let account = data.account;
        let petInfo = data.pet_info;
        let guild = data.guild;
        let leader = data.ketua_guild;

        // Menyusun informasi akun Free Fire
        let accountInfo = `
✅ *Data Akun Free Fire Ditemukan!*

👤 *Nama*: ${account.name}
🏆 *Level*: ${account.level}
🎮 *XP*: ${account.xp}
🌍 *Region*: ${account.region}
❤️ *Like*: ${account.like}
📅 *Tanggal Buat*: ${account.create_time}
🕓 *Terakhir Login*: ${account.last_login}
🏅 *Honor Score*: ${account.honor_score}
🎖️ *Booyah Pass*: ${account.booyah_pass}

🐾 *Pet*:
- *Nama*: ${petInfo.name}
- *Level*: ${petInfo.level}
- *XP*: ${petInfo.xp}

💥 *Guild*:
- *Nama*: ${guild.name}
- *Level*: ${guild.level}
- *Anggota*: ${guild.member}/${guild.capacity}

👑 *Ketua Guild*:
- *Nama*: ${leader.name}
- *Level*: ${leader.level}
- *XP*: ${leader.xp}
- *Like*: ${leader.like}
- *BR Points*: ${leader.BR_points}
- *CS Points*: ${leader.CS_points}

🎮 *ID Akun*: ${account.id}
`;

        // Kirim informasi akun
        lenwyreply(accountInfo);

    } catch (err) {
        console.error("⚠ *Error Saat Mendapatkan Data Akun Free Fire :*", err.message);
        lenwyreply("*Terjadi Kesalahan Dalam Proses Permintaan.*");
    }
}
break

case 'stalktele':
case 'ttg': {
    if (!args[0]) return lenwyreply('Harap masukkan username Telegram!');

    let username = args.join(' '); // Mengambil username dari argumen

    try {
        lenwyreply('Sebentar ya, sedang mencari informasi pengguna Telegram...');

        // Panggil API untuk mendapatkan informasi pengguna Telegram
        let res = await axios.get(`https://fastrestapis.fasturl.cloud/stalk/telegram?username=${username}`);

        // Parsing hasil API
        let result = res.data.result;
        if (res.data.status !== 200 || !result) {
            return lenwyreply('Gagal menemukan informasi pengguna Telegram dengan username tersebut.');
        }

        // Menyusun pesan yang menarik
        let telegramInfo = `*👤 Nama Pengguna:* ${result.title}\n` +
                           `📝 *Deskripsi:* ${result.desc}\n`;

        // Kirim gambar profil dan informasi pengguna Telegram
        await lenwy.sendMessage(m.chat, { 
            image: { url: result.imageUrl }, // Gambar dari URL
            caption: telegramInfo
        }, { quoted: m });

    } catch (err) {
        console.error(err);
        lenwyreply('Terjadi kesalahan saat memproses permintaan.');
    }
}
break

case 'stalkmc': {
    if (!args[0]) return lenwyreply('Harap masukkan username Minecraft!');

    let username = args.join(' '); // Mengambil username dari argumen

    try {
        lenwyreply('Sebentar ya, sedang mencari informasi pemain Minecraft...');

        // Panggil API untuk mendapatkan informasi pemain Minecraft
        let res = await axios.get(`https://fastrestapis.fasturl.cloud/stalk/minecraft?username=${username}`);

        // Parsing hasil API
        let result = res.data.result;
        if (res.data.status !== 200 || !result) {
            return lenwyreply('Gagal menemukan informasi pemain Minecraft dengan username tersebut.');
        }

        // Menyusun pesan yang menarik
        let minecraftInfo = `*👤 Nama Pengguna:* ${result.username}\n` +
                            `🆔 *ID Pemain:* ${result.id}\n`;

        // Kirim avatar dan skin pemain Minecraft beserta informasi
        await lenwy.sendMessage(m.chat, { 
            image: { url: result.avatar }, // Gambar avatar pemain
            caption: minecraftInfo
        }, { quoted: m });

        // Kirim skin pemain Minecraft (jika ada)
        await lenwy.sendMessage(m.chat, { 
            image: { url: result.skinTexture }, // Gambar skin pemain
            caption: 'Ini adalah skin pemain Minecraft tersebut.'
        }, { quoted: m });

    } catch (err) {
        console.error(err);
        lenwyreply('Terjadi kesalahan saat memproses permintaan.');
    }
}
break


case 'pinvt': {
    if (!q) return lenwyreply(`*Contoh ${prefix + command} https://pin.it/1dsNeQAfe*`);
    lenwyreply(mess.wait);

    try {
        // Menambahkan emoji ⏱️ pada pesan saat proses dimulai
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "⏱️", // Emoji saat proses
                key: m.key,
            }
        });

        // API URL
        const apiUrl = `https://api.ryzendesu.vip/api/downloader/aiodown?url=${encodeURIComponent(q)}`;

        // Fetch data dari API
        const response = await axios.get(apiUrl);

        if (response.data.success) {
            const result = response.data.quality;

            for (let media of result) {
                if (media.url.endsWith('.mp4')) {
                    // Kirim video
                    const videoBuffer = await axios.get(media.url, { responseType: 'arraybuffer' });
                    await lenwy.sendMessage(from, { video: videoBuffer.data, caption: `Quality: ${media.quality}` }, { quoted: m });
                }
            }
        } else {
            lenwyreply('Gagal mengambil data dari API.');
        }

        // Setelah proses selesai, beri reaksi dengan emoji ✅
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅", // Emoji selesai
                key: m.key,
            }
        });

    } catch (err) {
        lenwyreply(`Terjadi kesalahan: ${err.message}`);
    }
}
break

case 'twitter2': {
    if (!text) return lenwyreply('Mohon masukkan URL tweet yang ingin diunduh.');

    lenwyreply('Sedang mencari video... ⚡🔍');

    try {
        // Meminta data video dari API Twitter
        const res = await fetch(`https://api.rifandavinci.my.id/dl/twitter?url=${encodeURIComponent(text)}`);
        const response = await res.json();

        if (response.status !== 200) return lenwyreply('Terjadi kesalahan dalam mengambil data dari Twitter.');

        const videoUrl = response.result.url;
        const quality = response.result.quality;

        let teks = `*🎥 Video Twitter Berhasil Ditemukan!*\n\n`;
        teks += `*🔗 URL Video :* [Klik Disini](${videoUrl})\n`;
        teks += `*📊 Kualitas :* ${quality}\n`;

        // Mengirimkan hasil unduhan video ke chat
        await lenwyreply(teks);
        
        // Mengirimkan video ke pengguna
        await lenwy.sendMessage(msg.from, { video: { url: videoUrl }, caption: 'Video dari Twitter' }, { quoted: msg });

    } catch (err) {
        console.error(err);
        lenwyreply('Terjadi kesalahan saat mengambil data dari Twitter.');
    }
}
break

case 'x': {
    if (!text) return lenwyreply('Mohon masukkan URL x yang ingin diunduh.');

    lenwyreply('Sedang mencari video... ⚡🔍');

    try {
        // Meminta data video dari API Twitter
        const res = await fetch(`https://api.rifandavinci.my.id/dl/twitter?url=${encodeURIComponent(text)}`);
        const response = await res.json();

        if (response.status !== 200) return lenwyreply('Terjadi kesalahan dalam mengambil data dari x.');

        const videoUrl = response.result.url;
        const quality = response.result.quality;

        let teks = `*🎥 Video Twitter Berhasil Ditemukan!*\n\n`;
        teks += `*🔗 URL Video :* [Klik Disini](${videoUrl})\n`;
        teks += `*📊 Kualitas :* ${quality}\n`;

        // Mengirimkan hasil unduhan video ke chat
        await lenwyreply(teks);
        
        // Mengirimkan video ke pengguna
        await lenwy.sendMessage(msg.from, { video: { url: videoUrl }, caption: 'Video dari X' }, { quoted: msg });

    } catch (err) {
        console.error(err);
        lenwyreply('Terjadi kesalahan saat mengambil data dari x.');
    }
}
break

case 'harilibur': {
    if (!text) return lenwyreply('Mohon masukkan tahun yang valid (misalnya: 2024).');
    
    lenwyreply('Proses 🗿');
    
    try {
        // Meminta data libur nasional dari API
        const res = await fetch(`https://api.rifandavinci.my.id/search/publicholidays?year=${text}`);
        const response = await res.json();
        
        if (response.status !== 200) return lenwyreply('Terjadi kesalahan dalam mengambil data libur nasional.');
        
        let teks = `*📅 Libur Nasional Tahun ${text}*\n\n`;
        
        // Mengolah hasil response dan menambahkan informasi ke teks
        for (let holiday of response.result) {
            teks += `*◦ Nama Hari Libur :* ${holiday.name}\n`;
            teks += `*◦ Tanggal :* ${holiday.date}\n`;
            teks += `*◦ Hari :* ${holiday.day}\n\n`;
        }
        
        // Mengirimkan hasil libur nasional ke chat
        await lenwyreply(teks);

    } catch (err) {
        console.error(err);
        lenwyreply('Terjadi kesalahan saat mengambil data libur nasional.');
    }

} // break diletakkan di sini, paling akhir
break

case 'bukalapaksearch': {
    if (!text) return lenwyreply('Mohon masukkan query pencarian (misalnya: sepatu sekolah).');

    lenwyreply('Sedang mencari... ⚡🔍');

    try {
        // Meminta data pencarian dari API Bukalapak
        const res = await fetch(`https://api.rifandavinci.my.id/search/bukalapak?q=${encodeURIComponent(text)}`);
        const response = await res.json();
        
        if (response.status !== 200) return lenwyreply('Terjadi kesalahan dalam mengambil data dari Bukalapak.');
        
        let teks = `*🔎 Hasil Pencarian Bukalapak untuk "${text}"*\n\n`;

        // Mengolah hasil response dan menambahkan informasi ke teks
        for (let item of response.result) {
            teks += `*◦ Nama Produk :* ${item.title}\n`;
            teks += `*◦ Harga :* ${item.harga}\n`;
            teks += `*◦ Rating :* ${item.rating}\n`;
            teks += `*◦ Terjual :* ${item.terjual}\n`;
            teks += `*◦ Lokasi Toko :* ${item.store.lokasi}\n`;
            teks += `*◦ Nama Toko :* [${item.store.nama}](${item.store.link})\n`;
            teks += `*◦ Link Produk :* [${item.title}](${item.link})\n\n`;
            teks += `![Image](${item.image})\n\n`;
        }

        // Mengirimkan hasil pencarian ke chat
        await lenwyreply(teks);

    } catch (err) {
        console.error(err);
        lenwyreply('Terjadi kesalahan saat mengambil data dari Bukalapak.');
    }
}
break

case 'formatjp': {
    if (!isCreator) return lenwyreply(mess.owner)

    lenwyreply(`*FORMAT JASPOST BY kayzuMD*
(BUKAN AKUN MILIK ADMIN)
                   
AKUN :
LOG :
SPEK :
HARGA :
MC :
NAMA PEMBELI :

#📝NOTE‼️: WAJIB MENGGUNAKAN JASA ADMIN KayzuMD AGAR TERHINDAR DARI PENIPUAN
*#BEE A SMART BUYER & SELLER*`)
}
break

case 'formatneed': {
    if (!isCreator) return lenwyreply(mess.owner)

    lenwyreply(`*FORMAT JASA NEED AKUN BY KayzuMd*

NAMA PEMILIK : 
AKUN :
LOGIN :
HARGA : 
SPEK AKUN :  
MC :                                                               
📝𝐍𝐎𝐓𝐄 : 
*WAJIB MENGGUNAKAN JASA ADMIN KayzuMd AGAR TERHINDAR DARI PENIPUAN*
*#BEE A SMART BUYER & SELLER*`)
}
break

case 'feerekber': {
    if (!isCreator) return lenwyreply(mess.owner)

    lenwyreply(`FEE BER² KayzuMD
• 0 - 99K ≠ 5K
• 100K - 150K ≠ 10K
• 151K - 200K ≠ 15K
• 201K - 324K ≠ 20K
• 325K - 400K ≠ 25K
• 401K - 500K ≠ 30K
• 501K - 599K ≠ 35K
• 600K - 699K ≠ 40K
• 700K - 799K ≠ 45K
• 800K - 1JT ≠ 50K
• 1,1JT - 1,7JT ≠ 55K`)
}
break

case 'rules': {
    lenwyreply(`*Peraturan Grup*

1. Hormati sesama anggota.
2. Tidak boleh spam/iklan.
3. Tidak boleh konten dewasa/SARA.
4. Tidak boleh aktivitas ilegal.
5. Tidak boleh informasi palsu.

*Komunikasi*

1. Bahasa sopan.
2. Tidak boleh hina/merendahkan.
3. Tidak boleh debat.
4. Gunakan emoji bijak.

*Administratif*

1. Hanya anggota yang diizinkan mengirim pesan.
2. Admin berhak menghapus/memblokir pelanggar.
3. Peraturan dapat berubah.

*Sanksi*

1. Peringatan 1: 1 hari.
2. Peringatan 2: 3 hari.
3. Pelanggaran berulang: keluar.

*Kontak Admin*

Nama: Kay  
No: 6289673462138  
Email: baimandrawan6@gmail.com

*Catatan:*  
Peraturan berlaku sejak 11 Januari 2025. Baca dan pahami peraturan ini.`)
}
break

case 'bokep': {
    if (!isCreator) return lenwyreply(mess.owner); // Periksa apakah pengguna adalah creator/owner

    try {
        // Daftar link video bokep
        const videoLinks = [
            'https://telegra.ph/file/e05d0a178f29d93ef0b91.mp4',
            'https://telegra.ph/file/bded55046397acf85835c.mp4',
            'https://telegra.ph/file/9bfae35f750bf5f450dfc.mp4',
            'https://telegra.ph/file/8d5834a8799e126467305.mp4',
            'https://telegra.ph/file/6fa263a716f07ea3dcc03.mp4',
            'https://telegra.ph/file/0800c4e6ab6ceddde0c38.mp4'
        ];

        // Pilih video secara acak
        const randomVideo = videoLinks[Math.floor(Math.random() * videoLinks.length)];
        const lenwycap = 'Mana Tahan 🤤';

        // Kirimkan video ke pengguna
        await lenwy.sendMessage(m.chat, { video: { url: randomVideo }, caption: lenwycap }, { quoted: m });

    } catch (error) {
        return lenwyreply(mess.error); // Pesan kesalahan jika terjadi error
    }
}
break

case 'bocil': {
    if (!isCreator) return lenwyreply(mess.owner); // Periksa apakah pengguna adalah creator/owner

    try {
        // Daftar link video
        const videoLinks = [
            "https://b.top4top.io/m_1931yxodg0.mp4",
            "https://k.top4top.io/m_193161p380.mp4",
            "https://l.top4top.io/m_1931i4g3p1.mp4",
            "https://a.top4top.io/m_1931tjlio2.mp4",
            "https://g.top4top.io/m_1931z2mc40.mp4",
            "https://h.top4top.io/m_1931auyof1.mp4",
            "https://i.top4top.io/m_19315hrle2.mp4",
            "https://j.top4top.io/m_1931xul5a3.mp4",
            "https://l.top4top.io/m_1931o92nr0.mp4",
            "https://a.top4top.io/m_1931j1rh21.mp4",
            "https://b.top4top.io/m_1931iaqpg2.mp4",
            "https://c.top4top.io/m_1931s5zlj3.mp4",
            "https://d.top4top.io/m_1931x0g5a4.mp4",
            "https://i.top4top.io/m_1931oj76n0.mp4",
            "https://j.top4top.io/m_19319gl3d1.mp4",
            "https://k.top4top.io/m_1931u52cq2.mp4",
            "https://l.top4top.io/m_1931mvgj73.mp4",
            "https://a.top4top.io/m_1931u07oz4.mp4",
            "https://j.top4top.io/m_1931h1fo60.mp4",
            "https://k.top4top.io/m_1931mro3u1.mp4",
            "http://sansekai.my.id/ptl_repost/120664457_338629710563119_6615226849280369453_n.mp4",
            "https://l.top4top.io/m_1931kx0ac2.mp4",
            "https://a.top4top.io/m_1931g9ezq3.mp4",
            "https://b.top4top.io/m_1931plin14.mp4",
            "https://c.top4top.io/m_1931aaxri5.mp4",
            "https://d.top4top.io/m_1931ijzzn6.mp4",
            "https://e.top4top.io/m_1931ugycd7.mp4",
            "https://f.top4top.io/m_1931l14nk8.mp4",
            "https://g.top4top.io/m_1931crgqt9.mp4"
        ];

        // Pilih video secara acak
        const randomVideo = videoLinks[Math.floor(Math.random() * videoLinks.length)];
        const lenwycap = 'Mana Tahan 🤤';

        // Kirimkan video secara pribadi ke pengguna
        await lenwy.sendMessage(m.sender, { video: { url: randomVideo }, caption: lenwycap });

        // Konfirmasi ke grup atau chat bahwa video sudah dikirim secara pribadi
        lenwyreply('Video telah dikirim secara pribadi ke chat Anda!');
        
    } catch (error) {
        return lenwyreply(mess.error); // Pesan kesalahan jika terjadi error
    }
}
break

case 'tobrut': {
    if (!isCreator) return lenwyreply(mess.owner); // Periksa apakah pengguna adalah creator/owner

    try {
        const videoLinks = [
            "https://telegra.ph/file/26e4dff45a31ee8225dd3.mp4",
            "https://telegra.ph/file/cbec7f1fb107e3a6ad22d.mp4",
            "https://telegra.ph/file/ba0aaf03ebca2093f69fe.mp4",
            "https://telegra.ph/file/a11bcb3cfc79b41d0cec7.mp4",
            "https://telegra.ph/file/d70b16f3d6bc1e27ea165.mp4",
            "https://telegra.ph/file/1390e9e192bb7e464f64d.mp4",
            "https://telegra.ph/file/94836946afaff5cda50b5.mp4",
            "https://telegra.ph/file/064258e8efeb464549b5b.mp4",
            "https://telegra.ph/file/ccbb0ca9f95f6a4443217.mp4",
            "https://telegra.ph/file/ad88681101c0cf868805b.mp4",
            "https://telegra.ph/file/0f01359df3d7607aed4cf.mp4",
            "https://telegra.ph/file/288614816d53ac8eae38f.mp4",
            "https://telegra.ph/file/09e2f3d9c01b2305784fa.mp4"
        ];

        // Pilih video secara acak dari daftar
        const randomVideo = videoLinks[Math.floor(Math.random() * videoLinks.length)];

        // Kirim pesan tunggu ke chat utama
        await lenwyreply('Wait Bang, dikirim lewat private chat.');

        // Kirim video ke private chat pengguna
        await lenwy.sendMessage(m.sender, { video: { url: randomVideo }, caption: 'Ini video tobrutnya 🥵 (Private)' });

    } catch (error) {
        lenwyreply(mess.error); // Tampilkan pesan error jika ada masalah
    }
}
break

case 'paptt': {
    if (!isCreator) return lenwyreply(mess.owner); // Pastikan hanya creator yang bisa menggunakan fitur ini

    try {
        const mediaLinksJPG = [
            "https://telegra.ph/file/a5730f376956d82f9689c.jpg",
            "https://telegra.ph/file/34d9348cd0b420eca47e5.jpg",
            "https://telegra.ph/file/73c0fecd276c19560133e.jpg",
            "https://telegra.ph/file/af029472c3fcf859fd281.jpg",
            "https://telegra.ph/file/0e5be819fa70516f63766.jpg",
            "https://telegra.ph/file/29146a2c1a9836c01f5a3.jpg",
            "https://telegra.ph/file/85883c0024081ffb551b8.jpg",
            "https://telegra.ph/file/d8b79ac5e98796efd9d7d.jpg",
            "https://telegra.ph/file/267744a1a8c897b1636b9.jpg"
        ];

        // Pilih secara acak media JPG
        const randomJPG = mediaLinksJPG[Math.floor(Math.random() * mediaLinksJPG.length)];

        // Kirim pesan 'Foto akan dikirim di chat pribadi' dengan emoji
        await lenwyreply('Foto akan dikirim di chat pribadi 😋');

        // Kirim gambar ke pengguna secara pribadi (DM) dengan caption
        await lenwy.sendMessage(m.sender, { 
            image: { url: randomJPG }, 
            caption: 'Mana tahan 🤤' 
        });

    } catch (error) {
        lenwyreply(mess.error); // Jika terjadi error, tampilkan pesan error
    }
}
break

case 'paptt2': {
    if (!isCreator) return lenwyreply(mess.owner); // Pastikan hanya creator yang bisa menggunakan fitur ini

    try {
        const mediaLinksMP4 = [
            "https://telegra.ph/file/5c62d66881100db561c9f.mp4",
            "https://telegra.ph/file/0c8d173a9cb44fe54f3d3.mp4",
            "https://telegra.ph/file/b58a5b8177521565c503b.mp4"
        ];

        // Pilih secara acak media MP4
        const randomMP4 = mediaLinksMP4[Math.floor(Math.random() * mediaLinksMP4.length)];

        // Kirim pesan 'Video akan dikirim di chat pribadi' dengan emoji
        await lenwyreply('Video akan dikirim di chat pribadi 😋');

        // Kirim video ke pengguna secara pribadi (DM) dengan caption
        await lenwy.sendMessage(m.sender, { 
            video: { url: randomMP4 }, 
            caption: 'Mana tahan 🤤' 
        });

    } catch (error) {
        lenwyreply(mess.error); // Jika terjadi error, tampilkan pesan error
    }
}
break


case 'emoji': {
    const axios = require('axios');

    if (!text) return lenwyreply("Contoh: .emoji 😅");

    try {
        // URL API dengan emoji dan apikey
        const apiUrl = `https://api.botcahx.eu.org/api/emoji/apple?emoji=${encodeURIComponent(text)}&apikey=kayganzz`;

        // Ambil data dari API
        const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });

        // Kirim gambar hasil API
        await lenwy.sendMessage(
            m.chat,
            { 
                image: Buffer.from(response.data), 
                caption: 'Berikut adalah emoji versi Apple.' 
            }, 
            { quoted: m }
        );
    } catch (error) {
        console.error(error);
        lenwyreply('Terjadi kesalahan saat memproses emoji.');
    }
}
break

case 'videy': {
    // Cek apakah pengguna adalah Premium
    if (!isPrem) return lenwyreply('Fitur ini hanya untuk pengguna Premium.');
    if (!args[0]) return lenwyreply('Harap masukkan URL Videy!');
    
    let url = args[0]; // URL Videy dari pengguna

    try {
        lenwyreply('Sebentar yaa... sedang mencari video');

        // Panggil API untuk mendapatkan URL video
        let res = await axios.get('https://api.agatz.xyz/api/videydl', {
            params: {
                url: url
            }
        });

        // Parsing hasil API
        let result = res.data;
        if (result.status !== 200 || !result.data) return lenwyreply('Gagal mendapatkan video.');

        let videoUrl = result.data; // URL video dari API
        let caption = `*🎥 Videy Downloader 🎥*\n\n` +
                      `🔗 *Link Video:* [Download Video](${videoUrl})\n\n` +
                      `Tunggu sebentar, video sedang dikirim...`;

        lenwyreply(caption); // Kirim informasi video

        // Unduh video menggunakan URL
        let videoBuffer = await axios.get(videoUrl, { responseType: 'arraybuffer' });

        // Kirim video kepada pengguna
        await lenwy.sendMessage(m.chat, { 
            video: Buffer.from(videoBuffer.data), 
            caption: 'Berikut video yang kamu minta!'
        }, { quoted: m });

    } catch (err) {
        console.error(err);
        lenwyreply('Terjadi kesalahan saat memproses permintaan.');
    }
}
break

case 'ceritahoror': {
    try {
        // Memberikan balasan bahwa bot sedang memproses
        lenwyreply('Sabar, sedang membuat cerita...');

        // Panggil API untuk mendapatkan cerita horor
        const response = await axios.get('https://api.lolhuman.xyz/api/ceritahoror?apikey=5be94ede1b5591e1d3d85392');
        const data = response.data;

        if (data.status !== 200) {
            return lenwyreply('Gagal mengambil cerita horor.');
        }

        // Ambil data cerita horor dari response API
        const title = data.result.title;
        const thumbnail = data.result.thumbnail;
        const desc = data.result.desc;
        const story = data.result.story;

        // Format pesan untuk dikirim ke pengguna
        let message = `*📚 Cerita Horor*\n\n` +
                      `📝 *Judul:* ${title}\n` +
                      `📷 *Thumbnail:* ${thumbnail}\n\n` +
                      `🔍 *Deskripsi:* ${desc}\n\n` +
                      `💀 *Cerita:* ${story}\n`;

        // Kirimkan pesan cerita horor ke pengguna
        lenwyreply(message);
    } catch (err) {
        console.error(err);
        lenwyreply('Terjadi kesalahan saat memproses permintaan cerita horor.');
    }
}
break

case 'cerpen': {
    try {
        // Memberikan balasan bahwa bot sedang memproses
        lenwyreply('Sabar, sedang membuat cerpen...');

        // Panggil API untuk mendapatkan cerpen
        const response = await axios.get('https://api.lolhuman.xyz/api/cerpen?apikey=5be94ede1b5591e1d3d85392');
        const data = response.data;

        if (data.status !== 200) {
            return lenwyreply('Gagal mengambil cerpen.');
        }

        // Ambil data cerpen dari response API
        const title = data.result.title;
        const creator = data.result.creator;
        const cerpen = data.result.cerpen;

        // Format pesan untuk dikirim ke pengguna
        let message = `*📚 Cerpen*\n\n` +
                      `📝 *Judul:* ${title}\n` +
                      `✍️ *Penulis:* ${creator}\n\n` +
                      `💭 *Cerpen:* \n${cerpen}\n`;

        // Kirimkan pesan cerpen ke pengguna
        lenwyreply(message);
    } catch (err) {
        console.error(err);
        lenwyreply('Terjadi kesalahan saat memproses permintaan cerpen.');
    }
}
break

case 'cerpenremaja': {
  lenwyreply('*Sabar ya, lagi nyari cerpen...*');

  try {
    // Ambil data dari API
    const response = await fetch('https://api.botcahx.eu.org/api/story/cerpen?type=remaja&apikey=kayganzz');
    const result = await response.json();

    if (result.status && result.result) {
      const title = result.result.title;
      const author = result.result.author;
      const cerita = result.result.cerita;

      // Kirim cerpen jika tersedia
      lenwyreply(`*Judul:* ${title}\n*Penulis:* ${author}\n\n${cerita}`);
    } else {
      lenwyreply('*Maaf, tidak dapat menemukan cerpen saat ini.*');
    }
  } catch (error) {
    console.error("Error:", error);
    lenwyreply('*Terjadi kesalahan saat mengambil cerpen, coba lagi nanti.*');
  }
}
break

case 'cerpenanak': {
  lenwyreply('*Sabar ya, lagi nyari cerpen anak...*');

  try {
    // Ambil data dari API cerpen anak
    const response = await fetch('https://api.botcahx.eu.org/api/story/cerpen?type=anak&apikey=kayganzz');
    const result = await response.json();

    if (result.status && result.result) {
      const title = result.result.title;
      const author = result.result.author;
      const kategori = result.result.kategori;
      const cerita = result.result.cerita;

      // Kirim cerpen anak jika tersedia
      lenwyreply(`*Judul:* ${title}\n*Penulis:* ${author}\n*Kategori:* ${kategori}\n\n${cerita}`);
    } else {
      lenwyreply('*Maaf, tidak dapat menemukan cerpen anak saat ini.*');
    }
  } catch (error) {
    console.error("Error:", error);
    lenwyreply('*Terjadi kesalahan saat mengambil cerpen anak, coba lagi nanti.*');
  }
}
break

case 'cerpenmisteri': {
  lenwyreply('*Sabar ya, lagi nyari cerpen misteri...*');

  try {
    // Ambil data dari API cerpen misteri
    const response = await fetch('https://api.botcahx.eu.org/api/story/cerpen?type=misteri&apikey=kayganzz');
    const result = await response.json();

    if (result.status && result.result) {
      const title = result.result.title;
      const author = result.result.author;
      const kategori = result.result.kategori;
      const cerita = result.result.cerita;

      // Kirim cerpen misteri jika tersedia
      lenwyreply(`*Judul:* ${title}\n*Penulis:* ${author}\n*Kategori:* ${kategori}\n\n${cerita}`);
    } else {
      lenwyreply('*Maaf, tidak dapat menemukan cerpen misteri saat ini.*');
    }
  } catch (error) {
    console.error("Error:", error);
    lenwyreply('*Terjadi kesalahan saat mengambil cerpen misteri, coba lagi nanti.*');
  }
}
break

case 'cerpencinta': {
  lenwyreply('*Sabar ya, lagi nyari cerpen cinta...*');

  try {
    // Ambil data dari API cerpen cinta
    const response = await fetch('https://api.botcahx.eu.org/api/story/cerpen?type=cinta&apikey=kayganzz');
    const result = await response.json();

    if (result.status && result.result) {
      const title = result.result.title;
      const author = result.result.author;
      const kategori = result.result.kategori;
      const cerita = result.result.cerita;

      // Kirim cerpen cinta jika tersedia
      lenwyreply(`*Judul:* ${title}\n*Penulis:* ${author}\n*Kategori:* ${kategori}\n\n${cerita}`);
    } else {
      lenwyreply('*Maaf, tidak dapat menemukan cerpen cinta saat ini.*');
    }
  } catch (error) {
    console.error("Error:", error);
    lenwyreply('*Terjadi kesalahan saat mengambil cerpen cinta, coba lagi nanti.*');
  }
}
break

case 'cerpenbudaya': {
  lenwyreply('*Sabar ya, lagi nyari cerpen budaya...*');

  try {
    // Ambil data dari API cerpen budaya
    const response = await fetch('https://api.botcahx.eu.org/api/story/cerpen?type=budaya&apikey=kayganzz');
    const result = await response.json();

    if (result.status && result.result) {
      const title = result.result.title;
      const author = result.result.author;
      const kategori = result.result.kategori;
      const cerita = result.result.cerita;

      // Kirim cerpen budaya jika tersedia
      lenwyreply(`*Judul:* ${title}\n*Penulis:* ${author}\n*Kategori:* ${kategori}\n\n${cerita}`);
    } else {
      lenwyreply('*Maaf, tidak dapat menemukan cerpen budaya saat ini.*');
    }
  } catch (error) {
    console.error("Error:", error);
    lenwyreply('*Terjadi kesalahan saat mengambil cerpen budaya, coba lagi nanti.*');
  }
}
break

case 'cerpen2': {
    try {
        // Memberikan balasan bahwa bot sedang memproses
        lenwyreply('Sabar, sedang membuat cerpen...');

        // Panggil API untuk mendapatkan cerpen
        const response = await axios.get('https://api.lolhuman.xyz/api/cerpen?apikey=5be94ede1b5591e1d3d85392');
        const data = response.data;

        if (data.status !== 200) {
            return lenwyreply('Gagal mengambil cerpen.');
        }

        // Ambil data cerpen dari response API
        const title = data.result.title;
        const creator = data.result.creator;
        const cerpen = data.result.cerpen;

        // Format pesan untuk dikirim ke pengguna
        let message = `*📚 Cerpen*\n\n` +
                      `📝 *Judul:* ${title}\n` +
                      `✍️ *Penulis:* ${creator}\n\n` +
                      `💭 *Cerpen:* \n${cerpen}\n`;

        // Kirimkan pesan cerpen ke pengguna
        lenwyreply(message);
    } catch (err) {
        console.error(err);
        lenwyreply('Terjadi kesalahan saat memproses permintaan cerpen.');
    }
}
break

case 'cerpenremaja': {
  lenwyreply('*Sabar ya, lagi nyari cerpen...*');

  try {
    // Ambil data dari API
    const response = await fetch('https://api.botcahx.eu.org/api/story/cerpen?type=remaja&apikey=kayganzz');
    const result = await response.json();

    if (result.status && result.result) {
      const title = result.result.title;
      const author = result.result.author;
      const cerita = result.result.cerita;

      // Kirim cerpen jika tersedia
      lenwyreply(`*Judul:* ${title}\n*Penulis:* ${author}\n\n${cerita}`);
    } else {
      lenwyreply('*Maaf, tidak dapat menemukan cerpen saat ini.*');
    }
  } catch (error) {
    console.error("Error:", error);
    lenwyreply('*Terjadi kesalahan saat mengambil cerpen, coba lagi nanti.*');
  }
}
break

case 'cerpenanak': {
  lenwyreply('*Sabar ya, lagi nyari cerpen anak...*');

  try {
    // Ambil data dari API cerpen anak
    const response = await fetch('https://api.botcahx.eu.org/api/story/cerpen?type=anak&apikey=kayganzz');
    const result = await response.json();

    if (result.status && result.result) {
      const title = result.result.title;
      const author = result.result.author;
      const kategori = result.result.kategori;
      const cerita = result.result.cerita;

      // Kirim cerpen anak jika tersedia
      lenwyreply(`*Judul:* ${title}\n*Penulis:* ${author}\n*Kategori:* ${kategori}\n\n${cerita}`);
    } else {
      lenwyreply('*Maaf, tidak dapat menemukan cerpen anak saat ini.*');
    }
  } catch (error) {
    console.error("Error:", error);
    lenwyreply('*Terjadi kesalahan saat mengambil cerpen anak, coba lagi nanti.*');
  }
}
break

case 'cerpenmisteri': {
  lenwyreply('*Sabar ya, lagi nyari cerpen misteri...*');

  try {
    // Ambil data dari API cerpen misteri
    const response = await fetch('https://api.botcahx.eu.org/api/story/cerpen?type=misteri&apikey=kayganzz');
    const result = await response.json();

    if (result.status && result.result) {
      const title = result.result.title;
      const author = result.result.author;
      const kategori = result.result.kategori;
      const cerita = result.result.cerita;

      // Kirim cerpen misteri jika tersedia
      lenwyreply(`*Judul:* ${title}\n*Penulis:* ${author}\n*Kategori:* ${kategori}\n\n${cerita}`);
    } else {
      lenwyreply('*Maaf, tidak dapat menemukan cerpen misteri saat ini.*');
    }
  } catch (error) {
    console.error("Error:", error);
    lenwyreply('*Terjadi kesalahan saat mengambil cerpen misteri, coba lagi nanti.*');
  }
}
break

case 'cerpencinta': {
  lenwyreply('*Sabar ya, lagi nyari cerpen cinta...*');

  try {
    // Ambil data dari API cerpen cinta
    const response = await fetch('https://api.botcahx.eu.org/api/story/cerpen?type=cinta&apikey=kayganzz');
    const result = await response.json();

    if (result.status && result.result) {
      const title = result.result.title;
      const author = result.result.author;
      const kategori = result.result.kategori;
      const cerita = result.result.cerita;

      // Kirim cerpen cinta jika tersedia
      lenwyreply(`*Judul:* ${title}\n*Penulis:* ${author}\n*Kategori:* ${kategori}\n\n${cerita}`);
    } else {
      lenwyreply('*Maaf, tidak dapat menemukan cerpen cinta saat ini.*');
    }
  } catch (error) {
    console.error("Error:", error);
    lenwyreply('*Terjadi kesalahan saat mengambil cerpen cinta, coba lagi nanti.*');
  }
}
break

case 'cerpenbudaya': {
  lenwyreply('*Sabar ya, lagi nyari cerpen budaya...*');

  try {
    // Ambil data dari API cerpen budaya
    const response = await fetch('https://api.botcahx.eu.org/api/story/cerpen?type=budaya&apikey=kayganzz');
    const result = await response.json();

    if (result.status && result.result) {
      const title = result.result.title;
      const author = result.result.author;
      const kategori = result.result.kategori;
      const cerita = result.result.cerita;

      // Kirim cerpen budaya jika tersedia
      lenwyreply(`*Judul:* ${title}\n*Penulis:* ${author}\n*Kategori:* ${kategori}\n\n${cerita}`);
    } else {
      lenwyreply('*Maaf, tidak dapat menemukan cerpen budaya saat ini.*');
    }
  } catch (error) {
    console.error("Error:", error);
    lenwyreply('*Terjadi kesalahan saat mengambil cerpen budaya, coba lagi nanti.*');
  }
}
break

case 'play2': {
    if (isBan) return lenwyreply('*Kamu Di Ban Owner*');
    if (args.length == 0) return lenwyreply('*Masukkan judul lagu atau kata kunci yang ingin dicari!*');

    // Cek limit hanya untuk user non-premium
    if (!isPrem && global.db.data.users[m.sender].limit < 5) return lenwyreply('*Limit Kamu Habis, Silahkan Hubunggi Kay/Tunggu besok*');
    if (!isPrem) global.db.data.users[m.sender].limit -= 5; // Mengurangi limit hanya jika bukan premium

    // Emoji react saat proses dimulai
    await lenwy.sendMessage(m.chat, {
        react: {
            text: "⏱️", // Emoji proses
            key: m.key,
        }
    });

    let query = args.join(' ');

    try {
        // Request ke API
        let response = await axios.get(`https://ochinpo-helper.hf.space/yt?query=${encodeURIComponent(query)}`);
        let res = response.data;

        if (!res.success || !res.result) {
            return lenwyreply('*Gagal mengambil data, coba kata kunci lain!*');
        }

        let result = res.result;

        // Data hasil pencarian
        let title = result.title;
        let url = result.url;
        let thumbnail = result.thumbnail;
        let duration = result.duration.timestamp;
        let views = result.views;
        let author = result.author.name;
        let audioUrl = result.download.audio;
        let videoUrl = result.download.video;

        // Kirim thumbnail dengan informasi video
        await lenwy.sendMessage(m.chat, {
            image: { url: thumbnail },
            caption: `🎧 *Informasi Video YouTube* 🎵\n\n` +
                     `📌 *Judul:* ${title}\n` +
                     `👀 *Penonton:* ${views.toLocaleString()} kali\n` +
                     `🎤 *Pengarang:* ${author}\n` +
                     `📅 *Diunggah:* ${result.ago}\n` +
                     `⏱️ *Durasi:* ${duration}\n` +
                     `🔗 *URL:* ${url}`
        });

        // Kirim video
        await lenwy.sendMessage(m.chat, {
            video: { url: videoUrl },
            caption: `🔍 *Hasil Pencarian:*\n` +
                     `📌 *Judul:* ${title}\n` +
                     `🎞 *Durasi:* ${duration}\n` +
                     `👤 *Channel:* ${author}\n` +
                     `👀 *Dilihat:* ${views.toLocaleString()} kali\n` +
                     `🌐 *Link Video:* ${url}`
        });

        // Kirim audio
        await lenwy.sendMessage(m.chat, {
            audio: { url: audioUrl },
            mimetype: 'audio/mpeg',
            fileName: `${title}.mp3`
        });

        // Emoji react selesai
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅", // Emoji selesai
                key: m.key,
            }
        });

    } catch (error) {
        console.error(error);
        lenwyreply('*Terjadi kesalahan saat memproses permintaan. Pastikan judul valid atau coba lagi nanti.*');

        // Emoji react jika terjadi kesalahan
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "❌", // Emoji error
                key: m.key,
            }
        });
    }
}
break

case 'play3': {
    const axios = require('axios');

    if (!text) return lenwyreply("Harap kirimkan query atau judul video YouTube yang ingin dicari.");

    // Cek limit hanya untuk user non-premium
    if (!isPrem && global.db.data.users[m.sender].limit < 5) return lenwyreply('*Limit Kamu Habis, Silahkan Hubunggi Kay/Tunggu besok*');
    if (!isPrem) global.db.data.users[m.sender].limit -= 5; // Mengurangi limit hanya jika bukan premium

    const query = text.trim();
    const apiUrl = `https://ochinpo-helper.hf.space/yt?query=${encodeURIComponent(query)}`;

    // Emoji react saat proses dimulai
    await lenwy.sendMessage(m.chat, {
        react: {
            text: "⏱️", // Emoji proses
            key: m.key,
        }
    });

    try {
        const res = await axios.get(apiUrl);
        if (res.data.success) {
            const videoUrl = res.data.result.url;
            const videoTitle = res.data.result.title;
            const videoThumbnail = res.data.result.thumbnail;
            const videoDuration = res.data.result.duration.timestamp;
            const videoDownloadUrl = res.data.result.download.video;
            const audioDownloadUrl = res.data.result.download.audio;

            // Kirim informasi video
            await lenwy.sendMessage(m.chat, {
                video: { url: videoDownloadUrl },
                caption: `🎬 *${videoTitle}*\n⏱️ *Durasi:* ${videoDuration}\n👀 *Views:* ${res.data.result.views}\n👤 *Uploader:* ${res.data.result.author.name}`,
                thumbnail: videoThumbnail,
            }, { quoted: m });

            // Kirim audio
            await lenwy.sendMessage(m.chat, {
                audio: { url: audioDownloadUrl },
                caption: `🎵 *Audio:* ${videoTitle}`,
                mimetype: 'audio/mpeg',
            }, { quoted: m });

            // Emoji react selesai
            await lenwy.sendMessage(m.chat, {
                react: {
                    text: "✅", // Emoji selesai
                    key: m.key,
                }
            });

        } else {
            lenwyreply("Gagal menemukan video. Coba lagi nanti.");
        }
    } catch (e) {
        console.error(e);
        lenwyreply("Terjadi kesalahan dalam memproses permintaan.");

        // Emoji react jika terjadi kesalahan
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "❌", // Emoji error
                key: m.key,
            }
        });
    }
}
break

case 'statistic': {
    try {
        // Memberikan balasan bahwa bot sedang memproses
        lenwyreply('Mengambil data statistik...');

        // Panggil API untuk mendapatkan data statistik
        const response = await axios.get('https://api.botcahx.eu.org/main/statistic');
        const data = response.data;

        if (!data.status) {
            return lenwyreply('Gagal mengambil data statistik.');
        }

        // Destrukturisasi data dari API
        const { memory, cpu, time, speed, info } = data;
        const cpu1 = cpu[0];
        const cpu2 = cpu[1];

        // Format pesan untuk dikirim ke pengguna
        let message = `*📊 Statistik Sistem*\n\n` +
                      `🧠 *Penggunaan Memori*: ${memory}\n` +
                      `⚙️ *CPU Core 1*:\n   - Model: ${cpu1.model}\n   - Kecepatan: ${cpu1.speed} MHz\n` +
                      `⚙️ *CPU Core 2*:\n   - Model: ${cpu2.model}\n   - Kecepatan: ${cpu2.speed} MHz\n` +
                      `⏰ *Waktu Server*: ${time}\n` +
                      `⚡ *Kecepatan Respon*: ${speed}\n\n` +
                      `👨‍💻 *Author*: ${info.author}\n`;

        // Kirimkan pesan ke pengguna
        lenwyreply(message);
    } catch (err) {
        console.error(err);
        lenwyreply('Terjadi kesalahan saat memproses permintaan statistik.');
    }
}
break


case 'animeinfo': {
    try {
        const fetch = require('node-fetch');
        if (!text) return lenwyreply('Masukkan nama anime yang ingin dicari, contoh: .animeinfo Roshidere');
        
        const res = await fetch(`https://api.lolhuman.xyz/api/anime?apikey=5be94ede1b5591e1d3d85392&query=${encodeURIComponent(text)}`);
        const json = await res.json();
        
        if (json.status === 200) {
            const anime = json.result;
            let message = `*Title (Romaji):* ${anime.title.romaji}\n`;
            message += `*Title (English):* ${anime.title.english}\n`;
            message += `*Title (Native):* ${anime.title.native}\n`;
            message += `*Format:* ${anime.format}\n`;
            message += `*Episodes:* ${anime.episodes}\n`;
            message += `*Duration:* ${anime.duration} minutes\n`;
            message += `*Status:* ${anime.status}\n`;
            message += `*Season:* ${anime.season} ${anime.seasonYear}\n`;
            message += `*Source:* ${anime.source}\n`;
            message += `*Genres:* ${anime.genres.join(', ')}\n`;
            message += `*Average Score:* ${anime.averageScore}\n`;
            message += `*Start Date:* ${anime.startDate.year}-${anime.startDate.month}-${anime.startDate.day}\n`;
            message += `*End Date:* ${anime.endDate.year}-${anime.endDate.month}-${anime.endDate.day}\n`;
            message += `*Description:* ${anime.description.replace(/<br>/g, '\n').replace(/<[^>]*>/g, '')}\n\n`;
            message += `*Synonyms:* ${anime.synonyms.join(', ')}\n`;
            message += `*Characters:*\n`;
            anime.characters.nodes.forEach((char, i) => {
                message += `  ${i + 1}. ${char.name.full} (${char.name.native})\n`;
            });
            message += `\n*Cover Image:* ${anime.coverImage.large}`;
            
            await lenwyreply(message); // Fungsi untuk mengirim balasan
        } else {
            await lenwyreply('Anime tidak ditemukan atau ada kesalahan.');
        }
    } catch (err) {
        console.error(err);
        await lenwyreply('Terjadi kesalahan saat memproses permintaan.');
    }
}
break

case 'anime': {
    try {
        // Cek apakah ada kata kunci
        if (!text) return lenwyreply('Masukkan kata kunci untuk mencari anime.\nContoh: *anime maou*');

        // Kirim pemberitahuan sedang mencari anime
        lenwyreply(`Sebentar... sedang mencari anime dengan kata kunci "${text}"...`);

        // Panggil API menggunakan kata kunci pengguna
        let apiUrl = `https://api.agatz.xyz/api/animebatch?message=${encodeURIComponent(text)}`;
        let res = await axios.get(apiUrl);

        if (res.data.status === 200 && res.data.data && res.data.data.data.length > 0) {
            let animeList = res.data.data.data; // Data daftar anime

            // Siapkan pesan output
            let result = `*Hasil Pencarian Anime: "${text}"*\n\n`;
            animeList.forEach((anime, index) => {
                result += `${index + 1}. *${anime.title}*\n`;
                result += `   🎯 Skor: ${anime.score}\n`;
                result += `   📺 Tipe: ${anime.type}\n`;
                result += `   🔗 Link: ${anime.url}\n\n`;
            });

            // Kirim hasil pencarian ke pengguna
            lenwyreply(result);

        } else {
            lenwyreply(`Tidak ditemukan anime dengan kata kunci "${text}". Coba kata kunci lain.`);
        }

    } catch (err) {
        console.error(err);
        lenwyreply('Terjadi kesalahan saat memproses permintaan.');
    }
}
break

case 'wattpad': {
    try {
        // Cek apakah ada kata kunci
        if (!text) return lenwyreply('Masukkan kata kunci untuk mencari cerita Wattpad.\nContoh: *wattpad cinta*');

        // Kirim pemberitahuan sedang mencari cerita
        lenwyreply(`Sebentar... sedang mencari cerita Wattpad berdasarkan kata kunci "${text}"...`);

        // Panggil API menggunakan kata kunci pengguna
        let apiUrl = `https://api.agatz.xyz/api/wattpad?message=${encodeURIComponent(text)}`;
        let res = await axios.get(apiUrl);

        if (res.data.status === 200 && res.data.data) {
            let wattpadStories = res.data.data; // Data cerita Wattpad

            // Siapkan pesan output
            let result = `*Hasil Pencarian Wattpad: "${text}"*\n\n`;
            wattpadStories.forEach((story, index) => {
                result += `${index + 1}. *${story.title}*\n`;
                result += `   Deskripsi: ${story.desc}\n`;
                result += `   📖 Pembaca: ${story.reads}\n`;
                result += `   👍 Vote: ${story.vote}\n`;
                result += `   📚 Bab: ${story.chapter}\n`;
                result += `   🔗 Link: ${story.link}\n\n`;
            });

            // Kirim hasil pencarian ke pengguna
            lenwyreply(result);

        } else {
            lenwyreply(`Tidak ditemukan cerita Wattpad dengan kata kunci "${text}". Coba kata kunci lain.`);
        }

    } catch (err) {
        console.error(err);
        lenwyreply('Terjadi kesalahan saat memproses permintaan.');
    }
}
break

case 'spotify': {
    if (!text) return lenwyreply('❌ Masukkan URL Spotify yang ingin diunduh!');
    
    try {
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "⏱️",
                key: m.key,
            }
        });

        const { spotifyDownloader } = require('./kiromi/kay/spotify.js');
        const result = await spotifyDownloader(text);

        let caption = `🎶 *Spotify Downloader*\n\n📌 *Judul:* ${result.title}\n🎤 *Artis:* ${result.artist}\n⏱ *Durasi:* ${result.duration}`;

        // Kirim Thumbnail terlebih dahulu
        await lenwy.sendMessage(m.chat, {
            image: { url: result.thumbnail },
            caption: caption,
        }, { quoted: m });

        // Kirim Audio setelah Thumbnail
await lenwy.sendMessage(m.chat, {
    audio: { url: result.audioUrl },
    mimetype: 'audio/mpeg',
    ptt: false, // Kalau mau dikirim sebagai voice note, ubah ke true
}, { quoted: m });

        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key,
            }
        });

    } catch (error) {
        console.error('Error Spotify Downloader:', error);
        lenwyreply('❌ Terjadi kesalahan saat memproses lagu.');
    }
}
break

case 'wiki': {
    if (!text) return lenwyreply(`*Masukkan kata yang ingin dicari!*`);
    lenwyreply(mess.wait);

    try {
        const axios = require('axios'); // Pastikan axios sudah diinstal

        // URL API dengan query yang dimasukkan oleh user
        const apiURL = `https://api.lolhuman.xyz/api/wiki?apikey=5be94ede1b5591e1d3d85392&query=${encodeURIComponent(text)}`;

        // Panggil API menggunakan axios
        const { data } = await axios.get(apiURL);

        // Validasi respons
        if (data && data.status === 200) {
            lenwyreply(`*Informasi Wiki:*\n\n${data.result}`);
        } else {
            lenwyreply(`❌ *Maaf, tidak ditemukan informasi untuk kata tersebut.*`);
        }
    } catch (error) {
        console.error("Error di case 'wiki':", error.message);
        lenwyreply(`❌ *Terjadi kesalahan saat memproses permintaan.*`);
    }
}
break

case 'searchbijak': {
    if (!args[0]) return lenwyreply('Harap masukkan kata kunci untuk mencari kutipan!');

    let query = args.join(' '); // Mengambil query dari argumen
    let apiUrl = `https://api.lolhuman.xyz/api/searchbijak?apikey=5be94ede1b5591e1d3d85392&query=${encodeURIComponent(query)}`;

    try {
        // Panggil API untuk mendapatkan kutipan bijak berdasarkan query
        let res = await axios.get(apiUrl);

        if (res.data.status === 200 && res.data.result && res.data.result.length > 0) {
            let quotes = res.data.result; // Daftar kutipan yang diterima dari API
            let randomQuote = quotes[Math.floor(Math.random() * quotes.length)]; // Pilih kutipan acak

            let caption = `*Kutipan Bijak tentang ${query}*:\n\n` +
                          `📝 *"${randomQuote.quote}"*\n` +
                          `- ${randomQuote.author}`;

            // Kirim kutipan
            lenwyreply(caption);

        } else {
            lenwyreply('Tidak ada kutipan yang ditemukan untuk kata kunci ini.');
        }

    } catch (err) {
        console.error(err);
        lenwyreply('Terjadi kesalahan saat memproses permintaan.');
    }
}
break

case 'stickerwa': {
    if (!args[0]) return lenwyreply('Harap masukkan kata kunci untuk mencari stiker!');

    let query = args.join(' '); // Mengambil query dari argumen
    let apiUrl = `https://api.lolhuman.xyz/api/stickerwa?apikey=5be94ede1b5591e1d3d85392&query=${encodeURIComponent(query)}`;

    try {
        // Kirim pesan pemberitahuan sedang mencari
        lenwyreply('Sebentar... sedang mencari sticker...');

        // Panggil API untuk mendapatkan stiker
        let res = await axios.get(apiUrl);

        if (res.data.status === 200 && res.data.result && res.data.result.length > 0) {
            let stickers = res.data.result[0].stickers; // Daftar stiker yang diterima dari API
            let title = res.data.result[0].title; // Judul stiker
            let author = res.data.result[0].author; // Nama pembuat

            let caption = `*Stiker "${title}" oleh ${author}*:\n\n` +
                          `Silakan pilih stiker berikut:`;

            // Kirim beberapa stiker ke chat pribadi pengguna
            for (let stickerUrl of stickers) {
                await lenwy.sendMessage(m.sender, { sticker: { url: stickerUrl }, caption: caption }, { quoted: m });
            }

            // Kirim konfirmasi bahwa stiker sudah berhasil dikirim
            lenwyreply('Berhasil dikirim secara pribadi, harap cek di chat.');

        } else {
            lenwyreply('Tidak ada stiker yang ditemukan untuk kata kunci ini.');
        }

    } catch (err) {
        console.error(err);
        lenwyreply('Terjadi kesalahan saat memproses permintaan.');
    }
}
break

case 'wallpaper': {
    if (!args[0]) return lenwyreply('Harap masukkan kata kunci untuk mencari wallpaper!');

    let query = args.join(' '); // Mengambil query dari argumen
    let apiUrl = `https://api.lolhuman.xyz/api/unsplash?apikey=5be94ede1b5591e1d3d85392&query=${encodeURIComponent(query)}`;

    try {
        // Kirim pesan pemberitahuan sedang mencari
        lenwyreply('Sebentar... sedang mencari wallpaper...');

        // Panggil API untuk mendapatkan wallpaper
        let res = await axios.get(apiUrl);

        if (res.data.status === 200 && res.data.result && res.data.result.length > 0) {
            let wallpapers = res.data.result; // Semua gambar yang ditemukan (array)

            // Kirim beberapa gambar (misalnya 5 gambar pertama)
            for (let i = 0; i < Math.min(wallpapers.length, 5); i++) {
                let wallpaperUrl = wallpapers[i]; // Ambil URL wallpaper ke-i
                // Kirim gambar ke chat pribadi pengguna
                await lenwy.sendMessage(m.sender, { image: { url: wallpaperUrl } }, { quoted: m });
            }

            // Kirim konfirmasi bahwa wallpaper berhasil dikirim
            lenwyreply('Beberapa wallpaper berhasil dikirim secara pribadi, harap cek di chat.');

        } else {
            lenwyreply('Tidak ada wallpaper yang ditemukan untuk kata kunci ini.');
        }

    } catch (err) {
        console.error(err);
        lenwyreply('Terjadi kesalahan saat memproses permintaan.');
    }
}
break

case 'pixiv1': {
const { pixivScraper } = require('./kiromi/kay/pixiv.js');

    if (!text) return lenwyreply(`• *Contoh:* ${command} anime girl`);
    
    lenwyreply('🕒 *Sedang mencari di Pixiv...*');

    let result = await pixivScraper(text);

    if (!result.status) return lenwyreply(`❌ ${result.message}`);

    let responseText = `✅ *Hasil Pencarian di Pixiv:*\n\n${JSON.stringify(result.results, null, 2)}`;

    lenwyreply(responseText);
}
break

case 'searchplace': {
    if (!args[0]) return lenwyreply('Harap masukkan kata kunci untuk mencari tempat!');

    let query = args.join(' '); // Mengambil query dari argumen
    let apiUrl = `https://api.lolhuman.xyz/api/searchplace?apikey=5be94ede1b5591e1d3d85392&query=${encodeURIComponent(query)}`;

    try {
        // Kirim pesan pemberitahuan sedang mencari
        lenwyreply('Sebentar... sedang mencari lokasi...');

        // Panggil API untuk mencari tempat
        let res = await axios.get(apiUrl);

        if (res.data.status === 200 && res.data.result && res.data.result.length > 0) {
            let result = res.data.result[0]; // Ambil hasil pertama dari array

            let caption = `*Hasil pencarian untuk tempat "${query}"*:\n\n` +
                          `Nama Tempat: ${result.display_name}\n` +
                          `Latitude: ${result.latitude}\n` +
                          `Longitude: ${result.longitude}\n\n` +
                          `Detail:\n` +
                          `Negara: ${result.full.country}\n` +
                          `Wilayah: ${result.full.region}\n` +
                          `Provinsi: ${result.full.state}\n` +
                          `Kode Negara: ${result.full.country_code}\n` +
                          `Kode Provinsi: ${result.full['ISO3166-2-lvl4']}`;

            // Kirim hasil pencarian ke chat pribadi pengguna
            lenwyreply(caption);

        } else {
            lenwyreply('Tidak ditemukan tempat untuk kata kunci ini.');
        }

    } catch (err) {
        console.error(err);
        lenwyreply('Terjadi kesalahan saat memproses permintaan.');
    }
}
break


case 'gsmarena': {
    if (!text) {
        return lenwyreply(`*Format salah!*\nGunakan format: /gsmarena <nama perangkat>\nContoh: /gsmarena iPhone 12`);
    }

    try {
        const axios = require('axios');
        const device = text.trim();
        lenwyreply(`*Tunggu sebentar, mencari informasi untuk "${device}"...*`);

        const apiURL = `https://fastrestapis.fasturl.cloud/search/gsmarena/advanced?query=${encodeURIComponent(device)}`;
        const { data } = await axios.get(apiURL);

        if (data.status !== 200 || !data.result) {
            return lenwyreply(`*Perangkat "${device}" tidak ditemukan.*`);
        }

        const {
            name,
            releaseDate,
            weight,
            os,
            storage,
            displaySize,
            displayResolution,
            camera,
            video,
            ram,
            chipset,
            battery,
            charging,
            imageUrl,
        } = data.result;

        const caption = `*ðŸ“± Informasi Perangkat: ${name}*\n\n` +
            `ðŸ“… *Rilis*: ${releaseDate}\n` +
            `âš– *Berat*: ${weight}\n` +
            `ðŸ–¥ *Sistem Operasi*: ${os}\n` +
            `ðŸ’¾ *Penyimpanan*: ${storage}\n` +
            `ðŸ“º *Layar*: ${displaySize} (${displayResolution})\n` +
            `ðŸ“¸ *Kamera Utama*: ${camera} MP\n` +
            `ðŸŽ¥ *Video*: ${video}\n` +
            `ðŸ§  *RAM*: ${ram} GB\n` +
            `âš™ *Chipset*: ${chipset}\n` +
            `ðŸ”‹ *Baterai*: ${battery} mAh\n` +
            `âš¡ *Pengisian Daya*: ${charging}\n\n` +
            `_Dapatkan spesifikasi lengkapnya di GSMArena!_`;

        // Kirim gambar dengan keterangan
        await lenwy.sendMessage(m.chat, {
            image: { url: imageUrl },
            caption: caption,
        }, { quoted: m });

    } catch (error) {
        console.error("âš  Error:", error.message);
        lenwyreply('*Terjadi kesalahan saat mengambil data perangkat.*');
    }
}
break

case 'carikodepos': {
    try {
        if (!text) return lenwyreply('Masukkan nama wilayah untuk mencari kode pos.\nContoh: *kodepos Medan*');

        lenwyreply(`Sebentar... sedang mencari kode pos untuk "${text}"...`);

        let apiUrl = `https://api.agatz.xyz/api/kodepos?message=${encodeURIComponent(text)}`;
        let res = await axios.get(apiUrl);

        // Debugging response
        console.log(res.data);

        // Memeriksa apakah status == 200 dan ada data
        if (res.data.status === 200 && res.data.data && res.data.data.length > 0) {
            let kodePosData = res.data.data;

            let result = `*Hasil Pencarian Kode Pos untuk "${text}":*\n\n`;

            kodePosData.forEach((item, index) => {
                result += `${index + 1}. **Kelurahan**: ${item.kelurahan}\n`;
                result += `   **Kecamatan**: ${item.kecamatan}\n`;
                result += `   **Kota**: ${item.kota}\n`;
                result += `   **Provinsi**: ${item.provinsi}\n`;
                result += `   **Kode Pos**: ${item.kode_pos}\n\n`;
            });

            lenwyreply(result);
        } else {
            lenwyreply(`Tidak ditemukan data kode pos untuk "${text}". Coba kata kunci lain.`);
        }

    } catch (err) {
        console.error(err);
        lenwyreply('Terjadi kesalahan saat memproses permintaan.');
    }
}
break

case 'cucimata': {
    try {
        // Kirim pesan pemberitahuan sedang mencari asupan
        lenwyreply('Sebentar... sedang mencari asupan...');

        // Panggil API untuk mendapatkan asupan
        let apiUrl = 'https://api.agatz.xyz/api/asupan';
        let res = await axios.get(apiUrl);

        if (res.data.status === 200 && res.data.data) {
            let asupanUrl = res.data.data; // URL video asupan
            let caption = 'Ini dia asupan untukmu!';

            // Kirim video asupan ke chat pribadi pengguna
            await lenwy.sendMessage(m.sender, { video: { url: asupanUrl }, caption: caption }, { quoted: m });

            // Kirim konfirmasi bahwa video asupan berhasil dikirim
            lenwyreply('Asupan berhasil dikirim.');

        } else {
            lenwyreply('Gagal mendapatkan asupan. Coba lagi nanti.');
        }

    } catch (err) {
        console.error(err);
        lenwyreply('Terjadi kesalahan saat memproses permintaan.');
    }
}
break

case 'artimimpi': {
  if (!text) return lenwyreply('*Masukkan mimpi yang ingin ditafsirkan!*');

  lenwyreply('*Sabar ya, sedang mencari arti dari mimpi kamu...*');

  try {
      // Ambil data dari API
      const response = await fetch(`https://api.botcahx.eu.org/api/primbon/artimimpi?mimpi=${encodeURIComponent(text)}&apikey=kayganzz`);
      const result = await response.json();

      if (result.status && result.code === 200 && result.result.status) {
          const msg = result.result.message;
          lenwyreply(
              `🔍 *Hasil Tafsir Mimpi:*\n\n` +
              `💤 *Mimpi:* ${msg.mimpi}\n` +
              `📖 *Arti:* ${msg.arti}\n\n` +
              `🛠️ *Solusi untuk mimpi buruk:*\n${msg.solusi}`
          );
      } else {
          lenwyreply('*Maaf, tidak bisa menemukan arti dari mimpi tersebut.*');
      }
  } catch (error) {
      console.error("Error:", error);
      lenwyreply('*Terjadi kesalahan, coba lagi nanti.*');
  }
}
break

case 'ramalanjodoh': {
  if (!text) return lenwyreply('*Masukkan nama dan tanggal lahir Anda dan pasangan!*\nContoh: .ramalanjodoh Erlan|14|5|2005|Anya|1|2|2005');

  // Memisahkan input pengguna
  const params = text.split('|');
  if (params.length !== 7) {
    return lenwyreply('*Format salah! Gunakan format: Nama1|Tanggal1|Bulan1|Tahun1|Nama2|Tanggal2|Bulan2|Tahun2*');
  }

  const [nama1, tanggal1, bulan1, tahun1, nama2, tanggal2, bulan2, tahun2] = params;

  lenwyreply('*Sabar ya, sedang menghitung ramalan jodoh kamu...*');

  try {
      // Ambil data dari API
      const response = await fetch(`https://api.botcahx.eu.org/api/primbon/ramalanjodoh?nama1=${encodeURIComponent(nama1)}&tanggal1=${tanggal1}&bulan1=${bulan1}&tahun1=${tahun1}&nama2=${encodeURIComponent(nama2)}&tanggal2=${tanggal2}&bulan2=${bulan2}&tahun2=${tahun2}&apikey=kayganzz`);
      const result = await response.json();

      if (result.status && result.code === 200 && result.result.status) {
          const msg = result.result.message;
          lenwyreply(
              `💌 *Hasil Ramalan Jodoh:*\n\n` +
              `👤 *Nama Anda:* ${msg.nama_anda.nama}\n` +
              `📅 *Tanggal Lahir Anda:* ${msg.nama_anda.tgl_lahir}\n\n` +
              `👤 *Nama Pasangan:* ${msg.nama_pasangan.nama}\n` +
              `📅 *Tanggal Lahir Pasangan:* ${msg.nama_pasangan.tgl_lahir}\n\n` +
              `📖 *Ramalan Jodoh:*\n${msg.result}\n\n` +
              `📝 *Catatan:*\n${msg.catatan}`
          );
      } else {
          lenwyreply('*Maaf, tidak dapat menghitung ramalan jodoh dari data tersebut.*');
      }
  } catch (error) {
      console.error("Error:", error);
      lenwyreply('*Terjadi kesalahan, coba lagi nanti.*');
  }
}
break


case 'nomerhoki': {
  if (!text) return lenwyreply('*Masukkan nomor yang ingin dicek hokinya!*');

  lenwyreply('*Sabar ya, sedang mengecek hoki nomor kamu...*');

  try {
      // Ambil data dari API
      const response = await fetch(`https://api.botcahx.eu.org/api/primbon/nomerhoki?nomer=${encodeURIComponent(text)}&apikey=kayganzz`);
      const result = await response.json();

      if (result.status && result.code === 200 && result.result.status) {
          const msg = result.result.message;
          lenwyreply(
              `🔍 *Hasil Analisa Nomor Hoki:*\n\n` +
              `📞 *Nomor HP:* ${msg.nomer_hp}\n` +
              `🔢 *Angka Shuzi:* ${msg.angka_shuzi}\n\n` +
              `💫 *Energi Positif:*\n` +
              `- Kekayaan: ${msg.energi_positif.kekayaan}\n` +
              `- Kesehatan: ${msg.energi_positif.kesehatan}\n` +
              `- Cinta: ${msg.energi_positif.cinta}\n` +
              `- Kestabilan: ${msg.energi_positif.kestabilan}\n` +
              `- Persentase: ${msg.energi_positif.persentase}\n\n` +
              `⚡ *Energi Negatif:*\n` +
              `- Perselisihan: ${msg.energi_negatif.perselisihan}\n` +
              `- Kehilangan: ${msg.energi_negatif.kehilangan}\n` +
              `- Malapetaka: ${msg.energi_negatif.malapetaka}\n` +
              `- Kehancuran: ${msg.energi_negatif.kehancuran}\n` +
              `- Persentase: ${msg.energi_negatif.persentase}\n\n` +
              `📜 *Catatan:*\n${msg.catatan}`
          );
      } else {
          lenwyreply('*Maaf, tidak bisa mengecek hoki nomor tersebut.*');
      }
  } catch (error) {
      console.error("Error:", error);
      lenwyreply('*Terjadi kesalahan, coba lagi nanti.*');
  }
}
break

case 'ramalansuamiistri': {
  if (!text) return lenwyreply('*Masukkan nama dan tanggal lahir Anda dan pasangan!*\nContoh: .ramalansuamiistri Erlan|14|5|2005|Anya|1|2|2005');

  // Memisahkan input pengguna
  const params = text.split('|');
  if (params.length !== 7) {
    return lenwyreply('*Format salah! Gunakan format: Nama1|Tanggal1|Bulan1|Tahun1|Nama2|Tanggal2|Bulan2|Tahun2*');
  }

  const [nama1, tanggal1, bulan1, tahun1, nama2, tanggal2, bulan2, tahun2] = params;

  lenwyreply('*Sabar ya, sedang menghitung ramalan rumah tangga kamu...*');

  try {
      // Ambil data dari API
      const response = await fetch(`https://api.botcahx.eu.org/api/primbon/suamiistri?nama1=${encodeURIComponent(nama1)}&tanggal1=${tanggal1}&bulan1=${bulan1}&tahun1=${tahun1}&nama2=${encodeURIComponent(nama2)}&tanggal2=${tanggal2}&bulan2=${bulan2}&tahun2=${tahun2}&apikey=kayganzz`);
      const result = await response.json();

      if (result.status && result.code === 200 && result.result.status) {
          const msg = result.result.message;
          lenwyreply(
              `💌 *Hasil Ramalan Suami Istri:*\n\n` +
              `👨‍💼 *Suami:*\n` +
              `- Nama: ${msg.suami.nama}\n` +
              `- Tanggal Lahir: ${msg.suami.tgl_lahir}\n\n` +
              `👩‍💼 *Istri:*\n` +
              `- Nama: ${msg.istri.nama}\n` +
              `- Tanggal Lahir: ${msg.istri.tgl_lahir}\n\n` +
              `📖 *Ramalan Kehidupan Rumah Tangga:*\n${msg.result}\n\n` +
              `📝 *Catatan:*\n${msg.catatan}`
          );
      } else {
          lenwyreply('*Maaf, tidak dapat menghitung ramalan rumah tangga dari data tersebut.*');
      }
  } catch (error) {
      console.error("Error:", error);
      lenwyreply('*Terjadi kesalahan, coba lagi nanti.*');
  }
}
break

case 'ramalancinta': {
  if (!text) return lenwyreply('*Masukkan nama dan tanggal lahir Anda dan pasangan!*\nContoh: .ramalancinta Erlan|14|5|2005|Anya|1|2|2005');

  // Memisahkan input pengguna
  const params = text.split('|');
  if (params.length !== 7) {
    return lenwyreply('*Format salah! Gunakan format: Nama1|Tanggal1|Bulan1|Tahun1|Nama2|Tanggal2|Bulan2|Tahun2*');
  }

  const [nama1, tanggal1, bulan1, tahun1, nama2, tanggal2, bulan2, tahun2] = params;

  lenwyreply('*Sabar ya, sedang menghitung ramalan cintamu...*');

  try {
    // Ambil data dari API
    const response = await fetch(`https://api.botcahx.eu.org/api/primbon/ramalancinta?nama1=${encodeURIComponent(nama1)}&tanggal1=${tanggal1}&bulan1=${bulan1}&tahun1=${tahun1}&nama2=${encodeURIComponent(nama2)}&tanggal2=${tanggal2}&bulan2=${bulan2}&tahun2=${tahun2}&apikey=kayganzz`);
    const result = await response.json();

    if (result.status && result.code === 200 && result.result.status) {
      const msg = result.result.message;
      lenwyreply(
        `💘 *Hasil Ramalan Cinta:*\n\n` +
        `👤 *Nama Anda:*\n` +
        `- Nama: ${msg.nama_anda.nama}\n` +
        `- Tanggal Lahir: ${msg.nama_anda.tgl_lahir}\n\n` +
        `👤 *Nama Pasangan:*\n` +
        `- Nama: ${msg.nama_pasangan.nama}\n` +
        `- Tanggal Lahir: ${msg.nama_pasangan.tgl_lahir}\n\n` +
        `✨ *Sisi Positif:* ${msg.sisi_positif}\n` +
        `🌩️ *Sisi Negatif:* ${msg.sisi_negatif}\n\n` +
        `📜 *Catatan:*\n${msg.catatan}`
      );
    } else {
      lenwyreply('*Maaf, tidak dapat menghitung ramalan cinta dari data tersebut.*');
    }
  } catch (error) {
    console.error("Error:", error);
    lenwyreply('*Terjadi kesalahan, coba lagi nanti.*');
  }
}
break

case 'kecocokannama': {
  if (!text) return lenwyreply('*Masukkan nama dan tanggal lahir Anda dengan format berikut:*\n.nama|tanggal|bulan|tahun\nContoh: .kecocokannama Erlan|14|5|2007');

  // Memisahkan input pengguna
  const params = text.split('|');
  if (params.length !== 4) {
    return lenwyreply('*Format salah! Gunakan format: Nama|Tanggal|Bulan|Tahun*');
  }

  const [nama, tanggal, bulan, tahun] = params;

  lenwyreply('*Sabar ya, sedang menghitung kecocokan namamu...*');

  try {
    // Ambil data dari API
    const response = await fetch(`https://api.botcahx.eu.org/api/primbon/kecocokannama?nama=${encodeURIComponent(nama)}&tanggal=${tanggal}&bulan=${bulan}&tahun=${tahun}&apikey=kayganzz`);
    const result = await response.json();

    if (result.status && result.code === 200 && result.result.status) {
      const msg = result.result.message;
      lenwyreply(
        `🔍 *Hasil Kecocokan Nama:*\n\n` +
        `👤 *Nama:*\n` +
        `- Nama: ${msg.nama}\n` +
        `- Tanggal Lahir: ${msg.tgl_lahir}\n\n` +
        `✨ *Analisis Numerologi:*\n` +
        `- Life Path: ${msg.life_path}\n` +
        `- Destiny: ${msg.destiny}\n` +
        `- Heart's Desire: ${msg.destiny_desire}\n` +
        `- Personality: ${msg.personality}\n\n` +
        `📊 *Persentase Kecocokan:*\n${msg.persentase_kecocokan}\n\n` +
        `📜 *Catatan:*\n${msg.catatan}`
      );
    } else {
      lenwyreply('*Maaf, tidak dapat menghitung kecocokan nama dari data tersebut.*');
    }
  } catch (error) {
    console.error("Error:", error);
    lenwyreply('*Terjadi kesalahan, coba lagi nanti.*');
  }
}
break

case 'artinama': {
  if (isBan) return lenwyreply('*Kamu Di Ban Owner*');
  if (!text) return lenwyreply('*Masukkan nama yang ingin dicari artinya!*');
  
  lenwyreply('*Sabar Sebentar, Aku Mencari Artinya*');
  
  try {
      // Ambil data dari API
      const response = await fetch(`https://api.lolhuman.xyz/api/artinama?apikey=5be94ede1b5591e1d3d85392&nama=${encodeURIComponent(text)}`);
      const result = await response.json();
      
      if (result.status === 200 && result.result) {
          lenwyreply(`🔮 *Arti Nama "${text}":*\n\n${result.result}`);
      } else {
          lenwyreply('*Maaf, arti nama tidak ditemukan.*');
      }
  } catch (error) {
      console.error("Error:", error);
      lenwyreply('*Terjadi kesalahan, coba lagi nanti.*');
  }
}
break

case 'jadian': {
  if (isBan) return lenwyreply('*Kamu Di Ban Owner*');
  if (!text) return lenwyreply('*Masukkan tanggal dalam format DD/MM/YYYY!*');
  
  lenwyreply('*Sabar Sebentar, Aku Mencari Artinya*');
  
  try {
      // Ambil data dari API
      const response = await fetch(`https://api.lolhuman.xyz/api/jadian/${text}?apikey=5be94ede1b5591e1d3d85392`);
      const result = await response.json();
      
      if (result.status === 200 && result.result) {
          lenwyreply(`💖 *Karakteristik Hubungan pada Tanggal ${text}:*\n\n*Filosofi*: ${result.result.karakteristik}\n*Deskripsi*: ${result.result.deskripsi}`);
      } else {
          lenwyreply('*Maaf, informasi jadian tidak ditemukan.*');
      }
  } catch (error) {
      console.error("Error:", error);
      lenwyreply('*Terjadi kesalahan, coba lagi nanti.*');
  }
}
break

case 'jodoh': {
  if (isBan) return lenwyreply('*Kamu Di Ban Owner*');
  if (!text || !text.includes(' ')) return lenwyreply('*Masukkan dua nama dengan spasi, misal: Nama1 Nama2*');
  
  const [nama1, nama2] = text.split(' ');

  lenwyreply('*Sabar Sebentar, Aku Mencari Kecocokanmu*');
  
  try {
      // Ambil data dari API
      const response = await fetch(`https://api.lolhuman.xyz/api/jodoh/${nama1}/${nama2}?apikey=5be94ede1b5591e1d3d85392`);
      const result = await response.json();
      
      if (result.status === 200 && result.result) {
          lenwyreply(`💖 *Kecocokan Jodoh antara ${nama1} dan ${nama2}:*\n\n*Positif*: ${result.result.positif}\n*Negatif*: ${result.result.negatif}\n*Deskripsi*: ${result.result.deskripsi}\n\n*Gambar Ramalan*: ${result.result.image}`);
      } else {
          lenwyreply('*Maaf, informasi kecocokan jodoh tidak ditemukan.*');
      }
  } catch (error) {
      console.error("Error:", error);
      lenwyreply('*Terjadi kesalahan, coba lagi nanti.*');
  }
}
break

case 'tebakgender': {
  if (!text) return lenwyreply('*Masukkan nama yang ingin ditebak gendernya!*');

  lenwyreply('*Sabar Sebentar, Aku Menebak Gender Kamu*');
  
  try {
      // Ambil data dari API
      const response = await fetch(`https://api.lolhuman.xyz/api/tebakgender?apikey=5be94ede1b5591e1d3d85392&name=${encodeURIComponent(text)}`);
      const result = await response.json();
      
      if (result.status === 200 && result.result) {
          lenwyreply(`🔍 *Tebakan Gender untuk nama ${text}:*\n\n*Gender*: ${result.result.gender}`);
      } else {
          lenwyreply('*Maaf, tidak bisa menebak gender dari nama tersebut.*');
      }
  } catch (error) {
      console.error("Error:", error);
      lenwyreply('*Terjadi kesalahan, coba lagi nanti.*');
  }
}
break

case 'tebakumur': {
  if (!text) return lenwyreply('*Masukkan nama yang ingin ditebak umurnya!*');

  lenwyreply('*Sabar Sebentar, Aku Menebak Umur Kamu*');
  
  try {
      // Ambil data dari API
      const response = await fetch(`https://api.lolhuman.xyz/api/tebakumur?apikey=5be94ede1b5591e1d3d85392&name=${encodeURIComponent(text)}`);
      const result = await response.json();
      
      if (result.status === 200 && result.result) {
          lenwyreply(`🔍 *Tebakan Umur untuk nama ${text}:*\n\n*Umur*: ${result.result.age} tahun`);
      } else {
          lenwyreply('*Maaf, tidak bisa menebak umur dari nama tersebut.*');
      }
  } catch (error) {
      console.error("Error:", error);
      lenwyreply('*Terjadi kesalahan, coba lagi nanti.*');
  }
}
break

case 'zodiak': {
  if (!text) return lenwyreply('*Masukkan zodiak yang ingin dicek!*');

  const zodiak = text.toLowerCase();
  
  lenwyreply('*Sabar Sebentar, Aku Mencari Zodiak Kamu*');
  
  try {
      // Ambil data dari API
      const response = await fetch(`https://api.lolhuman.xyz/api/zodiak/${zodiak}?apikey=5be94ede1b5591e1d3d85392`);
      const result = await response.json();
      
      if (result.status === 200 && result.result) {
          lenwyreply(`🔮 *Informasi Zodiak ${text.toUpperCase()}:*\n\n${result.result}`);
      } else {
          lenwyreply('*Maaf, zodiak yang Anda masukkan tidak ditemukan.*');
      }
  } catch (error) {
      console.error("Error:", error);
      lenwyreply('*Terjadi kesalahan, coba lagi nanti.*');
  }
}
break

case 'randomnama': {
    const apiUrl = `https://api.lolhuman.xyz/api/random/nama?apikey=5be94ede1b5591e1d3d85392`;

    try {
        // Beritahu pengguna bahwa permintaan sedang diproses
        lenwyreply('Sedang mencari nama acak...');

        // Panggil API untuk mendapatkan nama acak
        const response = await axios.get(apiUrl);
        const data = response.data;

        if (data.status !== 200) {
            return lenwyreply('Gagal mendapatkan nama acak.');
        }

        // Kirim hasil nama acak ke pengguna
        const namaAcak = data.result;
        lenwyreply(`Berikut nama acak untukmu:\n\n*${namaAcak}*`);
    } catch (err) {
        console.error('Error:', err);
        lenwyreply('Terjadi kesalahan saat memproses permintaan.');
    }
}
break

case 'randompeople': {
    const apiUrl = `https://api.lolhuman.xyz/api/random/people?apikey=5be94ede1b5591e1d3d85392`;

    try {
        // Beritahu pengguna bahwa permintaan sedang diproses
        lenwyreply('Sedang mencari data orang acak...');

        // Panggil API untuk mendapatkan data orang acak
        const response = await axios.get(apiUrl);
        const data = response.data;

        if (data.status !== 200) {
            return lenwyreply('Gagal mendapatkan data orang acak.');
        }

        // Ekstrak hasil dari API
        const result = data.result;
        const { gender, name, location } = result;
        const fullName = `${name.title} ${name.first} ${name.last}`;
        const address = `${location.street.number} ${location.street.name}, ${location.city}, ${location.state}, ${location.country}, ${location.postcode}`;
        const coordinates = `Latitude: ${location.coordinates.latitude}, Longitude: ${location.coordinates.longitude}`;
        const timezone = `${location.timezone.description} (GMT ${location.timezone.offset})`;

        // Kirim hasil ke pengguna
        const output = `*📋 Data Orang Acak*\n\n` +
            `👤 *Nama*: ${fullName}\n` +
            `⚧ *Jenis Kelamin*: ${gender}\n` +
            `🏡 *Alamat*: ${address}\n` +
            `📍 *Koordinat*: ${coordinates}\n` +
            `⏱ *Zona Waktu*: ${timezone}`;
        
        lenwyreply(output);
    } catch (err) {
        console.error('Error:', err);
        lenwyreply('Terjadi kesalahan saat memproses permintaan.');
    }
}
break

case 'randompuisi': {
    const apiUrl = `https://api.lolhuman.xyz/api/random/puisi?apikey=5be94ede1b5591e1d3d85392`;

    try {
        // Beritahu pengguna bahwa permintaan sedang diproses
        lenwyreply('Mencari puisi terbaik untukmu...');

        // Panggil API untuk mendapatkan puisi
        const response = await axios.get(apiUrl);
        const data = response.data;

        if (data.status !== 200) {
            return lenwyreply('Gagal mendapatkan puisi.');
        }

        // Ekstrak hasil dari API
        const result = data.result;

        // Kirimkan hasil ke pengguna
        lenwyreply(`*📜 Puisi Pilihan*\n\n${result}`);
    } catch (err) {
        console.error('Error:', err);
        lenwyreply('Terjadi kesalahan saat memproses permintaan.');
    }
}
break

case 'dilanquote': {
    try {
        let response = await fetchJson('https://api.lolhuman.xyz/api/quotes/dilan?apikey=5be94ede1b5591e1d3d85392');
        let { result } = response;
        lenwyreply(`_Dilan Quote:_\n\n"${result}"`);
    } catch (err) {
        console.error(err);
        lenwyreply('Maaf, terjadi kesalahan saat mengambil data.');
    }
}
break

case 'checkresi': {
  const resi = args[0]; // Misalnya pengguna memasukkan nomor resi
  const resiApi = `https://api.lolhuman.xyz/api/checkresi?apikey=5be94ede1b5591e1d3d85392&resi=${resi}`;

  fetch(resiApi)
    .then(response => response.json())
    .then(data => {
      if (data.status === 200) {
        const result = data.result;
        let message = `**Info Resi**\n\n`;
        message += `**Resi**: ${result.resi}\n`;
        message += `**Kurir**: ${result.courier}\n`;
        
        result.history.forEach(history => {
          message += `\n${history.note} | ${history.time}`;
        });

        // Kirimkan informasi resi ke pengguna
        return lenwyreply(message);
      } else {
        return lenwyreply('Gagal mengambil data resi.');
      }
    })
    .catch(error => {
      console.error(error);
      return lenwyreply('Terjadi kesalahan saat mengambil data resi.');
    });
} 
break

case 'checkapikey': {
    lenwyreply(mess.wait);

    try {
        const axios = require('axios'); // Pastikan axios sudah diinstal

        // URL API
        const apiURL = `https://api.lolhuman.xyz/api/checkapikey?apikey=5be94ede1b5591e1d3d85392`;

        // Panggil API menggunakan axios
        const { data } = await axios.get(apiURL);

        // Validasi respons
        if (data && data.status === 200) {
            const { username, requests, today, account_type, expired } = data.result;
            const accountStatus = `*Status Akun API*\n\n` +
                `*Username:* ${username}\n` +
                `*Jumlah Request:* ${requests}\n` +
                `*Request Hari Ini:* ${today}\n` +
                `*Tipe Akun:* ${account_type}\n` +
                `*Akun Expired:* ${expired}`;

            lenwyreply(accountStatus);
        } else {
            lenwyreply(`❌ *Tidak ada informasi yang valid mengenai API.*`);
        }
    } catch (error) {
        console.error("Error di case 'checkapikey':", error.message);
        lenwyreply(`❌ *Terjadi kesalahan saat memproses permintaan.*`);
    }
}
break

case 'toaudio': case 'audio': {
    if (isBan) return lenwyreply(m.chat, '*Lu Di Ban Owner Gak Usah Sok Asik Tolol*');
    await loading();

    if (!/video/.test(mime) && !/audio/.test(mime)) throw `*Send/Reply the Video/Audio You Want to Use as Audio With Caption* ${prefix + command}`;
    if (!quoted) throw `*Send/Reply the Video/Audio You Want to Use as Audio With Caption* ${prefix + command}`;

    let media = await lenwy.downloadMediaMessage(quoted);
    let { toAudio } = require('./lib/converter');
    let audio = await toAudio(media, 'mp4');

    lenwyreply(m.chat, {audio: audio, mimetype: 'audio/mpeg'}, { quoted : m });
}
break

case 'jadwaltv': {
    if (!text) {
        return lenwyreply(`*Format salah!*\nGunakan format: /jadwaltv <nama channel>\nContoh: /jadwaltv gtv`);
    }

    try {
        const axios = require('axios');
        const channel = text.trim();
        lenwyreply(`*Tunggu sebentar, mencari jadwal untuk channel "${channel}"...*`);

        const apiURL = `https://fastrestapis.fasturl.cloud/search/tvschedule?channel=${encodeURIComponent(channel)}`;
        const { data } = await axios.get(apiURL);

        if (data.status !== 200 || !data.result) {
            return lenwyreply(`*Channel "${channel}" tidak ditemukan atau tidak tersedia.*`);
        }

        const events = data.result.result;
        if (events.length === 0) {
            return lenwyreply(`*Jadwal untuk channel "${channel}" tidak tersedia.*`);
        }

        let jadwal = `* Jadwal TV untuk channel ${channel}:*\n\n`;
        events.forEach(event => {
            jadwal += `${event.date} - ${event.event}\n`;
        });

        // Kirim jadwal dalam bentuk teks
        lenwyreply(jadwal);

    } catch (error) {
        console.error(" Error:", error.message);
        lenwyreply('*Terjadi kesalahan saat mengambil jadwal TV.*');
    }
}
break

case 'animeinfo2': {
    if (!args[0]) return lenwyreply('Harap masukkan nama anime!');
    
    let animeName = args.join(' '); // Nama anime dari pengguna

    try {
        lenwyreply('Sebentar ya, sedang mencari informasi anime...');

        // Panggil API untuk mendapatkan informasi anime
        let res = await axios.get('https://fastrestapis.fasturl.cloud/anime/animeinfo', {
            params: {
                name: animeName
            }
        });

        // Parsing hasil API
        let result = res.data.result;
        if (res.data.status !== 200 || !result) {
            return lenwyreply('Gagal menemukan informasi anime.');
        }

        // Menyusun informasi anime
        let animeInfo = `* Info Anime - ${result.title}:*\n\n` +
                        ` *Link:* ${result.url}\n` +
                        ` *Rating:* ${result.score}\n` +
                        ` *Anggota:* ${result.members}\n` +
                        ` *Status:* ${result.status}\n\n` +
                        ` *Sinopsis:*\n${result.synopsis}\n\n` +
                        ` *Favorit:* ${result.favorites}\n` +
                        ` *Genres:* ${result.genres}\n`;

        // Kirim gambar anime dengan caption informasi lainnya
        await lenwy.sendMessage(m.chat, { 
            image: { url: result.images.jpg.image_url },
            caption: animeInfo
        }, { quoted: m });

    } catch (err) {
        console.error(err);
        lenwyreply('Terjadi kesalahan saat memproses permintaan.');
    }
}
break

case 'mlbb': {
    if (!args[0]) return lenwyreply('Harap masukkan nama hero!');

    let heroName = args.join(' '); // Nama hero dari pengguna

    try {
        lenwyreply('Sebentar ya, sedang mencari informasi hero...');

        // Panggil API untuk mendapatkan informasi hero MLBB
        let res = await axios.get(`https://fastrestapis.fasturl.cloud/character/mlbb?name=${heroName}`);

        // Parsing hasil API
        let result = res.data.result;
        if (res.data.status !== 200 || !result) {
            return lenwyreply('Gagal menemukan hero dengan nama tersebut.');
        }

        // Menyusun pesan yang menarik
        let heroInfo = `* Nama Hero:* ${result.name}\n` +
                       ` *ID Hero:* ${result.id}\n` +
                       ` *Story:* ${result.story}\n` +
                       ` *Role:* ${result.role.map(r => r.name).join(', ')}\n` +
                       ` *Lane:* ${result.lane.map(l => l.name).join(', ')}\n` +
                       ` *Durability:* ${result.ability.durability}\n` +
                       ` *Offense:* ${result.ability.offense}\n` +
                       ` *Ability Effects:* ${result.ability.ability_effects}\n` +
                       ` *Difficulty:* ${result.ability.difficulty}\n` +
                       ` *Specialty:* ${result.speciality.join(', ')}\n\n`;

        // Menampilkan skill hero
        heroInfo += `* Skills:* \n`;
        result.skills.forEach(skill => {
            heroInfo += `\n*Skill Name:* ${skill.name}\n` +
                        `*Description:* ${skill.desc}\n` +
                        `*Cooldown:* ${skill.cooldown}\n` +
                        `*Mana Cost:* ${skill.mana_cost}\n\n`;
        });

        // Kirim gambar dan informasi hero
        await lenwy.sendMessage(m.chat, { 
            image: { url: result.media.potrait }, // Gambar potrait hero
            caption: heroInfo
        }, { quoted: m });

    } catch (err) {
        console.error(err);
        lenwyreply('Terjadi kesalahan saat memproses permintaan.');
    }
}
break

case 'ff': {
    if (!args[0]) return lenwyreply('Harap masukkan nama karakter!');

    let characterName = args.join(' '); // Nama karakter dari pengguna

    try {
        lenwyreply('Sebentar ya, sedang mencari informasi karakter...');

        // Panggil API untuk mendapatkan informasi karakter Free Fire
        let res = await axios.get(`https://fastrestapis.fasturl.cloud/character/freefire?name=${characterName}`);

        // Parsing hasil API
        let result = res.data.result;
        if (res.data.status !== 200 || !result) {
            return lenwyreply('Gagal menemukan karakter dengan nama tersebut.');
        }

        // Menyusun pesan yang menarik
        let characterInfo = `*🎮 Nama Karakter:* ${result.name}\n` +
                            `🆔 *Alias:* ${result.alias}\n` +
                            `🎂 *Usia:* ${result.age}\n` +
                            `📅 *Tanggal Lahir:* ${result.birthDate}\n` +
                            `🍽️ *Kemampuan:* ${result.ability}\n` +
                            `♂️ *Jenis Kelamin:* ${result.gender}\n` +
                            `🤝 *Afliasi:* ${result.affiliation}\n\n`;

        // Kirim gambar dan informasi karakter
        await lenwy.sendMessage(m.chat, { 
            image: { url: result.imageUrl }, // Gambar karakter
            caption: characterInfo
        }, { quoted: m });

    } catch (err) {
        console.error(err);
        lenwyreply('Terjadi kesalahan saat memproses permintaan.');
    }
}
break

case 'profil': case 'profile': {
    let taa = db.data.users[sender];
    const owned = `${owner}@s.whatsapp.net`;
    const version = 2;
    const text12 = `*Hai, selamat ${ucapanWaktu}*


 *Info User* 
Nama Pengguna  : *@${sender.split('@')[0]}*
Premium : ${isPrem ? '' : ''}
Limit  : ${taa.limit}
Status : Terdaftar di database 


Terima kasih sudah mendaftar ke dalam bot *Kayzu MD*.

Powered By *@${owned.split("@")[0]}*
`;

    lenwy.sendMessage(m.chat, {
        text: text12,
        contextInfo: {
            mentionedJid: [sender, owned],
            externalAdReply: {
                showAdAttribution: true,
                title: 'Kayzu MD',
                body: 'Powered by Kayzu MD',
                thumbnailUrl: 'https://telegra.ph/file/107d5a304546533444f39.jpg', // Ganti thumbnail jika perlu
                sourceUrl: "https://chat.whatsapp.com/IRRkLJqImnuB6lCjGzyME0", // Link grup WhatsApp atau URL relevan
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: m });
}
break

case 'stkbaik': {
  if (!text) return lenwyreply('⚠️ Harap masukkan nama yang ingin dibuatkan sertifikat.');
  
  try {
    await lenwy.sendMessage(m.chat, { react: { text: '⏱️', key: m.key }});
    let url = `https://mdsay.xyz/api/v1?key=md&api=baik&nama=${encodeURIComponent(text)}`;
    let caption = `_✅ Sukses Membuat Sertifikat ${command} Dengan Nama ${text}_`;
    
    // Kirim pesan gambar dengan caption
    await lenwy.sendMessage(m.chat, { 
      image: { url: url }, 
      caption: caption 
    }, { quoted: m });
    await lenwy.sendMessage(m.chat, { react: { text: '✅', key: m.key }});
  } catch (err) {
    console.error(err);
    lenwyreply('❌ Terjadi kesalahan saat membuat sertifikat.');
  }
}
break

case 'stkcantik': {
  if (!text) return lenwyreply(`⚠️ Masukkan nama untuk sertifikat!\n\nContoh:\n${prefix + command} Nama`);
  try {
    await lenwy.sendMessage(m.chat, { react: { text: '⏱️', key: m.key }});
    const imageUrl = `https://mdsay.xyz/api/v1?key=md&api=cantik&nama=${encodeURIComponent(text)}`;
    const caption = `_✅ Sukses Membuat Sertifikat ${command} Dengan Nama ${text}_`;

    await lenwy.sendMessage(
      m.chat,
      { 
        image: { url: imageUrl }, 
        caption: caption 
      },
      { quoted: m }
    );
    await lenwy.sendMessage(m.chat, { react: { text: '✅', key: m.key }});
  } catch (error) {
    console.error('Error:', error);
    lenwyreply('❌ Maaf, terjadi kesalahan saat membuat sertifikat.');
  }
}
break

case 'stkganteng': {
  if (!text) return lenwyreply(`⚠️ Masukkan nama untuk sertifikat!\n\nContoh:\n${prefix + command} Nama`);
  try {
    await lenwy.sendMessage(m.chat, { react: { text: '⏱️', key: m.key }});
    const imageUrl = `https://mdsay.xyz/api/v1?key=md&api=ganteng&nama=${encodeURIComponent(text)}`;
    const caption = `_✅ Sukses Membuat Sertifikat ${command} Dengan Nama ${text}_`;

    await lenwy.sendMessage(
      m.chat,
      { 
        image: { url: imageUrl }, 
        caption: caption 
      },
      { quoted: m }
    );
    await lenwy.sendMessage(m.chat, { react: { text: '✅', key: m.key }});
  } catch (error) {
    console.error('Error:', error);
    lenwyreply('❌ Maaf, terjadi kesalahan saat membuat sertifikat.');
  }
}
break

case 'stkhitam': {
    if (!text) return lenwyreply(`⚠️ Masukkan nama untuk sertifikat!\n\nContoh:\n${prefix + command} Nama`);
    try {
        await lenwy.sendMessage(m.chat, { react: { text: '⏱️', key: m.key }});
        const imageUrl = `https://mdsay.xyz/api/v1?key=md&api=hitam&nama=${encodeURIComponent(text)}`;
        const caption = `_✅ Sukses Membuat Sertifikat ${command} Dengan Nama ${text}_`;

        await lenwy.sendMessage(
            m.chat,
            { 
                image: { url: imageUrl }, 
                caption: caption 
            },
            { quoted: m }
        );
        await lenwy.sendMessage(m.chat, { react: { text: '✅', key: m.key }});
    } catch (error) {
        console.error('Error:', error);
        lenwyreply('❌ Maaf, terjadi kesalahan saat membuat sertifikat.');
    }
}
break

case 'stkmiskin': {
    if (!text) return lenwyreply(`⚠️ Masukkan nama untuk sertifikat!\n\nContoh:\n${prefix + command} Nama`);
    try {
        await lenwy.sendMessage(m.chat, { react: { text: '⏱️', key: m.key }});
        const imageUrl = `https://mdsay.xyz/api/v1?key=md&api=miskin&nama=${encodeURIComponent(text)}`;
        const caption = `_✅ Sukses Membuat Sertifikat ${command} Dengan Nama ${text}_`;

        await lenwy.sendMessage(
            m.chat,
            { 
                image: { url: imageUrl }, 
                caption: caption 
            },
            { quoted: m }
        );
        await lenwy.sendMessage(m.chat, { react: { text: '✅', key: m.key }});
    } catch (error) {
        console.error('Error:', error);
        lenwyreply('❌ Maaf, terjadi kesalahan saat membuat sertifikat.');
    }
}
break

case 'stkkaya': {
    if (!text) return lenwyreply(`⚠️ Masukkan nama untuk sertifikat!\n\nContoh:\n${prefix + command} Nama`);
    try {
        await lenwy.sendMessage(m.chat, { react: { text: '⏱️', key: m.key }});
        const imageUrl = `https://mdsay.xyz/api/v1?key=md&api=kaya&nama=${encodeURIComponent(text)}`;
        const caption = `_✅ Sukses Membuat Sertifikat ${command} Dengan Nama ${text}_`;

        await lenwy.sendMessage(
            m.chat,
            { 
                image: { url: imageUrl }, 
                caption: caption 
            },
            { quoted: m }
        );
        await lenwy.sendMessage(m.chat, { react: { text: '✅', key: m.key }});
    } catch (error) {
        console.error('Error:', error);
        lenwyreply('❌ Maaf, terjadi kesalahan saat membuat sertifikat.');
    }
}
break

case 'stkmarah': {
  await lenwy.sendMessage(m.chat, { react: { text: '⏱️', key: m.key }})
  await lenwy.sendMessage(m.chat, { 
    image: { url: `https://mdsay.xyz/api/v1?key=md&api=marah&nama=${text}_`}, 
    caption: `_Sukses Membuat Sertifikat ${command} Dengan Nama ${text}` 
  }, { quoted: m })
  await lenwy.sendMessage(m.chat, { react: { text: '✅', key: m.key }})
}
break

case 'stksabar': {
  await lenwy.sendMessage(m.chat, { react: { text: '⏱️', key: m.key }})
  await lenwy.sendMessage(m.chat, { 
    image: { url: `https://mdsay.xyz/api/v1?key=md&api=sabar&nama=${text}_`}, 
    caption: `_Sukses Membuat Sertifikat ${command} Dengan Nama ${text}` 
  }, { quoted: m })
  await lenwy.sendMessage(m.chat, { react: { text: '✅', key: m.key }})
}
break

case 'stksakiti': {
  await lenwy.sendMessage(m.chat, { react: { text: '⏱️', key: m.key }})
  await lenwy.sendMessage(m.chat, { 
    image: { url: `https://mdsay.xyz/api/v1?key=md&api=sakiti&nama=${text}_`}, 
    caption: `_Sukses Membuat Sertifikat ${command} Dengan Nama ${text}` 
  }, { quoted: m })
  await lenwy.sendMessage(m.chat, { react: { text: '✅', key: m.key }})
}
break

case 'stkkeren': {
  await lenwy.sendMessage(m.chat, { react: { text: '⏱️', key: m.key }})
  await lenwy.sendMessage(m.chat, { 
    image: { url: `https://mdsay.xyz/api/v1?key=md&api=keren&nama=${text}_`}, 
    caption: `_Sukses Membuat Sertifikat ${command} Dengan Nama ${text}` 
  }, { quoted: m })
  await lenwy.sendMessage(m.chat, { react: { text: '✅', key: m.key }})
}
break

case 'stkmisterius': {
  await lenwy.sendMessage(m.chat, { react: { text: '⏱️', key: m.key }})
  await lenwy.sendMessage(m.chat, { 
    image: { url: `https://mdsay.xyz/api/v1?key=md&api=misterius&nama=${text}_`}, 
    caption: `_Sukses Membuat Sertifikat ${command} Dengan Nama ${text}` 
  }, { quoted: m })
  await lenwy.sendMessage(m.chat, { react: { text: '✅', key: m.key }})
}
break

case 'stksantai': {
  await lenwy.sendMessage(m.chat, { react: { text: '⏱️', key: m.key }})
  await lenwy.sendMessage(m.chat, { 
    image: { url: `https://mdsay.xyz/api/v1?key=md&api=santai&nama=${text}_`}, 
    caption: `_Sukses Membuat Sertifikat ${command} Dengan Nama ${text}` 
  }, { quoted: m })
  await lenwy.sendMessage(m.chat, { react: { text: '✅', key: m.key }})
}
break

case 'stksombong': {
  await lenwy.sendMessage(m.chat, { react: { text: '⏱️', key: m.key }})
  await lenwy.sendMessage(m.chat, { 
    image: { url: `https://mdsay.xyz/api/v1?key=md&api=sombong&nama=${text}_`}, 
    caption: `_Sukses Membuat Sertifikat ${command} Dengan Nama ${text}` 
  }, { quoted: m })
  await lenwy.sendMessage(m.chat, { react: { text: '✅', key: m.key }})
}
break

case 'stklucu': {
  await lenwy.sendMessage(m.chat, { react: { text: '⏱️', key: m.key }})
  await lenwy.sendMessage(m.chat, { 
    image: { url: `https://mdsay.xyz/api/v1?key=md&api=lucu&nama=${text}_`}, 
    caption: `_Sukses Membuat Sertifikat ${command} Dengan Nama ${text}` 
  }, { quoted: m })
  await lenwy.sendMessage(m.chat, { react: { text: '✅', key: m.key }})
}
break

case 'stkgila': {
  if (!text) return lenwyreply('⚠️ Mana nama nya kak..')
  await lenwy.sendMessage(m.chat, { react: { text: '⏱️', key: m.key }})
  await lenwy.sendMessage(m.chat, { 
    image: { url: `https://mdsay.xyz/api/v1?key=md&api=gila&nama=${text}_`}, 
    caption: `_Sukses Membuat Sertifikat ${command} Dengan Nama ${text}` 
  }, { quoted: m })
  await lenwy.sendMessage(m.chat, { react: { text: '✅', key: m.key }})
}
break

case 'backup': {
    if (!isCreator) return lenwyreply(mess.owner);
    
    await lenwy.sendMessage(m.chat, {
        react: {
            text: "⏱️",
            key: m.key,
        }
    });

    const { execSync } = require("child_process");
    const fs = require("fs");

    try {
        // Daftar file & folder yang akan dibackup, kecuali yang tidak diperlukan
        const ls = execSync("ls")
            .toString()
            .split("\n")
            .filter((pe) =>
                pe !== "node_modules" &&
                pe !== "lenwy" &&
                pe !== "package-lock.json" &&
                pe !== "yarn.lock" &&
                pe !== ""
            );

        // Membuat file zip
        execSync(`zip -r ZenithMD.zip ${ls.join(" ")}`);

        // Mengirim file zip ke chat
        await lenwy.sendMessage(m.chat, {
            document: fs.readFileSync("./ZenithMD.zip"),
            mimetype: "application/zip",
            fileName: "ZenithMD.zip",
        }, { quoted: m });

        // Hapus file zip setelah dikirim
        execSync("rm -rf ZenithMD.zip");

        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key,
            }
        });
    } catch (e) {
        console.error(e);
        lenwyreply('Terjadi kesalahan saat melakukan backup.');
    }
}
break

case 'akira':
case 'akiyama':
case 'ana':
case 'art':
case 'asuna':
case 'ayuzawa':
case 'boruto':
case 'bts':
case 'chiho':
case 'chitoge':
case 'cosplay':
case 'cosplayloli':
case 'cosplaysagiri':
case 'cyber':
case 'deidara':
case 'doraemon':
case 'elena':
case 'emilia':
case 'erza':
case 'exo':
case 'gamewallpaper':
case 'gremory':
case 'hacker':
case 'hestia':
case 'hinata':
case 'husbu':
case 'inori':
case 'islamic':
case 'isuzu':
case 'itachi':
case 'itori':
case 'jennie':
case 'jiso':
case 'justina':
case 'kaga':
case 'kagura':
case 'kakasih':
case 'kaori':
case 'cartoon':
case 'shortquote':
case 'keneki':
case 'kotori':
case 'kurumi':
case 'lisa':
case 'loli2':
case 'madara':
case 'megumin':
case 'mikasa':
case 'mikey':
case 'minato':
case 'mountain':
case 'naruto':
case 'neko':
case 'neko2':
case 'nekonime':
case 'nezuko':
case 'onepiece':
case 'pentol':
case 'pokemon':
case 'programming':
case 'randomnime':
case 'randomnime2':
case 'rize':
case 'rose':
case 'sagiri':
case 'sakura':
case 'sasuke':
case 'satanic':
case 'shina':
case 'shinka':
case 'shinomiya':
case 'shizuka':
case 'shota':
case 'space':
case 'technology':
case 'tejina':
case 'toukachan':
case 'tsunade':
case 'waifu':
case 'yotsuba':
case 'yuki':
case 'yulibocil':
case 'yumeko': {
    let heyy;
    if (/akira/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/akira.json');
    if (/akiyama/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/akiyama.json');
    if (/ana/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/ana.json');
    if (/art/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/art.json');
    if (/asuna/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/asuna.json');
    if (/ayuzawa/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/ayuzawa.json');
    if (/boruto/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/boruto.json');
    if (/bts/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/bts.json');
    if (/chiho/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/chiho.json');
    if (/chitoge/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/chitoge.json');
    if (/cosplay/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/cosplay.json');
    if (/cosplayloli/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/cosplayloli.json');
    if (/cosplaysagiri/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/cosplaysagiri.json');
    if (/cyber/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/cyber.json');
    if (/deidara/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/deidara.json');
    if (/doraemon/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/doraemon.json');
    if (/elena/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/elena.json');
    if (/emilia/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/emilia.json');
    if (/erza/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/erza.json');
    if (/exo/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/exo.json');
    if (/gamewallpaper/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/gamewallpaper.json');
    if (/gremory/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/gremory.json');
    if (/hacker/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/hacker.json');
    if (/hestia/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/hestia.json');
    if (/husbu/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/husbu.json');
    if (/inori/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/inori.json');
    if (/islamic/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/islamic.json');
    if (/isuzu/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/isuzu.json');
    if (/itachi/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/itachi.json');
    if (/itori/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/itori.json');
    if (/jennie/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/jennie.json');
    if (/jiso/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/jiso.json');
    if (/justina/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/justina.json');
    if (/kaga/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/kaga.json');
    if (/kagura/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/kagura.json');
    if (/kakasih/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/kakasih.json');
    if (/kaori/.test(command)) heyy = await fetchJson('https://raw.githubusercontent.com/DGXeon/XeonMedia/master/kaori.json');

    // Menambahkan reaksi "⏱️" sebelum mengirim gambar
    await lenwy.sendMessage(m.chat, {
        react: {
            text: "⏱️",
            key: m.key,
        }
    });

    let imageUrl = heyy[Math.floor(Math.random() * heyy.length)];
    let buttons = [{ buttonId: command, buttonText: { displayText: 'Next Image' }, type: 1 }];
    let buttonMessage = {
        image: { url: imageUrl },
        caption: `Berikut gambarnya`,
        footer: 'Kay Bot',
        buttons: buttons,
        headerType: 4
    };

    // Mengirim gambar
    await lenwy.sendMessage(m.chat, buttonMessage, { quoted: m });

    // Menambahkan reaksi "✅" setelah mengirim gambar
    await lenwy.sendMessage(m.chat, {
        react: {
            text: "✅",
            key: m.key,
        }
    });
}
break

case 'glitchtext':
case 'writetext':
case 'advancedglow':
case 'typographytext':
case 'pixelglitch':
case 'neonglitch':
case 'flagtext':
case 'flag3dtext':
case 'deletingtext':
case 'blackpinkstyle':
case 'glowingtext':
case 'underwatertext':
case 'logomaker':
case 'cartoonstyle':
case 'papercutstyle':
case 'watercolortext':
case 'effectclouds':
case 'blackpinklogo':
case 'gradienttext':
case 'summerbeach':
case 'luxurygold':
case 'multicoloredneon':
case 'sandsummer':
case 'galaxywallpaper':
case '1917style':
case 'makingneon':
case 'royaltext':
case 'freecreate':
case 'galaxystyle':
case 'lighteffects': {
    if (!q) return lenwyreply(`❌ Masukkan teks!\nContoh: ${prefix+command} Happy Birthday`);

    await lenwy.sendMessage(m.chat, {
        react: { text: "⏱️", key: m.key }
    });

    let url = `https://fastrestapis.fasturl.cloud/maker/ephoto360?text=${encodeURIComponent(q)}&style=${command}`;

    try {
        await lenwy.sendMessage(m.chat, {
            image: { url },
            caption: `✅ *Berhasil!*\n🖼️ Style: ${command}\n📜 Teks: ${q}`
        }, { quoted: m });

        await lenwy.sendMessage(m.chat, {
            react: { text: "✅", key: m.key }
        });
    } catch (err) {
        lenwyreply("❌ Gagal mengambil gambar! Cek kembali teks atau coba lagi nanti.");
    }
}
break

case 'antiwork': 
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var notnot = JSON.parse(fs.readFileSync('./kay/randompics/antiwork.json'));
var img = pickRandom(notnot);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: img.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'blackpink2': 
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var notnot = JSON.parse(fs.readFileSync('./kay/randompics/blackpink.json'));
var img = pickRandom(notnot);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: img.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'bike': 
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var notnot = JSON.parse(fs.readFileSync('./kay/randompics/bike.json'));
var img = pickRandom(notnot);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: img.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'boneka': 
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var notnot = JSON.parse(fs.readFileSync('./kay/randompics/boneka.json'));
var img = pickRandom(notnot);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: img.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'cosplay': 
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var notnot = JSON.parse(fs.readFileSync('./kay/randompics/cosplay.json'));
var img = pickRandom(notnot);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: img.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'cat': 
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var notnot = JSON.parse(fs.readFileSync('./kay/randompics/cat.json'));
var img = pickRandom(notnot);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: img.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'doggo': 
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var notnot = JSON.parse(fs.readFileSync('./kay/randompics/doggo.json'));
var img = pickRandom(notnot);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: img.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'justina': 
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var notnot = JSON.parse(fs.readFileSync('./kay/randompics/justina.json'));
var img = pickRandom(notnot);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: img.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'kayes': 
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var notnot = JSON.parse(fs.readFileSync('./kay/randompics/kayes.json'));
var img = pickRandom(notnot);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: img.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'kpop': 
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var notnot = JSON.parse(fs.readFileSync('./kay/randompics/kpop.json'));
var img = pickRandom(notnot);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: img.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'notnot': 
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var notnot = JSON.parse(fs.readFileSync('./kay/randompics/notnot.json'));
var img = pickRandom(notnot);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: img.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'car': 
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var notnot = JSON.parse(fs.readFileSync('./kay/randompics/car.json'));
var img = pickRandom(notnot);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: img.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'couplepic': case 'couplepicture': 
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var notnot = JSON.parse(fs.readFileSync('./kay/randompics/ppcouple.json'));
var img = pickRandom(notnot);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: img.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'profilepic': case 'profilepicture': 
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var notnot = JSON.parse(fs.readFileSync('./kay/randompics/profile.json'));
var img = pickRandom(notnot);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: img.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'pubg': 
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var notnot = JSON.parse(fs.readFileSync('./kay/randompics/pubg.json'));
var img = pickRandom(notnot);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: img.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'rose': 
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var notnot = JSON.parse(fs.readFileSync('./kay/randompics/rose.json'));
var img = pickRandom(notnot);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: img.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'ryujin': 
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var notnot = JSON.parse(fs.readFileSync('./kay/randompics/ryujin.json'));
var img = pickRandom(notnot);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: img.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'ulzzangboy': 
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var notnot = JSON.parse(fs.readFileSync('./kay/randompics/ulzzangboy.json'));
var img = pickRandom(notnot);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: img.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'ulzzanggirl':
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var notnot = JSON.parse(fs.readFileSync('./kay/randompics/ulzzanggirl.json'));
var img = pickRandom(notnot);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: img.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'wallml': case 'wallpaperml': case 'mobilelegend':
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var notnot = JSON.parse(fs.readFileSync('./kay/randompics/wallml.json'));
var img = pickRandom(notnot);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: img.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'wallpaperphone': case 'wallphone':
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var notnot = JSON.parse(fs.readFileSync('./kay/randompics/wallhp.json'));
var img = pickRandom(notnot);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: img.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'tiktokgirl':
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var asupan = JSON.parse(fs.readFileSync('./kay/tiktokvids/tiktokgirl.json'));
var ii = pickRandom(asupan);
await lenwy.sendMessage(m.chat, { caption: 'don banh', video: { url: ii.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'tiktokghea':
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var gheayubi = JSON.parse(fs.readFileSync('./kay/tiktokvids/gheayubi.json'));
var iii = pickRandom(gheayubi);
await lenwy.sendMessage(m.chat, { caption: 'don banh', video: { url: iii.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'tiktokbocil':
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var bocil = JSON.parse(fs.readFileSync('./kay/tiktokvids/bocil.json'));
var iiii = pickRandom(bocil);
await lenwy.sendMessage(m.chat, { caption: 'don banh', video: { url: iiii.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'tiktoknukhty':
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var ukhty = JSON.parse(fs.readFileSync('./kay/tiktokvids/ukhty.json'));
var iiiii = pickRandom(ukhty);
await lenwy.sendMessage(m.chat, { caption: 'don banh', video: { url: iiiii.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'tiktoksantuy':
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var santuy = JSON.parse(fs.readFileSync('./kay/tiktokvids/santuy.json'));
var iiiiii = pickRandom(santuy);
await lenwy.sendMessage(m.chat, { caption: 'don banh', video: { url: iiiiii.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'tiktokkayes':
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var kayes = JSON.parse(fs.readFileSync('./kay/tiktokvids/kayes.json'));
var iiiiiii = pickRandom(kayes);
await lenwy.sendMessage(m.chat, { caption: 'don banh', video: { url: iiiiiii.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'tiktokpanrika':
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var rikagusriani = JSON.parse(fs.readFileSync('./kay/tiktokvids/panrika.json'));
var iiiiiiii = pickRandom(rikagusriani);
await lenwy.sendMessage(m.chat, { caption: 'don banh', video: { url: iiiiiiii.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'tiktoknotnot':
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var notnot = JSON.parse(fs.readFileSync('./kay/tiktokvids/notnot.json'));
var iiiiiiiii = pickRandom(notnot);
await lenwy.sendMessage(m.chat, { caption: 'don banh', video: { url: iiiiiiiii.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'chinese':
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var chinesePics = JSON.parse(fs.readFileSync('./kay/tiktokpics/china.json'));
var selectedChinesePic = pickRandom(chinesePics);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: selectedChinesePic.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'hijab':
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var hijabPics = JSON.parse(fs.readFileSync('./kay/tiktokpics/hijab.json'));
var selectedHijabPic = pickRandom(hijabPics);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: selectedHijabPic.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'indo':
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var indoPics = JSON.parse(fs.readFileSync('./kay/tiktokpics/indonesia.json'));
var selectedIndoPic = pickRandom(indoPics);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: selectedIndoPic.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'japanese':
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var japanesePics = JSON.parse(fs.readFileSync('./kay/tiktokpics/japan.json'));
var selectedJapanesePic = pickRandom(japanesePics);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: selectedJapanesePic.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'korean':
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var koreanPics = JSON.parse(fs.readFileSync('./kay/tiktokpics/korea.json'));
var selectedKoreanPic = pickRandom(koreanPics);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: selectedKoreanPic.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'malay':
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var malayPics = JSON.parse(fs.readFileSync('./kay/tiktokpics/malaysia.json'));
var selectedMalayPic = pickRandom(malayPics);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: selectedMalayPic.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'randomgirl':
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var randomGirl = JSON.parse(fs.readFileSync('./kay/tiktokpics/random.json'));
var selectedGirl = pickRandom(randomGirl);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: selectedGirl.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'randomboy':
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var randomBoy = JSON.parse(fs.readFileSync('./kay/tiktokpics/random2.json'));
var selectedBoy = pickRandom(randomBoy);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: selectedBoy.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'thai':
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var thaiPics = JSON.parse(fs.readFileSync('./kay/tiktokpics/thailand.json'));
var selectedThai = pickRandom(thaiPics);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: selectedThai.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case 'vietnamese':
await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key }});
var vietnamPics = JSON.parse(fs.readFileSync('./kay/tiktokpics/vietnam.json'));
var selectedVietnam = pickRandom(vietnamPics);
await lenwy.sendMessage(m.chat, { caption: 'don banh', image: { url: selectedVietnam.url } }, { quoted: m });
await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key }});
break

case "globaltv": case "gtv":
{
  let teksz = `📺SALURAN TELEVISI GLOBAL TV📺`;
  let channel = `https://m.rctiplus.com/tv/globaltv`;
  let teksnya = `Ketuk Thumnile Bertuliskan Play Untuk Memulai!`;
  let titel = `⇆ㅤ ||◁ㅤ▶️ㅤ▷||ㅤ ↻`;
  let desk = `Click Here To Play!`;

  lenwy.sendMessage(m.chat, {
    text: `${teksz}\n\n${teksnya}`, 
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true,
        mediaType: 1,
        title: titel, 
        body: desk, 
        description: teksz,
        sourceUrl: channel,
        thumbnail: global.thumb,
        previewType: 'PHOTO',
        renderLargerThumbnail: true
      }
    }
  }, {quoted: m});
}
break


case "rcti":
{
  let teksy = `📺SALURAN TELEVISI RCTI📺`
  let channel = `https://m.rctiplus.com/tv/rcti`
  let teksnya = `Ketuk Thumnile Bertuliskan Play Untuk Memulai!`;
  let titel = `⇆ㅤ ||◁ㅤ▶️ㅤ▷||ㅤ ↻`;
  let desk = `Click Here To Play!`;

  lenwy.sendMessage(m.chat, {
    text: `${teksy}\n\n${teksnya}`, 
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true,
        mediaType: 1,
        title: titel, 
        body: desk, 
        description: teksy,
        sourceUrl: channel,
        thumbnail: global.thumb,
        previewType: 'PHOTO',
        renderLargerThumbnail: true
      }
    }
  }, {quoted: m});
}
break

case "mnctv":
{
  let teksuu = `📺SALURAN TELEVISI MNCTV📺`
  let channel = `https://m.rctiplus.com/tv/mnctv`;
  let teksnya = `Ketuk Thumnile Bertuliskan Play Untuk Memulai!`;
  let titel = `⇆ㅤ ||◁ㅤ▶️ㅤ▷||ㅤ ↻`;
  let desk = `Click Here To Play!`;

  lenwy.sendMessage(m.chat, {
    text: `${teksuu}\n\n${teksnya}`, 
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true,
        mediaType: 1,
        title: titel, 
        body: desk, 
        description: teksuu,
        sourceUrl: channel,
        thumbnail: global.thumb,
        previewType: 'PHOTO',
        renderLargerThumbnail: true
      }
    }
  }, {quoted: m});
}
break

case "trans7": 
{
  let tekshb = `📺SALURAN TELEVISI TRANS 7📺`
  let channel = `https://www.transtv.co.id/live/trans7`
  let teksnya = `Ketuk Thumnile Bertuliskan Play Untuk Memulai!`;
  let titel = `⇆ㅤ ||◁ㅤ▶️ㅤ▷||ㅤ ↻`;
  let desk = `Click Here To Play!`;

  lenwy.sendMessage(m.chat, {
    text: `${tekshb}\n\n${teksnya}`, 
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true,
        mediaType: 1,
        title: titel, 
        body: desk, 
        description: tekshb,
        sourceUrl: channel,
        thumbnail: global.thumb,
        previewType: 'PHOTO',
        renderLargerThumbnail: true
      }
    }
  }, {quoted: m});
}
break

case "transtv":
{
  let teksbn = `📺SALURAN TELEVISI TRANS TV📺`
  let channel = `https://www.transtv.co.id/live`
  let teksnya = `Ketuk Thumnile Bertuliskan Play Untuk Memulai!`;
  let titel = `⇆ㅤ ||◁ㅤ▶️ㅤ▷||ㅤ ↻`;
  let desk = `Click Here To Play!`;

  lenwy.sendMessage(m.chat, {
    text: `${teksbn}\n\n${teksnya}`, // Tambahkan koma di sini
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true,
        mediaType: 1,
        title: titel, 
        body: desk, 
        description: teksbn,
        sourceUrl: channel,
        thumbnail: global.thumb,
        previewType: 'PHOTO',
        renderLargerThumbnail: true
      }
    }
  }, {quoted: m});
}
break

case "antv":
{
let tekshbb = `📺SALURAN TELEVISI ANTV📺`
let channel = `https://m.vidio.com/live/782-antv`
  let teksnya = `Ketuk Thumnile Bertuliskan Play Untuk Memulai!`;
  let titel = `⇆ㅤ ||◁ㅤ▶️ㅤ▷||ㅤ ↻`;
  let desk = `Click Here To Play!`;

  lenwy.sendMessage(m.chat, {
    text: `${tekshbb}\n\n${teksnya}`, 
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true,
        mediaType: 1,
        title: titel, 
        body: desk, 
        description: tekshbb,
        sourceUrl: channel,
        thumbnail: global.thumb,
        previewType: 'PHOTO',
        renderLargerThumbnail: true
      }
    }
  }, {quoted: m});
}
break

case "sctv":
{
let teksknn = `📺SALURAN TELEVISI SCTV📺`
let channel = `https://m.vidio.com/live/204`
  let teksnya = `Ketuk Thumnile Bertuliskan Play Untuk Memulai!`;
  let titel = `⇆ㅤ ||◁ㅤ▶️ㅤ▷||ㅤ ↻`;
  let desk = `Click Here To Play!`;

  lenwy.sendMessage(m.chat, {
    text: `${teksknn}\n\n${teksnya}`, 
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true,
        mediaType: 1,
        title: titel, 
        body: desk, 
        description: teksknn,
        sourceUrl: channel,
        thumbnail: global.thumb,
        previewType: 'PHOTO',
        renderLargerThumbnail: true
      }
    }
  }, {quoted: m});
}
break

case "nettv": case "net":
{
let teksim = `📺SALURAN TELEVISI NET TV📺`
let channel = `https://www.netmedia.co.id/live-streaming`
  let teksnya = `Ketuk Thumnile Bertuliskan Play Untuk Memulai!`;
  let titel = `⇆ㅤ ||◁ㅤ▶️ㅤ▷||ㅤ ↻`;
  let desk = `Click Here To Play!`;

  lenwy.sendMessage(m.chat, {
    text: `${teksim}\n\n${teksnya}`, 
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true,
        mediaType: 1,
        title: titel, 
        body: desk, 
        description: teksim,
        sourceUrl: channel,
        thumbnail: global.thumb,
        previewType: 'PHOTO',
        renderLargerThumbnail: true
      }
    }
  }, {quoted: m});
}
break

case "indosiar":
{

let tekskop = `📺SALURAN TELEVISI INDOSIAR📺`
let channel = `https://m.vidio.com/live/205`
  let teksnya = `Ketuk Thumnile Bertuliskan Play Untuk Memulai!`;
  let titel = `⇆ㅤ ||◁ㅤ▶️ㅤ▷||ㅤ ↻`;
  let desk = `Click Here To Play!`;

  lenwy.sendMessage(m.chat, {
    text: `${tekskop}\n\n${teksnya}`, 
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true,
        mediaType: 1,
        title: titel, 
        body: desk, 
        description: tekskop,
        sourceUrl: channel,
        thumbnail: global.thumb,
        previewType: 'PHOTO',
        renderLargerThumbnail: true
      }
    }
  }, {quoted: m});
}
break

case "globaltv": case "gtv":
{
  let teksz = `📺SALURAN TELEVISI GLOBAL TV📺`;
  let channel = `https://m.rctiplus.com/tv/globaltv`;
  let teksnya = `Ketuk Thumnile Bertuliskan Play Untuk Memulai!`;
  let titel = `⇆ㅤ ||◁ㅤ▶️ㅤ▷||ㅤ ↻`;
  let desk = `Click Here To Play!`;

  lenwy.sendMessage(m.chat, {
    text: `${teksz}\n\n${teksnya}`, 
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true,
        mediaType: 1,
        title: titel, 
        body: desk, 
        description: teksz,
        sourceUrl: channel,
        thumbnail: global.thumb,
        previewType: 'PHOTO',
        renderLargerThumbnail: true
      }
    }
  }, {quoted: m});
}
break

case "globaltv": case "gtv":
{
  let teksz = `📺SALURAN TELEVISI GLOBAL TV📺`;
  let channel = `https://m.rctiplus.com/tv/globaltv`;
  let teksnya = `Ketuk Thumnile Bertuliskan Play Untuk Memulai!`;
  let titel = `⇆ㅤ ||◁ㅤ▶️ㅤ▷||ㅤ ↻`;
  let desk = `Click Here To Play!`;

  lenwy.sendMessage(m.chat, {
    text: `${teksz}\n\n${teksnya}`, 
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true,
        mediaType: 1,
        title: titel, 
        body: desk, 
        description: teksz,
        sourceUrl: channel,
        thumbnail: global.thumb,
        previewType: 'PHOTO',
        renderLargerThumbnail: true
      }
    }
  }, {quoted: m});
}
break

case 'joinrpg': {
    const fs = require('fs');
    const dbPath = './database/userRpg.json';

    // Pastikan database ada
    if (!fs.existsSync(dbPath)) {
        fs.writeFileSync(dbPath, JSON.stringify([]));
    }

    function formatNomor(sender) {
        return sender.includes('@s.whatsapp.net') ? sender : sender + '@s.whatsapp.net';
    }

    function isRpgRegistered(sender) {
        let userRpg = JSON.parse(fs.readFileSync(dbPath));
        return userRpg.some(user => user.id === formatNomor(sender));
    }

    function addRpgUser(sender, pushname) {
        let userRpg = JSON.parse(fs.readFileSync(dbPath));

        // Cek apakah user sudah ada
        if (userRpg.some(user => user.id === formatNomor(sender))) return false;

        let newUser = {
            id: formatNomor(sender),  
            name: pushname || "No Name",
            attackdigi: 0,
            DarahOrang: 100,
            tp: 0,
            bits: 0,
            kenyang: 0,
            happy: 0,
            digivice: false,
            recoverplug: 0,
            apajob: false,
            job: "nganggur",
            hitcmd: 0,
        };

        userRpg.push(newUser);
        fs.writeFileSync(dbPath, JSON.stringify(userRpg, null, 2));
        return true;
    }

    // Format nomor pengirim
    let senderFormatted = formatNomor(m.sender);

    if (isRpgRegistered(senderFormatted)) {
        let userRpg = JSON.parse(fs.readFileSync(dbPath));
        let userData = userRpg.find(user => user.id === senderFormatted);

        if (!userData) return lenwyreply('Terjadi kesalahan, data tidak ditemukan.');

        return lenwyreply(`Kamu sudah Join RPG sebagai *${userData.name}*!`);
    }

    if (addRpgUser(senderFormatted, pushname)) {
        return lenwyreply(`Sukses Join RPG sebagai *${pushname || "No Name"}*!`);
    } else {
        return lenwyreply('Gagal Join RPG.');
    }
}
break;
case 'profile2': {
    const fs = require('fs');
    const dbPath = './database/userRpg.json';

    // Pastikan database ada
    if (!fs.existsSync(dbPath)) {
        fs.writeFileSync(dbPath, JSON.stringify([]));
    }

    function formatNomor(sender) {
        return sender.includes('@s.whatsapp.net') ? sender : sender + '@s.whatsapp.net';
    }

    function getRpgUser(sender) {
        let userRpg = JSON.parse(fs.readFileSync(dbPath));
        return userRpg.find(user => user.id === formatNomor(sender));
    }

    let senderFormatted = formatNomor(m.sender);
    let userData = getRpgUser(senderFormatted);

    if (!userData) {
        return lenwyreply('Kamu belum Join RPG. Ketik `.joinrpg` untuk memulai.');
    }

    // Kirim profil user
    return lenwyreply(`
    *Profile RPG* - ${userData.name}
    ──────────────────
    ❤️ Darah: ${userData.DarahOrang}
    ⚔️ Attack: ${userData.attackdigi}
    💰 Bits: ${userData.bits}
    🍖 Kenyang: ${userData.kenyang}
    😁 Happy: ${userData.happy}
    🧳 Job: ${userData.job}
    `);
}
break;
case 'kerja': {
    const fs = require('fs');
    const dbPath = './database/userRpg.json';

    // Pastikan database ada
    if (!fs.existsSync(dbPath)) {
        return lenwyreply('Database tidak ditemukan.');
    }

    // Fungsi untuk format nomor pengirim agar menjadi standar
    function formatNomor(sender) {
        return sender.includes('@s.whatsapp.net') ? sender : sender + '@s.whatsapp.net';
    }

    // Ambil data user dari database
    let userRpg = JSON.parse(fs.readFileSync(dbPath));
    let userData = userRpg.find(user => user.id === formatNomor(m.sender));

    if (!userData) {
        return lenwyreply('Pengguna tidak ditemukan dalam database.');
    }

    // Daftar pekerjaan
    const jobs = [
        { name: "Petani", bits: 20, kenyang: 10 },
        { name: "Pedagang", bits: 30, kenyang: 5 },
        { name: "Pekerja Kantoran", bits: 50, kenyang: 3 },
        { name: "Nelayan", bits: 40, kenyang: 8 }
    ];

    // Menampilkan daftar pekerjaan yang tersedia
    let jobList = jobs.map((job, index) => `${index + 1}. ${job.name} (Bits: ${job.bits}, Kenyang: ${job.kenyang})`).join('\n');

    return lenwyreply(`Pilih pekerjaan yang ingin kamu ambil:\n${jobList}\nKetik angka pekerjaan yang kamu pilih.`);
}
break;

case 'pilihkerja': {
    const fs = require('fs');
    const dbPath = './database/userRpg.json';

    // Pastikan database ada
    if (!fs.existsSync(dbPath)) {
        return lenwyreply('Database tidak ditemukan.');
    }

    // Fungsi untuk format nomor pengirim agar menjadi standar
    function formatNomor(sender) {
        return sender.includes('@s.whatsapp.net') ? sender : sender + '@s.whatsapp.net';
    }

    // Ambil data user dari database
    let userRpg = JSON.parse(fs.readFileSync(dbPath));
    let userData = userRpg.find(user => user.id === formatNomor(m.sender));

    if (!userData) {
        return lenwyreply('Pengguna tidak ditemukan dalam database.');
    }

    // Daftar pekerjaan
    const jobs = [
        { name: "Petani", bits: 20, kenyang: 10 },
        { name: "Pedagang", bits: 30, kenyang: 5 },
        { name: "Pekerja Kantoran", bits: 50, kenyang: 3 },
        { name: "Nelayan", bits: 40, kenyang: 8 }
    ];

    // Mengambil input pekerjaan
    let jobChoice = parseInt(text);
    if (isNaN(jobChoice) || jobChoice < 1 || jobChoice > jobs.length) {
        return lenwyreply('Pilihan pekerjaan tidak valid. Silakan pilih angka yang valid.');
    }

    let selectedJob = jobs[jobChoice - 1];

    // Update pekerjaan, bits, dan kenyang
    userData.job = selectedJob.name;
    userData.bits += selectedJob.bits;
    userData.kenyang += selectedJob.kenyang;

    // Menyimpan data kembali ke database
    fs.writeFileSync(dbPath, JSON.stringify(userRpg, null, 2));

    return lenwyreply(`Kamu berhasil mendapatkan pekerjaan sebagai *${selectedJob.name}*! Kamu mendapatkan *${selectedJob.bits} bits* dan *${selectedJob.kenyang} kenyang*.`);
}
break

case 'splay': {
    const { spotifyScraper } = require('./kiromi/kay/spotify.js');

    if (!args.length) {
        return lenwyreply("⚠️ Masukkan judul lagu yang ingin dicari.\nContoh: *!spotify bunga matahari*");
    }

    let query = args.join(" ");

    // Kirim reaksi proses ⏱️
    await lenwy.sendMessage(m.chat, {
        react: {
            text: "⏱️",
            key: m.key,
        }
    });

    spotifyScraper(query).then(async (result) => {
        if (result.error) {
            return lenwyreply("🚫 *Gagal mengambil data.* Pastikan judul lagu benar atau coba lagi nanti.");
        }

        let { title, artist, duration, popularity, preview, thumbnail, spotifyUrl, audioUrl } = result;

        // Kirim informasi lagu
        await lenwy.sendMessage(m.chat, {
            image: { url: thumbnail },
            caption: `🎵 *Judul:* ${title}\n👤 *Artist:* ${artist}\n⏱️ *Durasi:* ${duration}\n✨ *Rating:* ${popularity}\n📌 *Preview:* ${preview}\n🔗 *Spotify Link:* ${spotifyUrl}`,
        }, { quoted: m });

        // Kirim audio lagu
        await lenwy.sendMessage(m.chat, {
            audio: { url: audioUrl },
            mimetype: 'audio/mp4',
            fileName: `${title}.mp3`,
        }, { quoted: m });

        // Ubah reaksi ke ✅ setelah sukses
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key,
            }
        });

    }).catch(async () => {
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key,
            }
        });
        lenwyreply("🚫 *Terjadi kesalahan saat mencari lagu.*");
    });
}
break
case 'tt1': {
    const { tiktokScraper } = require('./kiromi/kay/tiktok.js');

    if (!args.length) {
        return lenwyreply("⚠️ Masukkan link TikTok yang ingin di-download.\nContoh: *!tiktok https://www.tiktok.com/@username/video/1234567890*");
    }

    let url = args[0];

    // Kirim reaksi proses ⏱️
    await lenwy.sendMessage(m.chat, {
        react: {
            text: "⏱️",
            key: m.key,
        }
    });

    tiktokScraper(url).then(async (result) => {
        if (result.error) {
            return lenwyreply("🚫 *Gagal mengambil data.* Pastikan link yang dimasukkan benar atau coba lagi nanti.");
        }

        let { username, userHandle, description, downloadLinks } = result;

        let caption = `👤 *Username:* ${username}\n🔗 *Handle:* ${userHandle}\n📄 *Deskripsi:* ${description}`;

        // Kirim video atau gambar dengan caption
        if (downloadLinks.video) {
            await lenwy.sendMessage(m.chat, {
                video: { url: downloadLinks.video },
                caption: caption,
            }, { quoted: m });
        } else if (downloadLinks.image) {
            await lenwy.sendMessage(m.chat, {
                image: { url: downloadLinks.image },
                caption: caption,
            }, { quoted: m });
        } else {
            return lenwyreply("🚫 *Gagal mendapatkan media.*");
        }

        // Kirim audio jika tersedia
        if (downloadLinks.audio) {
            await lenwy.sendMessage(m.chat, {
                audio: { url: downloadLinks.audio },
                mimetype: "audio/mp4",
                fileName: "tiktok_audio.mp3",
            }, { quoted: m });
        }

        // Ubah reaksi ke ✅ setelah sukses
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key,
            }
        });

    }).catch(async () => {
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key,
            }
        });
        lenwyreply("🚫 *Terjadi kesalahan saat mengambil video TikTok.*");
    });
}
break


case 'alkitab': {
const { alkitabSearch } = require('./kiromi/kay/alkitab');
    if (!args.length) {
        return lenwyreply("⚠️ Masukkan teks pencarian.\nContoh: *!alkitab kejadian*");
    }

    let query = args.join(" ");

    // Kirim reaksi ⏱️ saat proses berjalan
    await lenwy.sendMessage(m.chat, {
        react: {
            text: "⏱️",
            key: m.key,
        }
    });

    let result = await alkitabSearch(query);
    if (result.error) {
        return lenwyreply("🚫 *Gagal mengambil data dari Alkitab.me*");
    }

    if (result.length === 0) {
        return lenwyreply("❌ *Tidak ditemukan hasil untuk pencarian ini.*");
    }

    let foto = 'https://telegra.ph/file/a333442553b1bc336cc55.jpg';
    let judul = '*────────「 Alkitab 」 ────────*';
    let caption = result.map(v => `💌 ${v.title}\n📮 ${v.teks}`).join('\n┄┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┄\n');

    await lenwy.sendMessage(m.chat, {
        image: { url: foto },
        caption: `${judul}\n\n${caption}`
    });

    // Ubah reaksi ke ✅ setelah sukses
    await lenwy.sendMessage(m.chat, {
        react: {
            text: "✅",
            key: m.key,
        }
    });
}
break;
case 'alquran': {
    const { alquran } = require('./kiromi/kay/alquran');

    if (!(args[0] && args[1])) {
        return lenwyreply(`📖 *Gunakan format:*\n${command} <nomor surah> <nomor ayat>\n\nContoh:\n${command} 1 2`);
    }

    if (isNaN(args[0]) || isNaN(args[1])) {
        return lenwyreply(`⚠️ *Input harus berupa angka!*\nContoh:\n${command} 1 2`);
    }

    let surah = Number(args[0]);
    let ayat = Number(args[1]);

    await lenwy.sendMessage(m.chat, {
        react: { text: "⏱️", key: m.key }
    });

    let res = await alquran(surah, ayat);
    
    let caption = `
📖 *${res.surah}* (Surah ${surah} Ayat ${ayat})
  
${res.arab}
_${res.latin}_

${res.terjemahan}

🔍 *Tafsir:*\n${res.tafsir || "Tidak tersedia"}
    `.trim();

    await lenwy.sendMessage(m.chat, { text: caption }, { quoted: m });
    await lenwy.sendMessage(m.chat, { audio: { url: res.audio }, mimetype: 'audio/mp4' });

    await lenwy.sendMessage(m.chat, {
        react: { text: "✅", key: m.key }
    });
}
break;

case 'cosplay': {
    const { scrapeCosplay } = require('./kiromi/kay/cosplay.js');

    await lenwyreply('⏱️ Sedang mencari gambar cosplay, tunggu sebentar...');

    try {
        let imageUrl = await scrapeCosplay();
        await lenwy.sendFile(m.chat, imageUrl, '', '_Random Cosplay_', m);
    } catch (e) {
        lenwyreply(`⚠️ Error: ${e}`);
    }
}
break;
case 'storyanime': {
    const { scrapeStoryAnime } = require('./kiromi/kay/storyanime.js');

    await lenwy.sendMessage(m.chat, {
        react: {
            text: "⏱️",
            key: m.key,
        }
    });

    try {
        let videoUrl = await scrapeStoryAnime();
        await lenwy.sendMessage(m.chat, { video: { url: videoUrl }, caption: '_Random Story Anime_' }, { quoted: m });

        // Ganti reaksi ke 💦 setelah video terkirim
        await lenwy.sendMessage(m.chat, {
            react: {
                text: "💦",
                key: m.key,
            }
        });

    } catch (e) {
        await lenwyreply(`⚠️ Error: ${e.message}`);
    }
}
break;
case 'ytplay3': {
    const { scrapeYoutubeAudio } = require('./kiromi/kay/scrapeYoutubeAudio.js');

    if (!q) return lenwyreply('🔍 Masukkan judul lagu atau link YouTube!');

    try {
        let { title, url, filePath } = await scrapeYoutubeAudio(q);
        await lenwy.sendMessage(from, { audio: { url: filePath }, mimetype: 'audio/mp4' }, { quoted: m });
    } catch (err) {
        lenwyreply(`⚠️ ${err.message}`);
    }
}
break;
case 'anime3': {
    const { scrapeAnime } = require('./kiromi/kay/scrapeAnime.js');

    if (!q) return lenwyreply('🔍 Masukkan judul anime!');

    try {
        let { title, episodes, start_date, end_date, type, rated, score, members, synopsis, image_url, url } = await scrapeAnime(q);
        
        let animeInfo = `✨️ *Judul:* ${title}
🎆️ *Episodes:* ${episodes}
➡️ *Tanggal Mulai:* ${start_date}
🔚 *Tanggal Selesai:* ${end_date}
💬 *Tipe:* ${type}
💌️ *Rating:* ${rated}
❤️ *Skor:* ${score}
👥 *Members:* ${members}
💚️ *Sinopsis:* ${synopsis}
🌐️ *URL*: ${url}`;

        await lenwy.sendMessage(from, { image: { url: image_url }, caption: animeInfo }, { quoted: m });
    } catch (err) {
        lenwyreply(`⚠️ ${err.message}`);
    }
}
break;

case 'play4': {
    if (!text) return lenwyreply('⚠️ Masukkan judul atau link video YouTube.');

    await lenwy.sendMessage(m.chat, {
        react: {
            text: "🔥",
            key: m.key,
        }
    });

    try {
        const axios = require("axios");
        let { data } = await axios.get(`https://ochinpo-helper.hf.space/yt?query=${encodeURIComponent(text)}`);

        if (!data.success || !data.result) return lenwyreply(`❌ Video tidak ditemukan atau terjadi kesalahan.`);

        let { title, author, views, duration, thumbnail, download } = data.result;

        let caption = `🎵 *YOUTUBE AUDIO*\n\n📌 *Judul:* ${title}\n👤 *Channel:* ${author.name}\n👀 *Views:* ${views.toLocaleString()}x\n⏱️ *Durasi:* ${duration.timestamp}\n\n🔽 *Sedang mengirim audio...*`;

        // Kirim thumbnail + info dulu
        await lenwy.sendMessage(m.chat, { image: { url: thumbnail }, caption }, { quoted: m });

        // Kirim audio
        await lenwy.sendMessage(m.chat, { audio: { url: download.audio }, mimetype: 'audio/mp4' }, { quoted: m });

        await lenwy.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key,
            }
        });

        console.log('Audio berhasil dikirim.');
    } catch (error) {
        console.error('Error fetching YouTube data:', error.message);
        lenwyreply('❌ Terjadi kesalahan saat mengambil data. Coba lagi nanti.');
    }
}
break

case 'tourl1': {
    const { catboxUpload, pomfUpload, fileIoUpload } = require('./kiromi/kay/fileupload.js');

    if (!m.quoted || !(m.quoted.msg || m.quoted.mimetype)) return lenwyreply("⚠️ Balas file yang ingin di-upload!");

    let fileType = m.quoted.mimetype;
    let fileName = `./temp/${new Date().getTime()}.${fileType.split('/')[1]}`;
    let filePath = await lenwy.downloadAndSaveMediaMessage(m.quoted, fileName);

    if (!fs.existsSync(filePath)) {
        return lenwyreply("⚠️ Gagal menyimpan file, coba lagi!");
    }

    await lenwy.sendMessage(m.chat, { react: { text: "⏱️", key: m.key } });

    try {
        let catbox = await catboxUpload(filePath);
        let pomf = await pomfUpload(filePath);
        let fileIo = await fileIoUpload(filePath);

        let result = `📤 *File Upload Result*\n\n🔹 *Catbox:* ${catbox}\n🔹 *Pomf:* ${pomf}\n🔹 *File.io:* ${fileIo}`;
        
        await lenwy.sendMessage(m.chat, { text: result }, { quoted: m });

        await lenwy.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
    } catch (err) {
        lenwyreply(`⚠️ ${err.message}`);
    } finally {
        if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    }
}
break

case 'delsesi': 
case 'clearsession': {
    fs.readdir("./session", async function (err, files) {
        if (err) {
            console.log('Unable to scan directory: ' + err);
            return lenwyreply('Unable to scan directory: ' + err);
        }
        let filteredArray = files.filter(item => 
            item.startsWith("pre-key") || 
            item.startsWith("sender-key") || 
            item.startsWith("session-") || 
            item.startsWith("app-state")
        );

        console.log(filteredArray.length);
        let teks = `📂 *Terdeteksi ${filteredArray.length} file dalam folder session!*\n\n`;
        if (filteredArray.length === 0) return lenwyreply(teks);

        filteredArray.forEach((e, i) => {
            teks += `*${i + 1}.* ${e}\n`;
        });

        lenwyreply(teks);
        await sleep(2000);
        lenwyreply("🗑️ *Menghapus semua file di folder session...*");

        await filteredArray.forEach(file => {
            fs.unlinkSync(`./session/${file}`);
        });

        await sleep(2000);
        lenwyreply("✅ *Berhasil menghapus semua file session!*");
    });
}
break;
case 'hade':
case 'hd2':
case 'jernih2': {
    if (!m.quoted) return lenwyreply(`*[ ⚠️ ] Reply ke gambar yang ingin diperjelas.*`);

    let mime = (m.quoted.msg || m.quoted).mimetype || '';
    if (!mime.startsWith('image/')) return lenwyreply(`*[ ⚠️ ] Reply ke gambar yang ingin diperjelas.*`);

    try {
        // Import scraper
        const { enhanceImage } = require('./kiromi/kay/hade.js');

        // Download gambar
        let media = await m.quoted.download();
        console.log('Media downloaded successfully.');

        // Proses gambar pakai scraper
        let enhancedBuffer = await enhanceImage(media);
        if (!enhancedBuffer) return lenwyreply('Gagal memperjelas gambar.');

        // Kirim hasilnya pakai lenwy.sendMessage()
        await lenwy.sendMessage(m.chat, { image: enhancedBuffer, caption: 'Ini Foto HD nya kak' }, { quoted: m });
        console.log('Enhanced image sent to user.');
    } catch (error) {
        console.error('Error processing image:', error.message);
        lenwyreply('Terjadi kesalahan saat memproses gambar.');
    }
}
break

case 'apkdl': {
    if (!text) return lenwyreply('Mohon masukkan ID APK yang ingin diunduh.');

    lenwyreply('Sedang mencari APK... ⚡🔍');

    try {
        // Mengimpor fungsi dari folder kiromi/kay/
        const { apkDownloader } = require('./kiromi/kay/apkDownloader.js'); // pastikan .js ada
        
        // Panggil fungsi apkDownloader dengan ID APK yang diberikan
        const apkData = await apkDownloader(text);

        if (apkData.error) return lenwyreply(apkData.error);

        let teks = `*📱 APK Berhasil Ditemukan!*\n\n`;
        teks += `*📝 Nama APK :* ${apkData.name}\n`;
        teks += `*📅 Terakhir Update :* ${apkData.lastUpdate}\n`;
        teks += `*📦 Ukuran APK :* ${apkData.size}\n`;
        teks += `*🔗 Download Link :* [Klik Disini](${apkData.downloadLink})\n`;

        // Kirim informasi APK ke chat
        await lenwyreply(teks);

    } catch (err) {
        console.error(err);
        lenwyreply('Terjadi kesalahan saat mengambil data APK.');
    }
}
break;
default:
if (isCmd && budy.toLowerCase() != undefined) {
if (m.isBaileys) return
if (from.endsWith('broadcast')) return
let msgs = global.db.data.database
if (!(budy.toLowerCase() in msgs)) return
lenwy.copyNForward(from, msgs[budy.toLowerCase()], true)}}
} catch (err) {
console.log(util.format(err))
let e = String(err)
lenwy.sendMessage('6289673462138' + "@s.whatsapp.net", { text: `*Ada Yang Error Nih! Di Bagian :* ` + util.format(e), 
contextInfo:{
forwardingScore: 9999999, 
isForwarded: true
}})
}}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.green(`Update : ${__filename}`))
delete require.cache[file]
require(file)
})
